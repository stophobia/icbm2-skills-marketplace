# markdown_to_tistory_html.py 변환 중 한국어 분해 버그 (68차)

## 날짜
2026-05-21

## 버그 설명

`markdown_to_tistory_html.py` 변환 중 특정 한국어 단어가 의도치 않게 분해·손상되는 버그가 발견됨. CJK cleaning 루프가 0회차로 통과해도 발생하므로 별도 검증이 필요함.

## 발견 사례

### 사례 1 — 저자명 손상
- **원본:** `BBC의 티저 Thomas Germain이 보낸`
- **변환 후:** `BBC의 티저 거ermin이 보낸`
- **위치:** 핫도그 먹기 세계 챔피언 실험段落
- **수정:** HTML에서 직접 `patch`로 수동 복원

### 사례 2 — 종결어미 손상
- **원본:** `이 방식에서 문제가 생긴다.`
- **변환 후:** `이 방식에서 문제가마루.`
- **위치:** AI 조작 원리 설명段落
- **수정:** HTML에서 직접 `patch`로 수동 복원

## 원인 추정

`markdown_to_tistory_html.py`의 문자 처리 로직이 UTF-8 바이트 단위로 동작하면서 한국어 음절(2-3바이트)을 분해하는 것으로 추정. Python `str.replace()`가 UTF-8 바이트 열을 문자열로 오해할 가능성.

## 필수 대응 절차

`markdown_to_tistory_html.py` 변환 직후 반드시 실행:

```python
korean_corruption_patterns = {
    # 68차 (2026-05-21): markdown_to_tistory_html.py 변환 중 분해
    '거ermin': 'Thomas Germain',
    '이 방식에서 문제가마루': '이 방식에서 문제가 생긴다',
    # 이전 세션 누적
    'isional': ' 문제',
    'rimonial': '',
    '各단대이': '각 팀이',
}
for bad, good in korean_corruption_patterns.items():
    if bad in html:
        print(f"⚠️ Korean text corruption: {bad} → {good}")
        html = html.replace(bad, good)
```

## 특징

- **CJK regex 탐지 불가:** CJK [\u4e00-\u9fff] 범위 밖에서 발생하므로 CJK cleaning 루프가 0회차로 통과해도 실제 텍스트가 손상됨
- **완전한 한국어 문자 손상:** 완성된 어절(저자명, 종결어미)이 의도치 않게 분해됨
- **고유명사 위험:** 저자명, 제품명, 고유명사가 가장 자주 손상됨

## 발견된 손상 패턴 누적

| 세션 | 손상 텍스트 | 원본 | 원인 |
|------|------------|------|------|
| 68차 | `거ermin` | `Thomas Germain` | 변환 중 이름 분해 |
| 68차 | `이 방식에서 문제가마루` | `이 방식에서 문제가 생긴다` | 종결어미 분해 |
| 62차 | `各단대이` | `각 팀이` | CJK dict 치환 corruption |
| 65차 | `AI가주류로` | `AI가 주류로` | HTML 변환 중 단어 합침 |
| 65차 | `마진，要求` | `마진, 요구` | CJK comma 혼입 |
| 58차 | `소사나혁명` | `작은 혁명이` | 변환 중 한국어→CJK 변질 |
| 58차 | `起码` | `최소한` | Chinese 단어 혼입 |