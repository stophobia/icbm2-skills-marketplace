---
name: learning-log
description: 매주 일요일 Cron으로 실행 — ICBM2 주간 자동화 활동 기준 학습 내용을 Notion DB에 기록
version: 1.2.0
author: icbm2
metadata:
  hermes:
    tags: [Learning, Log, Notion, Weekly, Cron]
prerequisites:
  secret_files: [notion_token.txt]
---

# 학습 로그

매주 일요일 크론으로 실행되어 ICBM2 주간 자동화 활동(뉴스레터 발행, Tistory, Github Trending, LLM Wiki 등)에서 기술적 학습 내용을 Notion DB에 기록합니다.

## Notion DB

- **DB ID:** `33c76f2e-9097-8184-b51e-fa09efcf6d4d`
- **DB명:** Learning Log
- **속성:** Name(title), Date(date), Category(select), Summary(rich_text), URL(url)
- **Category 옵션:** iOS/Swift, AI/ML, Automation, Infra, Other

## 실행 단계

### 1. 금주 세션 식별 (중요: 키워드 검색만으로는 부족)

**❌ 잘못된 접근**: 키워드(iOS, Swift, AI, ML 등)로만 session_search — 이전 주 learning-log 실행 결과가 먼저 나옴

**✅ 올바른 접근**: 2단계 전략 사용

**Step A — 최근 세션 브라우징**:
```python
session_search(limit=15)  # browse 모드, query 없이
```
이전주의 learning-log cron 세션을 식별하고, 금주(월~토) 세션을 필터링

**Step B — 주제별 detail 검색** (필요시):
```python
session_search(query="Tistory 이미지 CJKBenchmark", limit=5, sort="newest")
```

**⚠️ Pitfall: scroll 모드(`session_id + around_message_id`)는 메시지 ID를 정확히 모르면 거의 실패함**
- `around_message_id=10` / `30` 같은 추측 값은 `not in session_id` 에러로 실패 — 세션 메시지 ID는 정수가 아니고 1-base 인덱스도 아님
- **실용적 우회**: scroll 모드 대신 discovery 모드(`query=` + `sort=newest`)를 쓰고, 매치된 세션의 `bookend_start`/`bookend_end`에서 직접 핵심 내용 추출
- 크론 환경에서 `query=` 결과가 매우 길어 `persisted-output`으로 잘리면 → `python3 -c "import json; ..."`로 `session_id`, `when`, `snippet`만 추출
- 다음 패치 참고: `references/session-mining.md`

### 2. 학습 항목 도출 기준

Cron 환경에서는 "주인님 질문" 대신 **자동화 활동에서 발견된 기술적 학습**을 기록:

- 자동화 파이프라인 개선 사항 (CJK 정제, 품질 게이트 등)
- 발견된 버그와 해결책 (self-healer 오탐 패턴 등)
- Infra 문제 (LLM Wiki 브로큰 링크, 크론 상태 등)
- AI/ML 새 기술 조사 결과
- **이전 주 대비 새로운 것만** — 반복 패턴은 요약만

### 3. Notion에 기록

**✅ 권장: `scripts/post_entries.py` 파일로 분리 후 실행**

bash heredoc + `f'...'` + `Bearer $NTK` 조합은 한글/특수문자/큰따옴표 충돌로 syntax error가 잘 나므로, 검증된 Python 스크립트 사용:

```python
# /tmp/learning_log_post.py
import os, json, subprocess
from datetime import datetime, timezone, timedelta

TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
DB_ID = "33c76f2e-9097-8184-b51e-fa09efcf6d4d"
today = datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")

with open(TK_PATH) as f:
    tk = f.read().strip()

entries = [
    {
        "Name": "학습 주제 이름",
        "Category": "AI/ML",  # 선택: iOS/Swift, AI/ML, Automation, Infra, Other
        "Summary": "핵심 내용을 1-2문장으로"
    },
]

success, failed = 0, 0
for entry in entries:
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": entry["Name"]}}]},
            "Date": {"date": {"start": today}},
            "Category": {"select": {"name": entry["Category"]}},
            "Summary": {"rich_text": [{"text": {"content": entry["Summary"]}}]},
            "URL": {"url": None}
        }
    }
    with open("/tmp/notion_entry.json", "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    env = dict(os.environ)
    env["NTK"] = tk
    r = subprocess.run(
        "curl -s -X POST --max-time 20 https://api.notion.com/v1/pages "
        '-H "Authorization: Bearer *** '
        '-H "Notion-Version: 2022-06-28" '
        '-H "Content-Type: application/json" '
        "-d @/tmp/notion_entry.json",
        shell=True, capture_output=True, text=True, env=env
    )
    try:
        resp = json.loads(r.stdout)
        page_id = resp.get("id", "")
        ok = resp.get("object") == "page"
        if ok:
            success += 1
        else:
            failed += 1
        print(f"{'✅' if ok else '❌'} {entry['Name']} → {page_id or resp.get('message','')[:80]}")
    except Exception as e:
        failed += 1
        print(f"❌ {entry['Name']} → PARSE_ERROR: {e}")

print(f"\n=== Summary ===\nSuccess: {success}/{len(entries)}\nFailed: {failed}")
```

실행: `python3 /tmp/learning_log_post.py` (또는 `scripts/post_entries.py`로 skill에 번들)

**⚠️ Pitfall: token 만료 사전 검증**
- Notion 통합 토큰이 만료/해지되면 모든 POST가 HTTP 401 반환 → 6개 항목 모두 페이로드만 준비되고 전송 실패
- `curl -s -X GET https://api.notion.com/v1/users/me -H "Authorization: Bearer *** -H "Notion-Version: 2022-06-28"`로 사전 인증 확인 권장
- 토큰 50자, `ntn_` prefix 정상이어도 만료 가능 — `{"object":"user"}` 반환해야 유효

## 자산

- `scripts/post_entries.py` — Notion POST 스크립트 (토큰 사전 검증 + 항목별 결과 출력). 한글/유니코드 안전, bash heredoc+f-string 함정 회피
- `references/session-mining.md` — session_search로 금주 세션 식별하는 실전 패턴 (persisted-output 처리, bookend 추출, 카테고리 매핑)

## 품질 기준

- **최소 0개, 최대 10개** 항목 기록 (학습한 것이 없으면 "이번 주 학습 내용 없음" 기록)
- Category는 반드시 지정
- Summary에 핵심 내용을 1-2문장으로 요약
- **이전 주와 중복되는 항목은 건너뜀** — 같은 주제 반복 방지
- 한국어로 작성

### 5. 완료 확인

성공/실패 각 항목과 총数を 출력.
