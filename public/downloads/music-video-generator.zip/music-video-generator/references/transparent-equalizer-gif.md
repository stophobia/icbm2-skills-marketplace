# 투명 배경 이퀄라이저 GIF 오버레이 기법

## 문제
이퀄라이저 애니메이션을 영상에 오버레이할 때, 이퀄라이저 바 주변의 검은 배경이 영상을 가림.

## 해결책
PNG 시퀀스 → GIF (투명 배경) → FFmpeg overlay

### ⚠️ overlay 위치: 반드시 우측 하단 고정 (2026-05-25)
**家主님 피드백: "이퀄라이저가 중앙에 위치해서 애니메이션이 안 보임"**
→ 절대 고정 좌표(예: `overlay=920:600`) 사용 금지. **동적 좌표**로 우측 하단 배치.

**크기: 480x160** (프로페셔널 디자인)

### 1단계: Python으로 RGBA 프레임 생성 (PIL)

```python
from PIL import Image, ImageDraw
import math, os, random

w, h = 480, 160  # 프로페셔널 크기 (우측 하단용)
num_bars = 24
bar_w, bar_spacing, margin = 14, 6, 12

# 7색 그라데이션 팔레트 (暖色→寒色)
palette = [
    (255,80,100),(255,140,60),(255,200,50),
    (100,255,150),(60,200,255),(100,120,255),(180,80,255)
]

random.seed(None)  # 매번 다른 시드 (자연스러움)
bass_h   = [random.randint(50,100) for _ in range(num_bars//3)]
mid_h    = [random.randint(40,80)  for _ in range(num_bars//3)]
treble_h = [random.randint(25,60) for _ in range(num_bars//3+1)]
base_heights = bass_h + mid_h + treble_h

frames = []
for frame in range(30):
    img = Image.new('RGBA', (w, h), (0, 0, 0, 0))  # 완전 투명
    draw = ImageDraw.Draw(img)
    t = frame / 30

    for i in range(num_bars):
        # 3개 주파수 조합 (리얼 이퀄라이저 느낌)
        w1 = math.sin(2*math.pi*2.5*t + i*0.35) * 0.45  # 低音 медленнее
        w2 = math.sin(2*math.pi*4.0*t + i*0.55) * 0.35  # 中音
        w3 = math.sin(2*math.pi*6.5*t + i*0.80) * 0.20  # 高音 빠름
        cw = 1.0 - abs(i - num_bars/2) / (num_bars/2) * 0.4  # 중앙 바 더 흔들림
        wave = max(0.15, min(1.0, (w1+w2+w3)*cw + 0.5))

        bar_h = max(8, min(int(base_heights[i]*wave), h - margin*2 - 4))
        x = margin + i * (bar_w + bar_spacing)
        y_top = (h - bar_h) // 2
        y_bot = y_top + bar_h

        ci = int((i / num_bars) * (len(palette)-1))
        c = palette[min(ci, len(palette)-1)]

        # 메인 바
        draw.rounded_rectangle([x, y_top, x+bar_w, y_bot], radius=4, fill=c+(220,))
        # 반사 하이라이트 (상단)
        hh = max(2, bar_h//4)
        draw.rounded_rectangle([x+1, y_top, x+bar_w-1, y_top+hh], radius=2,
                               fill=tuple(min(255,v+60) for v in c)+(180,))
        # mirror 바 (하단)
        mh = max(3, bar_h//5)
        draw.rounded_rectangle([x, y_bot-mh, x+bar_w, y_bot], radius=2,
                               fill=tuple(max(0,v-40) for v in c)+(140,))

    frames.append(img)

frames[0].save(
    '/Users/hjshin/.hermes/music_videos/wave_animation.gif',
    save_all=True, append_images=frames[1:],
    duration=int(1000/30), loop=0, optimize=False
)
for f in frames: f.close()
```

**핵심:**
- `Image.new('RGBA', ..., (0,0,0,0))` → 완전 투명 배경
- `color + (220,)` → alpha=220 (거의 불투명)
- `rounded_rectangle` → 모서리 둥근 바
- `optimize=False` → 최적화 비활성화 (투명도 손실 방지)
- **3개 주파수 조합** → 자연스러운 리듬
- **반사 하이라이트 + mirror 바** → 입체적 효과
- **매번 다른 random.seed** → 자연스러움

### 2단계: FFmpeg overlay — 우측 하단 동적 좌표

```bash
# ⚠️ 절대 금지: overlay=920:600 (고정 좌표 → 중앙에 위치)
# ✅ 반드시 동적 좌표: overlay=W-500:H-180

ffmpeg -y \
  -i main_video.mp4 \
  -stream_loop -1 -i wave_animation.gif \
  -filter_complex "[0:v][1:v] overlay=W-500:H-180:shortest=1" \
  -c:v libx264 -preset ultrafast -crf 23 \
  -c:a copy \
  final_with_wave.mp4
```

**핵심 옵션:**
- `W-500`: 영상 너비 - 500 (우측에서 500px 여백)
- `H-180`: 영상 높이 - 180 (하단에서 180px 여백)
- `-stream_loop -1`: GIF를 영상 길이만큼 무한 반복
- `shortest=1`: 메인 영상이 끝나면 전체 종료

## 위치 가이드 (동적 좌표)

| 영상 해상도 | overlay 좌표 | 설명 |
|-----------|-------------|------|
| 1920x1080 | `W-500:H-180` | 우측 하단 (500px 우측, 180px 하단) |
| 1280x720 | `W-500:H-180` | 동일하게 동작 |
| 1080x1920 (Shorts) | `W-480:H-180` | Shorts도 동일한 상대 위치 |

**⚠️ 절대 고정 좌표 사용 금지:** `overlay=920:600`은 1280x720에서만 우측 하단. 1920x1080에서는 완전히 잘못된 위치(중앙~우측)에 배치됨.