---
name: dev-news-to-wiki
description: Notion Dev News Archive 뉴스 클리핑을 분석하여 LLM Wiki에 자동 등록
---

# Dev News → Wiki Sync

## Overview
Notion Dev News Archive의 뉴스 클리핑 DB를 매일 분석하여 LLM Wiki에 등록하는 자동화.

## Notion Page
- URL: `https://www.notion.so/Dev-<DB_ID>` (본인 DB URL로 설정)
- Integration: ICBM2 Notion Integration (연결 완료)
- DB 이름: 뉴스 클리핑
- DB 속성: 이름, 분류(뉴스/인사이트/TIP/오픈소스/iOS), 발견일, 부연설명, 원문 URL, 즐겨찾기

## Schedule
- 크론: 평일(월~금) 20:00
- 스크립트: `~/.hermes/scripts/notion_news_to_wiki.py`

## Workflow (정확한 절차)

### 1단계: 스크립트 실행
```bash
python3 ~/.hermes/scripts/notion_news_to_wiki.py
```
출력의 지시사항을 반드시 읽고 따를 것.

### 2단계: Wiki 방향 확인 ( Orientation)
Wiki 조작 전 반드시 실행:
1. `SCHEMA.md` 읽기 — conventions, tag taxonomy, page thresholds 파악
2. `index.md` 읽기 — 현재 페이지 목록과 중복 체크
3. `log.md` 마지막 20~30줄 — 최근 활동 확인

### 3단계: Raw Source 파일 작성
각 뉴스 항목의 핵심 내용을 요약하여 `raw/articles/`에 저장.
파일명: `{주제-2026}.md`, 형식: 타이틀, URL, Date, Category, 요약

**Content fetch 전략:**
- **hada.io/GeekNews TIP급**: 제목+URL로 핵심 파악 가능 → fetch 불필요, 제목+카테고리+간단 요약만 raw source로 저장
- **AI Times 기술 기사** (깊은 분석, 벤치마크 수치 포함): `mcp_ddg_search_fetch_content`로 본문 fetch 후 핵심 정리
- **유튜브 인사이트**: 제목+카테고리로 판단 → 로컬 GPU 비교, 페르소나 등 기술적 깊이 있는 것은 fetch, 단순 TIP은 skip
- 판단 기준: 항목명에 벤치마크/비교/프레임워크/아키텍처 관련어가 있으면 → fetch

**Content Fetch Fallback Strategy (YouTube / Minimal Content):**
- 유튜브만 제공되는 경우: `mcp_ddg_search_search`로 실제 GitHub 또는 프로젝트 페이지를 먼저 검색. 본문 fetch는 GitHub/프로젝트 페이지에서 수행
  - 예: "OpenSwarm" YouTube → DuckDuckG 검색 → `github.com/openswarm-ai/openswarm` repo 요약으로 Wiki 정보 충당
- GeekNews (hada.io) 요약만 있는 경우: 제목+URL로 판단, deep fetch 불필요
- 403 Forbidden 우회: `mcp_ddg_search_search`로 동일 기사를 dev.to, medium, pasqualepillitteri.it 등 대체 출처에서 검색

**이미지 기반 콘텐츠 (유머/게임 등):**
- 루리웹 게임 매출 순위, 밈/유머 게시글 등 → **즉시 skip** (주인님 핵심 관심사 AI/ML/iOS/개발자 도구 범위 밖)
- 판단이困难的 경우: "이것이 에이전트, 코딩, iOS, AI 모델, 개발 도구와 직접 관련 있는가?"로 테스트

### 4단계: 분류
Notion DB에 이미 주인님 관심사만 스크랩되어 있으므로, **모든 항목을 Wiki에 등록**합니다.

**분류 규칙:**
- products, models, frameworks, companies, tools → **entities/**
- techniques, formats, theories, paradigms → **concepts/**

### 5단계: Wiki 페이지 작성
Batch로 처리하면 효율적. **모든 write_file을 한 번에 호출한 뒤 한 번에 patch하는 순서**가 context 절약에 유리.

**페이지 타입 결정:**
- entity: products, models, frameworks, companies, tools
- **concept**: techniques, formats, theories, paradigms, tools (MCP 서버, CLI 등)
- **comparison**: 두 가지 이상의 접근법/기술/도구를 비교하는 기사 (예: RAG vs LLM Wiki vs Agent Memory) → `comparisons/` 디렉토리에 저장

**Wiki page 파일 처리 순서:**
1. **신규 페이지**: 모든 Wiki page 파일을 먼저 `write_file` (create)
2. **기존 페이지 업데이트**: 반드시 `read_file`으로 현재 내용을 확인한 뒤 `patch`. 기존 content를 모르면 잘못된 patch가 발생함
3. **Raw source 파일**: 모든 raw source 파일을 마지막에 `write_file`
4. **index.md**: `patch`로 alphabetical 삽입 + Total pages + Last updated 갱신
5. **log.md**: `## [YYYY-MM-DD] ingest | ...` 형식으로 Append

> ⚠️ **index.md patch 주의사항 ( Critica)**: `patch`는 old_string이 파일에서 **2곳 이상** 매치되면 2곳 모두 수정한다. 이 session에서 my patch가 원본 section과 기존 duplicate section 양쪽에 매치되어 중복이 2배로 늘어났다. 이렇게 되면:
> 1. **미리 `read_file`으로 전체 파일을 읽고** 매치 범위를 확인한다
> 2. **매치되는 곳이 2곳 이상이면** `patch`를 쓰지 말고 파일 전체를 다시 읽고 **unique한 context** (예: surrounding 3줄 이상)를 포함시켜서 매치를 제한한다
> 3. 그래도 안 되면 파일을 `read_file`으로 전체 읽은 후 `write_file`로 통째書き換え
> 4. **수정 후** `read_file`으로 중복이 사라졌는지 반드시 확인한다
>
> **index.md duplicate 복구 방법**: duplicate section을 인식했으면, duplicate 영역의 첫 3줄 정도를 unique context로 사용해서 `patch`하면 정확히 한 곳만 고친다. 그래도 안 되면 `read_file` 후 `write_file`로 통째 수정.

## Pitfalls

### patch tool 매치 2곳 이상 문제
`patch` action의 `old_string`이 파일에서 여러 곳에 매치되면 **모든 매치 지점이 한 번에 수정**된다. 이로 인해:
- 중복 content가 생김 (index.md에서 같은 섹션이 2배로 복제)
- 의도하지 않은 section이 사라짐

**防止:**
- 매치 전에 `read_file`으로 파일 전체를 읽고 old_string의 고유성 확인
- 최소 3줄 이상의 surrounding context를 old_string에 포함
- 2곳 이상 매치되면 `write_file`로 전체 재작성

**복구:**
- 중복이 생겼으면, `read_file`으로 전체 파일 확인
- unique한 3줄 context로 중복 영역 중 하나를 정확히 지정하여 patch로 제거
- 그래도 안 되면 `write_file`로 통째書き換え

> Note: Raw source 저장은 Wiki page 생성 후에 해도 무방. `/tmp/notion_news_digest.json`에 원본 데이터가 이미 존재하므로 raw source는 "참조용"이며 Wiki page가 주요 산출물이다.

- frontmatter 필수: title, created, updated, type, tags (taxonomy만), sources
- 최소 2개 이상의 outbound `[[wikilinks]]` 포함
- 기존 페이지 있으면 새 정보만 추가, updated 날짜 갱신
- 같은 entity/concept에 여러 뉴스가 있으면 **한 페이지에 병합** (중복 방지)

### 6단계: Navigation 갱신
- `index.md`: 새 페이지 추가 (alphabetical), Total pages + 헤더 갱신. **중복 항목 체크**: 같은 wikilink가 두 번 등록된 경우 (예: `ios-trends-2026` 중복) 발견 시 제거
- `log.md`: `## [YYYY-MM-DD] ingest | Notion Dev News → LLM Wiki 동기화` 형식으로 Append

## 주인님 관심사 프로필
Notion DB에 이미 관심사만 스크랩되어 있으므로, 모든 항목을 Wiki에 등록합니다.

**실제 적용된 건너뜀 기준 (2026-05-04 확인):**
- 삼성 AI 안경, 중소IT기업 인수/투자, 공공기관 hwp 금지 등 — **하드웨어/산업 트렌드/규제** 전반 → 관심사(AI/ML, iOS, 개발자 도구) 범위 밖
- **게임 산업 데이터** (루리웹 게임 매출 순위 등) → 즉시 skip
- 단순 산업 뉴스 (시장 확장, 단순 파트너십) — 새로운 개념/엔티티 없음
- 단일 TIP 급 item — 핵심 관심사에 부합하지 않으면 skip
- 접근 불가 URL (403 등) → 403 우회 전략 시도 후 실패 시 skip
- **유튜브만 제공**: Claude Code 공식插件 등 → ai-agents-trends-2026.md 관련 항목으로 통합
- **주인님 프로젝트 직접 연관 항목은 entities에 등록** (예: Hermes 데스크톱 앱 → [[hermes-agent]]로 생성)
