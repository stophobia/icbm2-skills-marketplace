# 2026-06-04 Sync Session Lessons

Session-specific detail captured for the dev-news-to-wiki skill. See SKILL.md for active rules.

## What Got Processed

| Notion Item | Category | Decision | Page Created/Updated |
|-------------|----------|----------|----------------------|
| Codex, 역할별 플러그인·Sites·주석 | 뉴스 | CREATE | `entities/codex.md` |
| MAI-Code-1-Flash | 뉴스 | CREATE | `entities/mai-code-1-flash.md` |
| 클로드 코드 Dynamic Workflow 비교 | TIP | SKIP (콘텐츠 미확보) | — |
| 랄프모드 딥인터뷰 | TIP | SKIP (콘텐츠 미확보) | — |

4 existing pages updated: `ai-agents-trends-2026.md`, `coding-agent-benchmark.md`, `github-copilot.md`, `openai.md`.

## YouTube Skip Decision — Documented Rationale

Two YouTube items arrived. Both have interesting-sounding titles but **no extractable body text**:

1. **"클로드 코드 Dynamic Workflow 기능 비교 총정리!"** (`youtube.com/watch?v=9fx2_1aTzq8`)
   - Title suggests feature comparison content
   - `mcp_ddg_search_fetch_content` on the URL returns YouTube watch page (no transcript)
   - `mcp_ddg_search_search` for "Claude Code Dynamic Workflow" → results not rich enough
   - **Verdict**: skip with "콘텐츠 미확보" reason; if another article references Dynamic Workflow with body text, revisit

2. **"랄프모드, 딥인터뷰 기능 아직 안들어본사람"** (`youtube.com/watch?v=gj_5zjpkguM`)
   - "Ralph mode" + "Deep Interview" — both look like Anthropic Claude Code features
   - Same YouTube transcript extraction problem
   - **Verdict**: skip; flagged as seed candidates for `concepts/claude-code-workflow-patterns.md` if pattern recurs

**Pattern**: Titles alone are insufficient for Wiki registration. Even when the keyword/feature sounds important, **the body content is the artifact that gets stored** — without it, the page would be all speculation.

## Domain Pattern Recognition — What Made This Session Different

The 2 entity creates (Codex, MAI-Code-1-Flash) are individually significant, but **the cross-cutting pattern** is what matters for the Wiki's compounding value:

### Pattern 1: Production Harness-Aligned Training
- MAI-Code-1-Flash was trained directly inside the GitHub Copilot harness, not on benchmark-only data
- This is a **new training paradigm** that complements the existing "harness engineering" concept
- Captured in `coding-agent-benchmark.md` (new section) + cross-linked from new entity page
- Future signal: when other vendors (Anthropic, Google) release "harness-trained" models, the concept page is ready

### Pattern 2: Coding Agent → Business Workflow Platform
- Codex Plugins/Sites/Annotations = OpenAI turning a coding agent into a general business tool
- 500만 users, 20% non-developer, 3× faster non-dev growth
- This is the "agentic workflow automation goes mainstream" inflection point
- Captured in `ai-agents-trends-2026.md` section 15 + Codex entity page

### Pattern 3: Three-Way Platform War (Anthropic vs OpenAI vs Microsoft)
- Anthropic: Skills + Cowork (law/finance domains)
- OpenAI: Codex Plugins + Sites + Annotations (6 roles)
- Microsoft: MAI models (in-house) + GitHub Copilot distribution
- **All three converging on "team-wide AI agent platform"** in 2026 Q2
- Currently living in `ai-agents-trends-2026.md`; if 2+ more events accumulate, extract to dedicated `concepts/agent-platform-war-2026.md`

## Backlink Web (Bidirectional Check)

The cron sync doesn't enforce bidirectional wikilinks. Manually verified this session:

- `codex.md` → links to: oh-my-harness, claude-cowork, claude-code-pro-max, openai, cursor, github-copilot, managed-agents, ai-agents-trends-2026, claude-proxy-economy, apple-on-device-openai ✓
  - Reverse: openai.md ✓, github-copilot.md ✓, ai-agents-trends-2026.md ✓
  - **Missing reverse links** (should be added in next sync that touches these pages): claude-cowork.md, claude-code-pro-max.md, cursor.md, managed-agents.md
- `mai-code-1-flash.md` → links to: github-copilot, qwen, qwen3-6-27b, qwen3-7-max, deepseek-v4, kimi-k2-6, glm-4-7, gemma-4, openai, codex, claude-code-pro-max, context-mode, coding-agent-benchmark, moe-local-comparison, ai-agents-trends-2026
  - Reverse: github-copilot.md ✓, openai.md ✓, ai-agents-trends-2026.md ✓, coding-agent-benchmark.md ✓
  - **Missing reverse links** (target for next sync): qwen.md, qwen3-6-27b.md, qwen3-7-max.md, deepseek-v4.md, kimi-k2-6.md, glm-4-7.md, gemma-4.md, claude-code-pro-max.md, context-mode.md, moe-local-comparison.md

This backlink gap list becomes a TODO for the next sync that touches any of those pages.

## Index.md Insertion Reference (For Future Syncs)

When you encounter entities that need alphabetical insertion near existing neighbors, always:
1. `grep -n "<neighbor1>\|<neighbor2>" ~/wiki/index.md` to confirm neighbors
2. Use unique context (3+ surrounding lines) in `old_string` to avoid the multi-match footgun
3. After patching, `grep` to verify the entry landed exactly once

In this session, `codex` was inserted between `codeburn` and `colleague-skill`, and `mai-code-1-flash` between `maestro-mcp` and `meta`. The hyphen sorts as a separator, so `mai-code-1-flash` < `meta` character-by-character (m-a-i- < m-e-t-). Verified.

## Notion Marking TODO (Recurring Pain)

`notion_news_to_wiki.py` does NOT mark processed items in Notion. The 2026-06-02 → 2026-06-03 sync was a no-op because yesterday's items re-appeared. This is the 2nd documented instance. Consider:

- Add a `Wiki-synced` date property to the Notion DB schema
- Modify the script to set `Wiki-synced = True` and `Wiki-synced-at = YYYY-MM-DD` after processing
- This would let the collector skip already-processed items at the source

Filed for upstream script patch. No skill change needed — this is a script issue, not a workflow issue.
