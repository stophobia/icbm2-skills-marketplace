# pygame 데스크탑 미니앱 시뮬레이터 — 2026-06-23 kiwi 세션 학습 노트

macOS 15.5 (Intel Mac mini) + Python 3.11 + pygame 2.6.1 + pyttsx3 + LLM API(MiniMax-M3)로 키위/스택챈 스타일 데스크탑 동반자 시뮬레이터를 만들면서 마주친 함정과 해결책 모음.

## 1. macOS에서 pygame은 **메인 스레드**에서만 호출

### 증상
```
pygame.error: NSWindow should only be instantiated on the main thread!
```

### 원인
macOS cocoa 백엔드에서 `pygame.display.set_mode()`가 내부적으로 `NSWindow` 인스턴스를 만드는데, 이건 **반드시 메인 스레드**에서만 가능. 다른 스레드(예: `face.run()`을 `threading.Thread`로 띄운 경우)에서 호출하면 즉시 크래시.

### 해결
- `face.py`는 단순한 상태 객체 (이벤트/그리기 메서드만)
- `kiwi.py`에서 메인 스레드 = `face.init_pygame() + face.tick()` 무한 루프
- LLM/TTS 같은 blocking I/O는 **별도 워커 스레드**에서 실행
- 메인/워커 간 통신은 `queue.Queue` 이벤트

```python
# kiwi.py 메인 루프
face = KiwiFace()
face.init_pygame()  # 메인 스레드
worker = threading.Thread(target=llm_worker, args=(...), daemon=True)
worker.start()
while face.tick():  # 메인 스레드
    time.sleep(0.005)
```

---

## 2. `pygame.init()` 절대 호출 금지 — mixer/audio 자동 init 크래시

### 증상
```
Exception Type:        EXC_BAD_ACCESS (SIGSEGV)
Exception Codes:       UNKNOWN_0xD at 0x0000000000000000
```
크래시 리포트에 활성 스레드로 `AudioQueue thread`, `AQConverterThread`, `com.apple.audio.IOThread` 다수 등장. pyttsx3가 macOS NSSpeechSynthesizer로 같은 오디오 디바이스 사용하다 race condition.

### 원인
`pygame.init()`은 `SDL_INIT_AUDIO`까지 자동 활성화. SDL2가 백그라운드에서 `SDLTimer`, `AudioQueue`, `AQConverter`, `com.apple.audio.IOThread.client` 등 비동기 스레드 띄움. 이 스레드들이 pyttsx3(macOS NSSpeechSynthesizer)와 같은 오디오 디바이스 핸들 두고 race. mixer 안 쓰더라도 `pygame.init()`만 호출하면 영향.

### 해결
**명시적 subsystem init만 호출**:
```python
# BAD — mixer/audio 자동 init됨
pygame.init()
pygame.display.set_mode((W, H))

# GOOD — 필요한 것만
pygame.display.init()
pygame.font.init()
pygame.display.set_mode((W, H))
```

`mixer.init()` 절대 호출 금지. 비활성 확인:
```python
print(bool(pygame.mixer.get_init()))  # False여야 안전
```

---

## 3. `pygame.time.Clock()` 절대 사용 금지 — SDLTimer race

### 증상
```
Exception Type:        EXC_BAD_ACCESS (SIGSEGV)
Exception Codes:       KERN_INVALID_ADDRESS at 0x000000000000000f
Termination Reason:    Namespace SIGNAL, Code 11 Segmentation fault: 11
```
크래시 위치: `event.cpython-311-darwin.so`의 `pg_event_get` → `pgEvent_New` → `PyDict_SetItemString` → `PyDict_SetItem` (offset 3388) → NULL+15 포인터 역참조. 활성 스레드에 `SDLTimer` (`SDL_TimerThread`) 존재.

### 원인
`pygame.time.Clock()` 객체 생성 시 SDL 내부 타이머 subsystem 활성화. `SDL_TimerThread`가 백그라운드에서 깨어나서 메인 스레드 Python 인터프리터와 race condition 일으킴. 메인 스레드가 `pg_event_get`에서 dict 채우려다 타이머 스레드가 동시에 dict 손대면서 NULL+15 포인터 역참조로 크래시.

### 해결
**Clock 안 쓰고 직접 `time.sleep()`으로 throttle**:
```python
# BAD — Clock 객체 생성 시 SDLTimer 활성화
self._clock = pygame.time.Clock()
while True:
    self._clock.tick(60)  # 60 FPS

# GOOD — 메인 루프에서 직접 sleep
while face.tick():
    time.sleep(0.005)  # ~200 FPS throttle, 타이머 스레드 안 띄움
```

---

## 4. 3대 크래시 해결 후 깨끗한 활성 스레드

모든 크래시 함정 해결 후 활성 스레드:
```
Thread 0:    Dispatch queue: com.apple.main-thread (pygame 메인 루프)
Thread 11:   com.apple.NSEventThread (AppKit — macOS 표준, 제거 불가)
```

다른 비동기 스레드 **모두 사라짐**. mixer/audio/SDLTimer race 완전 차단.

---

## 5. pyttsx3 한국어 음성 (Yuna) 정확히 매칭

### 증상
기본 검색 `"ko" in voice.id`로 매칭하면 첫 매칭이 `Eddy (Korean)` 같은 Eloquence 음성 — 발음 기계적이고 부자연스러움. macOS는 Yuna라는 고품질 compact 한국어 음성을 따로 제공.

### 해결
**우선순위 함수로 매칭**:
```python
_KOREAN_PREFERENCE_KEYS = ("yuna", "kyung", "ko-kr.yuna", "ko_kr.yuna")

def _find_korean_voice(engine):
    for keyword in _KOREAN_PREFERENCE_KEYS:
        for v in engine.getProperty("voices"):
            if keyword == "yuna":
                # Yuna 정확 매칭 (단순 substring은 Eddy 등이 먼저 잡힘)
                if v.name == "Yuna" or v.id.endswith(".Yuna") or "ko-kr.yuna" in v.id:
                    return v
            elif keyword in v.name.lower() or keyword in v.id.lower():
                return v
    return None
```

### macOS TTS 음성 정리 (177개 중 한국어 관련)
- **Yuna** — `com.apple.voice.compact.ko-KR.Yuna` — 자연스러운 여성 목소리, compact
- **Kyung** — 한국어 남성 목소리
- **Eddy/Flo/Grandma/Grandpa/Reed/Rocko/Sandy/Shelley (Korean South Korea)** — Eloquence 합성음, 부자연스러움

`pyttsx3` + `pyobjc` (Cocoa 바인딩) 설치되면 자동 사용 가능. 폴백으로 `subprocess.run(["say", "-v", "Yuna", text])`도 작동.

---

## 6. pygame.arc 좌표계 + vision 평가 한계

### pygame 좌표계
- 원점 (0, 0) = 좌상단
- x는 오른쪽으로 증가, y는 아래로 증가
- 0 rad = 3시(오른쪽), 0.5π = 6시(아래), π = 9시(왼쪽), 1.5π = 12시(위)
- `arc(rect, start, end)`: rect 외접 타원 위의 호

### 호 방향 규칙
- `arc(..., 0, π)` → rect 위쪽에 호 그려짐 (위로 볼록, ∪)
- `arc(..., π, 2π)` → rect 아래쪽에 호 그려짐 (아래로 볼록, ∩)
- `arc(..., 0.5π, 1.5π)` → 반 바퀴 = 완전한 원

### vision 평가 한계 (치명적)
같은 `0.15π → 0.85π` 호를 vision API가 분석할 때:
- 호출 1: "위로 볼록 ∪ (웃음)"
- 호출 2: "아래로 볼록 ∩ (찡그림)"
- 호출 3: "S자 모양"
- 호출 4: "불명확"

→ **vision은 arc 곡선 방향을 신뢰할 수 없음**. arc 사용 후 vision 검증에 의존하면 디버깅 시간 낭비.

### 해결: 픽셀 점 직접 그리기
```python
# BAD — arc + vision 검증 불안정
pygame.draw.arc(screen, color, (cx-35, cy-22, 70, 38), 0.15*math.pi, 0.85*math.pi, 5)

# GOOD — sin 곡선 따라 픽셀 점 21개
smile_points = []
for i in range(21):
    t = i / 20.0
    x = cx - 55 + int(110 * t)
    y_offset = int(-25 * math.sin(math.pi * t))  # ∪ 모양
    smile_points.append((x, cy + y_offset))
for x, y in smile_points:
    pygame.draw.circle(screen, color, (x, y), 3)
```

vision이 명확하게 인식 + 사용자가 PNG 봐도 직관적. **호 그리기는 픽셀 점 우선, arc는 최후의 수단**.

---

## 7. macOS 한글/이모지 폰트 깨짐 회피

### 증상
pygame 라벨에 한글 또는 이모지 넣으면 `□` 깨진 글자로 표시. vision이 PNG 분석 시에도 한글이나 이모지를 `□`로 잘못 인식.

### 원인
- `pygame.font.SysFont("Apple SD Gothic Neo", 22)` — 폰트 객체는 로드되지만 실제 glyph 렌더링 깨질 수 있음
- pygame은 컬러 이모지 글리프(🥝 😊) 미지원 → 무조건 `□`

### 해결
**라벨은 영문 대문자만 사용**:
```python
labels = {
    "happy":     "HAPPY",
    "sad":       "SAD",
    "thinking":  "THINKING",
    "surprised": "SURPRISED",
    "neutral":   "NEUTRAL",
}
```

**macOS 폰트 후보 6개 순차 시도 + 실제 glyph 렌더링 검증**:
```python
for font_name in ["Apple SD Gothic Neo", "AppleSDGothicNeo-Regular",
                  "AppleGothic", "Nanum Gothic", "Noto Sans CJK KR", "Helvetica"]:
    try:
        f = pygame.font.SysFont(font_name, 20, bold=True)
        test = f.render("HI", True, (0, 0, 0))
        if test.get_width() > 10:  # 정상 glyph
            font = f
            break
    except Exception:
        continue
```

한글이 꼭 필요하면 `f.render("한글테스트", ...)`로 검증 후 사용.

---

## 8. vision 비주얼 디버깅 — 5단계 워크플로우

데스크탑 변형에서 외형/표정이 의도대로 그려졌는지 확인하는 5단계:

1. **헤드리스 PNG 저장** — `os.environ['SDL_VIDEODRIVER'] = 'dummy'`로 윈도우 없이 PNG 저장
   ```python
   f = face.KiwiFace()
   f.init_pygame()
   f.set_emotion('happy')
   f._update(0)
   f._draw()
   pygame.image.save(f._window, 'preview/kiwi_happy.png')
   ```

2. **vision 분석** — `mcp__minimax__understand_image`로 표정-라벨 일치 확인

3. **호 방향/구성 확인** — vision이 "↑/↓/○/—" 모양 인식 결과와 의도 비교

4. **사용자 직접 확인** — `open preview/`로 Finder에서 사용자가 직접 본다. vision과 사용자 인식이 다를 수 있으므로 **사용자 확인이 최종 권위**.

5. **arc 함정 회피** — vision 결과가 arc 방향과 안 맞으면 픽셀 점 방식으로 재구현

### vision 한계 보완
- vision이 arc 곡선 방향 일관성 없게 평가 → 픽셀 점 우선
- vision이 한글/이모지 `□`로 잘못 인식 → 영문 라벨만
- vision이 "작은 호"와 "큰 호" 구분 어려움 → 호 크기 키우기

---

## 9. conda 환경 분리 (base pip 깨짐 함정)

### 증상
```
# 시스템 conda base에서 pip install 시도 시
InvalidVersion: '4.0.0-unsupported'
```

### 원인
시스템 conda base의 pip이 너무 구버전. `pkg_resources`가 `4.0.0-unsupported` 같은 비표준 버전 파싱 실패.

### 해결
**새 conda 환경에 설치**:
```bash
/opt/anaconda3/bin/conda create -y -n {env_name} python=3.11 pip
/opt/anaconda3/envs/{env_name}/bin/pip install pygame pyttsx3 requests
```

**bash 래퍼로 사용자 conda activate 없이 자동 활성화**:
```bash
#!/bin/bash
CONDA_ENV_PYTHON="/Users/{user}/opt/anaconda3/envs/{env_name}/bin/python"
SECRETS_FILE="$HOME/.hermes/secrets/{provider}.env"
set -a; source "$SECRETS_FILE"; set +a
exec "$CONDA_ENV_PYTHON" "{script}.py" "$@"
```

`write_file`로 .sh 작성 → `chmod +x` → `bash run.sh`로 실행. 비밀 키가 들어간 export는 `write_file` 결과에서 `$HOME...` 등으로 마스킹되니 참고.

---

## 10. Apple Silicon 전용 App Store 앱 함정

### 증상
"Stackchan 시뮬레이터 만들어줘" → 첫 추측: macOS App Store의 `StackChan World by M5Stack` 앱 설치. 이 앱은 **Apple Silicon (M1+) 전용**. Intel Mac에서는 설치 자체 불가.

### 해결
`mcp__minimax__web_search`로 "Intel Mac 지원" 명시 확인. 안 나오면 macOS App Store 변형 제외. 다른 변형(데스크탑 pygame, 웹 시뮬레이션) 결정.

```python
# 검색어
"stackchan simulator Mac Apple Silicon Intel 호환"
"stackchan desktop simulator python library"
```

Intel Mac에서는 M5Stack 공식 앱 설치 불가 → 직접 만드는 변형(데스크탑 pygame)으로 빠짐.

---

## 11. Python 3.8 호환성 (PEP 604)

### 증상
```python
def call_llm(user_text: str, conversation: list | None = None) -> dict:
```
Python 3.10+에서 작동하지만 Python 3.8 (`TypeError: unsupported operand type(s) for |: 'type' and 'NoneType'`).

### 해결
`from typing import Optional, List, Dict` 사용:
```python
def call_llm(user_text: str, conversation: Optional[List[Dict]] = None) -> Dict:
```

conda 환경 만들 때 `python=3.11` 명시하면 PEP 604 사용 가능. 3.8 환경이면 Optional 패턴.

---

## 12. patch tool의 들여쓰기 깨짐 함정

### 증상
`patch` tool로 큰 블록을 교체할 때 old_string 매칭이 부분적으로 어긋나면서 들여쓰기가 한 단계씩 밀려나거나, `if/elif` 체인이 깨져서 `elif`만 남는 경우. 결과: `IndentationError: unindent does not match any outer indentation level`.

### 해결
큰 메서드(>50줄) 통째 교체 시:
- `read_file`로 전체 메서드 읽고 정확한 들여쓰기 확인
- `patch` 매칭 시 `old_string`에 들여쓰기 컨텍스트 1~2줄 더 포함
- 깨지면 `read_file` + `patch`로 재시도 2~3회
- 최후 수단: 파일 통째 `write_file`로 재작성 (단, 다른 부분 보존 위해 반드시 백업/검증)

---

## 13. PNG 미리보기 + 사용자 확인 워크플로우

`bash run.sh`로 GUI 띄우기 전 단계로:

```bash
# 1) 헤드리스 dummy로 PNG 저장
cd ~/projects/kiwi-companion
SDL_VIDEODRIVER=dummy python3 -c "
import sys; sys.path.insert(0, '.')
import face, pygame
f = face.KiwiFace()
f.init_pygame()
for em in ['happy','sad','thinking','surprised','neutral']:
    f.set_emotion(em); f.set_speaking(False); f._update(0); f._draw()
    pygame.image.save(f._window, f'preview/kiwi_{em}.png')
f.shutdown()"

# 2) vision 분석
mcp__minimax__understand_image image_source=preview/kiwi_happy.png

# 3) 사용자 직접 확인
open preview/
```

`open` 명령은 macOS에서 Finder로 폴더 열어줌. 사용자가 PNG 직접 보고 "happy 입이 위로 휜 ∪ 맞아?" 식으로 확인. vision과 사용자 시각이 다를 수 있어 사용자 확인이 최종 권위.

---

## 14. "Brainstorming-first" 워크플로우 (재확인)

이번 세션에서도 사용자 선호 재확인:
- 구현 전 A/B/C 옵션 2~3개 + 추천 1개 굵게 표시
- 결정 포인트 3~4개 (방향/톤/라이브러리/배포 등)
- 사용자 답변 "그대로 진행해" 받으면 즉시 실행

특히 LLM 기반 창작/시각화 작업은 이 패턴이 잘 들어맞음. 추측으로 바로 구현하면 사용자 의도와 어긋날 위험 큼.

---

## 15. 정리 (cleanup) 시 데스크탑 변형 추가 체크리스트

웹/플랫폼 SDK 변형 정리 + 데스크탑 변형 추가:
- [ ] GitHub repo (push 했을 경우)
- [ ] 로컬 디렉토리 (`trash`, 절대 `rm -rf` 금지)
- [ ] **conda 환경** (`/opt/anaconda3/envs/{env_name}`) — `conda env remove -n {env_name}`
- [ ] `~/.hermes/secrets/{provider}.env` — 다른 프로젝트에서 안 쓰면 보존
- [ ] 미리보기 PNG (있으면 `trash`)

---

## 부록: 디버깅 체크리스트 (pygame + macOS 데스크탑)

1. **크래시 발생 시**: `~/Library/Logs/DiagnosticReports/python*.ips` 에서 최신 .ips 확인
2. **크래시 리포트 보는 법**:
   - `Crashed Thread`: 어떤 스레드 죽었는지 (0 = 메인 스레드)
   - `Exception Type`: SIGSEGV, SIGABRT 등
   - `images` 마지막 호출 stack: 어떤 Python/C 함수에서 죽었는지
   - `threads` 활성 스레드 목록: SDLTimer, AudioQueue 등이 있으면 그것이 race 원인
3. **헤더 1차 진단**:
   - NSThread 0 + SDLTimer/AudioQueue → #2, #3 크래시 (mixer/audio race)
   - NSThread 0 + PyDict_SetItemString → #3 크래시 (Clock race)
   - NSThread 0 + pygame.display.set_mode → #1 크래시 (NSWindow 메인 스레드)
4. **점진적 수정**: 한 번에 하나씩. mixer 빼고 → 크래시 → 그 다음 Clock 빼고 → 크래시 → 그 다음 ... 식으로 격리

---

## 부록: 코드 템플릿 (3파일 구조)

세 파일로 분리하면 유지보수 쉬움:

```
llm.py   — LLM API 호출 + 감정 태그 파싱
tts.py   — pyttsx3 wrapper + Yuna 음성 + say 폴백
face.py  — pygame 얼굴 윈도우 (메인 스레드 init_pygame/tick/shutdown)
kiwi.py  — 메인 루프 + LLM/TTS 워커 스레드
run.sh   — conda 환경 + 키 로드 + 실행
```

각 파일 100~300줄 정도. 변경 시 영향 범위 명확. 테스트도 파일별로 가능 (`python llm.py "테스트"`).
