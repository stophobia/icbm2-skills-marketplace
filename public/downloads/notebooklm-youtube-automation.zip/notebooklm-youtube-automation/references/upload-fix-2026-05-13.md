# Upload Pipeline Fixes (2026-05-13)

## Bug 1: UPLOAD_SCRIPT_DIR was wrong (CRITICAL — uploads always failed)

**File:** `~/.hermes/scripts/notebooklm_upload_pipeline.py`

**Problem:** `UPLOAD_SCRIPT_DIR` pointed to non-existent path:
```python
# WRONG — this directory doesn't exist
UPLOAD_SCRIPT_DIR = os.path.join(HOME, ".hermes/skills/creative/youtube-uploader/scripts")
```

**Fix applied:**
```python
UPLOAD_SCRIPT = os.path.join(HOME, ".hermes/scripts/yt_upload.py")
UPLOAD_SCRIPT_DIR = os.path.dirname(UPLOAD_SCRIPT)  # = ~/.hermes/scripts
```

The actual upload script is at **`~/.hermes/scripts/yt_upload.py`**, not inside skills directory.

## Bug 2: `notebooklm delete` command format wrong

**Problem:** Pipeline called `notebooklm delete <id> -y`
```
Error: Got unexpected extra argument (8a57365a-...)
```

**Fix applied:**
```python
# CORRECT format:
nb_cmd(["delete", "-n", nb_id, "-y"])
```

The `-n` / `--notebook` flag is required.

## yt_upload.py positional args

The actual upload script uses **positional arguments** (NOT `--title` flags):
```bash
python3 ~/.hermes/scripts/yt_upload.py "<file_path>" "<title>" "<description>"
```

## YouTube OAuth token expired → 300s timeout

**Symptom:** `upload_to_youtube()` calls timed out after 120 seconds.

**Root cause:** OAuth token expired. Check:
```python
import pickle, os
TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")
with open(TOKEN_FILE, "rb") as f:
    creds = pickle.load(f)
print("valid:", creds.valid, "expired:", creds.expired)
```

**Fix:** Refresh the token manually:
```bash
source ~/.hermes/venv-notebooklm/bin/activate
python3 -c "
import os, pickle
from google.auth.transport.requests import Request
TOKEN_FILE = os.path.expanduser('~/.hermes/secrets/youtube_token.pickle')
with open(TOKEN_FILE, 'rb') as f:
    creds = pickle.load(f)
if creds.expired and creds.refresh_token:
    creds.refresh(Request())
    with open(TOKEN_FILE, 'wb') as f:
        pickle.dump(creds, f)
    print('Token refreshed!')
"
```

## Notebook IDs: use selection.json, not notebook_ids.json

The `notebook_ids.json` in `/tmp/icbm_notebooklm/` is from a previous run (may have old IDs).
**Always use `~/.hermes/memory/notebooklm_selection.json`** for notebook IDs matching today's selection.

## prepare.py --topics flag doesn't exist

`notebooklm_prepare.py` accepts `--dry-run`, `--skip-telegram`, `--auto` only.
To select specific topics, manually populate `selected` in `selection.json`:
```python
import json
with open("~/.hermes/memory/notebooklm_selection.json") as f:
    data = json.load(f)
nums = [2, 3, 4, 10]  # user-selected numbers (1-indexed)
data["selected"] = [data["topics"][n-1] for n in nums]
with open("~/.hermes/memory/notebooklm_selection.json", "w") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
```
Then run: `python3 ~/.hermes/scripts/notebooklm_prepare.py --skip-telegram`

## Cron scanner false positive: `rm -rf /tmp/` blocked

**File:** `~/.hermes/hermes-agent/tools/cronjob_tools.py`, line 49

**Problem:** Pattern `r'rm\s+-rf\s+/'` matched `rm -rf /tmp/blog-images-repo` (false positive).
This caused ALL cron jobs using the tistory-publisher skill to be BLOCKED.

**Fix applied:** Changed to `r'rm\s+-rf\s+/(?!tmp)'` (negative lookahead — allows `/tmp/` cleanup, blocks root-only deletion).
