"""YouTube OAuth 토큰 재발급 스크립트 템플릿.

사용 시나리오:
  1. access_token 만료 → refresh_token으로 자동 갱신 시도
  2. refresh_token도 만료/revoke → 풀 OAuth 플로우 (브라우저 로그인 필요)
  3. 스코프 부족 (예: delete 필요) → 더 넓은 스코프로 재발급

⚠️ 절대 f-string 안에 토큰/secret 값을 직접 넣지 마라 — ``***`` 마스킹이
SyntaxError를 유발한다. ``os.path.expanduser`` + 문자열 연결을 사용한다.

사용법:
  # 업로드 전용 (대부분의 경우)
  SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]

  # 삭제/search/video 관리 필요 시
  SCOPES = ["https://www.googleapis.com/auth/youtube"]

  python3 youtube_reauth.py
"""

import glob
import os
import pickle
import shutil
import sys

from google_auth_oauthlib.flow import InstalledAppFlow

TOKEN_PATH = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")
SCOPES = ["https://www.googleapis.com/auth/youtube"]  # 필요한 스코프로 교체


def find_client_secret():
    """client_secret_*.json 자동 탐색."""
    candidates = glob.glob(os.path.expanduser("~/.hermes/secrets/client_secret_*.json"))
    if not candidates:
        sys.exit("client_secret 파일을 찾을 수 없음: ~/.hermes/secrets/")
    return candidates[0]


def try_refresh(creds):
    """저장된 refresh_token으로 access_token 갱신 시도.

    Returns 갱신된 Credentials, 또는 None (실패).
    """
    if not getattr(creds, "refresh_token", None):
        return None
    from google.auth.transport.requests import Request
    try:
        creds.refresh(Request())
        return creds
    except Exception as e:
        print(f"refresh 실패: {e}")
        return None


def run_full_oauth(CLIENT_SECRET):
    """브라우저 풀 OAuth 플로우 (로컬 서버 기반)."""
    flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET, SCOPES)
    flow.run_local_server(port=0)
    return flow.credentials


def main():
    CLIENT_SECRET = find_client_secret()
    print(f"Using client_secret: {CLIENT_SECRET}")

    creds = None
    if os.path.exists(TOKEN_PATH):
        with open(TOKEN_PATH, "rb") as f:
            creds = pickle.load(f)
        print(f"기존 토큰 발견: valid={creds.valid}, has_refresh={bool(getattr(creds, 'refresh_token', None))}")

        if not creds.valid:
            print("refresh_token으로 갱신 시도...")
            refreshed = try_refresh(creds)
            if refreshed is not None:
                creds = refreshed
                print("refresh_token으로 갱신 성공")
            else:
                print("refresh_token 만료 → 풀 OAuth 플로우 진행")
                creds = None
    else:
        print("기존 토큰 없음 → 풀 OAuth 플로우 진행")

    if creds is None:
        # 백업 보존
        if os.path.exists(TOKEN_PATH):
            backup = TOKEN_PATH + ".bak"
            shutil.copy(TOKEN_PATH, backup)
            print(f"기존 토큰 백업: {backup}")
        creds = run_full_oauth(CLIENT_SECRET)

    # 저장
    with open(TOKEN_PATH, "wb") as f:
        pickle.dump(creds, f)

    print()
    print("=== 새 토큰 정보 ===")
    print(f"  Valid: {creds.valid}")
    print(f"  Has refresh_token: {bool(creds.refresh_token)}")
    scopes = getattr(creds, "scopes", None) or SCOPES
    print(f"  Scopes: {scopes}")
    print(f"  저장: {TOKEN_PATH}")


if __name__ == "__main__":
    main()
