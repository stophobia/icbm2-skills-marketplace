# 이미지 자동 삽입 정책 충돌 (2026-06-04, 82차 발견)

## 문제 정의
`tistory-publisher` 스킬의 **이미지 호스팅 정책**과 **`tistory_publisher.py`의 실제 동작**이 서로 모순된다.

## 스킬 본문의 정책
> "Tistory CDN 업로드(attach.json)는 불안정하므로 사용하지 마라. **GitHub 저장소를 이미지 호스팅**으로 사용한다."
> - 이미지 저장소: `sigco3111/blog-images` (public)
> - 로컬 클론: `/tmp/blog-images-repo/`
> - GitHub raw URL: `https://raw.githubusercontent.com/sigco3111/blog-images/main/{filename}`

## `tistory_publisher.py` v1.8.7+ 의 실제 동작
별도 플래그 없이도 Picsum 무료 이미지를 2장 자동 다운로드 → Tistory CDN(`attach.json`)에 업로드 → 본문에 삽입한다.

**증거 (82차 발행 로그):**
```
🔍 무료 이미지(Picsum)로 2장 검색 중...
🖼️  이미지 CDN 업로드 중... (1/2)
🖼️  이미지 업로드 성공: image.jpg (126KB)
🖼️  이미지 업로드 성공: image.jpg (74KB)
🖼️  이미지 2장 삽입 완료 (CDN 업로드: 2/2, query: Velith — AI 기반...)
🖼️  OG 썸네일 설정: https://blog.kakaocdn.net/dna/...
```

## 근본 원인
- `tistory_publisher.py` 작성 시 Picsum 자동삽입이 "이미지 없는 글 발행"을 막기 위한 안전장치로 추가됨
- 깁(GitHub) 호스팅 정책은 발행 에이전트(LLM agent)가 **수동으로** 깁 업로드 후 HTML에 삽입하는 워크플로우를 전제
- 그러나 자동 발행 파이프라인은 깁 업로드 단계가 없으므로 `tistory_publisher.py`의 Picsum 자동삽입이 항상 발동

## 옵션

### 옵션 1: `tistory_publisher.py`에 `--no-images` 플래그 추가 (권장)
```python
parser.add_argument('--no-images', action='store_true',
                    help='이미지 자동 삽입 비활성화 (깁 호스팅 수동 삽입 시 사용)')
```
- 본문에 깁 호스팅 이미지가 이미 포함된 경우에만 사용
- 깁 호스팅을 명시적으로 선호하는 발행 워크플로우 보존

### 옵션 2: `--images` 값으로 소스 제어
```python
parser.add_argument('--images', default='picsum',
                    choices=['picsum', 'github', 'none'],
                    help='이미지 소스 선택 (default: picsum)')
```

### 옵션 3: 스킬 본문 정책을 Picsum 기본으로 변경
- Picsum + Tistory CDN이 "기본값"
- 깁 호스팅은 "특수 케이스(깁 업로드가 이미 완료된 이미지 URL 전달 시)"
- 현실에 맞게 정책 단순화

## 임시 대응 (플래그 추가 전)
1. **이미지 원치 않을 때:** 발행 후 Tistory 관리자에서 수동 제거
2. **깁 호스팅 이미지를 명시적으로 쓰고 싶을 때:** 
   - 깁 업로드 후 `markdown_to_tistory_html.py`로 HTML 변환
   - HTML에 `<figure>` 태그가 이미 포함됨
   - `tistory_publisher.py`가 중복 삽입 시 → 첫 번째 Picsum이 깁 이미지를 덮어쓸 수 있음
   - **검증 필요:** 우선순위가 어떻게 되는지 확인 안 됨

## 후속 조치
- [ ] `tistory_publisher.py` 소스 읽고 Picsum 자동삽입 트리거 조건 확인
- [ ] `--no-images` 또는 `--images {picsum,github,none}` 플래그 추가 패치
- [ ] 깁 호스팅 우선순위 + 중복 삽입 회피 로직 확인
