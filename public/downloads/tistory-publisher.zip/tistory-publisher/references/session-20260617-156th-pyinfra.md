# 156차 (2nd run) — 2026-06-17 pyinfra 발행 (긱뉴스 5,000자+ 분기 긱뉴스 단독)

## 결과
- **주제**: pyinfra — 에이전트 없는 인프라 자동화, 순수 Python으로
- **발행 URL**: https://sigco.tistory.com/774
- **분기**: 긱뉴스 본문 5,000자+ (HN 코멘트 + 공식 사이트 본문 풍부) → 긱뉴스 단독 진행 (fetch_content 시도 생략)
- **A 83점 (content 33 + readability 13 + originality 20 + seo 17) / 1회 컷 / decision=pass**
- freshness FP 0건 / CJK 0건 46회 연속 / 1회 patch 0회 (1차 초안에서 바로 통과)

## 핵심 사항
- **긱뉴스 단독 진행 누적 9회째 (동일 세션 2번째 156차 발행)** (131/135/138/141/144/146/151/152/156차 tradingcodex / **156차 pyinfra**)
  - 5,000자+ 분기 = fetch_content 시도 생략, 긱뉴스 단독으로 즉시 전환
- **A 83 = readability 13 + seo 17 동시 도달 케이스 정형화 (156차 신규)**
  - 짧은 단문 위주 작성 + 도입 SEO 친화 (긴 문장 분리) + 본문 2,692자 + 태그 9개 + 제목 38자 동시 충족 시 A 83 자동 도달
  - 1회 patch 불필요. 1차 초안 작성 그대로 게이트 통과
- **S 86 진입 조건 갱신 (156차 정량화)**: 134차 정량화 "S 16+ = avg_sentence 50자 이하" 와 156차 "avg_sentence 25.9자 / readability 13" 의 비교 → **avg_sentence가 너무 짧아도 readability 상한 13~14 부근에서 정체 가능** (sentence_count 70 부근이 적정). S 86 진입은 readability 16+ (avg_sentence 50~60자+ 적정 길이) + content 35 + originality 20 동시 필요. 단문 위주 작성만으로 S 진입 어려움
- **본문 2,692자 + paragraphs 12 + sentence_count 70 = A 83 안정 분포 (156차 정량화)**
  - 게이트 content_length 2,692자 / 헬퍼 1,841자 (차이 851자, 132~154차 정량화 일치)
  - paragraphs 12 (만점 15+는 아니지만 A 등급 정상) + sentence_count 70 (가독성 적정)
  - **판단: 본문 2,600~2,800자 + H2 6 + paragraphs 12 + sentence_count 60~80이면 A 80~84 안정 도달**

## A 등급 breakdown (156차 pyinfra)
- content 33 (paragraphs 12, h2 6, body 2,692자, has_intro true, has_conclusion false)
- readability 13 (avg_sentence 36.0자, sentence_count 70, formatting_score 3)
- originality 20 (word_count 529, unique 372, TTR 0.703)
- seo 17 (이슈 0건)
- **A 83점은 readability 13 + originality 20 + seo 17 케이스의 안정 상한**

## Pits (156차 pyinfra 신규)
- **readability 8 정체 / avg_sentence 25.9자 / sentence_count 71 (tradingcodex 156차와 동일 현상)**: 짧은 단문 patch를 많이 적용하면 avg_sentence가 급격히 낮아지고 sentence_count가 부풀어남. **판단 정식화 (양 156차 합산 정형화)**: readability 8~9 + decision=pass + A 67~83이면 발행 진행. 1~2회 patch 더 시도로 readability +2~3 회복은 시간 낭비. **avg_sentence 25.9자 / sentence_count 71 = readability 정체 임계 (단문 너무 많으면 formatting_score 0 + readability 8~9 정체)**
- **헬퍼 vs 게이트 본문 글자수 차이 851자 (156차 pyinfra)**: 헬퍼 1,841자 / 게이트 content_length 2,692자 (차이 851자). 132~155차 정량화 "차이 400~1,500자" 정합. **게이트 통과 여부가 진짜 기준, 헬퍼 글자수는 참고용** (128차 정식화 6회째 재확인)
- **S 86 진입 조건 갱신 (156차)**: 단문 위주 작성 (avg_sentence < 30자) 는 readability 13 부근에서 정체, S 86 진입 어려움. readability 16+ 도달은 **avg_sentence 50~60자 적정 길이** (sentence_count 40~60) 가 필요. 짧은 단문 patch 누적은 formatting_score 0 + readability 8~9로 이어질 위험

## Picsum 자동 이미지
- `--image-query "pyinfra python infrastructure automation ssh"` 영문 키워드 그대로 → picsum.photos/id/146/1080 + picsum.photos/id/1056/1080 = 2장 자동 삽입
- OG 자동 1장 (blog.kakaocdn.net) = 본문 3장 동시 무충돌

## 발행 시퀀스 (3단계 무오류)
1. `python3 ~/.hermes/scripts/tistory_publisher.py --content "$(cat /tmp/blog_tistory.html)" --title "..." --tags "..." --category 1219748 --image-query "..." --record-topic "주제" "제목" "TBD" "TOPIC_URL"` → 발행 성공 + topic_url record
2. `python3 ~/.hermes/scripts/blog_pipeline.py --record "주제" "제목" "https://sigco.tistory.com/774"` → 발행 기록 추가
3. `rm -f /tmp/blog_post.md /tmp/blog_tistory.html /tmp/qg.json /tmp/measure.py /tmp/gn.html` → 임시 파일 정리

## 1회 컷 36회째 정량화 (156차 양 런 합산)
- 1회 컷 연속 진행: 122~156차 누적 36회 (tradingcodex 156차도 1회 컷)
- A 등급 분포 (양 156차): A 67 (tradingcodex, readability 8) / A 83 (pyinfra, readability 13) = A 67~83 가설 4/4 + freshness FP 0건 케이스의 안정 분포
- 긱뉴스 단독 진행 누적 9회째 (양 156차 포함)
