# Platform SDK Capability Check — 외부 플랫폼 SDK 가능 범위 검증 절차

타겟 플랫폼(앱인토스, 스팀 워크샵, iOS/Android 등)의 SDK가 **실제로 사용자/디바이스 데이터에 접근 가능한 범위**를 brainstorming 전에 검증하기 위한 절차. 아이디어가 참신해도 SDK가 닫혀있으면 구현 불가하므로 시간 낭비 방지.

## 일반 검증 절차 (모든 플랫폼 공통)

1. **공식 SDK 패키지 검색**
   - NPM: `curl -sL "https://registry.npmjs.org/-/v1/search?text={org-scope}&size=50"`
   - Pub.dev: `curl -sL "https://pub.dev/api/search?q={pkg}"`
   - CocoaPods: `pod search {name}`
   - PyPI: `curl -sL "https://pypi.org/pypi/{pkg}/json"`

2. **tarball 직접 추출 + src/ 트리 검사**
   ```bash
   curl -sL "https://registry.npmjs.org/{pkg}/-/{pkg}-{version}.tgz" -o /tmp/pkg.tgz
   tar -tzf /tmp/pkg.tgz | grep -E '\.ts$'    # TypeScript 시그니처 확인
   tar -xzf /tmp/pkg.tgz -C /tmp/             # 필요 시
   ```

3. **함수 시그니처 + 반환 타입 추출**
   - `Promise<string>` vs `Promise<object[]>` 차이 확인 (특히 데이터 묶음 필요 시)
   - `@category` JSDoc 태그가 있으면 데이터 도메인 그룹화 가능
   - `ErrorCode` 타입이 있으면 거부 케이스까지 매핑

4. **공식 예제 repo에서 use case 목록 추출**
   - `curl -sL "https://api.github.com/repos/{org}/{repo}/contents/examples"` → 디렉토리 목록
   - `with-payment-history` 같은 게 없으면 그 기능 SDK 부재 **강력 신호**

5. **부재 보고** — 아이디어가 그 기능에 의존하면 솔직하게 "기술적으로 불가능" 보고.

## 앱인토스 (AppsInToss) Granite SDK 검증 사례 (2026-06-18)

대상: 토스 앱인토스 미니앱 빌드. SDK: `@apps-in-toss/native-modules` 2.9.1.

### 추출 명령
```bash
# 1. SDK 검색
curl -sL "https://registry.npmjs.org/-/v1/search?text=@apps-in-toss&size=50"

# 2. native-modules 패키지 tarball 다운로드
curl -sL "https://registry.npmjs.org/@apps-in-toss/native-modules/2.9.1" | python3 -c "
import sys, json
data = json.load(sys.stdin)
print('NAME:', data['name'])
print('VERSION:', data['version'])
"

curl -sL "https://registry.npmjs.org/@apps-in-toss/native-modules/-/native-modules-2.9.1.tgz" \
  -o /tmp/nm.tgz

# 3. src/ 트리에서 모든 native module 함수 추출
tar -tzf /tmp/nm.tgz | grep "package/src/MiniAppModule/native-modules" | grep -v "/index.ts"

# 4. 특정 함수 시그니처 확인 (예: getConsentedUserData)
tar -xzf /tmp/nm.tgz package/src/MiniAppModule/native-modules/getConsentedUserData.ts -C /tmp/
cat /tmp/package/src/MiniAppModule/native-modules/getConsentedUserData.ts
```

### 가능 범위 (2026-06 기준)

#### ✅ 사용 가능
- **사용자 동의 기반 데이터**: `getConsentedUserData` → 8개 키 (모두 `string`)
  - USER_NAME, USER_GENDER, USER_NATIONALITY, USER_BIRTHDAY, USER_PHONE, USER_ADDRESS, USER_EMAIL
  - USER_CONSUMPTION_HISTORY (이름과 달리 string 한 개, 데이터 묶음 아님 — 함정)
  - 호출 시 약관 웹뷰 자동 표시, 개별 키마다 동의 필요
  - 콘솔에 HTTPS 회사 도메인 약관 URL 등록 필수
- **로그인**: `appLogin` → authorizationCode + referrer 반환 (서버에서 토큰 교환)
- **로컬 저장**: `storage` → 단순 KV (`setItem`, `getItem`, `removeItem`, `clearItems`)
- **디바이스 권한 SDK**: `getCurrentLocation`, `fetchContacts`, `fetchAlbumItems`, `getClipboardText`/`setClipboardText`, `openCamera`, `share`, `getTossShareLink`
- **광고/결제/IAP**: `ads/googleAdMobV2`, `checkoutPayment`, `iap`, `requestTossPayPaysBilling`, `grantPromotionReward`
- **유틸**: `getServerTime`, `getDeviceId`, `getAnonymousKey`, `getGroupId`, `getOperationalEnvironment`, `getPermission`, `openPermissionDialog`, `requestNotificationAgreement`

#### ❌ 부재 (의외로 못 쓰는 것들)
- **결제 내역 조회 API 없음**
- **카드 사용 내역 조회 API 없음**
- **송금 내역 조회 API 없음**
- **자산/계좌 내역 조회 API 없음**
- **친구 목록 조회 API 없음**
- **카테고리별 지출 분류 API 없음**
- **푸시 알림 발송 SDK 없음** (consent만 있음, 실제 발송은 토스측)

### 검증 후 결정해야 할 아이디어 패턴

| 아이디어 유형 | 가능 여부 | 이유 |
|---|---|---|
| "내 토스 사용 패턴 리포트" | ❌ | 결제/카드/송금 내역 SDK 부재 |
| "토스 친구 생일 캐처" | ✅ | `fetchContacts` (디바이스 연락처) 활용 |
| "우리 동네 오늘 한 줄" | ✅ | `getCurrentLocation` + 외부 공개 API (기상청 등) |
| "내 인생 토스 MBTI" | ✅ | `storage`로 결과 저장, 사용자 직접 응답 |
| "토스 결제 알림 메이커" | ❌ | 결제 내역 SDK 부재 |

### 공식 예제 repo 활용 패턴
- `toss/apps-in-toss-examples` — `with-{기능명}` 디렉토리 = 공식 지원 use case
- 없는 기능(`with-payment-history`, `with-account`, `with-friends` 등) = SDK 부재 간접 증거
- 예: `with-storage`, `with-app-login`, `with-contacts`, `with-location-once`, `with-share-link`, `with-clipboard-text`, `with-camera`, `with-network-status`, `with-haptic-feedback`, `with-game`, `with-in-app-purchase`, `with-interstitial-ad`, `with-rewarded-ad` 등

### 함정 / 주의

- **`USER_CONSUMPTION_HISTORY` 오해 금지**: 이름은 "소비 이력"이지만 타입이 `string` 한 개. SDK 예시 코드는 **배송 정보(USER_NAME + USER_PHONE + USER_ADDRESS)** 용도로만 사용. "내 사용 패턴" 류 아이디어는 이 키로 해결 불가.
- **약관 URL 필수**: `getConsentedUserData` 호출 전 콘솔에 HTTPS 회사 도메인의 `termsUrl` 등록해야. 미리미터 등록 안 하면 `TERMS_NOT_SET` 에러.
- **개별 키 동의**: `USER_CONSUMPTION_HISTORY` 같은 일부 키는 비즈니스 승인 필요할 가능성 ↑.
- **`appLogin` ≠ 서버 토큰 교환 끝**: 클라이언트는 `authorizationCode`까지만 받고, 실제 토큰 교환은 **반드시 서버** 필요 → 서버 없는 미니앱은 `appLogin`도 못 씀 (단순 userKey 해시 정도만 가능).

## 일반화 원칙 (모든 플랫폼 검증 시)

1. **아이디어가 "플랫폼 사용자의 X 데이터를 분석/표시" 류면**, step 0의 0.1 절차로 **반드시** SDK 가능 범위 검증.
2. **검증 결과가 "안 됨"이면 brainstorming으로 가지 말고** 솔직히 거절. "노력하면 됩니다" 거짓말 금지.
3. **가능한 SDK 범위 내에서만** brainstorming 진행 — 그 자체가 좋은 제약 조건이 됨.
4. 검증 절차 자체는 **5분이면 끝남** — brainstorming에 들어가는 30분 전에 투자할 가치 있음.