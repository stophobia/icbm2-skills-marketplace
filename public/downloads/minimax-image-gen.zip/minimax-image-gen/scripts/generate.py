#!/usr/bin/env python3
"""
MiniMax image-01 텍스트→이미지 생성기
Usage: python3 generate.py "<prompt>" [aspect_ratio] [n]
"""
import os, json, sys
import urllib.request

API_KEY = os.environ.get('MINIMAX_API_KEY')
URL = "https://api.minimax.io/v1/image_generation"

def generate(prompt, aspect_ratio="16:9", n=1, retry=3):
    payload = {
        "model": "image-01",
        "prompt": prompt,
        "aspect_ratio": aspect_ratio,
        "response_format": "url",
        "n": n
    }
    
    for attempt in range(retry):
        data = json.dumps(payload).encode()
        req = urllib.request.Request(URL, data=data, method="POST")
        req.add_header("Authorization", f"Bearer {API_KEY}")
        req.add_header("Content-Type", "application/json")
        
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                result = json.loads(resp.read())
                urls = result.get("data", {}).get("image_urls", [])
                status = result.get("base_resp", {}).get("status_code")
                
                if status == 0 and urls:
                    return urls
                elif status == 1033 and attempt < retry - 1:
                    print(f"Attempt {attempt+1} failed (1033), retrying...", file=sys.stderr)
                    continue
                else:
                    return []
        except Exception as e:
            if attempt < retry - 1:
                print(f"Attempt {attempt+1} error: {e}", file=sys.stderr)
                continue
            return []
    
    return []

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: generate.py <prompt> [aspect_ratio] [n]")
        sys.exit(1)
    
    prompt = sys.argv[1]
    ratio = sys.argv[2] if len(sys.argv) > 2 else "16:9"
    n = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    
    urls = generate(prompt, ratio, n)
    if urls:
        for u in urls:
            print(u)
    else:
        print("Failed to generate image", file=sys.stderr)
        sys.exit(1)