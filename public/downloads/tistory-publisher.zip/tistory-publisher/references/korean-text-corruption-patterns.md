# Korean Text Corruption 패턴 (누적)

## 개요
`markdown_to_tistory_html.py` 변환 중 또는 CJK cleaning 과정에서 Korean 텍스트가 의도치 않게 손상되는 패턴을 기록한다.

## 발생 패턴

### 1. CJK multi-character 치환 → Korean word boundary 결합 (70차)
**문제:** Chinese 단일 문자를 multi-character Korean으로 치환할 때 공백이 소실되어 인접 Korean 텍스트와 결합됨
```
원본 Markdown:  ##졸업식에서
CJK 정제:       '毕' → '졸업'
결과:           ##졸업업식에서  ← Korean 단어 합쳐짐!
```
**원인:** `'毕': '졸업'` 치환 시 원래 `毕` 앞뒤의 공백이 사라지고 `졸업`이 인접 텍스트에 직접 연결됨

**대응:**
```python
# ❌ 이렇게 하지 말 것
'毕': '졸업'  # 공백 소실 유발

# ✅ 올바른 방식 — 빈 문자열 제거 또는 단일 character만 사용
'毕': ''       # 제거만 수행
'者': '글'    # 단일 character Korean만 치환
```

### 2. CJK cleaning 후 합쳐진 Korean 단어 복구 패턴
```python
korean_corruption_patterns = {
    '각단대이': '각 팀이',    # 62차
    'AI가주류로': 'AI가 주류로',  # 65차
    '마진，要求': '마진, 요구',  # 65차
    '소사나혁명': '작은 혁명이',  # 58차
    '起码': '최소한',           # 58차
    '正经한': '정확한',          # 58차
    'キャプチャ': '캡처',       # 58차
    'ситуаций': '상황',        # 58차 (Russian)
}
```

### 3. markdown_to_tistory_html.py 변환 중 직접 손상
```
입력:  "在北京举行的" 
출력:  "재북경에서열린"  ← Chinese가 Korean으로 변환되면서 합쳐짐
```

## 발견 시나리오별 체크리스트

| 시나리오 | 체크포인트 | 대응 |
|----------|-----------|------|
| Markdown CJK 선검사 1차 후 | 합쳐진 Korean 단어 탐지 | `korean_corruption_patterns`로 복구 |
| HTML CJK cleaning 루프 0회차 통과 후 | Korean 텍스트 무결성 검사 | `korean_corruption_patterns`比对 |
| markdown_to_tistory_html.py 변환 직후 | `<p>` 태그 내 텍스트 결합 | 헤더 패턴 `##Text` → `<p>##Text` 확인 |
| Korean Hanja (U+CDF0 등) | Unicode 범위 밖 문자 | `'쾨': '쾌'` 형식의 별도 사전 |

## 실체 사례

| 차수 | 날짜 | 손상 패턴 | 원인 | 복구 |
|------|------|----------|------|------|
| 58차 | 2026-05-18 | `소사나혁명`, `起码`, `キャプチャ` | markdown_to_tistory_html.py 변환 중 | `korean_corruption_patterns`로 복구 |
| 62차 | 2026-05-18 | `각단대이` → `각 팀이` | CJK cleaning이 Korean 단어를 Chinese로 오해 | 수동 patch |
| 65차 | 2026-05-19 | `AI가주류로`, `마진，要求` | HTML 변환 직후 Korean 텍스트 합쳐짐 | `korean_corruption_patterns`로 복구 |
| 70차 | 2026-05-23 | `##졸업식에서` → `##졸업업식에서` | `'毕': '졸업'` 치환 시 공백 소실 | 빈 문자열 제거로 변경, Markdown 수정 |
| 79차 | 2026-05-31 | `시饮할 → 사용할`, `专业적인 → 전문적인` | Markdown 작성 단계에서 Chinese `饮`(U+996E)과 `专`(U+4E13)이 Korean 단어 사이에 직접 혼입 | CJK 선검사 1차에서 탐지 → targeted fix로 `시饮할 → 사용할`, `专业적인 → 전문적인` 복구 |
| 80차 | 2026-06-01 | `차 계산에될 필요 없이` → `시차 계산에 불편함 없이` | CJK cleaning에서 `困`(困扰 일부)과 `扰`를 각각 빈 문자열로 제거하면서 Korean 단어 끊어짐. 원본 Chinese 복합어 `困扰`(당황/困难)에서 개별 문자만 남아있어 CJK cleaning 시 `困`/`扰`만 제거 → `차 계산에될 필요 없이`로 남음 | targeted fix로 `차 계산에될 필요 없이` → `시차 계산에 불편함 없이` 복구. korean_corruption_patterns dict에 패턴 추가 필요 |
| 81차 | 2026-06-06 | `등에서발표 공공문서` → `등에서 발표한 공공문서`, `VLM 개발이될` → `VLM 개발이 가속화될` | Markdown 작성 시 `发布` (중국어) 가 Korean 단어 사이 (`에서...공공문서`)에 직접 삽입됨 → CJK 선검사에서 `发`/`布`만 빈 문자열로 제거 → 인접 Korean 단어가 공백 없이 합쳐짐 (`등에서발표`, `개발이될`) | Markdown 단계에서 `发布` 한 단어 단위로 `발표`로 먼저 치환한 뒤 잔여 `发`/`布`을 빈 문자열로 제거. 또는 CJK cleaning 후 반드시 `korean_corruption_patterns`로 read-through → `등에서발표` → `등에서 발표한`, `개발이될` → `개발이 가속화될` 복구. **공백 유무 확인은 CJK cleaning의 사후 필수 단계** |

## 예방 규칙

1. **CJK 정제 시 multi-character Korean 치환 금지** — `'毕': '졸업'` 대신 `'毕': ''`
2. **HTML CJK cleaning 전에 Korean corruption check 실행**
3. **markdown_to_tistory_html.py 출력 헤더 패턴 먼저 확인** — `##`가 `<p>` 태그 안에서 결합되는지 체크
4. **루프 0회차 통과해도 Korean corruption check는 별도 실행** (CJK regex 밖이므로)