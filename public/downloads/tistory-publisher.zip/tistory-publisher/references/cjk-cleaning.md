# CJK Cleaning — 한국어-한자/일본어/중국어 혼입 방지 레퍼런스

## 핵심 원칙

1. **Markdown 작성 단계에서 CJK를 근본적으로 방지** — 웹 검색 결과나 기사 원문을 복사할 때 Chinese 문자가 함께 붙을 수 있음
2. **HTML 변환 전에 Markdown에서 먼저 탐지** — `markdown_to_tistory_html.py` 변환 전에 CJK 선검사 실행
3. **HTML 변환 후 루프 정제** — `html == html_before` 조건으로 안정화될 때까지 반복
4. **루프 안정화 후에도 잔여 CJK가 있을 수 있음** — 반드시 2차 정제 실행

## Markdown CJK 선검사 (HTML 변환 전)

```python
import re

def check_markdown_cjk(md_path):
    with open(md_path, 'r') as f:
        md = f.read()
    cjk = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', md))
    if cjk:
        print(f"⚠️ Markdown에서 CJK 발견: {cjk}")
        return cjk
    return set()

def clean_markdown_cjk(md_path, replacements):
    with open(md_path, 'r') as f:
        md = f.read()
    for old, new in replacements.items():
        md = md.replace(old, new)
    cjk = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', md))
    if cjk:
        print(f"⚠️ 정제 후 잔여 CJK: {cjk}")
    else:
        print("✅ Markdown CJK 완전 제거 완료")
    with open(md_path, 'w') as f:
        f.write(md)
    return md
```

## HTML CJK 정제 (markdown_to_tistory_html.py 변환 후)

### CJK 문자 Regex

```python
# CJK 문자 탐지
import re
def has_cjk(text):
    return bool(re.search(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', text))

# CJK 문자 추출
def get_cjk_chars(text):
    return set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', text))
```

### CLEANING_LOOP — 루프 기반 정제

```python
def clean_cjk_loop(html, replacements, max_passes=20):
    """CJK가 없어질 때까지 루프 돌기. 안정화되면 2차 정제 실행."""
    pass_num = 0
    while has_cjk(html):
        html_before = html
        for old, new in replacements.items():
            html = html.replace(old, new)
        pass_num += 1
        if html == html_before:
            # 루프 안정화 — 잔여 문자 2차 정제
            remaining = get_cjk_chars(html)
            print(f"⚠️ CJK 루프 {pass_num}회차 후 잔여: {remaining} — 2차 정제 실행")
            for old, new in SECOND_PASS_FIXES.items():
                html = html.replace(old, new)
            remaining = get_cjk_chars(html)
            if remaining:
                print(f"⚠️ 2차 정제 후 잔여: {remaining}")
            break
        if pass_num > max_passes:
            print(f"⚠️ {max_passes}회차 초과 — 잔여: {get_cjk_chars(html)}")
            break
    else:
        print(f"✅ CJK 완전 정제 완료 ({pass_num}회차)")
    return html
```

### 2차 정제 잔여 문자 (누적)

```python
SECOND_PASS_FIXES = {
    # 38차
    '年': '년', '间': '간', '当': '당', '时': '시', '成': '성',
    # 39차
    '房': '방', '起': '기', '音': '음', '料': '료', '购': '구',
    '压': '압', '敌': '적', '点': '점', '感': '감', '足': '족',
    '频': '빈', '塑': '소', '文': '문', '碾': '년도', '植': '식', '力': '력',
    # 40차
    '判': '판', '优': '우', '物': '물', '凌': '능', '訓': '훈',
    '层': '층', '做': '작', '晨': '신', '劲': '근', '断': '단',
    '致': '치', '导': '도',
    # 41차
    '重': '중', '无': '무', '启': '계', '比': '비', '速': '속',
    '導': '도', '向': '향', '缝': '봉', '加': '가', '傘': '산',
    # 48차 (2026-05-16 — Markdown 작성 단계 Chinese 복합어 분해混入)
    '戦': '전', '場': '장', '市': '시', '値': '값', '定': '정',
    '應': '응', '商': '상', '局': '격', '業': '업', '限': '한',
    '和': '화', '赶': '쫓아', '用': '용', '上': '상', '決': '결', '追': '쫓아',
    # 57차 (2026-05-18): markdown_to_tistory_html.py converter corruption
    '正经한': '정확한',
    '正经': '정확',
    '起码': '최소한',
    'キャプチャ': '캡처',
    # 62차 (2026-05-18 — 플랫폼 엔지니어링 블로그 글)
    '团': '단',
    '队': '대',
    '沌': '혼',
    # 기타 자주 발견
    '拠': '거', 'ほ': '호', 'ど': '도', '无': '무', 'ろ': '로',
    '証': '증', '上': '상', '移': '이', '万': '만', '历': '력',
    '能': '능', '几': '기', '实': '실', '处': '처', '识': '식',
}
```

### Cyrillic 잔여 (CJK regex 밖)

```python
cyrillic = set(re.findall(r'[\u0400-\u04FF]', html))
if cyrillic:
    print(f"⚠️ Cyrillic 잔여: {cyrillic}")
    for c in cyrillic:
        html = html.replace(c, '')
```

### Korean Hanja Corruption 검증

```python
CORRUPTION_COMPLETE = ['开发', '发表', '韩', '中', '文']
for pat in CORRUPTION_COMPLETE:
    if pat in html:
        print(f"⚠️ Korean Hanja corruption (complete): {pat}")

MIXED_PATTERNS = ['례외', '热潮', '实证', '研究', '無', '無検討']
for pat in MIXED_PATTERNS:
    if pat in html:
        print(f"⚠️ Mixed CJK-in-Korean suspicious: {pat}")
```

## 주기적으로 발견되는 Chinese 단어 → Korean 매핑

```python
CHINESE_WORD_REPLACEMENTS = {
    '记录': '기록',
    '实用': '실용',
    '实时': '실시간',
    '的同时': '동시에',
    '举动': '조치',
    '负责': '책임',
    '原则': '원칙',
    '対応': '대응',
    '동호会': '동호회',
    '社区': '커뮤니티',
    '激烈': '열렬',
    '赞同': '동의',
    '当地时间': '현지 시간',
    # 48차 — Traditional Chinese 복합어
    '战场上': '전장에서', '決定적': '결정적인', '局限': '한계',
    # 49차 — Chinese 숙어 단위 (2026-05-16)
    '在这种局面下': '이러한 상황에서',
    # 51차 (2026-05-16 — 모델이 Japanesehiragana/한자를 한국어 텍스트 사이에 직접 섞어 생성)
    '共': '공', 'す': '', '值': '값', '得': '득', '府': '부', '政': '정',
    '注': '주', '公': '공', 'て': '', '看': '볼', '么': '', 'べ': '베',
    '你': '당신', '理': '리', '整': '정', '怪': '괴', '料': '료',
    '次': '차', 'の': '', '現': '현', '象': '상', '這': '제',
    # 62차 (2026-05-18 — 플랫폼 엔지니어링 블로그 글)
    # "混沌" individually → 混(혼)+沌(혼) = "혼혼", correct Korean is "혼돈"
    '混沌': '혼돈',
    # 67차 (2026-05-21): GeekNews 원문 참조 시 Chinese 복합어 유입
    '規模': '규모', '影響': '영향', '攻撃': '공격', '情報': '정보',
    '技術': '기술', '開発': '개발', '必須': '필수', '需要': '수요',
    '可能': '가능', '提供': '제공', '利用': '이용', '場合': '경우',
    ' 대응': '대응', '期待': '기대', '注目': '주목', '研究': '연구',
    '結果': '결과', '方法': '방법',
}
```

## 대표적 유입 경로

| 출처 | 패턴 | 예시 |
|------|------|------|
| GeekNews 원문 | Chinese 단어가 한국어 사이에 삽입 | 受影响→수영향, 发生→발생 |
| Wikipedia/위키독스 | 한국어 한자 섞인 표현 | 移動 중 → 이동 중 |
| 검색 결과 복사 | Chinese/Japanese 문자 포함 | "plástica" → "플라스틱" |
| 모델 생성 | 모델이 직접 Chinese 텍스트 생성 | "Microsoft傘下의 GitHub" |
| 모델 생성 (48차) | Chinese 복합어가 한국어 사이에 직접 섞어짐 | "战场上決定적인 차이" →战场上, 決定적 개별 한자로 분해混入 |
| 모델 생성 (51차) | Japanesehiragana/한자가 한국어 사이에 직접 섞어짐 | "영국政府재", "MHCLG)가 밝힌이번", "你怎么看" → 한국어 단어 내부에서 개별 한자로 분해混入 |
| **converter (57차)** | `markdown_to_tistory_html.py` 변환 중 한국어 텍스트 자체를 CJK로 변환 | `'소사나혁명'` → Korean Hanja corruption, `'起码'` → Chinese 혼입, `'キャプチャ'` → Japanese katakana 혼입, `'正经한'` → Chinese 혼입 |
| **CJK cleaning (62차)** | CJK cleaning 시 individual char 매핑이 Korean word를 깨뜨림 | `'混沌'` → 混(혼)+沌(혼) = `'혼혼'` (정답: `'혼돈'`), `'각 팀이'` → `'각단대이'` (CJK cleaning이 team/단을 잘못 치환) |

## 품질 체크포인트 요약

| 단계 | 파일 | 체크포인트 |
|------|------|-----------|
| 1 | Markdown 작성 직후 | CJK 선검사 — 있으면 정제 후 저장 |
| 2 | markdown_to_tistory_html.py 변환 직후 | **Korean text corruption 검사** — CJK regex 밖의 corruption도 탐지 |
| 3 | converter corruption 검사 후 | 루프 정제 실행 |
| 4 | 루프 안정화 후 | 2차 정제 + 잔여 탐지 |
| 5 | 최종 HTML | corruption/잔여 검증 |

## Korean Text Corruption 검증 (converter 도입, 57차)

`markdown_to_tistory_html.py`는 변환 과정에서 **완전히 한국어로 작성된 텍스트마저 Chinese/Japanese로 변질**시키는 corruption을 일으킨다. 이는 CJK regex (`[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]`)로 탐지되지 않는 경우가 있다 — 한국어 문자열인데 Chinese/Japanese 단어가 결합된 형태이기 때문이다.

```python
KOREAN_CORRUPTION_PATTERNS = {
    '起码': '최소한',
    'キャプチャ': '캡처',
    '正经한': '정확한',
    '正经': '정확',
    '소사나혁명': '작은 혁명이',
    # 62차 (2026-05-18): CJK cleaning broke "각 팀이" → "각단대이"
    '각단대이': '각 팀이',
    # 기타 발견 시 추가
}

def check_korean_corruption(html):
    found = []
    for bad, good in KOREAN_CORRUPTION_PATTERNS.items():
        if bad in html:
            print(f"⚠️ Korean text corruption: {bad} → {good}")
            html = html.replace(bad, good)
            found.append(bad)
    return html, found
```

**실행 시점:** HTML 변환 직후, CJK cleaning 루프 전에 실행. CJK cleaning이 0회차로 통과해도 이 검사는 반드시 별도로 실행한다.
