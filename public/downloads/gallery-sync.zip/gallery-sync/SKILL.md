---
name: gallery-sync
description: ICBM2 뮤직비디오 갤러리 자동 동기화 — gallery_data.json 변경 시 index.html 내장 데이터 자동 동기화 + 유효성 검증 + Git 푸시
trigger: gallery_data.json 수정 후 index.html 자동 동기화 필요 시
---

## 언제 쓰는가?
gallery_data.json을 수동/자동으로 수정한 후, index.html의 내장 데이터가 항상 동기화된 상태를 유지해야 할 때 실행한다.

## 사용법

```bash
bash ~/.hermes/scripts/gallery_build.sh
```

## 검증 체크리스트

- [ ] `images` 배열이 비어있지 않은지 확인 (비어있으면 에러)
- [ ] `gallery_data.json` JSON 유효성
- [ ] `index.html` 내장 데이터 = `gallery_data.json` 동일성 확인
- [ ] 불일치 시 자동 동기화
- [ ] Git 자동 커밋 & 푸시

## 예방 체크리스트 (갤러리 업데이트 전 반드시 확인)

- [ ] `gallery_data.json`에서 해당 entry의 `images` 배열이 비어있지 않은지 확인
  ```bash
  cat gallery_data.json | python3 -c "
  import json, sys
  data = json.load(sys.stdin)
  for e in data['entries']:
      if not e.get('images'):
          print(f'❌ [{e[\"date\"]}] {e[\"topic\"]} - images 배열 비어있음!')
          sys.exit(1)
  print('✅ 모든 entry에 이미지 있음')
  "
  ```
- [ ] build.sh 실행하여 index.html 동기화
- [ ] Git 푸시 후 GitHub Pages 배포 확인 (1~2분 소요)

## 주요 문제 원인

| 문제 | 원인 |对策 |
|------|------|------|
| 카드에 이미지 없음 | `images: []` 빈 배열 | build 스크립트에서 빈 배열 检测시 에러 |
| 모달에 이미지 안 뜸 | `updateModalImage()`에서 `getImageSrc()` 미호출 | 항상 getImageSrc 거치도록 검증 |
| 내장 데이터陈旧 | index.html 업데이트 누락 | build.sh에서 자동 동기화 |

## 경고 시스템 (index.html 내장)

`GALLERY_DATA` 로딩 시:
1. `images` 배열이 비어있는 entry 발견 → console.error + 경고 메시지
2. 모달 열 때 `MODAL_IMAGES.length === 0` → 아무 동작 안 함

## 데이터 흐름

```
gallery_data.json (진실)
    → build.sh가 검증 후 index.html에 동기화
    → GitHub Pages 배포
    → 브라우저가 gallery_data.json fetch + 내장 데이터 폴백
```

## 관련 참고 자료

- `references/dual-data-source-pattern.md` — dual-data-source 문제의 원인, 해결 흐름, self-healer 오탐 패턴