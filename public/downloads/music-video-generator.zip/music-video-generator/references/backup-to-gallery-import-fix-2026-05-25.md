# backup_to_gallery Import Fix (2026-05-25)

## Symptom
`music_video_review.py --approved` runs, YouTube upload succeeds, but gallery card never appears.

## Root Cause

`backup_to_gallery()` was defined in `music_video_producer.py` but **never imported** in `music_video_review.py`. The call caused a `NameError` — but failed silently since it was in a try block or subprocess context.

## The Fix

**1. Added import in `music_video_review.py`:**
```python
import sys
sys.path.insert(0, os.path.join(os.path.expanduser("~"), ".hermes", "scripts"))
from music_video_producer import backup_to_gallery
```

**2. Added `--image-dir` argument to pass generated image directory:**
```bash
# In music_video_producer.py — pass image_dir to review script:
result = subprocess.run([
    "python3", review_script,
    "--review",
    "--video", f"video_wave_{timestamp}.mp4",
    ...
    "--image-dir", image_dir
], ...)

# In music_video_review.py argparse:
parser.add_argument("--image-dir", dest="image_dir", default="", help="생성된 이미지 디렉토리")
parser.add_argument("--mood", dest="mood", ...)
# etc.

# In do_review():
def do_review(video_file, short_file, title, description, topic_name, mood, image_dir=""):
    review_data = {
        ...
        "image_dir": image_dir,
        ...
    }

# In do_approved() — build image_paths and call:
image_dir = review_data.get("image_dir", "")
image_paths = []
if image_dir and os.path.isdir(image_dir):
    image_paths = [os.path.join(image_dir, f) for f in os.listdir(image_dir) if f.endswith(".png")]

backup_to_gallery(image_paths, topic_name, video_url, short_url or "", mood, review_data.get("description", ""))
```

## Files Modified

- `~/.hermes/scripts/music_video_review.py` — import + `--image-dir` arg + updated call
- `~/.hermes/scripts/music_video_producer.py` — pass `--image-dir` to review script

## Verification

```bash
python3 -m py_compile ~/.hermes/scripts/music_video_review.py && echo "OK"
python3 -m py_compile ~/.hermes/scripts/music_video_producer.py && echo "OK"
```