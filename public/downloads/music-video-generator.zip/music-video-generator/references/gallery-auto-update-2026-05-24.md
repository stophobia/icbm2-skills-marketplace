# Gallery Auto-Update — 2026-05-24

## 문제

YouTube 업로드 후 GitHub Pages 갤러리가 자동 갱신 안 됨.

**Root Cause 1:** `music_video_producer.py`의 `init_gallery_repo()`가 repo가 이미 존재하면 `return True`만 하고 git pull을 안 함. 로컬이 원격 대비 stale 상태.

**Root Cause 2:** `music_video_review.py`의 `do_approved()`에서 YouTube 업로드 후 `backup_to_gallery()`를 호출하지 않음. 검수 → 업로드 파이프라인에서 백업 단계가 빠짐.

## 수정 내용

### 1. `init_gallery_repo()` — 원격 동기화 추가

```python
def init_gallery_repo():
    git_dir = os.path.join(GALLERY_LOCAL, ".git")
    if not os.path.exists(git_dir):
        # 첫 초기화
        os.makedirs(GALLERY_LOCAL, exist_ok=True)
        subprocess.run(["git", "init"], cwd=GALLERY_LOCAL, capture_output=True)
        subprocess.run(["git", "remote", "add", "origin", GALLERY_REPO], cwd=GALLERY_LOCAL, capture_output=True)
        subprocess.run(["git", "fetch", "origin"], cwd=GALLERY_LOCAL, capture_output=True)
        subprocess.run(["git", "checkout", "-b", "main"], cwd=GALLERY_LOCAL, capture_output=True)
        os.makedirs(os.path.join(GALLERY_LOCAL, "images"), exist_ok=True)
    else:
        # 이미 초기화된 repo — 항상 원격과 동기화
        subprocess.run(
            ["git", "-C", GALLERY_LOCAL, "pull", "origin", "main"],
            capture_output=True, text=True
        )
    os.makedirs(os.path.join(GALLERY_LOCAL, "images"), exist_ok=True)
    return True
```

### 2. `do_approved()` — gallery 백업 호출 추가

```python
# do_approved()에서 YouTube 업로드 성공 후:
backup_to_gallery(topic_name, video_url, short_url or "", mood)
```

## 핵심 교훈

gallery 자동 갱신이 작동하려면 **두 파일 모두** 수정 필요:
1. `music_video_producer.py` — repo sync 로직 수정
2. `music_video_review.py` — YouTube 업로드 후 `backup_to_gallery()` 호출 추가

gallery 백업은 YouTube 업로드 후 수행하는 것이 올바른 순서 (검수 대기 상태의 임시 파일이 아니라, 실제 업로드 완료 후 갱신).

## youtube_url 오염 버그

`upload_to_youtube()`의 로그 메시지 (`"Uploading: ...\nSUCCESS: https://...")가 youtube_url 필드에 그대로 저장됨.
**방어:** `backup_to_gallery()`에서 `startswith("http")`으로 검증 후 저장.

```python
clean_yt_url = youtube_url if youtube_url.startswith("http") else ""
clean_short_url = short_url if short_url.startswith("http") else ""
```