# Gallery Modal Fix + AI Image Replacement (2026-05-24)

## 문제 1: 이미지 클릭 → 새창 열림 (모달 대신)

**원인:** `showImage()`가 `window.open(src, "_blank")`로 새창 열기만 함.

**해결:** 모달 UI로 교체.

```javascript
// Before
function showImage(src) { window.open(src, "_blank"); }

// After — Modal 패턴
var MODAL_INDEX = 0;
var MODAL_IMAGES = [];

function openModal(images, index) {
    MODAL_IMAGES = images;
    MODAL_INDEX = index;
    updateModalImage();
    document.getElementById('imageModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    document.getElementById('imageModal').classList.remove('active');
    document.body.style.overflow = '';
}

function prevImage() {
    MODAL_INDEX = (MODAL_INDEX - 1 + MODAL_IMAGES.length) % MODAL_IMAGES.length;
    updateModalImage();
}

function nextImage() {
    MODAL_INDEX = (MODAL_INDEX + 1) % MODAL_IMAGES.length;
    updateModalImage();
}

function updateModalImage() {
    document.getElementById('modalImg').src = getImageSrc(MODAL_IMAGES[MODAL_INDEX]);
    document.getElementById('modalCounter').textContent =
        (MODAL_INDEX + 1) + " / " + MODAL_IMAGES.length;
}

// Keyboard navigation
document.addEventListener('keydown', function(e) {
    var modal = document.getElementById('imageModal');
    if (!modal.classList.contains('active')) return;
    if (e.key === 'Escape') closeModal();
    if (e.key === 'ArrowLeft') prevImage();
    if (e.key === 'ArrowRight') nextImage();
});
document.getElementById('imageModal').addEventListener('click', function(e) {
    if (e.target.id === 'imageModal') closeModal();
});
```

**HTML 구조:**
```html
<div class="modal" id="imageModal">
    <button class="modal-close" onclick="closeModal()">&times;</button>
    <img class="modal-img" id="modalImg" src="" alt="">
    <div class="modal-nav">
        <button onclick="prevImage()">◀ 이전</button>
        <span class="counter" id="modalCounter"></span>
        <button onclick="nextImage()">다음 ▶</button>
    </div>
</div>
```

## 문제 2: 편의점 삼겹살 카드에 캡처 이미지 vs AI 생성 이미지 혼재

**원인:** `index.html`의 인라인 `GALLERY_DATA`와 `gallery_data.json`이 불일치.
- `gallery_data.json`에는 정상 이미지 배열
- `index.html` 인라인 데이터에 `"images": []` (빈 배열) 하드코딩

추가로 **유일한 생성 이미지가 아닌 YouTube 썸네일 캡처**를 사용함.

**해결:**
1. AI 생성 이미지를 `gallery_gh/images/`에 복사 (`test_samgye/` → `20260524_gen_image_*.png`)
2. `gallery_data.json`의 images 배열을 실제 생성 이미지로 교체
3. `index.html`의 인라인 데이터도同步更新
4. `loadGalleryData()`로 gallery_data.json 동적 fetch + fallback 인라인 데이터

**실제 AI 생성 이미지 경로:**
```
~/.hermes/music_videos/test_samgye/image_0.png
~/.hermes/music_videos/test_samgye/image_1.png
~/.hermes/music_videos/test_samgye/image_2.png
```
→ `gallery_gh/images/20260524_gen_image_0/1/2.png`로 복사

**⚠️ 핵심教训:** `index.html`에 인라인 GALLERY_DATA 하드코딩 금지 — gallery_data.json만 사용하고, 인라인은 fallback으로만 유지.