# Genre Plugin README Template (장르 플러그인 README 양식)

> **이 템플릿은 ai-gm-strategy-war, ai-gm-fantasy-rpg, ai-gm-sci-fi-explore, ai-gm-mystery-detective 4개 repo에서 검증된 README 양식**입니다. 새 장르 plugin repo를 만들 때 그대로 복제 + 장르별 4가지 결정 + 샘플 시드 + 엔티티 스키마만 채우면 됩니다.

## 템플릿 사용법

1. 워크스페이스에 새 디렉토리 생성 (예: `ai-gm-horror-survival/`)
2. 아래 템플릿 복사 후 `<장르명>`, `<장르 한국어명>`, `<톤 카테고리>`, `<엔티티 스키마>`, `<샘플 시드>` 등만 채우기
3. 검증된 양식이므로 **구조 변경 금지** — 단어/문장 다듬기만

## 템플릿

````markdown
# AI Game Master — <장르> (장르 플러그인)

> **장르 플러그인:** <한 줄 톤>. <플레이어 역할>. AI GM 시뮬레이션.
> **Genre plugin:** <영문 한 줄>. <Player role>. Under an AI GM.

[![Genre](https://img.shields.io/badge/genre-<장르>-<색>](#🎮-새-게임을-시작하세요)
[![Depends on](https://img.shields.io/badge/depends%20on-ai--gm-blue)](#요구사항)
[![Status](https://img.shields.io/badge/status-MVP%20planning-yellow)](#로드맵)
[![License](https://img.shields.io/badge/license-Apache%202.0-blue)](#라이선스)

---

## 🇰🇷 한국어 소개

### 이게 뭔가요?

이 저장소는 [`sigco3111/ai-gm`](https://github.com/sigco3111/ai-gm) **장르 비종속 공통 엔진 위에 얹는 장르 플러그인**입니다. 공통 인프라(MCP 서버, 메모리, RAG, 검증)는 ai-gm에서 가져오고, 이 repo는 장르 콘텐츠만 담습니다:

- <장르>의 JSON 스키마 (<엔티티 1> / <엔티티 2> / ...)
- <장르> 톤에 맞춘 GM 시스템 프롬프트
- **시작 가능한 샘플 시드** (예: <샘플 시드명>)
- **사용자 정의 시드**를 만드는 도구와 가이드
- 샘플 lore (<lore 카테고리>)

플레이어는 **<플레이어 역할>**. AI GM이 **<GM이 운영하는 것>**을 운영합니다. 1턴 = <시간 단위>, 무한 진행.

### 의존성

**반드시 [`sigco3111/ai-gm`](https://github.com/sigco3111/ai-gm) 코어를 먼저 설치**하세요. 이 저장소만으로는 동작하지 않습니다.

```
ai-gm (공통 엔진) ← ai-gm-strategy-war (장르 1: 전략/전쟁)
                  ← ai-gm-fantasy-rpg (장르 2: 판타지)
                  ← ai-gm-sci-fi-explore (장르 3: SF)
                  ← ai-gm-mystery-detective (장르 4: 미스터리)
                  ← <이 저장소> (장르 5: <장르>)
```

---

## 🇺🇸 English

### What is this?

This is a **genre plugin** for the [`sigco3111/ai-gm`](https://github.com/sigco3111/ai-gm) genre-agnostic engine. The core engine (MCP server, memory, RAG, validation) lives in `ai-gm`. This repo adds only genre-specific content:

- Genre-specific JSON schemas (<entity 1>, <entity 2>, ...)
- GM system prompt tuned for <장르> tone
- **Sample seeds** you can play right away (e.g. <샘플 시드 영문명>)
- **Tools & guides for crafting your own seed**
- Sample lore (<lore categories 영문>)

The player is **<player role 영문>**. The AI GM operates **<what GM operates 영문>**. 1 turn = <time unit>, infinite progression.

### Dependency

**You must first install [`sigco3111/ai-gm`](https://github.com/sigco3111/ai-gm) core.** This repo alone cannot run.

```
ai-gm (core engine) ← ai-gm-strategy-war (genre 1: strategy/war)
                  ← ai-gm-fantasy-rpg (genre 2: fantasy)
                  ← ai-gm-sci-fi-explore (genre 3: sci-fi)
                  ← ai-gm-mystery-detective (genre 4: mystery)
                  ← <this repo> (genre 5: <장르 영문>)
```

---

## 🎮 새 게임을 시작하세요 / Start a New Game

> **시작할 때 미리 정해진 설정은 없습니다. 게임 시작 시 GM이 당신에게 물어보고, 당신이 결정합니다.**
>
> **Nothing is preset. When you start, the GM will ask you and you'll decide.**

GM이 먼저 던지는 질문은 단 하나 — **"어떤 게임을 플레이하시겠어요?"**

The GM opens with a single question — **"What kind of game do you want to play?"**

### 4가지 결정 사항 / Four Decisions

| # | 결정 / Decision | 옵션 (예시) / Options (examples) |
|---|---------|------|
| 1 | **<결정 1 한국어>** / **<결정 1 영문>** | <옵션 1> / <옵션 2> / <옵션 3> |
| 2 | **톤** / **Tone** | <톤 옵션> |
| 3 | **<결정 3 한국어>** / **<결정 3 영문>** | <옵션> |
| 4 | **<결정 4 한국어>** / **<결정 4 영문>** | <옵션> |

**모르겠으면?** GM이 "<추천>"을 제시하거나, 샘플 시드를 추천해줍니다.

**Don't know?** The GM will offer a "<recommendation>" or point you to a sample seed.

### 샘플 시드 (바로 시작 가능) / Sample Seeds (play immediately)

미리 만들어진 시드 중 골라도 됩니다 — 결정 4가지를 한 번에 단축:

| 시드 / Seed | <결정 1> | <결정 2> | <결정 3> | <결정 4> |
|------|------|------|------|------|
| **<시드명>** (<시드 영문명>) | <값> | <값> | <값> | <값> |
| _(더 많은 샘플 시드 추가 예정)_ | | | | |

샘플 시드는 **그냥 시작점**입니다 — 본게임에 들어서면 톤·규칙·세계관은 GM이 자유롭게 변주할 수 있어요.

Sample seeds are just **starting points** — once the game begins, the GM may freely riff on tone, rules, and world.

### 직접 시드 만들기 (고급) / Craft Your Own Seed (advanced)

`lore/seeds/`에 직접 YAML/JSON을 작성해 완전히 새로운 세계를 던져줄 수도 있습니다. `seed_template.json`을 참고하세요.

You can also drop your own YAML/JSON into `lore/seeds/` to hand the GM a fully custom world. See `seed_template.json` for the schema.

---

## 🌰 샘플 시드 미리보기: <시드명> / Sample Seed Preview: <시드 영문명>

> **이건 *하나의 예시*일 뿐입니다. 위 "새 게임을 시작하세요" 섹션의 옵션으로 당신이 무엇이든 정할 수 있어요.**
>
> **This is *one* example. The "Start a New Game" section above lets you pick anything you want.**

<시드 한국어 한 줄 분위기>

<시드 영문 한 줄 분위기>

**당신의 자리 / Your seat:** <플레이어 위치 한국어>

**Your seat:** <플레이어 위치 영문>

**시작 조건 / Starting conditions:**
- <조건 1>
- <조건 2>
- <조건 3>

전체 시드 파일은 `lore/seeds/<시드 디렉토리명>/`에서 확인 (Phase 1 추가).

Full seed files in `lore/seeds/<시드 디렉토리명>/` (Phase 1).

---

## 🧱 장르 엔티티 / Genre-Specific Entities

> **이 스키마는 "플레이 가능한 모든 시나리오"의 공통 부분집합입니다.** 시드마다 일부 필드가 추가/오버라이드될 수 있습니다.
>
> **This schema is the common subset of all playable scenarios.** Individual seeds may add or override fields.

```json
{
  "<엔티티 1>": {
    "<id 필드>": {
      "<필드 1>": "...",
      "<필드 2>": "..."
    }
  },
  "<엔티티 2>": {
    "<id 필드>": {
      "<필드 1>": "...",
      "<필드 2>": "..."
    }
  }
}
```

전체 스키마는 Phase 1에서 `schemas/`에 들어갑니다.

Full schema lives in `schemas/` (Phase 1).

---

## 🗂️ 저장소 구조 / Repository Structure

```
<이 repo>/
├── lore/                       # 정적 세계관 + 청크 (Git 추적)
│   ├── rules/                  # [CHUNK: rules] (장르 공통, 핀 고정)
│   │   ├── <rule 1>.md
│   │   ├── <rule 2>.md
│   │   └── ...
│   ├── seeds/                  # 시작 가능한 시드 모음 (각 시드 = 디렉토리)
│   │   ├── <시드 디렉토리명>/       # [CHUNK: seed]
│   │   │   ├── seed.json       # 시드 정의
│   │   │   ├── <lore dir 1>/
│   │   │   ├── <lore dir 2>/
│   │   │   └── overview.md
│   │   └── _template/          # 새 시드 작성용 템플릿
│   └── _shared/                # 시드 간 공유 청크
│
├── schemas/                    # 장르 스키마 (Phase 1)
├── system_prompt.md            # GM 행동 규약
├── seed_template.json          # 새 시드 작성 가이드
├── games/                      # (gitignored) 실제 진행 게임
│   └── .gitkeep
├── examples/                   # 샘플 트랜스크립트
│   └── turn-001-<filename>.jsonl
├── LICENSE
└── README.md
```

---

## 🚀 빠른 시작 / Quick Start (목표)

```bash
# 1. 코어 + 이 플러그인 클론 / Clone core + this plugin
git clone https://github.com/sigco3111/ai-gm.git
git clone https://github.com/sigco3111/<이 repo명>.git

# 2. 코어 설치 / Install core
cd ai-gm && pip install -e ".[dev]" && cd ..

# 3. MCP 서버를 에이전트에 등록 / Register MCP server
#    (OpenCode / Claude Code / Hermes 설정 — ai-gm/docs/ 참조)

# 4. 에이전트에게 / Tell your agent:
#    "Start a new game of <이 repo명>"
#    → GM이 "어떤 게임을 플레이하시겠어요?" 라고 물어봄
#    → The GM will ask "What kind of game do you want to play?"
```

---

## 🎲 게임플레이 루프 / Gameplay Loop (per turn)

1. **플레이어 입력** — 자유 자연어 (예: "<입력 예시 1>" / "<입력 예시 2>")
2. **GM 컨텍스트 조회** — Tier 1 (최근 턴) + Tier 2 (<Tier 2 무엇>) + Tier 3 (관련 lore RAG)
3. **GM 도구 호출** — `<tool 1>`, `<tool 2>`, `<tool 3>` 등
4. **GM 서술** — 도구 결과를 바탕으로 묘사, **절대 임의 숫자 ❌**
5. **턴 종료** — 트랜스크립트 저장, 필요 시 자동 요약 트리거

**No silent fixes.** 도구 실패 시 GM은 플레이어에게 정직하게 알리고 대기.

**No silent fixes.** If a tool fails, the GM tells the player honestly and waits for input.

---

## 🗺️ 로드맵 / Roadmap

| Phase | 범위 / Scope | 상태 / Status |
|-------|-------------|------------|
| **0. 계획** | 아키텍처, README, 시드 시스템 설계 | ✅ 진행 중 |
| **1. 시드 시스템** | `seed_template.json` + `lore/seeds/<시드 디렉토리명>/` (샘플 1개) | 🔜 다음 |
| **2. 스키마** | 장르별 JSON 스키마 (ai-gm 코어에 등록) | 🔜 다음 |
| **3. 샘플 시드 2~3** | 시드 옵션 확장 | ⏳ |
| **4. 시드 빌더 도구** | `start_game` MCP 도구 + 대화형 설정 UI | ⏳ |
| **5. 샘플 플레이** | 50턴 진행 가능한 샘플 | ⏳ |

---

## 🎨 톤 & 영감 / Tone & Inspiration

<기본 톤>가 **기본 톤**이지만, 시드에서 다른 톤을 지정하면 GM이 그대로 따릅니다.

- <참고 게임 1> — <차용 요소>
- <참고 게임 2> — <차용 요소>
- <참고 게임 3> — <차용 요소>

**플레이어 권리가 최우선입니다.** GM은 플레이어 입력 없이 플롯을 진행하지 않습니다. 세계는 *반응*하지 *추진*하지 않습니다.

**<기본 톤 영문> is the *default* tone** — but if you pick a different tone in the seed, the GM follows your lead.

- <영문 참고 게임 1>
- <영문 참고 게임 2>
- <영문 참고 게임 3>

**Player agency is paramount.** The GM does not advance the plot without player input. The world *reacts*; it does not *push*.

---

## 📚 함께 보기 / See Also

- [`sigco3111/ai-gm`](https://github.com/sigco3111/ai-gm) — 공통 엔진 / shared engine
- (장르 1) [`sigco3111/ai-gm-strategy-war`](https://github.com/sigco3111/ai-gm-strategy-war) — 전략/전쟁
- (장르 2) [`sigco3111/ai-gm-fantasy-rpg`](https://github.com/sigco3111/ai-gm-fantasy-rpg) — 판타지 RPG
- (장르 3) [`sigco3111/ai-gm-sci-fi-explore`](https://github.com/sigco3111/ai-gm-sci-fi-explore) — SF 탐험
- (장르 4) [`sigco3111/ai-gm-mystery-detective`](https://github.com/sigco3111/ai-gm-mystery-detective) — 미스터리
- [ai-gm-architecture.md](https://gist.github.com/sigco3111/) — 풀 디자인 문서 (한글) / full design doc (Korean)

## 📄 라이선스 / License

Apache 2.0 — see [LICENSE](LICENSE).
````

## 양식 검증 체크리스트

새 장르 repo 만들 때 다음을 확인:

- [ ] 한국어/영문 모두에서 "미리 정해진 설정은 없습니다" 명시
- [ ] 4가지 결정 사항이 **장르 특성**에 맞게 차별화됨 (그대로 복사 ❌)
- [ ] 샘플 시드 1개 — `<장르>-<연도>` 또는 `<시리즈>-<연도>` 형식
- [ ] 샘플 시드 미리보기에 플레이어 위치/시작 조건 명시
- [ ] 장르 엔티티 JSON은 `<placeholder>` 추상화 (시드 비종속 메시지)
- [ ] `lore/seeds/<seed-name>/` 디렉토리 구조
- [ ] 한/영 병기 — 시드명/엔티티 ID는 영문 유지, 본문은 한/영 병기
- [ ] See Also에 모든 기존 장르 repo 링크
- [ ] About description: `<장르 설명> — ai-gm 코어 기반. <톤>. 샘플 시드: <시드명>. 미리지정 시드 없음.` 4요소

## 양식 사용 예시 (실제 적용된 4개 repo)

- **ai-gm-strategy-war** — 4가지 결정 = 시대/톤/맵 규모/국가. 샘플 = 고구려 391. 엔티티 = nations/characters/active_wars.
- **ai-gm-fantasy-rpg** — 4가지 결정 = 서브장르/톤/스케일/캐릭터 빌드. 샘플 = Age of Dragons 1024. 엔티티 = party/characters/active_quests.
- **ai-gm-sci-fi-explore** — 4가지 결정 = 하드/소프트 SF/톤/스케일/함선. 샘플 = Expansion Era 2247. 엔티티 = ships/characters/star_systems/active_missions.
- **ai-gm-mystery-detective** — 4가지 결정 = 시대/톤/사건 규모/탐정. 샘플 = Haberton Manor 1923. 엔티티 = case/characters/locations/clues/alibis.
