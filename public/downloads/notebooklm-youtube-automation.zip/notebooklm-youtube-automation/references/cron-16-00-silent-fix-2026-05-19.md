# Cron 16:00侯選 미전송 — 재실행 트리거 (2026-05-19)

## 상황
매일 16:00 NotebookLM侯選 크론이 `[SILENT]`으로 응답。原因: `notebooklm_selection.json`에 이미 오늘 날짜의 topics가 존재 → cron이 덮어쓰기를 방지하며侯選 마커를 출력하지 않음.

## 확인 방법
크론 출력 파일에서 아래 텍스트 확인:
```
昨天的 topics 유지 (덮어쓰기 방지)
```
+ `===== NOTEBOOKLM侯選 =====` 마커 absent.

## 재실행 트리거 (항상 이 순서)

### Step 1: selection.json 삭제
```bash
rm ~/.hermes/memory/notebooklm_selection.json
```

### Step 2: 크론 수동 재실행
```
cronjob action=run job_id=dc9a2e6aaaaa
```

### Step 3:侯選 직접 전달
크론 재실행 후侯選가 telegram으로 자동 전달되지 않으면(텔레그램 설정이 비어있을 때), 직접 실행해서侯選 목록을 수동 전송:
```bash
source ~/.hermes/venv-notebooklm/bin/activate && python3 ~/.hermes/scripts/notebooklm_selection.py
```
→侯選 목록 stdout으로 출력됨 → 크론 에이전트가侯選를 telegram으로 직접 전달.

## 핵심 원인
`notebooklm_selection.py`의 덮어쓰기 방지 로직:
```python
if existing_date == today:
    log("昨天的 topics 유지 (덮어쓰기 방지)")
    # 마커 출력 없이 조용히 종료
```
→ 크론이侯選 없이 `[SILENT]` 반환.

## 방지법 (장기적)
없음 — 매일 16:00侯選 전송이라는 크론 의도와, 사용자가 오전에 이미侯選를 선택→영상 생성한 경우라는 중복 방지 의도가 충돌. 위 트리거로 해결.