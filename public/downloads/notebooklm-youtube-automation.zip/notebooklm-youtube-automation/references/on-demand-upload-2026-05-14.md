# On-Demand NotebookLM Upload (2026-05-14)

## 시나리오
사용자가 기존 pipeline ([2,4,6] 선택 → prepare → upload) 외에 **노트북 URL을 직접 제공**하여 추가 업로드 요청.

## 노트북 정보

| 노트북 | ID | GeekNews 소스 |
|--------|----|----|
| Googlebook 공개 - AI를 위해 설계된 새로운 노트북 | `9277dfa4-39d4-4389-b5c8-93ed384f5faf` | `https://news.hada.io/topic?id=29437` |
| Gemini Intelligence - Android에 선제적 AI 기능 도입 | `9fb23010-602d-494b-beb6-007296884a40` | `https://news.hada.io/topic?id=29446` |

## 완료된 업로드

| 영상 | URL |
|------|-----|
| Googlebook 일반 영상 | `https://www.youtube.com/watch?v=hxaVt7zCTSU` |
| Googlebook Shorts | `https://www.youtube.com/watch?v=vR3vtMVQ_NQ` |
| Gemini 일반 영상 | `https://www.youtube.com/watch?v=pb3feBiUFQg` |
| Gemini Shorts | `https://www.youtube.com/watch?v=XC6xZV2PxXo` |

## FFmpeg Shorts 변환 디버깅 (핵심 발견)

**FFmpeg 4.3.2** 에서 `scale+pad` 체이닝 시 두 가지 문제 발생:

### 문제 1: Padded dimensions cannot be smaller
```
-vf "scale=1080:1920:force_original_aspect_ratio=increase,pad=1080:1920:(ow-iw)/2:(oh-ih)/2"
```
→ 16:9 입력(1280x720)을 scale하면 1080x607이 되는데, pad 필터가 "입력보다 작게 패딩 못함" 에러

**원인:** `force_original_aspect_ratio=increase`가 scale 결과를 1920 높이로 키우려 하는데, FFmpeg pad 필터의 제약상 입력より작은 출력을 수용불가

### 문제 2: boxblur + setdar/setsar 오작동
MEMORY에 기록된 known issue — `boxblur` 필터와 `setdar`/`setsar` 동시 사용 시 FFmpeg 4.3에서 오작동 가능

### 해결: Crop → Scale 방식 (FFmpeg 4.3.2 호환)

16:9 입력(1280x720)에서 9:16 출력(1080x1920)을 얻으려면:
1. 중심 기준 수평으로 `crop=405:720:437:0` (9:16 영역 추출)
2. `scale=1080:1920` (해당 영역만 1080x1920로 확대)

```python
def make_shorts_ffmpeg(input_path, output_path):
    r = subprocess.run([
        "ffprobe", "-v", "error",
        "-show_entries", "stream=width,height",
        "-of", "csv=p=0", input_path
    ], capture_output=True, text=True)
    w, h = [int(x) for x in r.stdout.strip().split(",")]
    crop_w = int(h * 9 / 16)
    crop_x = (w - crop_w) // 2
    cmd = [
        "ffmpeg", "-y", "-i", input_path,
        "-vf", f"crop={crop_w}:{h}:{crop_x}:0,scale=1080:1920",
        "-t", "59", "-c:v", "libx264", "-preset", "fast", "-crf", "23",
        "-c:a", "aac", "-b:a", "128k", "-r", "30",
        output_path
    ]
    subprocess.run(cmd, capture_output=True, text=True, timeout=300)
```

**이 crop 방식의 장점:**
- 입력 해상도에 관계없이 올바른 9:16 영역 추출
- FFmpeg 4.3.2에서 100% 동작
- blur letterbox보다 처리속도 빠름
- 출력 화질 더 선명 (확대 방식이므로)

**단점:**
- 화면 좌우가 약간 잘림 (center crop이므로)
- 배경 blur 효과를 원하는 경우 다른 방식 필요

## notebooklm CLI 참고

```bash
# 노트북 목록
notebooklm list --json

# 소스 목록
notebooklm source list -n <nb_id> --json

# 영상 다운로드 (positional — -o 없음!)
notebooklm download video --notebook <nb_id> <output_path>

# 영상 dry-run
notebooklm download video --notebook <nb_id> --dry-run
```