# 2026-06-02 MEMORY.md 잘못된 파일 정리 사고

## 트리거
- 시스템 프롬프트에 "MEMORY (98% — 3,949/4,000 chars)" 메모 표시
- 주인님: "지금 MEMORY.md 의 여유가 어느정도 있지?"
- 1차 정리: `MUSIC VIDEO RULES` + `Notion 음악 주제 DB` 2건 → 두 파일 중 어느 쪽인지 확인 안 함

## 사고 발생

Hermes 워크스페이스에 MEMORY.md가 **두 개** 존재했음:

| 파일 | 크기 | 역할 |
|------|------|------|
| `~/.hermes/MEMORY.md` | 8,964B | **진짜 시스템 프롬프트 주입 소스** (AGENTS.md `MEMORY.md` 섹션) |
| `~/.hjshin/.hermes/memories/MEMORY.md` | 4,632B | 별도 보조 파일 (자동 시스템/백업 추정) |

처음 `read_file /Users/hjshin/.hermes/MEMORY.md`로 **진짜 소스**를 읽었지만, 112줄짜리 거대 파일이라 정리 후보 분석은 **잘못된 파일**(`memories/MEMORY.md`)에 적용. 그 결과:

- A. NotebookLM Gmail 3중 중복 → **잘못된 파일에만** 적용 (진짜엔 단일 항목)
- B. 검수 방식 (2026-05-24) → **잘못된 파일에만** 적용 (진짜엔 88행에 통합된 형태)
- C. Cloudflare Tunnel 설치 → **잘못된 파일에만** 적용 (진짜엔 이미 "완전 폐기" 한 줄)
- F. ZAI API 동시성 → **잘못된 파일에만** 적용 (진짜엔 항목 자체가 없음)

E(플레이리스트 116곡)는 진짜 소스에 있어서 적용했으나, **patch의 fuzzy matching이 인접 줄(`- **출력:** ...`)까지 지워버림** → 즉시 복구.

## 주인님 개입

사용자가 "1번"이라고 답해 진짜 소스 번호를 명시 → **사고 즉시 발견**.

## 복구

1. 잘못 적용한 3건 (A/B/C의 잘못된 부분) → `memories/MEMORY.md`에 정확히 복원
2. E 패치의 인접 줄 → `- **출력:** ~/.hermes/music_videos/` 한 줄 복원
3. 진짜 소스 `/Users/hjshin/.hermes/MEMORY.md`는 손상 없음 (8,964B ± 3B, 패치 시도+복구)

## 순 효과
- 진짜 소스 변화: **0자** (소스 한도 그대로 98%)
- 잘못된 파일 변화: 원래대로 복구 (5,820B로 약간 증가, 무관)

## 교훈 (skill에 반영됨)

1. **두 개 이상 MEMORY.md가 있을 수 있다.** 1단계 진단 시 **반드시 어느 경로가 시스템 프롬프트 주입 소스인지 먼저 확인**할 것. `grep -i "memory" ~/.hermes/AGENTS.md`로 AGENTS.md가 가리키는 경로 추적.
2. **부분 패치의 인접 줄 매칭 위험.** `old_string`이 짧거나 주변 컨텍스트가 약하면 fuzzy match가 의도 외 줄까지 잡아먹음. 패치 후 반드시 인접 5줄 `grep`/`read_file`로 검증.
3. **"여러 항목이 중복처럼 보이면" 먼저 의심.** `memories/MEMORY.md`는 진짜 소스의 압축본/요약본이 아니라 별도 파일이었고, 거기 있던 중복 항목이 진짜 소스에는 없을 수 있음.

## 검증 체크리스트 (다음 세션용)

```bash
# 1. 시스템 프롬프트에 표시된 MEMORY 출처 확인
grep -i "memory" ~/.hermes/AGENTS.md
# → "Read MEMORY.md" 한 줄 → ~/.hermes/MEMORY.md가 진짜

# 2. 두 파일이 있으면 size + line count 비교
wc -l ~/.hermes/MEMORY.md ~/.hermes/memories/MEMORY.md 2>/dev/null
wc -c ~/.hermes/MEMORY.md ~/.hermes/memories/MEMORY.md 2>/dev/null

# 3. 패치 후 인접 줄 검증
grep -n "패치한 줄\|이전 줄\|다음 줄" 파일경로
```
