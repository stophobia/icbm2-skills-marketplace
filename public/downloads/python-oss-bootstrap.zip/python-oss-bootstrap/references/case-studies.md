last_updated: 2026-06-17

# 실전 사례 — hwp2md, md-doctor, cron-doctor, kakao-summary (kmsg-doctor), opencode-trading

> **시계순 읽기 권장**: 사례 1 → 2 → 3 → 4 → 5. 각 사례가 이전 사례의 학습을 어떻게 활용하는지 보임.

---

## 사례 1: hwp2md (2026-06-08, v1.0.0)

**트리거**: "오랜만에 가벼운 서브프로젝트" + "hwp2md 만들어줘"
**소요**: 단일 세션 ~30분
**결과**: 8/8 테스트 통과, v1.0.0 (1.0 정식 출시)

### 시퀀스
1. gh repo create → clone
2. pyproject.toml + LICENSE + .gitignore
3. 소스: `__init__` (convert/batch_convert), core (dispatcher), cli, exceptions
4. 백엔드: hwpx (0.2.0 예정 스텁), hwp5 (0.2.0 스텁)
5. 스모크 테스트 6개
6. README (한글 + 영문) + CHANGELOG
7. CI + action.yml
8. v0.1.0 태그 → 푸시
9. About 한글화 (1차 영문 → 2차 한글)

### 배운 점
- **백엔드 디스패처 패턴**: `core.py`가 `hwp/hwpx` 확장자 보고 분기. 새 포맷 추가 = 새 파일 + dispatcher 1줄.
- **GitHub About 영문 → 한글**: 사용자 요청으로 2차 한글화. 처음부터 한글로 가는 게 더 빠름.

---

## 사례 2: md-doctor (2026-06-09, v0.1.0)

**트리거**: "hwp2md 완료했음. 다음 서브프로젝트?" → 추천 3개 거절 → "md-doctor 진행하자"
**소요**: 단일 세션 ~25분
**결과**: 16/16 테스트 통과, v0.1.0

### 시퀀스 (hwp2md와 거의 동일, 그래서 자동화 가치가 입증됨)
1. gh repo create → clone
2. pyproject.toml (실패 1회: 이메일 형식) + .gitignore + pytest.ini
3. `models.py` 분리 (이게 새로운 학습!)
4. 소스: __init__, __main__, cli, core, models, exceptions, checks/{token_stats, heading_consistency, dead_links 스텁, broken_images 스텁}
5. 스모크 테스트 16개
6. README (한글 + 영문 부록) + CHANGELOG + CONTRIBUTING (BaseCheck 상속 튜토리얼)
7. CI (Python 3.9-3.12 매트릭스) + action.yml (composite)
8. v0.1.0 태그 → 푸시
9. About 한글화 (처음부터 한글)

### 새 학습 (hwp2md와 차이)
- **순환 import**: core ↔ checks 구조에서 발생 → `models.py` 분리 + lazy import로 해결. **다음 프로젝트부터는 처음부터 적용**.
- **`pyproject.toml` authors.email 함정**: PEP 621 위반으로 `pip install -e .` 깨짐 → 이메일 빼고 `name`만.
- **argparse `nargs="?"`**: `--list-checks` 같은 부속 명령과 동시 사용 가능하게.
- **체크 모듈 패턴**: `BaseCheck` 상속 → `default_checks()` 레지스트리 → 0.1.0엔 2개 활성, 2개는 스텁. hwp2md의 백엔드 스텁 패턴과 동일.

---

## 사례 3: cron-doctor (2026-06-16, v0.1.0 — Phase 0)

**트리거**: "새 프로젝트를 시작하고 싶네? 뭐가 좋을까?" → 추천 4개 중 "Cron YAML 검증기로 하자" 선택 → "리드미와 About은 한글로, 다른 PC에서 작업"
**소요**: 단일 세션 ~20분
**결과**: Phase 0 스켈레톤 (README/CHANGELOG/CONTRIBUTING/LICENSE + 5개 검사 모듈 stub + 2개 파서 stub) + v0.1.0 태그

### Phase 0 변형의 핵심 차이 (사례 1·2와 다른 점)
- **소스 코드는 다른 PC에서 작업** → 이 PC는 README/About + 스켈레톤(빈 함수 + docstring 가이드)만
- **브레인스토밍 단계 추가**: 결정 포인트(이름/범위/CLI/테스트/README)별 옵션 2~3개 + 추천 → "그대로 진행해" 받음 → 즉시 실행. 음악/디자인 워크플로와 동일 패턴.
- **README 다층 옵션 구조**: 1-옵션 단순 거부, **결정 사항 4가지 + 샘플 옵션 + 직접 작성(고급) + 4단계 로드맵** 등 단계적 깊이 선호
- **각 스텁 파일에 docstring 가이드**: 다른 PC 작업자가 빈 파일 보고 헤매지 않게. 예: `Y001_yaml.py`엔 "PyYAML 의존성 vs 자체 구현 trade-off" 결정 가이드, `cli.py`엔 "`nargs='?'` 잊지 말 것" 함정 알림, `models.py`엔 "core와 checks 모두 models만 직접 import" 패턴

### 시퀀스
1. `mkdir -p ~/.openclaw/workspace/cron-doctor` (워크스페이스에 격리)
2. `write_file` 4종: README.md (다층 옵션, 9.5KB) / CHANGELOG.md / CONTRIBUTING.md / LICENSE / .gitignore
3. `mkdir -p src/cron_doctor/checks src/cron_doctor/parsers tests/fixtures .github/workflows` (⚠️ 한 줄 mkdir가 가끔 race condition)
4. `touch` 23개 파일 (스켈레톤 + .gitkeep)
5. `write_file`로 각 스텁에 docstring 가이드 작성 (12개 파일)
6. `git init -b main && git add -A && git commit`
7. `gh repo create sigco3111/cron-doctor --public --description "<한글>" --source=. --remote=origin --push` (--license 빼고 — 일부 gh 버전에서 help만 출력되는 현상 회피)
8. `git tag -a v0.1.0 -m "..." && git push origin v0.1.0`
9. `gh repo view`로 description + license + visibility 확인

### 새 학습 (사례 1·2에 없는 것)
- **Phase 0 변형 = 부트스트랩의 정당한 부분**: 코드 작업은 다른 곳에서, README/스켈레톤/문서만이라도 가치 있음. **사용자가 명시적으로 "다른 PC에서" 요청**할 때만 사용.
- **스텁 docstring 가이드 = 핸드오프 도구**: 다른 PC 작업자(또는 미래의 나)에게 "이 파일은 이런 책임, 이런 trade-off, 이런 패턴" 알려주기. ai-gm 시리즈의 README가 했던 역할과 같음.
- **`mkdir -p` race condition**: `mkdir -p A B/C` 직후 `touch B/C/x.py`가 같은 한 줄 안에 있을 때, 가끔 B/C가 아직 안 만들어진 상태로 touch가 실행됨. **안전한 패턴**: `mkdir -p`를 한 번 더 실행하거나 dir을 한 줄씩 만들기.
- **`gh repo create --license MIT` 옵션 문제**: 일부 gh 버전에서 `--license` 플래그 위치가 잘못 인식돼 도움말만 출력됨. **안전한 패턴**: `--license` 빼고 repo 생성, MIT 라이선스는 `LICENSE` 파일 푸시로 처리.
- **브레인스토밍 2-3 옵션 + 추천 → 선택**: 음악 창작 / 프로젝트 디자인 / OSS 부트스트랩 모두 공통 패턴. **사용자 "그대로 진행해"가 가장 흔한 답** — 옵션 4~5개 넘지 않게, 추천은 명확히.

---

## 사례 4: kmsg-doctor → kakao-summary (2026-06-16, v0.1.0 — Phase 1 + 이름 변경)

**트리거**: cron-doctor (Phase 0) 완료 직후 사용자가 첨부 카톡 카드뉴스 이미지 + `kmsg-mcp` GitHub URL 공유 → "이걸로 단톡방 카드뉴스 요약할 수 있나?" → 브레인스토밍 4개 옵션 → "에르메스 PC에서 직접 작업" 선택 → **v0.1.0 완성 후 사용자가 "kmsg-doctor는 적합하지 않은것 같아"로 rename 요청** → kakao-summary로 변경

**소요**: 단일 세션 ~40분 (35분 부트스트랩 + 5분 이름 변경)
**결과**: 9개 모듈 + 32/32 테스트 통과 (0.14초) + v0.1.0 태그 + GitHub public

### Phase 1 변형의 핵심 차이 (사례 1·2·3과 다른 점)
- **이 PC에서 직접 작업** → 소스 코드를 직접 작성, 스텁 아님. 핵심 4개 모듈(`kmsg_client`, `prefilter`, `cache`, `summarizer`)은 실제 동작
- **외부 도구 wrapping** — kmsg-mcp라는 별도 MCP 서버를 stdio subprocess + JSON-RPC 2.0으로 통합. pip 의존성 0개 유지하면서 외부 도구 기능 흡수
- **SQLite 캐시** — kmsg-mcp의 `limit=100` 한계를 로컬 DB로 우회. 1000개+ 영구 보관 + 증분 sync + 시간 윈도우 쿼리
- **결정론적 v0.1.0** — LLM 호출 0회. 시간 갭 30분 기준 토픽 그룹핑. 비용 $0, 즉시 응답. v0.2.0+ 에서 LLM 추가 예정
- **다중 출력 포맷** — 터미널 컬러 / Telegram Markdown / JSON. CLI `--format` 옵션으로 선택
- **사용자 첨부 이미지 → 형식 결정** — "이 카톡 카드뉴스처럼 만들어줘" 식 요청이 들어오면 첨부 이미지 분석 + JSON fixture로 시뮬레이션 후 같은 형식 생성
- **이름 변경 워크플로** (Phase 1.5) — 1세션 만에 kmsg-doctor → kakao-summary로 rename (사용자 "프로젝트명으로 적합하지 않음" 신호)

### 시퀀스
1. **브레인스토밍** (5 결정 포인트) — 이름(kmsg-doctor 시리지 일관성) / 범위(카드뉴스+캐시) / 통합 방식(stdio subprocess) / 출력(text+telegram+json) / 저장소(SQLite). 옵션 A/B/C + 추천 → "진행해"
2. `mkdir -p ~/.openclaw/workspace/kmsg-doctor` + `python-oss-bootstrap` 스킬 로드
3. `pyproject.toml` (zero-deps, scripts=kmsg-doctor) + `.gitignore` (+ `*.sqlite` 추가)
4. **소스 9개 모듈 직접 작성** (Phase 0의 stub과 다름):
   - `models.py` — RawMessage, Card, CardNews (frozen dataclass + Literal type)
   - `exceptions.py` — KmsgDoctorError + 5 서브클래스
   - `kmsg_client.py` — **외부 도구 stdio 클라이언트** (subprocess + JSON-RPC, ⚠️ 4개 함정 주의)
   - `prefilter.py` — _SIMPLE_REACTIONS frozenset + _SYSTEM_PATTERNS tuple (substring 매칭)
   - `cache.py` — SQLite + ID-based upsert + 시간 윈도우 쿼리
   - `summarizer.py` — group_by_topic(30분 갭) + extract_speakers/request + generate_card_title
   - `formatter.py` — format_text(컬러) + format_telegram(Markdown) + format_json
   - `core.py` — sync_chat / summarize_chat 오케스트레이션
   - `cli.py` — argparse 4 서브 명령 (sync/summarize/status/chats) + 단축 사용
5. **CLI entry point** — `pyproject.toml` `[project.scripts] kmsg-doctor = "kmsg_doctor.cli:main"`
6. **venv + 설치** — `rm -rf venv && /usr/bin/python3 -m venv venv && pip install -e ".[dev]"` (⚠️ system python 3.8.8 함정)
7. **fixture 작성** — `tests/fixtures/sample_messages.json` (첨부 이미지의 실제 카드뉴스 3장과 매칭되는 시나리오)
8. **단위 테스트 32개** — conftest.py + test_prefilter(8) + test_cache(6) + test_summarizer(8) + test_formatter(4) + test_cli(6)
9. **pytest 1차** — 31/32 통과, 1개 실패 (system message "홍길동님이 입장하셨습니다" 가 substring 패턴으로 안 잡힘) → _SYSTEM_PREFIXES → _SYSTEM_PATTERNS (substring) 변경
10. **pytest 2차** — 32/32 통과 (0.14초)
11. **CLI 동작 검증** — `kmsg-doctor --version` + `kmsg-doctor --help` + `/Users/.../venv/bin/python3 -c "..."`로 실제 카드뉴스 3장 생성 확인
12. **README (다층 옵션 + 아키텍처 + 토큰 비용)** — 12KB 한/영 병기, 11개 섹션 (동기/설치/CLI/시나리오/아키텍처/토큰/디렉토리/로드맵/주의/감사)
13. **CHANGELOG** (Keep a Changelog 1.1.0) + **CONTRIBUTING** (4단계 튜토리얼: 새 필터/새 포맷터/디버깅/아키텍처)
14. **git init -b main** + commit + `gh repo create sigco3111/kmsg-doctor --public --description "<한글>" --source=. --remote=origin --push` (--license 빼고)
15. **v0.1.0 태그** 푸시 + `mcp_ddg_search_fetch_content`로 GitHub 페이지 렌더링 확인

### Phase 1.5 — 이름 변경 (kmsg-doctor → kakao-summary)

**사용자 트리거**: "kmsg-doctor는 프로젝트명으로 적합하지 않은것 같아. 다른 이름을 제안해봐"

**사용자 두 번째 트리거**: "kakao 단톡방 내용 요약을 직관적으로 알수 있는 제목이면 좋겠는데..."

**네이밍 의사결정** (사용자 선호 + 옵션 제시):
- A. `chat-doctor` (md-doctor/cron-doctor 시리즈 통일)
- B. `kakao-doctor` (kmsg-mcp 의존 명시)
- C. `cardnews` (직관적, 기능 중심)
- D. `kakao-digest` (digest = 요약의 IT/영어 컨벤션)
- E. `kakao-summary` (직관적, 한국어 "요약" 영어 컨벤션)
- F. `kakao-cardnews` (카드뉴스 명시)
- → 사용자 선택: **E. kakao-summary** ("직관적 + kakao + 기능명시" 모두 만족)

**이름 변경 6단계 시퀀스** (5분):
1. **브레인스토밍** (8개 옵션 → 4개 압축 → 추천 → 사용자 결정)
2. **`gh repo rename kakao-summary --yes`** (owner prefix 없이! `/` 때문에 거부됨)
3. **모든 파일의 옛 이름 일괄 변경** (sed):
   ```bash
   # Python 소스: import + module references
   find src tests -name "*.py" -exec sed -i '' 's/kmsg_doctor/kakao_summary/g' {} +
   # README/CHANGELOG/CONTRIBUTING: 하이픈 표기 + 언더스코어 표기 모두
   sed -i '' 's/kmsg-doctor/kakao-summary/g' README.md CHANGELOG.md CONTRIBUTING.md
   sed -i '' 's/kmsg_doctor/kakao_summary/g' README.md CHANGELOG.md CONTRIBUTING.md
   # 도큐먼트 내부에 남은 하이픈 표기 한 번 더
   find src tests -name "*.py" -exec sed -i '' 's/kmsg-doctor/kakao-summary/g' {} +
   ```
4. **디렉토리 rename** — `git mv src/kmsg_doctor src/kakao_summary` (git이 자동 감지, history 보존)
5. **venv 재생성 + pytest 재검증** — 32/32 통과 확인
6. **별도 커밋 + v0.1.0 태그 force-update**:
   ```bash
   git add -A
   git commit -m "refactor: rename kmsg-doctor → kakao-summary
   - <변경 이유>
   - <검증 결과>"
   git tag -d v0.1.0 && git push origin :refs/tags/v0.1.0
   git tag -a v0.1.0 -m "v0.1.0 - ... (프로젝트명: kakao-summary, 2026-06-16 rename)"
   git push origin v0.1.0
   ```

### 새 학습 (사례 1·2·3에 없는 것)
- **Phase 1 변형 = 풀 부트스트랩을 한 세션에**: 사용자가 "이번 PC에서 작업" / "에르메스 PC에서" 식으로 명시하면 Phase 0가 아닌 정식 10단계를 한 번에. 핵심 모듈 3~4개는 실제 동작, 30~50개 테스트 통과. **소요 35~45분**.
- **외부 도구 wrapping = 새로운 OSS 클래스**: kakao-summary는 자체 로직뿐 아니라 **다른 도구의 Python wrapper**. 이런 OSS는 (a) `*_client.py` 모듈이 외부 도구 stdio/subprocess 통합, (b) 나머지 로직은 우리 로직. README에 "전제 조건: X 설치 + 권한 필요" 명시 필수 (사용자 06-11 "데이터 ≠ 표시" 원칙).
- **사용자 첨부 이미지 → 형식 결정**: "이 카톡 카드뉴스처럼 만들어줘" → 첨부 이미지 분석 → JSON fixture로 시뮬레이션 → 같은 형식 생성. **fixture-first 개발**: 실제 외부 도구 없이도 형식 검증 가능. 단, **실제 외부 도구 호출은 사용자 PC에서** (이 PC에는 카톡 없음).
- **사용자 컨펌 기반 동적 길이 README**: README 12KB (cron-doctor의 9.5KB보다 김). 이유는 외부 의존성/kmsg-mcp 통합이라는 새 클래스라 **아키텍처 다이어그램 + 토큰 비용 분석 + 외부 의존 명시**가 필요. 짧은 README는 충분한 정보를 못 줌.
- **stdout 컬러 = formattable**: `format_text(use_color=False)` 옵션으로 CI에서도 깨지지 않게. Telegram Markdown는 `*` `_` `` ` `` escape 필수 (`text.replace("*", "\\*")`).
- **system message prefix → substring 패턴**: "님이 입장하셨습니다" prefix로 매칭하면 "홍길동님이 입장하셨습니다"가 안 잡힘. **substring 매칭**으로 변경 ("입장하셨습니다" 같은 핵심 동사만).
- **fixture-first 테스트가 진짜 회귀 방지**: sample_messages.json이 첨부 이미지의 카드뉴스 3장과 정확히 매칭 → `test_summarizer.py::test_summarize_creates_cardnews`로 fixture → 카드뉴스 형식 검증. **이게 다층 README + 32 테스트의 가치**.
- **이름 변경 워크플로 (Phase 1.5)**: 1세션 만에 부트스트랩 완료 + 이름 변경 모두 가능. **사용자 후회 신호는 1세션 내 발생** — 사용자가 "kmsg-doctor는 적합하지 않은것 같아"라고 했을 때 즉시 옵션 3~5개 + 추천을 다시 제시. **사용자 "kakao-summary로 하자" 같은 답을 받으면 5분 만에 6단계 rename 워크플로 실행**.
- **이름 결정 후회 패턴 = 두 번째 교훈**: 1차 결정 (kmsg-doctor) 시 "md-doctor / cron-doctor / **kmsg-doctor**" 시리즈 일관성 추천을 받아 진행했지만, 사용자는 "직관성"을 더 중시. **다음부터는 브레인스토밍 단계에서 "기능 명시 + 도메인 직관성" 모두 만족하는 옵션을 추천**해야 함. 시리즈 일관성만으로 추천하면 사용자가 1세션 만에 rename 요청.
- **`gh repo rename` owner prefix 함정**: `gh repo rename sigco3111/kakao-summary`는 `/` 때문에 "New repository name cannot contain '/' character" 에러. `gh repo rename <new-name> --yes` 형식만. ⚠️ `gh repo rename --help` 출력에는 명시 안 됨 — 도움말이 거짓말.
- **GitHub redirect는 자동**: repo rename 후 옛 URL `https://github.com/sigco3111/kmsg-doctor`는 그대로 살아있고 `kakao-summary`로 자동 리다이렉트. **사용자가 기존 URL로 클론해도 안전**. 단, 로컬 `git remote` URL은 수동 업데이트 필요.
- **v0.1.0 태그 force-update 패턴**: 같은 SHA에 같은 태그를 다시 발행하려면 로컬/원격 모두 삭제 후 재생성. 또는 v0.1.1 새 태그 발행 (이게 git 모범 사례). kakao-summary는 v0.1.0 그대로 force-update (이름만 바뀌었지 의미는 같음).

### 외부 도구 wrapping 의사결정 트리 (2026-06-16 정리)

새 OSS가 다른 도구의 wrapper일 때 다음을 결정:

| 결정 포인트 | 옵션 | 추천 | 이유 |
|---|---|---|---|
| 통합 방식 | pip 의존성 / subprocess / fork | **subprocess (stdio JSON-RPC)** | zero-deps 유지 + 버전 분리 + 격리 |
| 응답 파싱 | 라이브러리 / 직접 JSON | 직접 JSON (try/except 견고) | 의존성 0 + 포맷 변경 시 한 곳만 수정 |
| 캐시 | SQLite / JSON 파일 / 없음 | SQLite (ID-based upsert) | 시간 윈도우 쿼리 + 증분 sync에 최적 |
| LLM 통합 시점 | v0.1.0부터 / v0.2.0+로 연기 | **v0.2.0+로 연기** | 결정론적 v0.1.0 = 비용 0 + 즉시 응답, 사용자가 가치 검증 후 LLM 추가 |
| 출력 포맷 | 1개 / 2개 / 3개+ | 3개 (text/telegram/json) | 사용자 패턴 (텔레그램 DM) + CI/훅 통합 |

→ 이 의사결정 트리는 kakao-summary가 처음 작성한 것이며, 다음 외부 도구 wrapping OSS (예: `notion-doctor`, `github-doctor` 등) 부트스트랩 시 그대로 재사용.

### 네이밍 의사결정 트리 (2026-06-16 kakao-summary 후회 패턴)

| 결정 포인트 | 옵션 | 추천 (2026-06-16 이전) | **수정된 추천 (2026-06-16 이후)** | 이유 변경 |
|---|---|---|---|---|
| 이름 | 시리즈 통일 vs 직관성 | 시리즈 통일 (md-doctor, cron-doctor) | **직관성 (기능 + 도메인)** | 사용자가 1세션 만에 rename 요청했음 |
| 신조어 사용 | OK / 회피 | OK (kmsg-doctor) | **회피 (kakao-summary)** | 신조어는 다른 사람이 검색/기억 어려움 |
| 도메인 prefix | 있음 / 없음 | 있음 (kmsg-) | **있되 명확한 브랜드 (kakao-) 또는 범용 (chat-)** | "kmsg"는 kmsg-mcp 종속처럼 보임 |

→ **다음 OSS 부트스트랩 시**: 브레인스토밍 단계에서 "기능 명시 + 도메인 직관성" 모두 만족하는 옵션을 추천. 시리즈 일관성은 부수적 고려사항 (만드는 게 우선, 통일은 나중에 `chat-doctor` 시리즈로 묶어도 됨).

---

## 사례 5: kakao-summary decommission (2026-06-16, 같은 세션, 사용자 명시 요청)

**트리거**: v0.1.0 완성 + 실제 카톡 연동 27개 성공 후 사용자가 "어제 내용 정리" 요청 → kmsg의 "최근 N개" 한계로 어제 데이터 fetch 불가 → 사용자 "해당 프로젝트를 제거하자. 저장소도 제거해줘."

**소요**: ~10분 (5단계 절차)
**결과**: GitHub repo 삭제 + 모든 로컬/시스템 잔재 100% 정리

### 5단계 시퀀스 (decommission)
1. **GitHub repo 삭제**: `gh repo delete sigco3111/kakao-summary --yes` + 404 확인
2. **로컬 워크스페이스 정리**: `trash ~/.openclaw/workspace/kakao-summary` + `trash ~/kmsg-mcp/`
3. **외부 의존성 uninstall**: `brew uninstall channprj/tap/kmsg` (⚠️ transitive deps python@3.13, ripgrep, fzf 자동 제거됨) + `trash ~/.local/share/kmsg-mcp/` + `trash ~/.cache/kakao-summary/` + `trash ~/Library/{Logs,Caches}/Homebrew/kmsg*`
4. **셸 환경변수 정리**: `sed -i '' '/^# kakao-summary:/d; /^export KMSG_BIN=/d' ~/.zshrc`
5. **메모리 업데이트** (선택): memory tool drift 가능성 → 다음 세션에 안전 정리

### 새 학습 (사례 1·2·3·4에 없는 것)
- **decommission = 작업의 정당한 부분**: 사용자가 명시적으로 "제거" 요청 시 5단계 절차는 정상 작업. **trash > rm 원칙** (사용자 06-11 선호, 복구 가능).
- **brew uninstall transitive deps 부작용**: kmsg uninstall 시 **python@3.13 (74MB), ripgrep, fzf** 자동 제거. **다른 용도로 쓰고 있었다면 `brew install` 재설치 필요**. 예방: `brew deps <formula> --installed`로 미리 확인.
- **GitHub redirect는 보존**: `kakao-summary` 삭제 전 `kmsg-doctor`로 rename했었던 history는 그대로 살아있음 (GitHub redirect chain). 최종적으로 repo 삭제되면 redirect chain도 사라짐.
- **memory tool drift**: `MEMORY.md`에 같은 날 추가된 다른 entry가 있어서 round-trip 거부됨. 백업은 자동 생성 (`.bak.<timestamp>`). **다음 세션에 한 번에 정리하는 게 안전**.
- **사용자 06-11 "데이터 ≠ 표시" 원칙의 OSS 적용**: kakao-summary는 "어제 데이터"라는 사용자 요구를 충족 못 시키는 도구. **사용자가 원하는 것을 못 주는 도구는 빠르게 decommission** (1세션 만에 결정). **decommission도 작업의 일부** — 굳이 더 붙잡고 fix하지 않음.

### 검증된 절차
```bash
# 1. GitHub
gh repo delete sigco3111/<name> --yes
gh repo view sigco3111/<name>  # 404 확인

# 2. 로컬 (trash 우선)
trash ~/.openclaw/workspace/<name> ~/.<name>-mcp/

# 3. 외부 의존성 + 잔재
brew uninstall <tap>/<formula>  # ⚠️ transitive deps 점검
trash ~/.local/share/<name>-mcp/ ~/.cache/<name>/ ~/Library/{Logs,Caches}/Homebrew/<formula>*
find ~ -maxdepth 5 -iname "*<name>*"  # 출력 없으면 깨끗

# 4. 환경변수
if grep -q "<NAME>" ~/.zshrc 2>/dev/null; then
  sed -i '' '/^# <package>:/d; /^export <NAME>=/d' ~/.zshrc
fi

# 5. 메모리 (선택, drift 가능)
# memory tool이 거부하면 다음 세션에 정리
```

---

## 시퀀스 요약 (재현 가능한 10단계)

```bash
gh repo create sigco3111/<name> --public --description "<한글>" --license MIT
git clone https://github.com/sigco3111/<name>.git ~/Documents/<name>/
cd ~/Documents/<name>
# 1. .gitignore (Python std)
# 2. pyproject.toml (setuptools>=68, name만, zero-deps, scripts)
# 3. pytest.ini
# 4. src/<pkg>/{__init__, __main__, cli, core, models, exceptions}
# 5. src/<pkg>/<sub>/{__init__, <impl1>, <impl2> 스텁}
# 6. tests/test_cli.py (6~16개)
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest  # 6+ 통과 확인
md-doctor <(echo "# test")  # CLI 스모크

# 7. README.md (한글 + 영문 부록, 다층 옵션)
# 8. CHANGELOG.md
# 9. CONTRIBUTING.md
# 10. .github/workflows/ci.yml + action.yml
git add -A
git commit -m "feat: initial project skeleton (v0.1.0) ..."
git push -u origin main
git tag -a v0.1.0 -m "..."
git push origin v0.1.0
gh repo edit sigco3111/<name> --description "<한글>"
```

## Phase 0 변형 시퀀스 (다른 PC에서 작업 케이스)

```bash
# 1. 워크스페이스에 디렉토리
mkdir -p ~/.openclaw/workspace/<name>
cd ~/.openclaw/workspace/<name>

# 2. 파일 4종 작성 (write_file)
README.md (다층 옵션 구조, "Phase 1+ 작업은 다른 PC에서" 명시)
CHANGELOG.md (0.1.0 Added/Notes만)
CONTRIBUTING.md (4단계 튜토리얼)
LICENSE (MIT)
.gitignore (Python std)

# 3. 소스 스켈레톤
mkdir -p src/<pkg>/<sub1> src/<pkg>/<sub2> tests/fixtures .github/workflows
touch src/<pkg>/__init__.py src/<pkg>/__main__.py ... (모든 .py + .gitkeep)
# 각 스텁에 docstring 가이드 작성 (write_file) — 책임/trade-off/패턴/코드 골격

# 4. git init + 커밋
git init -b main
git add -A
git commit -m "docs: initial project skeleton (v0.1.0) - Phase 0"

# 5. gh repo create (--license 빼고 안전하게)
gh repo create sigco3111/<name> --public \
  --description "<한글 한 줄>" \
  --source=. --remote=origin --push

# 6. 태그 푸시
git tag -a v0.1.0 -m "v0.1.0 - Phase 0: 스켈레톤 + 문서"
git push origin v0.1.0
```

## Phase 1 변형 시퀀스 (이 PC에서 직접 풀 부트스트랩)

```bash
# 1. 브레인스토밍 (5 결정 포인트, 옵션 A/B/C + 추천)
#    ⚠️ 이름은 "기능 + 도메인 직관성" 모두 만족하는 옵션 추천
# 2. 워크스페이스 + pyproject.toml + .gitignore (Phase 0와 동일)
# 3. 소스 9개 모듈 직접 작성 (스텁 아님, 핵심 3~4개는 실제 동작)
# 4. CLI entry point 등록
# 5. venv + pip install -e ".[dev]" (system python 버전 확인!)
# 6. fixture + 단위 테스트 6~32개
# 7. pytest + 실패 디버그 (1~2회 반복)
# 8. README (다층 옵션 + 아키텍처 + 토큰 비용) + CHANGELOG + CONTRIBUTING
# 9. git init + commit + gh repo create + push + v0.1.0 태그
# 10. GitHub 페이지 렌더링 확인
```

## Phase 1.5 변형 시퀀스 (이름 변경 워크플로, 5분)

```bash
# 1. 브레인스토밍 (옵션 3~5개 + 추천)
# 2. gh repo rename
gh repo rename <new-name> --yes  # owner prefix 없이!

# 3. git remote URL 업데이트
git remote set-url origin https://github.com/sigco3111/<new-name>.git

# 4. 모든 파일의 옛 이름 일괄 변경
find src tests -name "*.py" -exec sed -i '' 's/<old_module>/<new_module>/g' {} +
sed -i '' 's/<old-name>/<new-name>/g' README.md CHANGELOG.md CONTRIBUTING.md
sed -i '' 's/<old_module>/<new_module>/g' README.md CHANGELOG.md CONTRIBUTING.md
find src tests -name "*.py" -exec sed -i '' 's/<old-name>/<new-name>/g' {} +

# 5. 디렉토리 rename (git mv)
git mv src/<old_module> src/<new_module>

# 6. venv 재생성 + pytest 재검증
rm -rf venv && /usr/bin/python3 -m venv venv
source venv/bin/activate
pip install -e ".[dev]"
pytest  # 32/32 통과 확인

# 7. 별도 커밋 + v0.1.0 태그 force-update
git add -A
git commit -m "refactor: rename <old> → <new> ..."
git tag -d v0.1.0 && git push origin :refs/tags/v0.1.0
git tag -a v0.1.0 -m "v0.1.0 - ... (rename)" && git push origin v0.1.0
```

## Phase 2 — Decommission 시퀀스 (제거, ~10분)

```bash
# 1. GitHub repo 삭제
gh repo delete sigco3111/<name> --yes
gh repo view sigco3111/<name>  # 404 확인

# 2. 로컬 (trash 우선)
trash ~/.openclaw/workspace/<name> ~/.<name>-mcp/

# 3. 외부 의존성 + 잔재
brew uninstall <tap>/<formula>  # ⚠️ transitive deps 점검
trash ~/.local/share/<name>-mcp/ ~/.cache/<name>/ ~/Library/{Logs,Caches}/Homebrew/<formula>*
find ~ -maxdepth 5 -iname "*<name>*"  # 출력 없으면 깨끗

# 4. 환경변수
if grep -q "<NAME>" ~/.zshrc 2>/dev/null; then
  sed -i '' '/^# <package>:/d; /^export <NAME>=/d' ~/.zshrc
fi

# 5. 메모리 (선택, drift 가능)
# memory tool이 거부하면 다음 세션에 정리
```

## 다른 PC에서 작업 시작 (Phase 0 결과물 받기)

```bash
git clone https://github.com/sigco3111/<name>.git
cd <name>
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest
```

**예상 시간: 3분** (clone + 설치 + 테스트). 이게 무사히 통과하면 환경 검증 끝.

---

## 📊 6개 사례 메타 비교

| | hwp2md | md-doctor | cron-doctor | kmsg-doctor | kakao-summary | **opencode-trading** |
|---|---|---|---|---|---|---|
| **날짜** | 2026-06-08 | 2026-06-09 | 2026-06-16 | 2026-06-16 (1차) | 2026-06-16 (rename) | **2026-06-17** |
| **소요** | ~30분 | ~25분 | ~20분 | ~35분 | ~5분 (rename) | **~25분** |
| **버전** | v1.0.0 | v0.1.0 | v0.1.0 (Phase 0) | v0.1.0 (Phase 1) | v0.1.0 (force-update) | **v0.1.0 (Phase 0)** |
| **테스트** | 8 통과 | 16 통과 | 스텁 (다른 PC) | 32 통과 | 32 통과 (재검증) | **18 통과 (0.24s)** |
| **변형** | 정식 10단계 | 정식 10단계 | Phase 0 | Phase 1 + 외부 도구 | Phase 1.5 (rename) | **Phase 0 (adaptor)** |
| **핵심 학습** | 백엔드 디스패처 | models.py + nargs="?" | 스텁 docstring + mkdir race | stdio JSON-RPC + SQLite + LLM-free | 이름 변경 + 네이밍 후회 | **zero-deps adaptor + sys.exit() 함정** |
| **클래스** | 변환 (transcoding) | 진단 (diagnosis) | 진단 (diagnosis) | wrapping | wrapping (decomm) | **adaptor (포맷 변환)** |
| **README 크기** | 작음 | 작음 | 9.5KB (다층) | 12KB (다층 + 아키텍처) | 12KB (재사용) | **10.4KB (다층)** |
| **외부 의존** | hwp5/olefile | stdlib only | stdlib only | kmsg-mcp (subprocess) | kmsg-mcp (subprocess) | **TradingCodex (zero-deps, stdlib tomllib)** |
| **이름 변경 횟수** | 0 | 0 | 0 | 0 | 1 (kmsg-doctor → kakao-summary) | **0 (브레인스토밍에서 한 번에 성공)** |
| **decommission** | 아니오 | 아니오 | 아니오 | 예 (2026-06-16 같은 세션) | — | 아니오 |
| **CLI subcommand handler** | 미사용 (단일 명령) | argparse subparsers | argparse subparsers | argparse subparsers | argparse subparsers | **argparse subparsers (함정 21번 발생 → 수정)** |

**시간이 줄어드는 이유 (또는 늘나는 이유)**: 매번 같은 함정을 학습해서 사전에 회피. `authors` 이메일, `nargs="?"`, `mkdir` race, `gh --license` 모두 1~3번째 만에 마스터. kakao-summary (kmsg-doctor)는 시간이 더 든 이유가 **외부 도구 wrapping**이라는 새 클래스라 stdio/subprocess 4개 함정을 새로 학습 + 32개 테스트로 검증. **이름 변경 워크플로 (Phase 1.5)는 5분** — `gh repo rename`, sed 일괄 변경, `git mv`, venv 재생성, 태그 force-update만 알면 됨.

**kakao-summary가 1세션 만에 이름이 바뀐 이유**: 
- kmsg-doctor 결정 시 추천을 "md-doctor / cron-doctor / **kmsg-doctor**" 시리즈 통일로 제시
- 사용자는 "직관성"을 더 중시 → 1세션 만에 "kmsg-doctor는 적합하지 않음"
- 두 번째 브레인스토밍에서 "kakao 단톡방 내용 요약을 직관적으로 알수 있는 제목" 명시 → kakao-summary 선택
- **교훈**: 다음 OSS 부트스트랩 시 브레인스토밍에서 "기능 명시 + 도메인 직관성" 모두 만족하는 옵션을 추천. 시리즈 통일만으로 추천하면 1세션 rename 비용 발생.

**kakao-summary가 같은 세션에 decommission된 이유**:
- v0.1.0 완성 + 실제 카톡 연동(27개) 성공 후 사용자가 "어제 내용 정리" 요청
- kmsg의 "최근 N개" 한계로 **어제 데이터 fetch 불가** (AX 트리 스크롤 한계)
- 사용자 요구(과거 시점 데이터) 충족 불가 → "해당 프로젝트를 제거하자" 결정
- 5단계 절차로 ~10분 만에 100% 정리
- **교훈**: 사용자가 원하는 것을 못 주는 도구는 빠르게 decommission. 외부 도구 wrapping OSS는 **wrapping 대상 도구의 한계가 곧 우리 OSS의 한계**. 첫 부트스트랩 전에 "wrapping 대상 도구가 우리 요구사항 충족하는지" 먼저 검증 필요 (특히 macOS 비공식 API 도구류).

---

## 사례 6: opencode-trading (2026-06-17, v0.1.0 — Phase 0, **adaptor 클래스**)

**트리거**: 사용자가 monarchjuno/tradingcodex URL 공유 + "이걸 OpenCode에서 사용할 수 있나?" → 분석: Codex 전용 (`.codex/agents/*.toml`, `.codex/prompts/*`, `.codex/hooks/*`) + oh-my-openagent와 충돌 안 함 (에이전트 네임스페이스 다름) → "A) OpenCode용 어댑터 포크" 결정 → "다른 PC에서 작업" 명시

**소요**: 단일 세션 ~25분
**결과**: 5종 변환기 스텁 + 도메인 모델 5개 + CLI + 18 테스트 통과 (0.24s) + v0.1.0 태그 + GitHub public

### 이 사례가 새 클래스 — **adaptor (포맷 변환)**

hwp2md(포맷 변환), md-doctor/cron-doctor(진단), kakao-summary(wrapping)와 다른 클래스:
- **목적**: 외부 도구(A) → 외부 도구(B) 포맷 변환 (TradingCodex Codex → OpenCode)
- **zero-deps 어댑터 전략**: TradingCodex 본체를 import하지 않고 stdlib `tomllib`로 `.codex/agents/*.toml`만 읽어서 OpenCode JSON 생성. **adaptee 의존 X, 결과물 의존 O**.
- **MCP 실행 경계 = 그대로 재사용**: TradingCodex MCP 서버 + Django 서비스 + SQLite ledger는 범용이라 변환 불필요.
- **oh-my-openagent 스쿼드와 직교**: 에이전트 이름 1개도 겹치지 않음 (sisyphus/oracle/librarian vs head-manager/fundamental-analyst/technical-analyst). 1+9 specialist 토폴로지는 보존.

### 5개 결정 포인트 (브레인스토밍)

| 결정 | 옵션 | 추천 | 채택 |
|---|---|---|---|
| 이름 | `tcx-opencode` / `opencode-trading` / `trading-opencode-bridge` | **B (opencode-trading)** | ✅ |
| 저장소 owner | sigco3111 조직 / 본인 계정 | sigco3111 (시리즈 일관성) | ✅ |
| 구조 | 모노레포 (워크스페이스 템플릿 + 어댑터) / 어댑터 only | 모노레포 | ✅ |
| 라이선스 | MIT (시그니처) / Apache-2.0 (TradingCodex 본체와 통일) | MIT | ✅ |
| README 톤 | 한/영 병기 다층 / 영문 only / 한글 only | 한/영 병기 다층 | ✅ |

→ "그대로 진행해" 받음 → 즉시 실행 (cron-doctor 06-16 패턴 동일).

### 시퀀스 (cron-doctor Phase 0와 거의 동일, ~25분)
1. `gh repo create sigco3111/opencode-trading --public --description "<한글>"` (--license 빼고, 사례 3 학습)
2. `mkdir -p ~/.openclaw/workspace/opencode-trading && mkdir -p src/opencode_trading/{agents,converters} tests/fixtures .github/workflows` (race condition 회피, 사례 3 학습)
3. **도메인 모델 5개** (frozen dataclass + Literal type): `OpenCodeAgent`, `OpenCodeSkill`, `OpenCodeHook`, `OpenCodeMCP`, `OpenCodeWorkspace` (models.py 분리, 사례 2 학습)
4. **5종 변환기 스텁** (각 docstring에 "다른 PC 작업자용 가이드" 포함): codex_to_opencode / hooks / commands / mcp / workflows
5. **CLI** (`opencode-trading convert --workspace <path> [--dry-run]`): argparse subcommand handler
6. **테스트 18개** (4 파일): test_models(5) + test_codex_to_opencode(5) + test_converters(4) + test_cli(4)
7. **CI** (`.github/workflows/ci.yml`): Python 3.11/3.12/3.13 + ruff + mypy || true + pytest + smoke CLI
8. **README (10.4KB)** — 한/영 병기 + 결정 매트릭스 6개 + 사용 시나리오 4개 + Phase 0 다른 PC 작업 흐름 + 로드맵 4단계 + 디렉토리 구조 + 의존성 명시
9. `git init -b main && git add -A && git commit` (한 번에)
10. `git push -u origin main` + `git tag -a v0.1.0 -m "..."` + `git push origin v0.1.0`
11. `gh repo edit sigco3111/opencode-trading --description "<한글>"` (About 한글화)

### 새 학습 (사례 1~5에 없는 것)

- **adaptor OSS 클래스 = 네 번째 OSS 클래스**: 변환(transcoding) / 진단(diagnosis) / wrapping(wrapping)에 이어 adaptor. **zero-deps 어댑터 전략**이 핵심: adaptee를 import하지 않고 결과물(파일)만 읽어서 변환. 의존성 0, adaptee 버전 변경에 영향 없음, pip install 시간 <1초.
- **TomlLib = stdlib 어댑터의 핵심 도구**: Python 3.11+ `tomllib` (read-only) + `tomli_w` (optional, write). tomli를 의존성에 추가하지 말 것. v0.2.0+ 구현 시 핵심 import.
- **oh-my-openagent와 직교 가능 검증**: 에이전트 이름 1개도 겹치지 않음 + MCP 클라이언트는 둘 다 지원 + oh-my-openagent의 sisyphus가 TradingCodex MCP 도구 호출 가능 → **스쿼드 시스템과 어댑터가 충돌 안 함**. 이게 "그냥 MCP로 가볍게 붙일까, 어댑터 만들까" 결정의 기술적 근거.
- **CLI subcommand handler 함정 21번 — 직접 발생**: `_cmd_convert`에서 `if not workspace.exists(): print(...); return 2` → 정상 경로 테스트 17개 통과, 에러 경로 테스트 1개 실패 (`assert result.returncode == 2` → 실제 0). 17/18 → 18/18 디버깅. **처음부터 `sys.exit(N)` 또는 main() dispatcher 통일**. **Phase 0 스텁이라도 CLI는 정상 + 에러 경로 둘 다 테스트**. 이 함정은 SKILL.md 함정 21번에 영구 기록.
- **mypy || true in CI = 점진적 타이핑**: 0.1.0은 mypy strict 모드 적용 X, 0.3.0+에서 strict. cron-doctor도 동일 패턴.
- **About 한글 description + 영문 README 한/영 병기 = 일관성**: About은 짧은 한 줄, README는 두 언어 섹션. GitHub 검색은 description 매칭하므로 한글 한 줄이 한국어 검색에 유리.
- **README "다른 PC에서 작업" 섹션의 작업 순서 권장**: Phase 0 README에는 **순서가 있는 9단계** 제시 (models → converter → hook → command → mcp → workflow → cli → tests → CI → tag). 다른 PC 작업자가 "어디서부터 시작?" 안 헤매게.
- **memory tool drift = 4번째 세션째 발생**: opencode-trading 부트스트랩 직후 memory 추가 시도했으나 drift guard 거부. 사례 4 (kakao-summary)에서도 발생했음. **패턴**: 06-16 학습 노트대로 "다음 세션에 한 번에 정리"가 안전. **drift 자체를 MEMORY.md에 노트로 남기는 게 더 나을 수도** (다음 drift 발생 시 비교 데이터).

### 네이밍 의사결정 트리 업데이트 (2026-06-17)

| 결정 포인트 | 옵션 | 추천 (2026-06-16 이전) | **수정된 추천 (2026-06-16)** | opencode-trading 검증 (2026-06-17) |
|---|---|---|---|---|
| 이름 | 시리즈 통일 vs 직관성 | 시리즈 통일 (md-doctor, cron-doctor) | **직관성 (기능 + 도메인)** | ✅ **opencode-trading**: OpenCode 메인 플랫폼 + trading 도메인. 시리즈 통일 (md-doctor/cron-doctor) 아님. 미래 `opencode-research`, `opencode-deploy` 확장 가능. |
| 신조어 사용 | OK / 회피 | 회피 (kakao-summary) | 회피 | ✅ 회피 유지 |
| 도메인 prefix | 있음 / 없음 | brand (kakao-) or 범용 (chat-) | brand (kakao-) or 범용 (chat-) | ✅ **범용 (opencode-)**: 미래 도메인 확장 시 시리즈 일관성 자동 확보. opencode는 단일 OSS가 아니라 OpenCode 통합 OSS **컬렉션**의 prefix 역할. |

→ **핵심 원칙 (2026-06-17 확정)**: "기능 명시 + 도메인 직관성" **+** "미래 확장 prefix 통일성" 모두 만족하는 옵션 추천. opencode-trading는 (1) 기능(OpenCode 변환), (2) 도메인(trading), (3) 미래 확장(`opencode-*` 시리즈) 셋 다 만족.

### 메타 비교표 (6개)

| | hwp2md | md-doctor | cron-doctor | kakao-summary | **opencode-trading** |
|---|---|---|---|---|---|
| **날짜** | 2026-06-08 | 2026-06-09 | 2026-06-16 | 2026-06-16 | **2026-06-17** |
| **소요** | ~30분 | ~25분 | ~20분 | ~40분 | **~25분** |
| **버전** | v1.0.0 | v0.1.0 | v0.1.0 (Phase 0) | v0.1.0 (decomm) | **v0.1.0 (Phase 0)** |
| **테스트** | 8 | 16 | 0 (다른 PC) | 32 | **18** |
| **변형** | 정식 10단계 | 정식 10단계 | Phase 0 | Phase 1 + rename + decomm | **Phase 0 (adaptor)** |
| **핵심 학습** | 백엔드 디스패처 | models.py + nargs="?" | 스텁 docstring + mkdir race | stdio JSON-RPC + SQLite | **zero-deps adaptor + sys.exit() 함정** |
| **클래스** | 변환 | 진단 | 진단 | wrapping (decomm) | **adaptor** |
| **이름 변경** | 0 | 0 | 0 | 1 | 0 |
| **decommission** | 아니오 | 아니오 | 아니오 | 예 | 아니오 |

→ opencode-trading는 **이름 결정이 한 번에 성공** (브레인스토밍 단계에서 "기능 + 도메인 + 미래 확장" 3축 추천). 사례 4 (kakao-summary) 교훈이 적용된 첫 사례.
