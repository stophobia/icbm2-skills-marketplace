# Cloudflare Tunnel — URL 추출 Python 패턴

## 핵심 문제

`cloudflared tunnel --url http://localhost:PORT`를 백그라운드(`&`)로 실행하면 stdout 로그를 캡처할 수 없어서 URL을 얻을 수 없다.

## 정결한 해결책: subprocess.Popen + readline()

```python
import subprocess, re, time, os

def start_review_server(video_dir, port=8766):
    """Cloudflare Tunnel + HTTP 서버 시작, URL 반환"""
    # 1. HTTP 서버 (백그라운드)
    http_proc = subprocess.Popen(
        ["python3", "-m", "http.server", str(port)],
        cwd=video_dir,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )

    # 2. Cloudflare Tunnel (stdout 파이프)
    cf_proc = subprocess.Popen(
        ["cloudflared", "--url", f"http://localhost:{port}"],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )

    # 3. URL 파싱 (15초 타임아웃)
    url = None
    start = time.time()
    while time.time() - start < 15:
        line = cf_proc.stdout.readline()
        if not line:
            break
        line = line.decode('utf-8', errors='ignore')
        match = re.search(r'https://[a-z-]+\.trycloudflare\.com', line)
        if match:
            url = match.group(0)
            break
        time.sleep(0.5)

    return url, cf_proc, http_proc

# 사용 예시
url, cf_proc, http_proc = start_review_server("/path/to/video_dir")
if url:
    video_link = f"{url}/video_wave.mp4"
    short_link = f"{url}/short.mp4"
    print(f"🎬 {video_link}")
    print(f"📱 {short_link}")

# 정리
cf_proc.terminate()
http_proc.terminate()
```

## 항상 실패하는 잘못된 패턴

```bash
# ❌ 이렇게 하면 stdout 로그를 못 잡음
cloudflared tunnel --url http://localhost:8000 2>&1 &
sleep 5
curl ...  # 로그를 파일로 리다이렉션해도タイミング不好

# ❌ terminal 백그라운드 후 process 로그 읽기도 어려움
# (새 세션에서는 stdout이 부모 프로세스에 안 넘어옴)
```

## 타임아웃 처리

15초内有郊果しない 경우:
```python
if not url:
    cf_proc.terminate()
    http_proc.terminate()
    raise TimeoutError("Cloudflare Tunnel URL 추출 실패")
```

## 포트 선택

- 기본: 8766 (다른 프로세스 포트와 충돌 최소화)
- video_dir별로 다른 포트 사용 권장