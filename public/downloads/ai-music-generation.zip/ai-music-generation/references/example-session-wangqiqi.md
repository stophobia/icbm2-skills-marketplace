# 실전 세션: 왕치치 「평범하게 네 곁에 있고 싶어」 → 「오늘도 잘했어」

> 2026-06-03 Telegram 세션. 사용자: 희정님. 결과물: mmx music-2.6, 117 BPM, C#m, 2:08, 4.1MB.

## 사용자 요구사항 (원문)

1. 따뜻한 발라드
2. 위로와 힐링
3. IU 톤 여성 보컬
4. 개인 감상 → 유튜브 업로드 고려
5. 순수 AI 여성 보컬
6. 원곡 「평범하게 네 곁에 있고 싶어」와 비슷한 구성/멜로디

## v1에서 틀린 것

사용자: "노래와 느낌은 좋은데, 내가 원하는 원곡의 구성과 후렴등은 동떨어진 느낌임."

**원인**: 제목만 보고 "잔잔한 발라드"로 가정 → 70 BPM, D major, 피아노+스트링 발라드로 생성.

**실제 원곡 (사후 확인)**:
- 장르: 중독성 있는 중국식 팝 (경쾌+귀여움)
- BPM: **117** (Spotify stats)
- Danceability: 85%, Energy: 39%
- Key: **C#m** (Chordify: C#m - A - B - E)
- 코드: 단순 4-코드 순환
- 가사 톤: 위트 ("못생기면 오래 산다") + 귀여움 + 진심
- 가사 키워드: "차라리 평범한 사람이 되어 네 곁에 있을래"

## v2에서 고친 것 (성공)

- BPM 70 → **117**
- Key D major → **C#m**
- 무드: "warm emotional ballad" → "cute, warm, addictive, hopeful, playful, sincere"
- 악기: 피아노+스트링 → **우쿨렐레+기타+신스+브러시드 드럼**
- 가사 톤: 진지한 위로 → **위트+귀여움+진심**
- 후렴에 반복 가능한 핵심 문장 ("난 평범한 사람이 될래 / 네 곁에 머물고 싶을 뿐")
- Bridge에 원곡의 위트 이미지 ("못난 게 오래 산다지만")

## v2 가사 전문 (한국어 창작)

```
[Intro]

[Verse 1]
잘생겨 봤자 빨리 늙고
예뻐 봤자 시간이 갈 뿐
난 차라리 평범한 사람이 되어
네 곁에 있을래

[Pre-Chorus]
빛나지 않아도 괜찮아
대단하지 않아도 돼
그냥 네 옆에 나 있으면 돼

[Chorus]
난 평범한 사람이 될래
네 곁에 머물고 싶을 뿐
특별하지 않아도 돼
오래 네 곁에 있을게

[Verse 2]
날 가꾸지 않아도 돼
화려하지 않아도 돼
그냥 이대로 내 모습 그대로
네 곁에 있고 싶어

[Pre-Chorus]
빛나지 않아도 괜찮아
대단하지 않아도 돼
그냥 네 옆에 나 있으면 돼

[Chorus]
난 평범한 사람이 될래
네 곁에 머물고 싶을 뿐
특별하지 않아도 돼
오래 네 곁에 있을게

[Bridge]
못난 게 오래 산다지만
난 너라서 오래오래 살고 싶어
평범한 만큼 깊은 이 마음
네 곁에 영원히

[Chorus]
난 평범한 사람이 될래
네 곁에 머물고 싶을 뿐
특별하지 않아도 돼
오래 네 곁에 있을게

[Outro]
오늘도 잘했어
네 곁에 평범하게
```

## v2 mmx 호출 (정확한 값)

```bash
mmx music generate \
  --prompt "Korean Chinese-style catchy pop, bouncy and sweet, medium tempo, addictive hook melody, charming female vocal, light percussion, ukulele, light guitar, soft synth bass, cute and warm, lo-fi pop feel, bright and playful" \
  --vocals "bright female vocal, playful yet sincere, slight K-pop timbre, IU inspired but with a brighter edge, sweet and charming, light vibrato" \
  --genre "k-pop, Chinese pop, indie pop" \
  --mood "cute, warm, addictive, hopeful, playful, sincere" \
  --instruments "ukulele, light guitar, soft synth, brushed drums, light bass, soft claps" \
  --tempo "medium" \
  --bpm 117 \
  --key "C#m" \
  --references "왕치치 我愿意平凡的陪在你身旁, IU BBIBBI, Cheer Up" \
  --lyrics-file /Users/hjshin/Music/ai-ballad-workspace/lyrics/lyrics.txt \
  --out /Users/hjshin/Music/ai-ballad-workspace/audio/오늘도_잘했어_v2.mp3 \
  --aigc-watermark
```

## 외부 전달 (PC 없는 사용자)

`MEDIA:` 태그가 텔레그램에서 동작 안 함 → **ngrok 터널**로 우회.

```bash
# 1. 로컬 HTTP 서버
cd /Users/hjshin/Music/ai-ballad-workspace/audio
python3 -m http.server 8080 &

# 2. ngrok 터널
ngrok http 8080 &

# 3. 30초 미리듣기
ffmpeg -y -i 오늘도_잘했어_v2.mp3 -ss 0 -t 30 -c:a libmp3lame -b:a 96k -ac 1 -ar 22050 오늘도_잘했어_v2_preview.mp3

# 4. 한글 파일명 URL 인코딩 우회 (ASCII 심볼릭 링크)
ln -sf 오늘도_잘했어_v2.mp3 preview_v2_full.mp3
ln -sf 오늘도_잘했어_v2_preview.mp3 preview_v2.mp3

# 5. ngrok URL 확인
curl http://127.0.0.1:4040/api/tunnels
```

최종 URL: `https://require-entangled-primer.ngrok-free.dev/preview_v2.mp3`

## v1 vs v2 비교

| 항목 | v1 (실패) | v2 (성공) |
|------|----------|----------|
| BPM | 70 | 117 |
| Key | D major | C#m |
| 무드 | 잔잔, 따뜻 | 경쾌, 중독성, 따뜻 |
| 악기 중심 | 피아노+스트링 | 우쿨렐레+기타+신스 |
| 가사 톤 | 진지한 위로 | 위트+귀여움+진심 |
| 사용자 반응 | "동떨어진 느낌" | (v2 듣고 추가 피드백 대기) |

## 핵심 교훈 (재정리)

1. **제목은 거짓말한다.** BPM/Key/danceability 숫자로 확인.
2. **원곡 분석을 못 하면 창작이 아니라 새로 짓는 거다.** 사용자가 원곡을 지목했으면 반드시 그 원곡의 골격 위에 입혀야 함.
3. **mmx CLI는 빠르고 저렴하다** (30~60초, 1곡당 과금). v1이 별로도 ㄱㅊ — 바로 v2.
4. **PC 없는 사용자** = ngrok. `MEDIA:` 태그 의존 X.
