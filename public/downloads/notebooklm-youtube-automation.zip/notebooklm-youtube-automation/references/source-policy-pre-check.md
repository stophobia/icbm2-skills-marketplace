# 출처 정책 사전 체크 가이드

> 작성: 2026-06-04 (Gemma 4 12B 주제 — Google 공식 출처로 2회 업로드-삭제 반복 후 학습)

## 주인님 출처 정책

| 분류 | 예시 | 정책 |
|------|------|------|
| ✅ 국내(한국) 주제 | GeekNews 한글 토픽, 한국어 블로그/뉴스 | 기본 권장 |
| ⚠️ 해외 메가 이벤트 | Google I/O, WWDC, Apple 이벤트 | 정책 보류 (사용자 판단) |
| ❌ 해외 일반 제품/기술 | Google 공식 블로그(developer blog), GitHub 릴리즈, 영문 Reddit HN | **업로드 자제** |

## 위반 사례 (2026-06-04)

1. **Gemma 4 12B: 통합형 인코더 없는 멀티모달 모델**
   - 출처: `https://blog.google/innovation-and-ai/technology/developers-tools/introducing-gemma-4-12b/` (Google 공식)
   - 16:45 — 업로드 4개 (Claude Code + Gemma 4)
   - 16:46 — 해외 출처 룰로 Gemma 2개 삭제 결정
   - 16:50 — 다시 업로드 요청됨 → 16:54 노트북 재생성
   - **총 3회 시도 / 1회 업로드 / 추가 작업 비용 큼**

## 검출 절차 (NotebookLM 후보 검토 시)

`--review` 단계에서 다음을 자동으로 확인:

```python
import re
TOPIC = topic["name"] + topic["url"]
NEWS_HA = "news.hada.io" in topic["url"]
SUSPICIOUS_KEYWORDS = [
    "google blog",
    "github.com",
    "developer.android.com",
    "developer.apple.com/news",  # Apple News 자체는 OK, releases는 ⚠️
    "openai.com/blog",
    "anthropic.com/news",
]
# NotebookLM 소스 URL도 함께 확인
for src in sources:
    if any(k in src["url"] for k in SUSPICIOUS_KEYWORDS):
        return "WARNING: 해외 공식 출처"
```

## 권장 메시지 템플릿 (검토 시)

```
⚠️ 출처 정책 사전 체크

이 주제의 출처는 해외 공식(Google 블로그)입니다.
주인님 정책상 국내(한국) 주제를 선호하셨는데, 그래도 업로드할까요?

옵션:
A) 진행 (해외 출처 그대로)
B) 건너뛰기 (다른 주제 선택)
C) 보류 (수동 결정)
```

## 정책 자동화 옵션 (미구현, 향후 검토)

- [ ] `--review` 단계에서 자동 경고
- [ ] 16:00 후보 수집 시 해외 출처는 `priority=low` 또는 후보 제외
- [ ] Notion DB에 `source_origin` 필드 추가 (해외/국내/공식/비공식)

## ⚠️ `sources[]` vs `topic_url` 출처 함정 (기존 문서 보강)

`--review` 출력은 두 종류 URL을 모두 보여줌:

- `topic_url`: 후보 topics 배열의 URL (보통 `news.hada.io`) — **YouTube description에 들어감**
- `sources[]`: NotebookLM이 노트북에 추가한 URL (원본 기사, Google 블로그 등) — **참고용 메타데이터**

검증 시 **description만** 보면 됨. description의 URL이 `news.hada.io`면 정상이고, `sources[]`의 Google 블로그는 메타데이터라 YouTube에 안 올라감. 둘이 다르게 보여도 description만 확인하면 됨.

## 출처가 명확치 않을 때의 폴백

- GeekNews URL이 `news.hada.io/topic?id=xxxxx` 형태로 있으면 → 항상 한국어 커뮤니티가 요약한 글 → **국내로 간주**
- `https://news.hada.io/topic?id=xxxxx` 페이지가 영문 원문 링크를 보여줄 뿐이면 → **원문 출처 기준**으로 해외 판정
- 트위터/X 원문 링크: `x.com` 또는 `twitter.com` 도메인 → 해외지만 토론 매체로 분류 (정책 보류)
