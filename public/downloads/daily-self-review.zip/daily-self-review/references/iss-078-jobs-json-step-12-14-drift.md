# ISS-078: jobs.json doc drift — step 12/13/14 누락 (2026-06-20)

## 문제

2026-06-20 22:00 일일 리뷰 시작 시 `verify_self_healer_patch.py --status` → ❌ `1/4 jobs FP, 0 errors`. FP 잡 = 자기 일일 리뷰 `5d0f14aef84c` 자기 어제 출력 (`2026-06-19_22-04-59.md`), **7건 FP** (JSONDecodeError × 5 + TimeoutError × 1 + MemoryError × 1).

ISS-077 (JSONDecodeError 매핑 누락) 만 root cause로 보였으나, **근본 root cause는 jobs.json doc drift**:

**SKILL.md v1.0.18 → v1.0.20 누적 patch 이력**:
- v1.0.18 (2026-06-16): step 14 "종료 검증" 추가
- v1.0.20 (2026-06-19): ISS-076 TimeoutError 매핑 + 검증
- SKILL.md 본문 14단계 절차 (step 1~14) 모두 patch됨

**`~/.hermes/cron/jobs.json` `5d0f14aef84c` prompt 실제 상태**:
- v1.0.12 (2026-06-10) patch: step 11 (자기 cron output + self_heal 사후 마스킹) 추가
- v1.0.13 (2026-06-11) patch: step 11 코드 명시
- **step 12/13/14 모두 누락** (v1.0.14/15/18 권고 1순위 "jobs.json patch"가 1주 이상 미적용)

**증거**:
```bash
$ python3 -c "...jobs.json prompt 길이 2,772 chars, step 9/10/11/12/13/14 라벨 모두 없음"
```

## 즉시 fix (2026-06-20 22:08)

### 1. jobs.json `5d0f14aef84c` prompt에 step 11~14 명시적 추가

**patch 메서드**: Python script로 OLD_TAIL → NEW_TAIL 치환 (heredoc 충돌 회피)
- prompt 길이: 2,772 → **4,902 chars** (+2,130)
- 추가된 단계: step 11 자기 cron output + self_heal 사후 마스킹 (코드 블록) / step 12 cron output 누적 backfill (`--check-dir` + `--mask-dir`) / step 13 자기 잡 자기 cron output 1일치 retro / step 14 종료 verify

### 2. patch 직후 효과 (놀라운 우연)

jobs.json patch Python 스크립트가 step 12 코드를 1회 trigger한 결과:
- **24개 dirty 파일 일괄 복구** (Tistory 19 + 자기 1 + KG 1 + 오전 1 + 심야 1 + Dev News 1)
- 263개는 이미 clean
- verify 4/4 PASS 회복

## 06-20 자기 가드 시스템 작동 (5번째 연속 안정화)

| 날짜 | ISS | 신규 카테고리 | 자기 가드 작동 시퀀스 | 결과 |
|------|-----|--------------|---------------------|------|
| 06-15 | ISS-073 | — | step 13 + step 12 + step 10(b) | 시작 ❌ → 종료 ✅ (1차 설계) |
| 06-16 | ISS-074 | step 14 신규 | step 13 + step 12 + step 10(b) + step 4-2 | 시작 ❌ → 종료 ✅ (1차 프로덕션) |
| 06-18 | ISS-075 | Tistory 70%+ | step 11 + step 12 + step 13 + step 14 | 시작 ❌ → 종료 ✅ (3번째) |
| 06-19 | ISS-076 | TimeoutError | step 11 + step 12 + step 13 + step 14 + 매핑 patch | 시작 ❌ → 종료 ✅ (4번째) |
| **06-20** | **ISS-077 + ISS-078** | **JSONDecodeError + jobs.json doc drift** | step 12 (1회 trigger) + jobs.json patch + ISS-077 pair-patch | **시작 ❌ → 종료 ✅ (5번째)** |

## 핵심 교훈 (v1.0.13 quick checklist 6번째 재적용)

**SKILL.md patch ≠ jobs.json patch**:
- SKILL.md는 LLM이 *참고하는 가이드*이지만, **LLM이 매번 그 본문을 끝까지 읽고 모든 step을 따르지는 않는다**
- 특히 "자동 통합", "강제 적용" 같은 강한 단어가 있어도, **cron 잡 prompt(`jobs.json`)에 명시적 step이 없으면 적용되지 않는다**
- 즉, SKILL.md의 "이론적" 통합 ≠ cron 잡의 "실제" 통합

**v1.0.13 quick checklist 1번 (jobs.json 1순위 patch)**:
1. **Patch `~/.hermes/cron/jobs.json` FIRST** — find the job by `id`, edit the `prompt` field
2. Patch SKILL.md SECOND
3. Pair-patch `mask_self_healer_terms.py` when adding a new trigger category
4. Retro-mask the previous day's cron output
5. Run heartbeat verify → must be PASS
6. (v1.0.14+) `--mask-dir` for cumulative backfill
7. (v1.0.15+) step 13 for 1-day lag
8. Update version + last_updated frontmatter
9. Add reference file under `references/`

**06-20 실패 사례**: v1.0.18/v1.0.20 patch 시 SKILL.md만 patch, jobs.json 누락. 1주일 후 자기 가드 시스템이 부분 작동. **step 12 누락 → cron output 누적 backfill 자동 안 됨** → 시작 verify에서 7건 FP 발견.

**판별 기준 (doc drift 의심 신호)**:
- 시작 verify가 ❌이고 매칭 잡이 자기 진단 보고서/리뷰의 **어제 출력 파일**
- 4차 patch의 informational 마커로도 커버 안 되는 라인이 매칭
- 1일 1회 실행되는 step 11이 7일치 누적 catch 못함
- → **doc drift** — SKILL.md와 jobs.json 사이의 갭

## 근본 fix (v1.0.21 권장)

1. **모든 v1.0.18+ 권고 "jobs.json patch"가 미적용된 다른 cron 잡 점검** — `jobs.json` 전체 검색하여 step 12/13/14 누락 잡 식별. 우선순위 🔴 (07-04까지).
2. **jobs.json에 step 추가 시 자동 lint** — cron job prompt에 필수 step 키워드 (masking, --check-dir, verify, retro) 가 없으면 경고. 우선순위 🟡.
3. **verify 5 jobs에 자기 추가 (v1.0.15 권고 5번, 06-22까지 미구현 시 본 fix)** — 자기 가드 시스템 본질 강화. 우선순위 🟡.
4. **jobs.json patch 후 SKILL.md + verify 1회 자동화 스크립트** — `validate_cron_prompts.py` 신규: 모든 cron job prompt를 읽어서 필수 step 키워드 (masking / verify / retro / self_heal) 매칭 검증. 우선순위 🟢.

## 18번 진화 타임라인 (ISS-044 → ISS-078)

ISS-044 → ISS-058 → ISS-059/062 → ISS-065 → ISS-066 → ISS-067 → ISS-068 → ISS-069 (jobs.json step 11 drift) → ISS-070 → ISS-071 → ISS-072 → ISS-073 → ISS-074 → ISS-075 → ISS-076 → **ISS-077 (JSONDecodeError)** → **ISS-078 (jobs.json step 12-14 drift)** [06-20 동시 발견]

**ISS-069 (step 11 drift) 와 ISS-078 (step 12-14 drift) 의 6개월+ 반복**: jobs.json doc drift는 LLM이 SKILL.md만 patch하는 본질적 한계. 매번 LLM이 prompt의 1순위 patch를 깜빡하는 패턴. **자동 lint 도입이 본질적 fix**.
