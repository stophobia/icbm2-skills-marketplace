# Category → Wiki Type Registration Guide

> Quick reference for matching Notion category → Wiki page type. Loaded by `dev-news-to-wiki` skill.

## Category → Type Mapping

| Notion Category | Wiki Type | Examples | Rule |
|----------------|-----------|----------|------|
| **오픈소스** | `entities/` | agentmemory, Agent of Empires, TalkMode | tools, platforms, CLI apps with direct utility for AI/iOS development |
| **TIP** (tool) | `entities/` | TalkMode, ANDON Labs | Specific tools/platforms with concrete use |
| **인사이트** | `concepts/` or `entities/` | HBM AI chip costs, memory cost trend | Depends: infrastructure/market-trend → `concepts/`; company/product news → `entities/` |
| **iOS** | `entities/` | — | Apple platform tools, Swift frameworks |
| **뉴스** | usually skip | — | Market/industry news without new entity/concept → skip |

## Skip Patterns (ennyō)

### Tutorial/How-to → Always skip
- Git 커밋 로그로 주간 업무 정리 자동화하기 (Claude Code + Obsidian 조합)
- Reason: **단일 튜토리얼, 새로운 개념/엔티티 없음**. Already covered by主人的 existing pattern (Claude Code + Obsidian workflow). 등록하려면 substantive entity or concept that extends the domain knowledge.

### 이미지/joke/meme → Always skip
- 루리웹 게임 매출, 밈 등 → 관심사 범위 밖

### 단일 Mention + Already registered
- 스크립트 출력의 "신규" ≠ Wiki belum 등록. 항상 `search_files` 또는 `ls ~/wiki/entities/`로 존재여부 확인.

## Correct Registration This Session (2026-05-26)

| Item | Category | Wiki Page | Type |
|------|----------|-----------|------|
| agentmemory | 오픈소스 | `entities/agentmemory.md` | entities/open-source, agent, memory |
| Agent of Empires | TIP | `entities/agent-of-empires.md` | entities/open-source, tool, cli, agent, session-manager |
| TalkMode | TIP | `entities/talkmode.md` | entities/open-source, tool, voice-agent, macos, platform |
| HBM AI chip costs | 인사이트 | `concepts/hbm-ai-chip-costs.md` | concepts/infrastructure, gpu, market-trend |
| Git commit log automation | TIP | — (skip) | Tutorial, no new entity/concept |

## How to Verify

```bash
# Check if entity already existsls ~/wiki/entities/<target>.md

# Quick category checkgrep -l "type: concept\|type: entity" ~/wiki/entities/*.md | xargs -I{} basename {} .md
```

## Key Signals for Entity vs Concept

**Entity signals:**
- Proper noun / product name (Agent of Empires, TalkMode, agentmemory)
- Actor-subject of "supports / has / provides"
- GitHub repo with concrete features

**Concept signals:**
- "-ing" nouns (computing-leadership, hbm-cost-trend)
- Market/infrastructure trends
- Paradigm/technique names (sleep-consolidation, context-mode)
- Comparison frameworks
