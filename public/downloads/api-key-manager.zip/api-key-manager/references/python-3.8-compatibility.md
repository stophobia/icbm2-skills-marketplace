# Python 3.8 vs 3.10+ Syntax Conflict

## 问题现象
Python 3.8.8 (시스템 기본값)에서는 `list | None` 같은 union 타입 힌트를 지원하지 않음.

```
# Python 3.10+ (OK)
def get_holidays(year: int, month: int) -> list | None:

# Python 3.8 (TypeError)
TypeError: unsupported operand type(s) for |: 'type' and 'NoneType'
```

## 발생 스크립트
- `~/.hermes/scripts/apikey_holiday_monitor.py` line 177: `get_holidays()` → 수정 완료

## 해결 방법
```python
from typing import Optional, List

# 변경 전 (Python 3.10+ only)
def foo() -> list | None:
    pass

# 변경 후 (Python 3.8 호환)
def foo() -> Optional[List[str]]:
    pass
```

## 검증
```bash
# AST parse로 문법 호환성 확인
python3 -c "import ast; ast.parse(open('script.py').read())"

# 실제 실행 테스트
python3 script.py
```

## 자기 개선 자동화
현재 문제 발생 시 Self-Healer가 cron 실패로 감지하지만, 실제로는 재실행 시 성공하는 경우가 많음 (Python 3.10이 설치된 환경에서). 감시 대상 스크립트:
- `apikey_holiday_monitor.py` (line 177 `get_holidays`)
- 다른 스크립트에서 `list | None` 구문 사용 시 발생 가능

## 관련 이슈
- ISS-036 (apikey_holiday_monitor.py)
- 2026-05-24 수정 완료