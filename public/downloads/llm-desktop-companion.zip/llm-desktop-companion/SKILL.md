---
name: llm-desktop-companion
description: "LLM + 음성(STT/TTS) + 얼굴/제스처 GUI가 통합된 데스크탑 동반자 빌드 워크플로. stackchan · Mochi · AI Pet 같은 '화면 속 캐릭터와 대화' 시뮬레이터를 macOS/Linux/Windows 데스크탑 환경에서 만든다. M5Stack StackChan, Replika, Mylo, AI 데스크탑 동반자 요청에 발동."
version: 0.4.0
author: icbm2
metadata:
  hermes:
    tags: [LLM, TTS, GUI, Pygame, Avatar, Companion, Desktop-pet]
trigger: stackchan 시뮬레이터, AI 데스크탑 동반자, 음성 얼굴 LLM 통합, 화면 속 캐릭터와 대화, AI 펫 만들기, Replika 비슷하게 만들자 같은 요청
last_updated: 2026-06-23
status: validated-2sessions-stackchan-iterated
---

# LLM Desktop Companion (음성+얼굴 LLM 동반자 빌드)

LLM + 음성(STT/TTS) + 얼굴/제스처 GUI가 통합된 **데스크탑 동반자**를 만드는 클래스 레벨 스킬.
stackchan · Mochi · AI Pet · 가상 비서 같은 "화면 속 캐릭터와 대화" 시뮬레이터.

## 트리거 조건

- "stackchan 시뮬레이터 만들어줘", "AI 데스크탑 동반자"
- "음성으로 대화하는 키위/고양이/펫 캐릭터"
- "M5Stack StackChan 시뮬레이션" (M5Stack 디바이스 없이 PC에서)
- "Replika/Mylo 비슷한 거 데스크탑에 띄우고 싶어"
- "화면 속 아바타 + TTS + LLM"

## ⚠️ 트리거 시 절대 놓치지 말 것

1. **브레인스토밍 우선** — 즉시 코딩 ❌. 결정 포인트(얼굴/외형, LLM 백엔드, STT, TTS, 윈도우/메뉴바/터미널)를 2~3 옵션 + 추천으로 먼저
2. **하드웨어 제약 먼저 확인** — Apple Silicon 전용 앱(예: StackChan World)은 Intel Mac에서 못 돌림. macOS Ventura+ Apple Silicon M1+ 필수 같은 제한 확인 후 옵션 선정
3. **헤드리스 환경 분리** — GUI 데모는 헤드리스에서 안 보임. `SDL_VIDEODRIVER=dummy`로 모듈 단위 검증 후 데스크탑 세션에서 통합 확인
4. **3-모듈 분리** — llm.py / tts.py / face.py / main.py 4파일로 쪼개기. face.py 단독 import 에러 → 전체 중단 안 됨
5. **v1은 텍스트 입력만, STT는 v2** — Whisper는 Intel Mac에서 무거움. v1은 키보드 입력으로 표정 변화 검증하고 점진적 확장
6. **macOS pygame 3대 함정** — `pygame.init()`(오디오 race) / `pygame.time.Clock()`(타이머 race) / 별도 스레드에서 `set_mode()`(NSWindow 제약). **세 가지 다 하지 말 것** (자세한 패턴은 아래 "✅ 검증된 안전한 face.py 패턴" 참조)

## 🏗️ 아키텍처 (4 모듈 + 메인 루프)

```
kiwi-companion/
├── llm.py         # LLM API 호출 + 구조화 태그 파싱
├── tts.py         # TTS (pyttsx3 + 시스템 음성 우선순위)
├── face.py        # Pygame 얼굴 윈도우 (메인 스레드에서 init + tick)
├── main.py        # 입력 → LLM → TTS + 표정 통합 (워커 스레드 + 큐)
└── run.sh         # 환경 자동 활성화 래퍼 (선택)
```

### 모듈 책임 분리

| 모듈 | 책임 | 비고 |
|------|------|------|
| `llm.py` | LLM API + 응답에서 메타데이터(감정, 표정) 파싱 | 시스템 프롬프트로 태그 출력 강제 |
| `tts.py` | 시스템 TTS 호출, 한국어/일본어/영어 음성 우선순위 | 실패 시 subprocess 폴백 |
| `face.py` | Pygame 윈도우, 감정 팔레트, 눈 깜빡임, 입 동기화 | **메인 스레드에서 init + tick 루프** |
| `main.py` | stdin 입력, LLM→TTS→face 상태 머신, 워커 스레드 + 큐 | LLM/TTS는 워커, pygame은 메인 |

### 데이터 흐름 (v3: 메인 스레드 + 워커 큐)

```
[stdin 입력 (select)]
   ↓ (메인 스레드)
[워커 스레드 시작] ←─ LLM 호출 + TTS 발화
   ↓
[event_queue.put({"type": "thinking_start"})]
[event_queue.put({"type": "emotion", "emotion": ..., "text": ...})]
[event_queue.put({"type": "speaking_end"})]
   ↓ (메인 스레드가 매 프레임 큐 비움)
[face.set_emotion / set_speaking]
[face.tick()] → pygame.display.flip()
   ↓
[다음 입력 대기]
```

## ✅ 검증된 안전한 face.py 패턴 (macOS 15.5 + Python 3.11 + pygame 2.6.1)

3차례 크래시를 거쳐 검증된 **유일하게 안정적인** 패턴. **이 패턴 그대로 복사해서 시작할 것.**

```python
import math
import os
import random
import time
from typing import Optional

import pygame


class KiwiFace:
    WINDOW_SIZE = 480
    FACE_RADIUS = 170
    EYE_OFFSET = 60
    EYE_RADIUS = 18
    BLINK_INTERVAL = (3.0, 5.5)

    def __init__(self):
        self.emotion = "neutral"
        self.speaking = False
        self.mouth_open = 0.0
        self.target_mouth = 0.0
        self._last_blink = time.time()
        self._next_blink = self._random_blink_delay()
        self._is_blinking = False
        self._blink_start = 0.0
        self._blink_duration = 0.15
        self._window = None
        self._clock = None  # pygame.time.Clock 안 씀
        self._ready = False
        self._running = False
        self._initialized = False
        self._quit_requested = False

    @staticmethod
    def _random_blink_delay() -> float:
        return random.uniform(*KiwiFace.BLINK_INTERVAL)

    # ─── Setter (어떤 스레드에서든 호출 가능 — 단순 attr) ───

    def set_emotion(self, emotion: str):
        if emotion in EMOTION_PALETTE:
            self.emotion = emotion

    def set_speaking(self, speaking: bool, amplitude: float = 1.0):
        self.speaking = speaking
        self.target_mouth = max(0.0, min(1.0, amplitude))

    def request_quit(self):
        self._quit_requested = True

    def is_ready(self) -> bool:
        return self._ready

    def is_quit_requested(self) -> bool:
        return self._quit_requested

    # ─── Pygame Lifecycle (반드시 메인 스레드에서) ───

    def init_pygame(self) -> bool:
        """pygame 초기화 + 윈도우 생성. 메인 스레드에서만 호출.

        절대 하면 안 되는 것:
        1) pygame.init() → SDL audio 자동 init → 오디오 race condition
        2) pygame.time.Clock() → SDL_TimerThread 활성화 → PyDict race
        3) 별도 스레드에서 set_mode() → NSWindow 메인 스레드 제약
        """
        if self._initialized:
            return True
        try:
            import os
            os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

            # 명시적 subsystem init만 (mixer/audio/time 제외)
            pygame.display.init()
            pygame.font.init()
            # pygame.init() 안 씀
            # pygame.time.Clock() 안 씀 — time.sleep으로 대체

            pygame.display.set_caption("Kiwi Companion - ESC to quit")
            self._window = pygame.display.set_mode((self.WINDOW_SIZE, self.WINDOW_SIZE))
            self._initialized = True
            self._ready = True
            return True
        except Exception as e:
            print(f"[face] init 실패: {e}")
            return False

    def tick(self) -> bool:
        """한 프레임 처리. 메인 스레드에서 호출."""
        if not self._initialized or self._window is None:
            return False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self._quit_requested = True
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                self._quit_requested = True
        if self._quit_requested:
            return False
        now = time.time()
        self._update(now)
        self._draw()
        pygame.display.flip()
        # pygame.time.Clock.tick(60) 안 씀
        return True

    def shutdown(self):
        if self._initialized:
            try: pygame.quit()
            except Exception: pass
            self._initialized = False
            self._ready = False

    def _update(self, now: float):
        # 입 부드럽게 보간
        self.mouth_open += (self.target_mouth - self.mouth_open) * 0.18
        # 깜빡임 타이밍
        if self._is_blinking:
            if now - self._blink_start > self._blink_duration:
                self._is_blinking = False
                self._next_blink = now + self._random_blink_delay()
        else:
            if now >= self._next_blink:
                self._is_blinking = True
                self._blink_start = now

    def _draw(self):
        # 감정별 표정 그리기 (원본 kiwi-companion/face.py 참조)
        pass
```

## 🛑 검증된 크래시 패턴 (하지 말 것)

| # | 패턴 | 결과 | 증상 |
|---|------|------|------|
| 1 | `pygame.init()` | 오디오 race | AudioQueue, AQConverter, IOThread 비동기 생성 → EXC_BAD_ACCESS |
| 2 | `pygame.time.Clock()` + `clock.tick(60)` | 타이머 race | SDLTimer 활성화 → PyDict_SetItemString → pgEvent_New NULL deref |
| 3 | `threading.Thread(target=face.run)` | NSWindow 제약 | NSWindow should only be instantiated on the main thread! |
| 4 | `pygame.mixer.get_init()` 자동 import | mixer init 발동 | audio subsystem init → 패턴 1과 동일 |

## 🧠 LLM 모듈 설계 — 구조화 태그 강제

LLM 응답에 메타데이터를 심는 가장 robust한 방법: **응답 끝에 태그 강제 출력**.

```python
SYSTEM_PROMPT = """너의 이름은 '키위'야. ...

[감정 표현 — 매우 중요]
**모든 답변의 마지막 줄에 반드시 다음 중 하나의 감정 태그를 1개만 붙여야 한다** (대괄호):
[emotion:happy]    — 기쁨, 즐거움, 신남
[emotion:sad]      — 슬픔, 위로
[emotion:thinking] — 생각 중, 의문
[emotion:surprised]— 놀라움, 반전
[emotion:neutral]  — 일반 인사

규칙:
- 이전 대화와 무관하게 매번 새 응답마다 1개 태그를 반드시 붙인다
- 사용자의 감정이 강하면 그에 맞춰 태그를 선택한다
- 태그를 빼먹지 않는다 — 절대 빼먹지 마
"""

EMOTION_RE = re.compile(r"\[emotion:\s*(happy|sad|thinking|surprised|neutral)\s*\]", re.IGNORECASE)

def call_llm(user_text, conversation=None):
    # ... API 호출
    raw = response.text
    match = EMOTION_RE.search(raw)
    emotion = match.group(1) if match else "neutral"  # 폴백
    text = EMOTION_RE.sub("", raw).strip()
    return {"text": text, "emotion": emotion, "raw": raw}
```

### 검증된 한계: LLM 컨텍스트 길이 + 태그 약화

**현상**: 시스템 프롬프트에 "절대 빼먹지 마"라고 강조해도, **대화 컨텍스트가 4~6턴 이상 누적되면 LLM이 태그를 빼먹음**. 짧은 대화는 100% 정확, 긴 대화는 폴백("neutral") 빈도 증가.

**근본 원인**: 모델의 instruction following이 컨텍스트 길이 증가에 따라 약해짐 (특히 chat-tuned 모델).

**대응 (우선순위)**:
1. **폴백** — 태그 없으면 "neutral"로 기본값. 표정이 "중립"으로라도 바뀌긴 함
2. **2차 분류** — 메타 LLM 호출로 짧은 텍스트 감정 분류. 비용 +1 호출, 정확도 ↑
3. **키워드 백업** — "슬프다/신난다/화난다" 같은 강한 단어 사전 매칭 → LLM 태그 덮어쓰기

→ v1은 (1)로 충분. (2)(3)은 사용자가 "감정이 안 바뀌어요"로 짚으면 추가.

## 🔊 TTS 모듈 설계 — macOS 시스템 음성 우선순위

macOS는 시스템에 177개 음성 내장, 그 중 한국어 Yuna가 compact 고품질. pyttsx3가 NSSpeechSynthesizer 백엔드라서 모든 음성 접근 가능.

### 검증된 한국어 음성 우선순위 (macOS 기준)

```python
_KOREAN_PREFERENCE_KEYS = ("yuna", "kyung", "ko-kr.yuna", "ko_kr.yuna", "korean")
```

### Pitfall: 단순 substring 매칭 함정

```python
# 잘못된 매칭
for v in voices:
    if any(k in name or k in vid for k in _KOREAN_PREFERENCE_KEYS):
        return v  # Eddy (Korean) 같은 Eloquence 음성이 먼저 잡힘
```

`com.apple.eloquence.ko-KR.Eddy`는 "korean"을 포함하니까 "yuna"보다 먼저 매칭됨. 결과: Yuna 대신 Eddy 선택.

**해결: 우선순위 키워드 루프 + 정확 매칭**

```python
for keyword in _KOREAN_PREFERENCE_KEYS:
    for v in voices:
        name = (getattr(v, "name", "") or "").lower()
        vid = (getattr(v, "id", "") or "").lower()
        if keyword == "yuna":
            if name == "yuna" or vid.endswith(".yuna") or "ko-kr.yuna" in vid:
                return v
        elif keyword in name or keyword in vid:
            return v
```

### pyttsx3 → macOS `say` 폴백

pyttsx3가 죽거나 음성 못 찾으면 `subprocess.Popen(["say", "-v", "Yuna", text])`로 폴백.

### Pitfall: pyttsx3 thread-safety

```python
import threading
self._lock = threading.Lock()

def say(self, text, blocking=False):
    with self._lock:  # 단일 락으로 직렬화
        self.engine.say(text)
        if blocking:
            self.engine.runAndWait()
        else:
            threading.Thread(target=self._run_and_wait_safe, daemon=True).start()
```

## 🐍 환경 함정 — conda base pip 죽음 (Intel Mac)

### Pitfall: conda base pip `InvalidVersion: '4.0.0-unsupported'`

```bash
$ /Users/hjshin/opt/anaconda3/bin/pip install pygame pyttsx3
# → pip._vendor.packaging.version.InvalidVersion: Invalid version: '4.0.0-unsupported'
# → python -m pip도 동일하게 죽음
```

**유일하게 견고한 해결: 별도 conda 환경 생성**

```bash
/Users/hjshin/opt/anaconda3/bin/conda create -y -n <name> python=3.11 pip
/Users/hjshin/opt/anaconda3/envs/<name>/bin/python -m pip install pygame pyttsx3 requests
```

### Hermes 내부 vs 사용자 터미널 python 분기

- **Hermes 내부** = `/Library/Frameworks/Python.framework/Versions/3.8/bin/python3` (시스템 Python 3.8)
- **사용자 터미널 `(base)`** = `/Users/hjshin/opt/anaconda3/bin/python3` (conda Python 3.9)
- **`pip install --user`로 한쪽에 깔아도 다른 쪽에서 import 실패**

→ **사용자에게 직접 실행 안내할 때 무조건 conda 환경 또는 venv 경로를 명시**할 것.

### run.sh 래퍼 패턴

```bash
#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

CONDA_ENV_PYTHON="/Users/hjshin/opt/anaconda3/envs/<env-name>/bin/python"

if [ ! -x "$CONDA_ENV_PYTHON" ]; then
    echo "[오류] conda 환경이 없습니다: $CONDA_ENV_PYTHON"
    echo "생성: $CONDA_BASE/bin/conda create -y -n <env-name> python=3.11 pip"
    exit 1
fi

# Hermes secrets 자동 source
SECRETS_FILE="[REDACTED]"; then
    set -a; source "$SECRETS_FILE"; set +a
fi

exec "$CONDA_ENV_PYTHON" "$SCRIPT_DIR/main.py" "$@"
```

## ✅ 헤드리스 검증 패턴 (CI/원격 작업용)

```bash
# face.py 검증
SDL_VIDEODRIVER=dummy python3 -c "
import sys; sys.path.insert(0, '.')
import face
f = face.KiwiFace()
ok = f.init_pygame()
print(f'init: {ok}')
# mixer/time init False 확인
import pygame
print(f'mixer: {bool(pygame.mixer.get_init())}')  # False여야 안전
f.shutdown()"

# main.py 전체 파이프라인 검증
printf '키위야 안녕!\n회사 힘든 일 있었어\nquit\n' | SDL_VIDEODRIVER=dummy bash run.sh --no-tts
```

## 🎨 얼굴 디자인 — StackChan 스타일 흰 박스 + 픽셀 아트

세션 #2 (2026-06-23)에서 사용자가 "stackchan 시뮬레이터처럼 만들어줘" 요청 → **흰 박스 + 검은 디스플레이 + 흰 픽셀 얼굴** 구조로 결정. 진짜 M5Stack StackChan 디자인과 거의 동일.

### 검증된 디자인 구조 (face.py `_draw()`)

```python
# 1) 배경
self._window.fill(palette["bg"])

# 2) 본체 (둥근 모서리 흰 박스)
body_rect = pygame.Rect(60, 60, 360, 360)
shadow_rect = body_rect.copy(); shadow_rect.y += 8
pygame.draw.rect(self._window, palette["body_shadow"], shadow_rect, border_radius=20)
pygame.draw.rect(self._window, palette["body"], body_rect, border_radius=20)
pygame.draw.rect(self._window, palette["body_shadow"], body_rect, 2, border_radius=20)

# 3) 디스플레이 (검은 사각형, 둥근 모서리)
display_rect = pygame.Rect(110, 110, 260, 260)
pygame.draw.rect(self._window, palette["display"], display_rect, border_radius=12)
inner_rect = display_rect.inflate(-4, -4)
pygame.draw.rect(self._window, palette["display_tint"], inner_rect, border_radius=8)

# 4) 흰 픽셀 얼굴 (디스플레이 안에)
self._draw_face(inner_rect, palette["pixel"])

# 5) 감정 라벨 (본체 아래 둥근 박스)
self._draw_emotion_label(body_rect, palette)
```

### EMOTION_PALETTE 6개 키 구조 (확장 가능)

```python
EMOTION_PALETTE = {
    "happy": {
        "bg": (235, 240, 245),         # 윈도우 배경 (옅은 회색)
        "body": (252, 252, 252),       # 본체 흰색
        "body_shadow": (210, 215, 220),# 본체 그림자
        "display": (10, 10, 15),       # 디스플레이 검정
        "display_tint": (30, 25, 20),  # 디스플레이 살짝 색조
        "pixel": (255, 255, 255),      # 얼굴 픽셀 색
        "label_bg": (255, 220, 100),   # 감정 라벨 배경
        "eye_style": "happy_arc",      # _draw_pixel_eyes가 분기
        "mouth_style": "big_smile",    # _draw_pixel_mouth가 분기
    },
}
```

### ⚠️ Pitfall: pygame.arc 좌표계 + vision 해석 한계

**3차례 크래시 + 3차례 방향 혼란**을 거쳐 검증된 발견:

```python
# pygame.arc(rect, start, end)는 시계방향 그림.
# y축이 아래로 증가하는 좌표계에서:
# - 0~π  → 호가 rect 위쪽에 그려짐 (위로 볼록 ∩)
# - π~2π → 호가 rect 아래쪽에 그려짐 (아래로 볼록 ∪)

# 그러나 vision_analyze가 위를 보고:
# - 0~π 호를 "아래로 휜 슬픈 입"으로 잘못 해석함 (3번 반복)
# - 픽셀 점 sin 곡선은 "위로 볼큰 ∪"로 정확히 해석함
```

**결론: 입/눈은 무조건 픽셀 점 (sin 곡선)으로 그릴 것. pygame.arc 사용 금지.**

```python
# ✅ 권장: 픽셀 점 sin 곡선
def _smile_big(self, cx, cy, color, width=80, depth=22):
    for i in range(21):
        t = i / 20.0
        px = cx - width // 2 + int(width * t)
        py = cy + int(-depth * math.sin(math.pi * t))  # 위로 볼록 (∪)
        pygame.draw.circle(self._window, color, (px, py), 3)

# ❌ 금지: pygame.arc (방향 혼란)
pygame.draw.arc(self._window, color, (x, y, w, h), 0.15*math.pi, 0.85*math.pi, 5)
# → vision이 슬픈 표정으로 잘못 해석
```

### 20개 표정 디자인 시스템 (StackChan 영감)

**표정 이름**은 `Gitshaoxiang/xiaozhi-esp32-avatar` (MIT)에서 차용, **디자인/좌표/색상은 100% 자체 구현**. 라이선스 안전.

| 표정 | eye_style | mouth_style | 비고 |
|---|---|---|---|
| happy | happy_arc | big_smile | ^ ^ + 큰 활짝 웃음 |
| laughing | closed_x | big_o | > < + 큰 O |
| funny | happy_arc | small_smile | ^ ^ + 살짝 |
| sad | sad_line | frown | ; ; + 내려간 입 |
| angry | angry_slash | zigzag | \> /< + 지그재그 |
| cry | crying | frown | ; ; + 눈물 흐름 |
| thinking | thinking_line | small_dot | - . + 점 |
| surprised | big_o | small_o | O O + 작은 O |
| shocked | huge_o | big_o | 큰 O O + 큰 O |
| winking | wink (asymmetric) | small_smile | 한쪽 ^, 한쪽 — |
| cool | sunglasses | small_smile | ▬▬ 선글라스 |
| loving | heart | small_o | ♥ ♥ |
| embarrassed | line | small_dot | - - + 점 |
| kissy | closed_x | kiss | > < + X + ♥ |
| confident | happy_arc | smug | ^ ^ + 비웃는 |
| relaxed | relaxed_line | small_smile | 〰 〰 |
| delicious | happy_arc | yum | ^ ^ + ∪ + 혀 |
| sleepy | closed_line | small_dot | — — + 점 |
| silly | asymmetric (O+o) | tongue | 큰 O + 작은 o + 혀 |
| confused | cross | zigzag | X X + 지그재그 |
| neutral | circle | small_smile | o o + 살짝 |

### vision_analyze로 PNG 시각 검증 패턴

매 디자인 변경 후 **반드시 PNG로 저장 + vision_analyze로 검증**:
1. 코드 수정 → preview PNG 5~21장 생성
2. vision_analyze로 표정 라벨 일치 확인
3. 표정-라벨 불일치 발견 시 코드 방향 수정

**vision 해석 한계 주의**:
- arc/원 기반 렌더링: 50% 확률로 방향 오인
- 픽셀 점 기반 렌더링: 95%+ 정확히 해석
- 색상: 정확
- 본체/디스플레이: 정확

### 디자인 결정 brainstorm 패턴 (Brainstorming-first)

사용자가 "stackchan처럼 만들어줘" → 3가지 옵션 제시 → A 선택 → 디테일 iterate:

| 단계 | 결정 포인트 | 옵션 |
|---|---|---|
| 1 | 캐릭터 스타일 | A: 키위 미니멀 / B: 풀세트(안테나) / C: 사실적 |
| 2 | 눈 스타일 | 1: 단순 동그라미 / 2: 흰눈+동자+하이라이트 / 3: OLED |
| 3 | 표정 표현 | a: 눈만 / b: 눈+입 / c: 전부 |
| 4 | 키위 본체 | i: 단색 / ii: 씨앗 점 / iii: 점박이 |

**매번 "이 옵션의 트레이드오프 + 추천" 구조로 제시 → 사용자가 "그대로 진행해"로 확정**.

## 🛡️ 오픈소스 자산 재사용 라이선스 워크플로

세션 #2에서 사용자가 "판매중인 M5Stack StackChan 얼굴 리소스 받아올 수 있을까?" 요청 → **체계적 라이선스 조사 후 가장 깨끗한 경로 선택**하는 워크플로 검증.

### 우선순위 (가장 자유로운 것부터)

1. **MIT** — 상업적 사용 OK, 수정 OK, 저작자 표시만 → ✅ 가장 안전
2. **Apache-2.0** — MIT과 거의 동일, LICENSE 사본 포함 → ✅ 안전
3. **BSD-2/3-Clause** — MIT과 거의 동일 → ✅ 안전
4. **CC0 / Public Domain** — 모든 권리 포기 → ✅ 무제한
5. **CC BY** — 저작자 표시만 → ✅ 사용 OK
6. **CC BY-SA** — 동일 라이선스 전파 (2차 창작물도 SA) → ⚠️ OK
7. **CC BY-NC** — 비영리만 → ❌ 상업 채널에 사용 금지
8. **CC BY-NC-SA** — 비영리 + SA → ❌
9. **GPL-3.0** — 2차 창작물도 GPL 공개 의무 → ⚠️ 신중
10. **라이선스 미명시** — All Rights Reserved 기본 → ❌ 사용 금지
11. **All Rights Reserved (커뮤니티 아트)** → ❌

### 조사 명령 시퀀스 (반복)

```bash
# 1. GitHub 리포의 LICENSE 파일 raw URL
curl -sL https://raw.githubusercontent.com/<owner>/<repo>/main/LICENSE | head -50

# 2. GitHub repo 페이지 (description에 license 배지 확인)
curl -sL https://github.com/<owner>/<repo> | grep -i 'license\|MIT\|Apache\|GPL' | head

# 3. submodule (서브모듈은 별도 라이선스)
# → 본체는 MIT인데 submodule은 All Rights Reserved 가능
```

**예시 결과 (M5Stack StackChan)**:
- `m5stack/StackChan/firmware/LICENSE` → **MIT** ✅
- `stack-chan/stack-chan/LICENSE` → **Apache-2.0** ✅
- `stack-chan/m5stack-avatar` → LICENSE 파일 없음 → ❌ (All Rights Reserved)
- `Gitshaoxiang/xiaozhi-esp32-avatar/LICENSE` → **MIT** ✅

### 차용 범위 원칙 (License-Safe Borrowing)

| 차용 OK | 차용 NG |
|---|---|
| ✅ 알고리즘/수학적 방법 (sin 곡선, 호 그리기) | ❌ 이미지/디자인 자산 (PNG, SVG) |
| ✅ 표정 이름/명명 규칙 (영어 단어) | ❌ 색상 팔레트 RGB 값 (디자인 선택) |
| ✅ 매핑 구조 (텍스트→표정→렌더링) | ❌ 픽셀 좌표 (디자인 선택) |
| ✅ 시스템 프롬프트 패턴 | ❌ 캐릭터 일러스트 |

→ CREDITS.md에 MIT 저작자 + 라이선스 전문 + 변경 사항 명시

### CREDITS.md 템플릿 (MIT 차용 시)

```markdown
# CREDITS

## <출처 프로젝트>
- Repository: <URL>
- License: MIT
- Copyright: (c) <year> <author>
- 참고 내용: <차용한 구체적 부분>

### 우리 프로젝트에서 무엇을 구현했는가
- ❌ 이미지/디자인 자산 차용 안 함
- ✅ 알고리즘과 구조 참고 — <구체적>
- ✅ <플랫폼>으로 재구현

### 라이선스 전문
<전문 붙여넣기>

## 변경 사항
본 프로젝트는 위 MIT 라이선스의 구조적 영감을 받아 다음을 자체 구현:
1. <자체 구현 1>
2. <자체 구현 2>
```

### ⚠️ 유튜브 자동화 + NC-SA 충돌 (2026-06-23)

희정님 채널 자동화 (Tistory, YouTube Shorts/일반 영상) — **상업적 사용이 가능한 라이선스만 채택**. NC/NC-SA 자료는 유튜브 자동화 파이프라인에 부적합.

→ **미리 license 트래커 + "상업 사용 OK" 필터**로 차단 (decommission/automation-audit 스킬과 통합).

## 🛠️ 메인 루프 통합 (워커 스레드 + 큐)

```python
import argparse
import queue
import select
import sys
import threading
import time
from typing import List, Dict

import face
import llm
from tts import KiwiSpeaker

event_queue: "queue.Queue[Dict]" = queue.Queue()

def llm_worker(user_text, conversation, max_history, speaker, use_tts):
    """워커 스레드: LLM 호출 + TTS 발화. 결과를 큐로 메인에 통지."""
    try:
        event_queue.put({"type": "thinking_start"})
        result = llm.call_llm(user_text, conversation=conversation[-max_history:])
        text = result["text"]
        emotion = result["emotion"]
        event_queue.put({"type": "emotion", "emotion": emotion, "text": text})
        if use_tts:
            event_queue.put({"type": "speaking_start"})
            speaker.say(text, blocking=False)
        event_queue.put({"type": "speaking_end", "text": text, "emotion": emotion})
    except Exception as e:
        event_queue.put({"type": "error", "message": str(e)})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-tts", action="store_true")
    parser.add_argument("--max-history", type=int, default=20)
    args = parser.parse_args()

    if not os.environ.get("MINIMAX_API_KEY"):
        print("[오류] MINIMAX_API_KEY 없음. source ~/.hermes/secrets/minimax.env")
        sys.exit(1)

    face_obj = face.KiwiFace()
    if not face_obj.init_pygame():
        print("[치명] pygame init 실패")
        sys.exit(1)

    speaker = KiwiSpeaker()
    stdin_fd = sys.stdin.fileno()

    def stdin_has_data():
        return select.select([stdin_fd], [], [], 0.0)[0]

    def read_stdin_line():
        if not stdin_has_data(): return None
        line = sys.stdin.readline()
        return line.rstrip("\n") if line else ""

    conversation: List[Dict] = []
    is_thinking = False

    face_obj.set_emotion("happy")
    greeting = "안녕~! 나는 키위야. 오늘 기분 어때?"
    print(f"[키위] {greeting}")
    if not args.no_tts:
        speaker.say(greeting, blocking=False)
    conversation.append({"role": "assistant", "content": greeting})

    try:
        while not face_obj.is_quit_requested():
            # 1) 워커 큐 비우기
            try:
                while True:
                    ev = event_queue.get_nowait()
                    if ev["type"] == "thinking_start":
                        is_thinking = True
                        face_obj.set_emotion("thinking")
                    elif ev["type"] == "emotion":
                        face_obj.set_emotion(ev["emotion"])
                        print(f"[키위:{ev['emotion']}] {ev['text']}")
                    elif ev["type"] == "speaking_start":
                        face_obj.set_speaking(True, 0.7)
                    elif ev["type"] == "speaking_end":
                        is_thinking = False
                        face_obj.set_speaking(False)
                        conversation.append({"role": "assistant", "content": ev["text"]})
                    elif ev["type"] == "error":
                        is_thinking = False
                        face_obj.set_emotion("sad")
                        print(f"[오류] {ev['message']}")
            except queue.Empty:
                pass

            # 2) stdin 폴링
            line = read_stdin_line()
            if line is not None and line.strip() and not is_thinking:
                user_text = line.strip()
                conversation.append({"role": "user", "content": user_text})
                if len(conversation) > args.max_history * 2:
                    conversation = conversation[-args.max_history * 2:]
                is_thinking = True
                face_obj.set_emotion("thinking")
                t = threading.Thread(
                    target=llm_worker,
                    args=(user_text, conversation, args.max_history, speaker, not args.no_tts),
                    daemon=True,
                )
                t.start()

            # 3) pygame 한 프레임
            if not face_obj.tick():
                break

            time.sleep(0.005)  # ~200 FPS cap

    except KeyboardInterrupt:
        pass
    finally:
        face_obj.set_emotion("neutral")
        if not args.no_tts:
            speaker.say("잘 가~! 다음에 또 놀자!", blocking=False)
        time.sleep(0.8)
        face_obj.shutdown()
        speaker.stop()
```

## 📋 검증된 환경 (2026-06-23)

| 항목 | 값 |
|---|---|
| OS | macOS 15.5 (Intel Mac) |
| Python | 3.11 (conda env) |
| pygame | 2.6.1 |
| pyttsx3 | 2.99 |
| LLM | MiniMax-M3 (Anthropic 호환 API) |
| TTS | macOS Yuna (compact ko-KR) |
| 얼굴 윈도우 | 480x480 Pygame, 메인 스레드 tick() 루프 |
| 표정 시스템 | 21개 (20 감정 + 깜빡임) |
| 활성 비동기 스레드 | 0개 (NSEventThread만 — AppKit 메인) |

## 📁 첨부 파일

- `templates/kiwi-companion-readme.md` — 4-모듈 구조 README 템플릿
- `references/case-study-2026-06-23.md` — 세션 #1 풀 노트 (브레인스토밍 결정 4개 + 환경 함정 + 첫 대화)
- `references/session-2-stackchan-iteration-2026-06-23.md` — 세션 #2 노트 (StackChan 스타일 + 3대 크래시 + 20개 표정 + 라이선스 정리)
- `references/macos-voice-priority.md` — macOS 한국어/일본어/영어 음성 우선순위 + 정확 매칭 패턴
- `references/llm-emotion-tag-tuning.md` — 시스템 프롬프트 패턴 + 컨텍스트 약화 한계 + 폴백 전략
- `references/macos-nswindow-main-thread.md` — NSWindow 메인 스레드 제약 + 메인 스레드 + 워커 큐 패턴
- `references/macos-pygame-crash-3pitfalls.md` — 3대 pygame race condition (init/clock/thread) 디버깅 케이스 스터디
- `scripts/headless-test.sh` — `SDL_VIDEODRIVER=dummy`로 4가지 모듈 자동 검증
- `scripts/verify-design-png.sh` — 21개 표정 PNG 자동 생성 + vision_analyze 호출 가이드

## ⚠️ 검증된 함정 (Pitfalls) — 통합

1. **Apple Silicon 전용 앱 함정** — StackChan World (App Store)는 Apple Silicon M1+ 전용. Intel Mac에서 설치 시도 시 "이 Mac은 지원되지 않습니다" 에러. **macOS Ventura+ & M1+ 요구사항**을 사용자에게 미리 확인.

2. **Hermes 내부와 사용자 conda 환경 site-packages 분리** — `pip install --user`로 시스템 Python에 깔아도 conda base 터미널에서는 import 실패. **반드시 사용자 환경에 맞는 설치 명령 안내**.

3. **conda base pip 죽음** — `InvalidVersion: '4.0.0-unsupported'` 에러로 base에 pip install 불가. **conda 환경 분기**가 유일한 견고한 해결.

4. **pyttsx3 thread-safety** — engine.runAndWait()는 thread-unsafe. **단일 threading.Lock**으로 직렬화 필수.

5. **단순 substring 음성 매칭 함정** — `any(k in name for k in keys)`는 Eloquence 음성("Korean" 포함)이 Yuna보다 먼저 매칭됨. **우선순위 키워드 루프 + 정확 매칭**.

6. **pygame random 위치 떨림** — 매 프레임 `random.randint()` 호출 시 점 위치가 깜빡임. **고정 시드 `random.Random(42)` + deterministic 위치**.

7. **LLM 감정 태그 컨텍스트 약화** — 4~6턴 이상 누적 시 태그 출력 빈도 감소. **폴백 "neutral" + 2차 분류/키워드 백업** 옵션 v2.

8. **헤드리스에서 GUI 검증 불가** — pygame 윈도우는 SSH/CI 환경에서 안 뜸. **`SDL_VIDEODRIVER=dummy` + stdin 파이프**로 모듈 단위 + 전체 파이프라인 자동 검증.

9. **(2026-06-23 1차 크래시) pygame.init() 오디오 race** — `pygame.init()`은 `SDL_INIT_AUDIO` 자동 활성화 → `AudioQueue`/`AQConverter`/`IOThread` 비동기 스레드 생성 → pyttsx3와 오디오 디바이스 경합 → EXC_BAD_ACCESS. **명시적 init (`display.init()` + `font.init()`)만 사용**.

10. **(2026-06-23 3차 크래시) pygame.time.Clock() SDLTimer race** — `pygame.time.Clock()` 인스턴스화 시 SDL 내부 timer 활성화 → `SDLTimer` 스레드 생성 → 메인 스레드의 `PyDict_SetItemString` race → `pgEvent_New`에서 NULL deref. **Clock 사용 안 하고 time.sleep(0.005~0.016)으로 throttle**.

11. **(2026-06-23 2차 크래시) NSWindow 메인 스레드 제약** — `pygame.display.set_mode()`는 macOS Cocoa에서 NSWindow를 생성하는데 **반드시 메인 스레드에서만** 가능. **별도 스레드에서 set_mode ❌ → 메인 스레드 init + 워커 큐 패턴**.

12. **(2026-06-23) mixer import도 위험** — `pygame.mixer` 모듈이 import만 되어도 audio subsystem이 부분 init될 수 있음. **`os.environ["SDL_AUDIODRIVER"] = "dummy"` 환경변수 사전 설정**으로 차단.

13. **miniMax → NIM 폴백 의존** — LLM이 메인 quota 소진 시 폴백 자동 전환. **API 키는 `~/.hermes/secrets/<provider>.env`**에 source 가능한 형태. main.py에서 자동 source.

14. **(2026-06-23) pygame.arc 좌표계 + vision 해석 한계** — pygame.arc는 `0~π = 위쪽 ∩`, `π~2π = 아래쪽 ∪`을 그리는데 vision_analyze가 이걸 50% 확률로 **반대로 해석**. 3차례 happy 입이 "슬픈 표정"으로 평가됨. **해결: 입/눈은 무조건 픽셀 점 (sin 곡선)으로 그리고 pygame.arc 사용 금지**.

15. **(2026-06-23) 오픈소스 자산 재사용 시 license-first 조사** — 사용자가 "X의 얼굴/이미지 받아와"라고 요청하면 **즉시 코드 작성하지 말 것**. 1) 라이선스 조사 (LICENSE raw URL curl), 2) 우선순위 (MIT > Apache > BSD > CC0 > CC BY > CC BY-SA > ⚠️GPL > ❌NC/NC-SA > ❌미명시), 3) **차용 OK (알고리즘/이름/구조) vs NG (이미지/색상/좌표) 분리**, 4) 깨끗한 경로 결정. → MIT 자료만 차용하고 디자인은 100% 자체 구현 + CREDITS.md 명시.

16. **(2026-06-23) `pygame.mixer` import 자체도 조심** — `import pygame` 후 mixer를 직접 안 부르더라도 mixer 모듈이 자동으로 부분 init될 수 있음. **`os.environ["SDL_AUDIODRIVER"] = "dummy"` 환경변수를 import 전에 설정**해야 안전. Hermes 헤드리스 검증에서 mixer.get_init() == False 확인 필수.

17. **(2026-06-23) BSD-3-Clause 같은 비공식 포크 출처 차용 시 출처 명시 필수** — "M5Stack stackchan처럼 만들어줘"는 **이름/명명 규칙/매핑 구조**만 차용, **디자인 자산은 100% 자체 구현**이어야 깨끗. CREDITS.md에 "이미지/디자인 차용 안 함" 명시.

18. **(2026-06-23) face.py 단독 import 시 pyobjc-framework-AppleScript 등 자동 import** — `import face`만 해도 macOS 환경에서 다양한 framework 모듈이 import되며, 이게 mixer init를 트리거할 수 있음. **헤드리스 검증은 import 단계부터 dummy driver 환경변수 설정 후** 진행.

19. **(2026-06-23) brainstorming 결정은 2~3 옵션 + 추천 패턴 유지** — 4차례 brainstorm 단계 (외형/눈/표정/본체)에서 2~3 옵션 + 추천 + tradeoff 명시. 사용자가 "그대로 진행해" 한마디로 확정. **이전 세션과 동일한 패턴이므로 그대로 유지** (이미 SOUL.md / AGENTS.md에 명시).

20. **(2026-06-23) 디자인 검증은 vision_analyze + PNG 자동화** — `pygame.image.save()`로 PNG 저장 → `mcp_minimax_understand_image`로 표정-라벨 일치 확인 → 불일치 시 코드 방향 수정. **vision은 arc/원 기반 렌더링을 잘못 해석하지만 픽셀 점은 정확히 해석**.

## 🔗 관련 스킬

- `text-game-builder` — LLM 기반 인터랙티브 시스템 + 시스템 프롬프트 + 상태 머신 차용
- `python-oss-bootstrap` — 4-모듈 + README + LICENSE 구조 차용
- `remotion-video` — 백그라운드 스레드 + 비동기 상태 객체 패턴 차용
- `comfyui` — 3rd-party SDK 통합 + 비공식 API 처리 패턴

## 🛣️ 로드맵 (v2+)

- [ ] STT 통합 (Whisper 로컬 또는 macOS Speech Framework)
- [ ] PNG 외형 (현재는 pygame primitive 도형)
- [ ] 표정 전환 시 부드러운 애니메이션 보간
- [ ] 대화 로그 저장 (SQLite)
- [ ] 맥락 표정 (시간대/날씨/사용자 활동 기반)
- [ ] 2차 LLM 호출로 감정 분류 정확도 ↑
- [ ] M5Stack StackChan 디바이스 연동 (실제 서보 모터)
- [ ] 음성 입력 시 자동 인터럽트 (TTS 중단 + 듣기 모드)
- [ ] cross-platform (Linux/Windows) — 위 macOS 함정들은 Linux에선 발생 안 함, 가드 코드 조건부 적용 필요
