# Session 2026-05-24 — Firefox Project Nova blog post

## Topic
- selected_topic: "미래를 위한 Firefox 디자인"
- source_url: https://news.hada.io/topic?id=29789
- category: AI/ML (1219746)

## Execution

### Step 1: blog_pipeline.py
```bash
python3 ~/.hermes/scripts/blog_pipeline.py
```
Status: ready. Selected topic confirmed fresh.

### Step 2: Content gathering
- GeekNews source via `mcp_ddg_search_fetch_content`
- Additional search via `mcp_ddg_search_search`

### Step 3: Markdown writing
- 2155 chars written to `/tmp/blog_post_20260524.md`
- CJK pre-scan found: `{号, 虑, ジ, ペ, ー, 疑, 代}`
- 1-pass comprehensive cleanup → 0 residual

### Step 4: Quality gate
```bash
python3 ~/.hermes/scripts/blog_quality_gate.py \
  --file /tmp/blog_post_20260524.md \
  --category "AI/ML" \
  --tags "Firefox,Project Nova,Mozilla,브라우저,개인정보 보호,UI 디자인,접근성"
```
Result: Grade A (77/100), decision: pass

### Step 5: HTML conversion
```bash
python3 ~/.hermes/scripts/markdown_to_tistory_html.py \
  /tmp/blog_post_20260524.md \
  /tmp/blog_tistory_20260524.html \
  --source-url "https://news.hada.io/topic?id=29789"
```
Output: 3366 bytes, CJK cleaning: 0 passes (clean from start)

### Step 6: Cover image
```bash
curl -sL "https://picsum.photos/seed/firefox-nova/800/400" -o /tmp/firefox_nova_cover.jpg
```
- Uploaded to GitHub blog-images: `20260524-firefox-nova-a3f.jpg`
- Inserted into HTML using `<h1` replacement pattern:
```python
html = html.replace('<h1', cover_image + '<h1', 1)
```
**Note:** `html.replace('<body>', ...)` does NOT work with markdown_to_tistory_html.py output — it has no `<body>` tag.

### Step 7: Tistory publish
```bash
python3 ~/.hermes/scripts/tistory_publisher.py \
  --title "미래를 위한 Firefox 디자인 — Project Nova 완전 해부" \
  --file /tmp/blog_tistory_20260524.html \
  --tags "Firefox,Project Nova,Mozilla,브라우저,개인정보 보호,UI 디자인,접근성" \
  --visibility public \
  --category 1219746
```
Result: ✅ Success — https://sigco.tistory.com/501

### Step 8: Record
```bash
python3 ~/.hermes/scripts/blog_pipeline.py --record "미래를 위한 Firefox 디자인" \
  "미래를 위한 Firefox 디자인 — Project Nova 완전 해부" \
  "https://news.hada.io/topic?id=29789"
```

## Key finding

**`blog_quality_gate.py` path resolution**: When running from `~/.hermes/hermes-agent/` workdir, `~/.hermes/scripts/blog_quality_gate.py` fails with "can't open file". Must use absolute path `python3 ~/.hermes/scripts/blog_quality_gate.py` or run from `~/.hermes/scripts/` directly.

Same applies to `blog_pipeline.py`, `markdown_to_tistory_html.py`, `tistory_publisher.py` — always use `~/.hermes/scripts/` prefix or full absolute path when calling from a different working directory context.