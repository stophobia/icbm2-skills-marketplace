---
name: api-key-manager
description: API Key的生命주기 관리 — 발급, 파일 저장, 만료 감시, Telegram 알림까지 Entire 파이프라인. 공공데이터포털(data.go.kr) 키 관리에 특화.
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [Automation, API, Secret, Expiry, Monitoring]
  created: 2026-05-14
---

# API Key Manager 스킬

## 개요

외부 API Key를 체계적으로 관리하고, 만료일을 추적하며 자동 알림을 주는 파이프라인.

**주 사용처:**
- 공공데이터포털 (data.go.kr) API 키
- 다른 외부 API 키들도 동일한 패턴 적용 가능

## 파일 명명 규약 (Naming Convention)

```
~/.hermes/secrets/
  {platform}_expiry_YYYYMMDD.txt    ← 만료일 관리 대상 키 (7일 전 알림)
  {platform}_key.txt               ← 만료일 없는 일반 키 (감시 안 함)
```

**`{platform}_expiry_YYYYMMDD.txt` 파일 규칙:**
- 파일명: `{플랫폼명}_expiry_{만료일(YYYYMMDD)}.txt`
- 내용: API Key 원본 (첫 줄만 또는 `KEY=값` 형태)
- 예: `datagokr_expiry_20280514.txt` → 만료일 2028-05-14

**`{platform}_key.txt` 파일 규칙:**
- 만료일 없는 일반 키 파일
- 스크립트가 자동 감지하지만 만료 알림은 보내지 않음

## 모니터링 스크립트

**스크립트:** `~/.hermes/scripts/apikey_holiday_monitor.py`

```bash
# Key 만료 체크 (7일 전부터 매일 알림)
python3 ~/.hermes/scripts/apikey_holiday_monitor.py --check-expiry

# 공휴일/연휴 조회 (14일 내)
python3 ~/.hermes/scripts/apikey_holiday_monitor.py --holidays current
python3 ~/.hermes/scripts/apikey_holiday_monitor.py --holidays 2026 12
```

## 크론 잡 설정

| 시간 | 작업 | 설명 |
|------|------|------|
| 09:00 | `--check-expiry` | Key 만료 7일 전부터 매일 알림 |
| 10:00 | `--holidays current` | 14일 내 공휴일/연휴 알림 |

## 새 키 추가 절차

1. **발급 받기** → 공공데이터포털에서 API Key 발급
2. **파일 저장** → 만료일 포함 파일명 사용
   ```bash
   echo "API_KEY_값" > ~/.hermes/secrets/{platform}_expiry_YYYYMMDD.txt
   ```
3. **즉시 검증** → 만료일 포함되었는지 확인
   ```bash
   python3 ~/.hermes/scripts/apikey_holiday_monitor.py --check-expiry
   ```

## ⚠️ data.go.kr API Quirks

[data.go.kr API 특징과 한계](references/datagokr-api-quirks.md)를 반드시 참조할 것.

## Telegram 알림 설정

환경 변수 `TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID` 설정 시 텔레그램으로 직접 전송.
미설정 시 stdout만 출력 (크론 로그에서 확인).

```bash
# Telegram 설정 확인
echo "TOKEN: ${TELEGRAM_BOT_TOKEN:-(not set)}"
echo "CHAT: ${TELEGRAM_CHAT_ID:-(not set)}"
```

## Pitfalls

- **Python global 변수 문제:** `DATAGOKR_KEY` 같은 모듈 전역 변수는 함수 안에서 `global` 선언 필수. 안 하면 `UnboundLocalError` 발생 (2026-05-14 버그 history)
- **http vs https:** 공공데이터포털 API는 `https://` 필수. `http://`는 타임아웃
- **만료일 형식:** YYYYMMDD 8자리. YYYY-MM-DD 형식 불가
