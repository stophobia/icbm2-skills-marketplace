# MiniMax CLI Music Generation — Techniques

## 음악 길이 3분 이상 만들기 (확인됨 2026-05-23)

`--duration` 파라미터 작동 안 함. 작동하는 방법:

**방법: 매우 긴 가사 + section별 상세 bar 수 명시**

```bash
mmx music generate \
  --prompt "Utaite style, upbeat J-pop inspired Korean pop, 120 BPM, cheerful female vocal. Full-length song approximately 3 minutes 30 seconds." \
  --lyrics "[Intro - extended instrumental with vocal ad-libs, 16 bars]
[Verse 1 - full 32 bars with complete lyrical content]
...
[Chorus - powerful and extended, 24 bars with multiple vocal layers]
...
[Bridge - emotional and extended, 16 bars]
...
[Final Chorus - climax with full instrumentation, 24 bars]
...
[Outro - gradual fade, 16 bars]
la la la la la la la la~" \
  --out music.mp3
```

**핵심 포인트:**
- `Verse 1` → `(32 bars)` 처럼 상세 bar 수 명시
- `Chorus` → `24 bars with multiple vocal layers` 처럼 감정적 강도 추가
- Outro에 `fade out` 명시
- 결과: **212초 (3분 32초)** 성공

## 가사 필터링 — 한자/일본어 제거 (2026-05-23)

Notion의 음악프롬프트에 한자/일본어가 섞여 있으면 음악 생성 시 문제가 발생함.

**필터링 함수:**
```python
import re

def filter_lyrics(text):
    """한국어와 영어만 남기고 한자/일본어/기타 문자 제거"""
    # 한글 (가-힣) + 영어 + 기본 punctuation + 공백/줄바꿈만 허용
    filtered = re.sub(r'[^\uAC00-\uD7A3a-zA-Z0-9\s.,!?~()\-\'\"]+', '', text)
    # 연속된 공백 정리
    filtered = re.sub(r'\s+', ' ', filtered).strip()
    return filtered
```

**테스트 결과:**
```
원본: 골목 끝 네온불빛이 반짝여 街灯の下で二人歩いた
필터후: 골목 끝 네온불빛이 반짝여
```

## CLI 기본 사용법

```bash
# 인증 (env 파일)
source ~/.hermes/secrets/minimax.env

# 이미지 생성
mmx image generate --prompt "..." --out image.png

# 음악 생성
mmx music generate --prompt "..." --lyrics "..." --out music.mp3

# 오디오만 생성 (가사 자동)
mmx music generate --prompt "..." --lyrics-optimizer --out music.mp3

# 인스트루멘탈
mmx music generate --prompt "..." --instrumental --out bgm.mp3
```