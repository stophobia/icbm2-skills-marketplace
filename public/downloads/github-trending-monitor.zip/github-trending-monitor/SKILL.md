---
name: github-trending-monitor
description: GitHub Trending 리포지토리 + 관심 리포의 새 릴리즈를 매일 자동으로 수집하여 Notion DB에 저장하고, 텔레그램용 한국어 요약을 출력하는 스킬. AI/ML/iOS 관련 리포만 필터링.
tags: [github, automation, cron, notion, korean, translation]
---

# GitHub Trending + Release Monitor

## 설명
GitHub 트렌딩 리포지토리와 관심 프로젝트의 새 릴리즈를 자동으로 모니터링하는 스킬입니다.
AI/ML/iOS 관련 트렌딩 리포를 수집하고, 관심 리포지토리의 릴리즈를 추적하여 Notion DB에 저장합니다.
Telegram용 한국어 요약도 함께 출력합니다.

## 스크립트
- `scripts/github_trending_monitor.py`
- 번역 패턴 상세: [references/translation-api.md](references/translation-api.md)

## 사용법

### 기본 실행 (전체 수집 + Notion 저장)
```bash
python3 scripts/github_trending_monitor.py
```

### 간결한 요약만 (--summary)
```bash
python3 scripts/github_trending_monitor.py --summary
```

### Notion 저장 없이 확인만
```bash
python3 scripts/github_trending_monitor.py --no-notion
```

### 릴리즈만 확인
```bash
python3 scripts/github_trending_monitor.py --releases-only
```

### 트렌딩만 확인
```bash
python3 scripts/github_trending_monitor.py --trending-only
```

## 설정

### 관심 리포지토리 (WATCHED_REPOS)
스크립트 내 `WATCHED_REPOS` 리스트에 추가/수정:
- anthropics/claude-code
- opencode-ai/opencode
- openai/swarm
- langchain-ai/langchain
- microsoft/autogen
- ollama/ollama
- vercel/ai
- anthropics/anthropic-sdk-python
- google-gemini/generative-ai-python
- swiftlang/swift
- apple/swift-openai-generator
- sirwandrie/llm-swift

### Notion DB
- **DB ID**: 33f76f2e-9097-8176-a537-d40ebb476ef9
- **부모 페이지**: ICBM 봇 (2f876f2e909780d797e5e7aa58f7c0c8)
- **속성**: Name, URL, Description, Stars, Language, Category, TrendingTopic, Date

### 트렌딩 카테고리
- Python, Swift, TypeScript (GitHub Trending 페이지 기반)

### 필터링 키워드
AI/ML 관련: ai, llm, gpt, claude, gemini, agent, langchain, transformer 등
iOS 관련: ios, swift, swiftui, uikit, xcode, apple, iphone 등

### 상태 파일
- `data/github_trending_state.json` — 마지막 확인한 릴리즈 태그 저장

### Cron 스케줄
매일 오전 9시 KST 실행:
```
0 0 * * * cd ~/.hermes/scripts && /usr/local/bin/python3 github_trending_monitor.py --summary >> /tmp/github_trending.log 2>&1
```

> ⚠️ **Python 호환성 주의**: `/usr/bin/python3` (시스템)에는 `bs4`, `requests` 등 의존성이 없음.
> `/usr/local/bin/python3` (Homebrew)에만 의존성이 설치되어 있음. 반드시 `/usr/local/bin/python3` 사용.
> `cd`를 빼면 작업 디렉토리 차이로 스크립트 내부의 상대 경로가 깨질 수 있음.

## 출력 형식
Telegram 메시지로 전달하기 적합한 한국어 요약을 출력합니다.
--summary 플래그 시 간결하게 상위 3개만 표시합니다.

## 한국어 번역
영어 description은 자동으로 한국어로 번역되어 출력/저장됩니다.
- **API**: MyMemory 무료 API (키 불필요, 일 5000자 한도)
- **Notion**: `🇰🇷 한국어 번역 + 🌐 원문` 형태로 Description 필드에 저장
- **Telegram 요약**: `🇰🇷 한국어` 한 줄 추가
- **릴리즈 노트**: 번역 안 함 (markdown/이슈 트래커 깨질 위험)
- **실패 시**: 원문 그대로 fallback (크론 실패 방지)
- **캐시**: 세션 내 dict 캐시로 같은 description 반복 번역 방지
- **상세 구현/한계/대안 API**: [references/translation-api.md](references/translation-api.md)
