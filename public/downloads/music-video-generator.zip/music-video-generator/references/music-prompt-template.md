# 음악프롬프트 템플릿 (2026-05-23)

## 필수 필드: 모든侯選 등록 시 음악프롬프트 반드시 포함

Notion DB `36976f2e-9097-81e1-a373-e06f2da6e99c`에 주제를 등록할 때,
**음악프롬프트 필드가 비어 있으면 크론 실행 시 음악 생성 실패**로 이어진다.

## 템플릿 구조

```
[Intro - {악기/분위기}, {bar 수} bars]
[Verse 1 - {장르描述}, {bar 수} bars]
{한국어 가사 - 구체적 상황 묘사}
[Verse 2 - {변화/발전}, {bar 수} bars]
{한국어 가사}
[Chorus - {후렴 분위기}, {bar 수} bars]
{브릿지 - 감정적 클라이맥스}
[Bridge - {긴장감 빌드업}, {bar 수} bars}
{Final Chorus - {압축적 결말}, {bar 수} bars]
[Outro - {fade out 등}, {bar 수} bars]
```

## 예시 (유머/위트 topic: 고양이 Face ID)

```
[Intro - Playful synth arpeggio, 8 bars]
[Verse 1 - Cheerful synth melody, 16 bars]
고양이가 내 핸드폰을 열고Situation, Face ID가 오작동
animal furry face가 human으로 인정받은Tonight
[Chorus - Catchy and funny, 16 bars]
고양이가 unlock을 했어,어떻게 이게 가능해?
내 얼굴이 아니라 고양이Face로,push pull 상황
[Verse 2 - Building rhythm, 16 bars]
귀여운 발바닥이 화면을 두드리고,notification이 떨어져
주인님은 당황,고양이는 여유롭게 앉아
[Bridge - Comic tension, 8 bars]
安防カメラ가 이 장면을 찍고 있으면,SNS에 업로드 되는ima
[Final Chorus - Full energy, 16 bars]
기술은 발전했지만,生物 인식의 한계는 여전해
고양이가 phone을 쓰는 세상, kita는 웃을 수밖에 없어
[Outro - Fade with meow sound, 8 bars]
```

## ⚠️ 한자/일본어 필터링 주의

`music_video_producer.py`의 `filter_lyrics()`가 한자/일본어를 제거하지만,
섹션 마커(`[Verse 1]` 등)는 영어로 유지해야 한다.

**가사 내용에 한자가 섞여 있으면:**
- 일본 기업명, 한자 고유명사 → 제거됨
- 의미 전달에 필수적인 한자 → 영어로 대체

**예시:**
```
원본: 東京駅에서 만난 낯선 사람, 그의 눈빛이 좋았어
필터후: 에서 만난 낯선 사람, 그의 눈빛이 좋았어
→ "东京駅"이 제거됨 → 의미 전달에 영향 없음 (장소 특정而已)
```