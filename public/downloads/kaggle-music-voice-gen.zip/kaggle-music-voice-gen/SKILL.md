---
name: kaggle-music-voice-gen
description: "음악/음성 생성 가이드 — ACE-Step 1.5 (카글) + edge-tts (로컬, 기본 TTS)"
tags: [tts, voice, music, edge-tts, ace-step, deprecated-kaggle]
---

# 음악/음성 생성

> ⚠️ **2026-06-03 갱신:** macOS 로컬 음악 생성의 기본 경로를 **`mmx music generate` (MiniMax CLI)** 로 전환. TTS는 edge-tts 유지. Kaggle ACE-Step은 인스트루멘탈 폴백으로 격하.

## 의사결정 트리 (가장 먼저 볼 것)

```
음악이 필요한가?
├─ TTS(말)/나레이션 → edge-tts → qwen3-tts 스킬 참조
└─ 보컬 포함 노래곡
   ├─ 1순위: mmx music generate (로컬 CLI, 즉시)
   ├─ 2순위: Suno/Udio 웹 (브라우저, 수동 업로드 필요시)
   └─ 폴백 (인스트루멘탈만): Kaggle ACE-Step
```

## 1. mmx music generate (기본, 권장)

> **왜 기본인가:** macOS/리눅스/윈도우 모두 즉시 실행. 한국어 가사, 여성 보컬, IU 풍 프롬프트까지 한 번에 처리. 30초~1분 안에 mp3 산출.

### 사전 점검
```bash
which mmx           # 보통 /usr/local/bin/mmx
mmx --version       # 1.0.16 이상 권장
mmx auth status     # API key 인증 상태 (json에 "method": "api-key" 확인)
```

### 갱신 (작업 시작 전 필수)
```bash
mmx update         # 현재 버전 확인
npm update -g mmx-cli   # 갱신 권고가 뜨면 실행
mmx --version      # 갱신 결과 재확인
```

> 💡 **Pitfall (학습된 워크플로우):** 사용자가 "업데이트 후 진행"을 명시적으로 요청함. **음악 생성 작업 시작 전엔 항상 `mmx update` 확인부터**. 단순 도구 실행이 아니라, 작업 흐름의 일부임.

### 핵심 플래그
| 플래그 | 용도 | 예시 |
|------|------|------|
| `--prompt` | 스타일 묘사 (2000자) | `"korean k-pop ballad, warm, healing, piano"` |
| `--lyrics-file` | 가사 파일 (3500자) | `lyrics/song.txt` |
| `--vocals` | 보컬 톤 | `"bright female soprano, IU-inspired, breathy"` |
| `--genre` | 장르 | `pop ballad` |
| `--mood` | 무드 | `warm, melancholic, comforting` |
| `--instruments` | 악기 | `"piano, soft strings, brushed drums"` |
| `--bpm` | 템포 | `70` |
| `--key` | 조성 | `D major` |
| `--references` | 레퍼런스 | `"IU, Paul Kim"` |
| `--out` | 출력 경로 | `output/song.mp3` |
| `--format` | 포맷 | `mp3` (기본) |
| `--model` | 모델 | `music-2.6` (기본) |

### 발라드 보컬곡 실행 예시
```bash
mmx music generate \
  --prompt "korean female vocal, emotional k-pop ballad, piano ballad, soft pop, singer-songwriter, warm and gentle, late night, soft strings, brushed drums, healing, comforting" \
  --vocals "bright female soprano, IU-inspired, breathy, whispery" \
  --genre "pop ballad" \
  --mood "warm, comforting, healing" \
  --instruments "piano, soft strings, brushed drums, acoustic guitar" \
  --bpm 70 --key "D major" \
  --references "IU 밤편지, Paul Kim" \
  --lyrics-file lyrics/song.txt \
  --out output/song_v1.mp3
```

> 📄 **상세 옵션/실패 대응법**: `references/mmx-music-cli.md`
> 📝 **보컬곡 프롬프트 템플릿**: `templates/ballad-prompt.md`

## 2. Suno / Udio (웹 폴백)

mmx 인증이 만료/실패했고, **직접 클릭해서 받고 싶을 때**:
- [suno.com](https://suno.com), [udio.com](https://udio.com)
- mmx `--prompt` 내용을 **Style of Music** 칸에 그대로 붙여넣기
- 가사 파일 내용 복사해서 Lyrics 칸에 붙여넣기
- Custom Mode에서 Female Vocal / K-Pop / Ballad 지정

> 💡 **Pitfall:** Suno 무료는 월 50크레딧. 결과 mp3는 Suno 워터마크 포함 → 유튜브 업로드 시 저작권 클린(상업적 사용은 Pro 필요).

## 3. Kaggle ACE-Step 1.5 (인스트루멘탈 폴백)

> ⚠️ 인스트루멘탈만 가능. 보컬 합성 못 함. 40분 유휴 타임아웃, 주 30시간 GPU 제한.

### 주의사항 (T4)
- `ACESTEP_DTYPE=float32` 필수
- uv venv 패키지 사용 시 sys.path 추가 필요
- wav 출력 후 ffmpeg으로 mp3 변환

### 사용 중단 사유 (상시 서버 불가)
- 카글 40분 유휴 타임아웃
- 주간 GPU 30시간 제한

## 4. HeartMuLa / HeartCodec (로컬 GPU, 대안 X)

> macOS에서는 사실상 사용 불가 (Triton 미지원, CPU 모드는 30~60분+ 소요).
> Kaggle/RunPod 같은 클라우드 GPU에서만 가성비 있음. macOS 로컬에서는 항상 mmx 또는 Suno 우선.

## 보컬곡 제작 시 워크플로우 (학습된 패턴)

1. **갱신**: `mmx update` → `npm update -g mmx-cli` → `mmx --version`
2. **가사 작성**: 원곡/주제 분석 → 한국어 가사 초안 → 구조태그([Verse]/[Chorus] 등) 적용 → 파일 저장
3. **제목 차별화 확인**: 원곡/참고곡과 명백히 다른지 사용자 확인 (특히 파생창작물)
4. **프롬프트 패키징**: `--prompt` + `--vocals` + `--genre` + `--mood` + `--instruments` + `--bpm` + `--key` + `--references` 채워서 한 번에 호출
5. **실행**: `--out` 으로 mp3 저장
6. **피드백 루프**: 사용자가 "분위기 X, Y 바꿔줘" 요청 시 → 프롬프트만 수정해서 v2 생성 (가사 재작성은 신중)

> 💡 **Pitfall (제목 차별화, 학습됨):** 사용자가 원곡 「평범하게 네 곁에 있고 싶어」 기반 창작곡을 의뢰했을 때, 처음 제안한 「그냥 곁에 있을게」를 "원곡과 너무 비슷하다"고 거절함. **파생 창작물은 반드시 사용자 확인 후 제목 확정** — 자동 선택 금지.
