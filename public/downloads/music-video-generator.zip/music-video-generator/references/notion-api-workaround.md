# Notion API Workaround for Music Video DB (2026-05-25)

## Problem

`POST /v1/databases/{DB_ID}/query` returns 404 from external tools (execute_code, plain curl):
```
"Could not find database with ID: 36976f2e--909-7-81-e1-a-373e06f2da6e"
```

But `music_video_producer.py` successfully calls the same endpoint. The token resolution differs per environment.

## Root Cause

The integration "ICBM2호" works from hermes environment but fails from other tools due to how `NOTION_API_KEY` is resolved.

## Verified Workarounds

### Option 1: search endpoint (always works)
```python
import urllib.request, json
NOTION_API_KEY = open("/Users/hjshin/.hermes/secrets/notion_token.txt").read().strip()
url = "https://api.notion.com/v1/search"
data = json.dumps({"filter": {"value": "database", "property": "object"}}).encode()
req = urllib.request.Request(url, data=data, method='POST')
req.add_header('Authorization', f'Bearer {NOTION_API_KEY}')
req.add_header('Notion-Version', '2022-06-28')
with urllib.request.urlopen(req) as resp:
    dbs = json.loads(resp.read())['results']
    mv_db = next(d for d in dbs if d['id'] == '36976f2e-9097-81e1-a373e06f2da6e99c')
    parent_page_id = mv_db['parent']['page_id']  # "2f876f2e-9097-80d7-97e5-e7aa58f7c0c8"
```

### Option 2: create pages via parent page ID (works)
```python
PARENT_PAGE_ID = "2f876f2e-9097-80d7-97e5-e7aa58f7c0c8"
payload = {
    "parent": {"page_id": PARENT_PAGE_ID},
    "properties": {
        "주제": {"title": [{"text": {"content": "테스트 주제"}}]},
        "상태": {"select": {"name": "대기"}},
    }
}
# POST to /v1/pages with API 2022-06-28
```

### Option 3: use music_video_producer.py (most reliable)
The producer script already handles the DB correctly — use its `notion_query()` pattern.

## DB Schema (discovered 2026-05-25)
```
주제: title, 이미지프롬프트: rich_text, 음악프롬프트: rich_text,
뉴스출처: url, 유튜브URL: url, 영상경로: rich_text, 음악스타일: rich_text,
생성일: date, 상태: select (대기/승인/보류/완료), 분위기: select (차분한/밝은/감성적/강렬한/유머/신나는)
```

## Manual Topic Registration (Simplest)
When API is problematic, register topics directly in Notion UI:

| Field | Required | Notes |
|-------|----------|-------|
| 주제 | ✅ | Title — humorous/witty scenario |
| 상태 | ✅ | Set to "대기" |
| 분위기 | recommended | Select: 신나는/유머/밝은/감성적/강렬한/차분한 |
| 음악프롬프트 | optional | Leave blank — auto-generated |
| 이미지프롬프트 | optional | Leave blank — auto-generated |
| 뉴스출처 | ❌ | No longer required (2026-05-25 rule) |

## Related
- DB ID: `36976f2e-9097-81e1-a373e06f2da6e99c`
- Parent Page ID: `2f876f2e-9097-80d7-97e5-e7aa58f7c0c8`
- Script: `~/.hermes/scripts/music_video_producer.py`