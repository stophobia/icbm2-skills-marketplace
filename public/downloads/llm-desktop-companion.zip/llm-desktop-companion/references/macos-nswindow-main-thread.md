# macOS NSWindow Main-Thread Constraint (v2 — 3대 pygame race condition 통합)

**세션**: 2026-06-23 (kiwi-companion stackchan simulator)
**환경**: macOS 15.5 + Python 3.11 + pygame 2.6.1

## 핵심 결론

NSWindow 메인 스레드 제약만 처리하면 **3가지 race condition 중 1개만** 해결됨. **반드시 같이 처리할 3가지**:

1. **NSWindow 메인 스레드** — `set_mode()`는 main thread 전용
2. **pygame.init() 오디오 race** — audio subsystem 자동 init 금지
3. **pygame.time.Clock() 타이머 race** — SDLTimer thread 생성 금지

자세한 디버깅 케이스 스터디는 `macos-pygame-crash-3pitfalls.md` 참조.

---

## 1차 증상: NSWindow 크래시

GUI 코드 맞아 보임, TTS 동작, LLM 응답, **하지만 pygame 윈도우 안 뜸**. 터미널에:

```
pygame.error: NSWindow should only be instantiated on the main thread!
```

채팅은 동작 (LLM/TTS는 영향 없음), GUI만 조용히 실패. 자동 테스트에서 놓치기 쉬움.

## 2차 증상: 오디오 race (수정 후에도)

`pygame.init()` + `pygame.time.Clock()` 패턴으로 NSWindow은 해결했지만, `EXC_BAD_ACCESS (SIGSEGV)` 새 크래시. 크래시 리포트에서 `AudioQueue`, `AQConverterThread`, `com.apple.audio.IOThread` 같은 비동기 스레드 다수 보임 → SDL audio 자동 init이 pyttsx3와 경합.

## 3차 증상: SDLTimer race (오디오 init 수정 후에도)

`pgEvent_New` → `PyDict_SetItemString` → NULL deref. `SDLTimer` 스레드만 살아있는데 메인 스레드 dict 조작과 race.

## 근본 원인

macOS Cocoa backend는:
- `NSWindow` 객체 생성 = **main thread only**
- `pygame.init()` = `SDL_INIT_AUDIO` 자동 활성화 → 비동기 오디오 스레드들
- `pygame.time.Clock()` = SDL 내부 timer 활성화 → `SDLTimer` 스레드

이 셋이 **각각 다른 비동기 스레드를 만들어서** 메인 스레드와 race.

## 최종 해결 (3가지 통합)

### 메인 스레드 + 워커 큐 패턴

```python
import queue
event_queue = queue.Queue()  # worker → main

def llm_worker(user_text, history, speaker, use_tts):
    try:
        event_queue.put({"type": "thinking_start"})
        result = llm.call_llm(user_text, conversation=history)
        text, emotion = result["text"], result["emotion"]
        event_queue.put({"type": "emotion", "emotion": emotion, "text": text})
        if use_tts:
            event_queue.put({"type": "speaking_start"})
            speaker.say(text, blocking=False)
        event_queue.put({"type": "speaking_end", "text": text, "emotion": emotion})
    except Exception as e:
        event_queue.put({"type": "error", "message": str(e)})

# Main thread:
face.init_pygame()  # NSWindow on main thread ✓
while not face.is_quit_requested():
    # 1) Drain worker events (non-blocking)
    try:
        while True:
            ev = event_queue.get_nowait()
            if ev["type"] == "thinking_start": face.set_emotion("thinking")
            elif ev["type"] == "emotion": face.set_emotion(ev["emotion"])
            elif ev["type"] == "speaking_start": face.set_speaking(True, 0.7)
            elif ev["type"] == "speaking_end": face.set_speaking(False)
            elif ev["type"] == "error": face.set_emotion("sad")
    except queue.Empty: pass

    # 2) Read stdin non-blocking
    import select
    if select.select([sys.stdin], [], [], 0.0)[0]:
        line = sys.stdin.readline().strip()
        if line and not is_thinking:
            threading.Thread(
                target=llm_worker,
                args=(line, history, speaker, use_tts),
                daemon=True,
            ).start()

    # 3) One pygame frame
    face.tick()
    time.sleep(0.005)  # ~200 FPS cap, SDLTimer 안 띄움
```

### Face API — 절대 하면 안 되는 것들 명시

```python
class KiwiFace:
    def init_pygame(self) -> bool:
        """pygame 초기화 + 윈도우 생성. 메인 스레드에서만 호출."""
        if self._initialized: return True
        try:
            # ❌ 절대 안 됨:
            #   pygame.init()                  # SDL audio 자동 init → race
            #   self._clock = pygame.time.Clock()  # SDLTimer 활성화 → race
            #   threading.Thread(target=face.run)  # NSWindow main thread 위반

            # ✅ 명시적 init만
            import os
            os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
            pygame.display.init()
            pygame.font.init()
            # pygame.time.init() 안 함, Clock 안 만듦

            pygame.display.set_caption("Kiwi Companion")
            self._window = pygame.display.set_mode((self.WINDOW_SIZE, self.WINDOW_SIZE))
            self._initialized = True
            self._ready = True
            return True
        except Exception as e:
            print(f"[face] init 실패: {e}")
            return False

    def tick(self) -> bool:
        """한 프레임 처리. 메인 스레드에서 호출."""
        if not self._initialized: return False
        for event in pygame.event.get():
            if event.type == pygame.QUIT: return False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return False
        if self._quit_requested: return False
        self._update(time.time())
        self._draw()
        pygame.display.flip()
        # ❌ self._clock.tick(60)  # SDLTimer race
        return True

    def shutdown(self):
        if self._initialized:
            try: pygame.quit()
            except: pass
            self._initialized = False
```

## setter는 어떤 스레드에서든 안전

`set_emotion`, `set_speaking`, `request_quit`는 단순 instance attr 변경이라 워커 스레드에서 호출해도 안전. **pygame API 호출 (init, draw, flip, event poll)만 메인 스레드 필요.**

## 진단 단계

1. **NSWindow 에러 in traceback** → 스레드 패턴 잘못됨, 위 패턴으로 리팩토링
2. **EXC_BAD_ACCESS with 오디오 스레드** → `pygame.init()` 사용 중. `display.init()` + `font.init()`만으로 교체 + `SDL_AUDIODRIVER=dummy`
3. **EXC_BAD_ACCESS in pgEvent_New/PyDict_SetItemString** → `pygame.time.Clock()` 사용 중. `time.sleep()`으로 throttle
4. **No error but window missing** → `print(pygame.display.get_driver())`가 `cocoa`여야 함. `dummy`면 `SDL_VIDEODRIVER` leak
5. **Window off-screen** → `F3` (Mission Control) 또는 `Cmd+Space → "Kiwi"`로 찾기

## 검증 체크리스트 (안정성 가드)

```python
import pygame
assert not pygame.mixer.get_init(), "mixer init됨 — 오디오 race 위험"
assert not pygame.time.get_init() if hasattr(pygame.time, 'get_init') else True
```

`os.environ["SDL_AUDIODRIVER"] = "dummy"` 환경변수만 설정해도 mixer init 자체를 막을 수 있음.

## Cross-Platform

- **Linux (X11/Wayland)**: NSWindow 제약 없음. 1차 크래시 안 남. 단 `pygame.init()`은 audio init 발동하므로 Intel Linux에서도 mixer 안 쓸 거면 명시 init 권장.
- **Windows**: MS 윈도우. COM apartment 메인 스레드 제약은 유사. 패턴은 동일하게 적용.

→ **macOS가 가장 까다롭고, 검증된 패턴은 다른 플랫폼에서도 안전**.

## Reference

자세한 크래시 리포트 + 디버깅 단계 + 비교 분석: `macos-pygame-crash-3pitfalls.md`
