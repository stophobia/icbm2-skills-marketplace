# Cron Timeout 문제 해결 (2026-05-24)

## 문제

크론 Job `a77ee904fa61` (매일 20:00)이 `no_agent` 모드로 설정되어 있어 기본 타임아웃 120초에 종료됨.

실제 스크립트 소요 시간:
- 이미지 3장 생성: ~360초 (각 120초 × 3)
- 음악 생성: ~300초
- 영상 합성 + Shorts: ~100초
- **총합: ~760초 (12분 이상)**

## ✅ 적용된 해결책

**가장 간단한 방법: `HERMES_CRON_SCRIPT_TIMEOUT` 환경변수 설정**

```bash
# ~/.hermes/.env에 추가 (cron 재시작 불필요, 새 크론 실행 시 자동 적용)
HERMES_CRON_SCRIPT_TIMEOUT=600
```

이후 gateway 재시작 불필요. 다음 크론 실행부터 600초(10분) 타임아웃 적용.

**기타 설정 방법:**
- `config.yaml`: `cron: { script_timeout_seconds: 600 }`
- CLI: `hermes config set cron.script_timeout_seconds 600`

## timeout 우선순위 (내림차순)

1. `HERMES_CRON_SCRIPT_TIMEOUT` 환경변수 (가장 우선)
2. `cron.script_timeout_seconds` in config.yaml
3. `_DEFAULT_SCRIPT_TIMEOUT = 120` (기본값)

## 소스 코드 확인 (scheduler.py)

```python
# ~/.hermes/hermes-agent/cron/scheduler.py
_DEFAULT_SCRIPT_TIMEOUT = 120

def _get_script_timeout() -> int:
    # 우선순위: _SCRIPT_TIMEOUT → HERMES_CRON_SCRIPT_TIMEOUT env → config → default
```

## 현재 상태

- Job ID: `a77ee904fa61`
- 스케줄: `0 20 * * *` (매일 20:00)
- 상태: `error` (마지막 실행 2026-05-24 20:02 실패)
- **해결 완료:** `HERMES_CRON_SCRIPT_TIMEOUT=600` 설정됨 → 다음 20시 크론부터 적용