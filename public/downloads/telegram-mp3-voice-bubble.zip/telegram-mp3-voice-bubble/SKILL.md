---
name: telegram-mp3-voice-bubble
description: "텔레그램에서 mp3를 음성 메시지 버블로 전달할 때 ffmpeg 재인코딩 우회법"
version: 1.0.0
platforms: [macos, linux]
metadata:
  hermes:
    tags: [telegram, audio, mp3, voice-bubble, ffmpeg, media-delivery]
    related_skills: []
---

# Telegram mp3 → 음성 버블 변환

## 문제
Hermes의 `MEDIA:/path/to/file.mp3` 태그는 텔레그램에서 **음악 파일 첨부**로 전달되거나, 텍스트로 출력되어 사용자에게 도달하지 않을 수 있다. **음성 메시지 버블**(OGG Opus, 자동 재생, 모바일 친화)로 전달하려면 컨테이너와 코덱을 맞추는 게 안정적.

## ffmpeg 인코더 가용성 체크
```bash
ffmpeg -encoders | grep -iE "opus|vorbis|libmp3lame"
```
- **macOS brew ffmpeg**: `libmp3lame`은 보통 포함. `libopus` / `libvorbis`는 별도.
- **opus / vorbis**는 ffmpeg 빌드에 따라 `libopus` / `libvorbis`이거나 네이티브 (`opus` / `vorbis`)

## 우회법: 30초 mp3 미리듣기 재인코딩
```bash
ffmpeg -y -i input.mp3 -ss 0 -t 30 \
  -c:a libmp3lame -b:a 96k -ac 1 -ar 22050 \
  output_preview.mp3
```
- **모노 + 22.05kHz + 96kbps** 조합은 텔레그램 음성 버블로 인식될 확률이 높음
- 30초 길이 제한 권장 (음성 메시지 인식의 sweet spot)
- 원본 full mp3은 별도로 저장해서 사용자가 요청 시 첨부로 전달

## 절대 안 되는 패턴
```bash
# ❌ 컨테이너/코덱 불일치
ffmpeg -i input.mp3 -c:a opus output.ogg
# → "Conversion failed" (opus 컨테이너에 mp3 못 담음)

# ❌ 인코더 이름 오타
ffmpeg -i input.mp3 -c:a libopus output.ogg
# → "Unknown encoder 'libopus'" (네이티브는 `opus`)
```

## 전체 워크플로우
1. `mmx music generate` 또는 다른 도구로 mp3 생성
2. `ffprobe`로 메타데이터 확인 (codec, duration, bitrate)
3. 30초 미리듣기 mp3 생성 (위 명령)
4. Hermes `MEDIA:` 태그로 전달
5. 사용자가 full 버전 요청 시 원본 mp3 경로 제공

## 검증
```bash
ffprobe -v error -show_format -show_streams output_preview.mp3
# codec_name=mp3, sample_rate=22050, channels=1, bit_rate=96000 확인
```

## Pitfalls
1. **30초 미리듣기 너무 짧으면** — 사용자가 분위기 판단 못함. 30~60초 적정.
2. **모노 변환 시 스테레오 효과 손실** — 미리듣기니까 OK. full 버전은 스테레로 유지.
3. **ffmpeg 빌드마다 인코더 이름 다름** — `-encoders | grep`으로 먼저 확인.
4. **opus 코덱 직접 사용 시** — `c:a opus` (네이티브) 또는 `c:a libopus` (외부 빌드). 둘 다 아니면 빌드 부족.
5. **telergam 인식** — 봇 API로 보내는 경우 attach_document vs sendVoice 구분 필요. Hermes `MEDIA:`는 후자 우선.

## Links
- ffmpeg 공식: https://ffmpeg.org/ffmpeg-formats.html
- 텔레그램 봇 API sendVoice: https://core.telegram.org/bots/api#sendvoice
