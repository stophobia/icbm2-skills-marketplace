# 세션 83차 — 2026-06-04 새벽 cron (Codex Sites 블로그 발행)

## 발행 결과
- 주제: OpenAI, Codex에서 웹사이트를 만들어 배포하는 Sites 플러그인 공개
- 제목: OpenAI Codex Sites 플러그인 공개 — 프롬프트만으로 웹사이트를 만들어 배포하는 새로운 개발 패러다임
- URL: https://sigco.tistory.com/624
- 카테고리: AI/ML (1219746)
- 본문: 3,833자 (HTML 검증 통과)
- Markdown: 3,862자, 28개 단락, H2 7개, H3 7개
- 태그: OpenAI,Codex,Sites,플러그인,웹사이트,AI개발,Cloudflare,D1,R2
- 품질: Grade A (79점) — content 35, readability 13, originality 20, SEO 11
- CJK/Cyrillic: 0회차 통과 (한자·일본어·중국어·키릴 모두 0)

## 주요 학습

### 1. inline `python3 -c` 패턴이 heredoc보다 빠른 경우
- 짧은 검증/CJK 검사/단순 replace는 inline `python3 -c "..."`로 처리
- 4줄 이상 multi-step은 heredoc `<< 'PYEOF'`
- 82차 reference의 `execute_code-cron-blocked.md`를 보강 (패턴 1 추가)
- 이 세션에서 사용한 inline 예시:
  ```bash
  python3 -c "
  import re
  with open('/tmp/blog_post.md', 'r') as f:
      md = f.read()
  cjk = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', md))
  print('CJK:', cjk if cjk else '없음')
  "
  ```

### 2. Picsum 시드명 규칙
- `https://picsum.photos/seed/{키워드}/800/400` 형태로 시드에 주제 키워드 사용
- 예: `https://picsum.photos/seed/codex-sites/800/400` → 항상 동일 이미지 (재현 가능)
- 파일명 규칙과 동일하게 `YYYYMMDD-{키워드}-{해시}` 형식으로 blog-images에 업로드
- 이번 세션: `20260604-codex-sites-a7f.jpg`

### 3. tistory_publisher.py 자동 OG 썸네일 설정
- 발행 시 Tistory가 본문 첫 이미지를 자동 OG 썸네일로 설정
- 별도 `--thumbnail` 인자 불필요
- 발행 로그:
  ```
  🖼️  이미지 업로드 중... (1/1)
  🖼️  이미지 업로드 성공: image.jpg (32KB)
  🖼️ OG 썸네일 설정: https://blog.kakaocdn.net/dna/...
  ✅ 발행 성공!
  ```
- 82차에서는 "Picsum + Tistory CDN 자동 삽입"이 문제였으나, 이번에는 **명시적으로 GitHub raw URL을 HTML에 직접 삽입**했더니 Tistory가 그 첫 이미지를 그대로 OG 썸네일로 설정
- **해결:** SKILL.md의 "GitHub 호스팅" 정책이 82차와 다르게 이번 세션에서 정상 동작 — 원인은 HTML에 `<img src="https://raw.githubusercontent.com/...">`가 있으면 Tistory가 그걸 OG로 인식
- 82차 reference의 "옵션 1 (--no-images 플래그)" 필요성 약화 — 명시적 GitHub URL 삽입 시 충돌 없음

### 4. 평균 문장 길이 54자에서도 감점 없음
- SKILL.md에 명시된 임계치: 60자 이상이면 가독성 감점
- 실제 이번 글: avg_sentence_length 54.5, sentence_count 67, 가독성 13/20 (감점 7)
- 즉, 50자대 후반은 가독성 13 확보 가능 — 50자 미만이면 15~17점까지 올라갈 것으로 추정
- **임계치:** 50자 이하면 양호, 60자 이상이면 가독성 감점 시작

### 5. markdown_to_tistory_html.py + --source-url 패턴
- 이번 세션 출처가 긱뉴스(`https://news.hada.io/topic?id=30128`)였음
- `--source-url` 인자로 자동 출처 HTML 섹션이末尾에 추가됨
- Markdown 본문에는 출처 섹션을 **작성하지 않음** (중복 방지, SKILL.md § 67차 교훈)

### 6. cron에서 `tistory_publisher.py` 발행 로그
- 정상 흐름: Content 검증 → 제목/태그 표시 → 이미지 업로드 → OG 썸네일 → 발행 성공 URL
- 모든 단계가 1초 이내 — 발행 후 URL만 회신받으면 됨

## 발행 흐름 타임라인
1. `blog_pipeline.py` → Codex Sites 주제 선정 (GeekNews #30128)
2. `mcp_ddg_search_fetch_content`로 긱뉴스 본문 + web_search로 영문 기사 9건 수집
3. Markdown 작성 (3,929자, CJK 0개)
4. inline `python3 -c` CJK 검사 → 없음
5. `blog_quality_gate.py --tags` → Grade A (79점) 통과
6. `markdown_to_tistory_html.py --source-url` 변환 (5,677 bytes)
7. inline `python3 -c`로 커버 이미지 삽입 (raw.githubusercontent.com URL)
8. `tistory_publisher.py` → 발행 성공 (sigco.tistory.com/624)
9. `blog_pipeline.py --record` → 중복 방지 해시 기록
10. 임시 파일 정리 (`rm -f`)

## 발견된 인사이트 (후속)

### ✅ 82차 "이미지 호스팅 정책 충돌" 해결
- 82차에서는 의도치 않게 Picsum + Tistory CDN 자동 삽입됐지만, 이번에는 HTML에 명시적 GitHub raw URL을 넣음
- Tistory는 HTML 첫 이미지를 OG 썸네일로 자동 설정하므로, 깁 호스팅 정책이 정상 동작
- SKILL.md의 "GitHub blog-images 호스팅" 정책은 유지 — 단, HTML에 명시적으로 `<img src="https://raw.githubusercontent.com/...">`를 삽입해야 함
- 82차 reference의 "옵션 1 (--no-images 플래그)"는 불필요 — 깁 호스팅을 원할 때 명시적 삽입이 더 깨끗
