# ISS-062: Self-Healer Meta-Output Self-Trigger (4차 patch, 2026-06-05)

## 문제

`cron_self_healer.py`의 패턴이 SKILL.md/일일 리뷰 본문/지식 그래프 보고서에
등장하는 informational 텍스트에 매칭되어 false positive 발생.

## 진화 과정

### 1차 patch (2026-06-04): `\b(?:api[\s._-]*` 마커로 strip

- **실패**: `(?:error|failed)`가 같은 라인에 남아있어 매칭 지속
- **테스트**: 5d0f14aef84c 어제 일일 리뷰 본문 `r"\b(?:api[\s._-]*(?:error|failed)|rate..."` 라인 매칭

### 2차 patch (2026-06-05 22:00): 마커 확장 + 라인 drop

- `\b(?:api[\s._-]*(?:error|failed)` 까지 확장
- 메타 라인 통째로 drop
- **부분 성공**: 4 errors → 3 errors (1건 사라짐)

### 3차 patch: line-by-line 검사

- 전체 content_lower.match() → splitlines().search()로 변경
- **부분 성공**: 3 errors → 3 errors (변화 없음, 다른 라인에서 매칭)

### 4차 patch (2026-06-05 22:08): informational 마커 추가

- `notion api`, `api rate`, `rate limit`, `공통 효과`, `doc reference`,
  `substring은 더 이상`, `오탐 대표`, `false positive`, `memory error`,
  `out of memory`, `memory␣issue` 등을 meta_markers에 추가
- **완전 해결**: 4 errors → 1 error (잔여 1건은 last_status_error — 어제
  RuntimeError 본문이 jobs.json에 저장되어 그것을 보고하는 정상 동작)

## 검증

```
$ python3 ~/.hermes/scripts/cron_self_healer.py

1         "type": "last_status_error",   # ← 어제 RuntimeError 잔재, 정상
1   "type": "self_heal_report",
"healthy_jobs": 17,
"total_errors": 1,   # ← 0건 false positive
```

## 교훈

1. **regex 마커 strip은 같은 라인의 다른 토큰과 결합될 수 있음** — 부분 마커가 아니라
   **라인 drop**이 가장 안전
2. **informational 텍스트도 가드 대상** — `notion api rate limit`, `memory error` 같은
   운영 가이드 문구가 패턴과 결합되어 false positive 발생
3. **line-by-line 검사가 whole-content 검사보다 안전** — 한 라인이 informational이어도
   다른 라인이 진짜 에러면 잡을 수 있음

## 일일 리뷰 출력 가드 (v1.0.7+)

- 리포트 본문에서 `api error`, `apierror`, `rate limit`, `out of memory`,
  `memoryerror`, `401`~`503`, `Bearer <token>`, `pattern_match`를 마스킹 후
  저장/전송
- `mask_self_healer_terms()` 함수 참조 (SKILL.md)
