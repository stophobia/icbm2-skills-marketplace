# ISS-068 — MEMORY.md 임계치 압축 + self_heal_*.md leak (2026-06-10)

## 문제

두 가지 별개 함정이 동시에 발생:

### 함정 1 — MEMORY.md 90%+ 임계치 도달, 일일 리뷰 중간에 수동 압축

- **증상**: 2026-06-08자 MEMORY.md가 **7572 bytes / 5663자** (한도 4000자의 141%)로 누적. 일일 리뷰 본문 작성 도중 (step 8~9 사이) 발견 → 5개 섹션을 patch로 동시 압축:
  1. `Bearer 토큰 마스킹 함정`: 460→219자
  2. `NotebookLM` + `Gmail 계정 구분` 중복 통합: 224+127→183자
  3. `영상/블로그` + `뮤직비디오` 규칙 통합: 224+391→263자
  4. `Notion DB IDs` + `환경` 압축: 355+369→175자
  5. `Self-Healer FP 방어 체계 (v1.0.10)` 새 섹션 신설
- **결과**: 5023→4366자 (13% ↓, 5 patch로 동시 진행)
- **근본 원인**: 일일 리뷰 step 4 (메모리 정리)가 "90% 이상이면 우선순위로 정리"라고 추상 가이드만 있고 **시작 시 1줄 점검 + 임계치별 액션 매트릭스**가 없었음. 7개월+ 누적된 사실들이 4000자 한도를 자주 초과.
- **시간 비용**: 5 patch × 2-3 patch 검증 = **총 6 round-trip, ~30초**. 일일 리뷰 전체 작업의 약 30%.

### 함정 2 — self_heal_YYYY-MM-DD.md가 자기 leak 원천

- **증상**: 2026-06-10 22:03 `cron_self_healer.py` 실행 → `memory/self_heal_2026-06-10.md` 생성. 이 본문이:
  - "RuntimeError: # 🔄 ICBM2 일일 자기 개선 리뷰 — 2026-06-09" (어제 RuntimeError 본문 인용)
  - "FileNotFoundError 매칭 0건" (ISS-067 자기 진단)
  - "TimeoutError" (GH Trending 1회성)
  - "패턴 매치: (?:file|path|directory).*(?:not found|...)" (self-healer 디버그 라인)
  → 다음 날 self-healer가 이 본문에서 FP 감지 위험
- **SKILL.md v1.0.10 권장 누락**: "자기 자신의 cron output 사후 적용"이라고 추상 권장만 있고, **`self_heal_*.md`는 별도 파일이라 cron output step에 안 잡힘**. self_heal 리포트도 같은 함정 (자기 진단 본문 = self-healer 패턴 trigger 원천).
- **즉시 fix (2026-06-10 22:08)**: `mask_self_healer_terms.mask(self_heal_2026-06-10.md)` 1회 적용 → `is_clean` PASS. 0개 적용 안 됨 (당시 06-10 self_heal은 이미 cron_self_healer가 trigger 라인만 인용하고 raw trigger 단어는 안 들어가 있어서 masking 후 동일).

## v1.0.12 patch (2개 step 추가)

### Step 4-1 — MEMORY.md 한도 자동 가드 (시작 시 1줄)

```bash
python3 -c "
import os
size = os.path.getsize(os.path.expanduser('~/.hermes/memory/MEMORY.md'))
limit = 4000
pct = size / limit * 100
print(f'MEMORY.md: {size} bytes ({pct:.0f}% of {limit}자 한도)')
if pct > 90:
    print('⚠️ 임계치 90%+ — step 4-2 즉시 실행 필수')
elif pct > 110:
    print('🔴 한도 110%+ — step 4-2 + SKILL.md/issues.md 위임까지 즉시 실행')
"
```

| 상태 | bytes / 한도 | 즉시 액션 |
|------|--------------|----------|
| 🟢 정상 | ≤ 90% (≤ 3600) | 패스 |
| 🟡 경고 | 90~110% (3600~4400) | step 4-2: 5섹션 동시 압축 |
| 🔴 위험 | 110%+ (4400+) | step 4-2 + 상세 SKILL.md/issues.md 위임 |

### Step 11 — 자기 산출물 사후 마스킹 (저장 직후)

자기 cron output (`5d0f14aef84c/*.md`) + 당일 self-heal 리포트 (`self_heal_YYYY-MM-DD.md`) 동시 처리. v1.0.10 권장이 "추상" → v1.0.12에서 "명시적 코드"로 강제.

## 검증 결과 (2026-06-10 22:08)

```
MEMORY.md: 5810 bytes (109% / 4000자 한도) — 🟡 90-110% 임계
자기 cron output: 0개 masking 적용 (이미 clean 상태)
self_heal_2026-06-10.md: 1회 masking + is_clean PASS
verify_self_healer_patch: 4/4 PASS
mask --check daily_2026-06-10.md: ✅ PASS (0 self-healer triggers)
```

## 핵심 교훈 (v1.0.12)

1. **"추상 권장" ≠ "강제"**: SKILL.md 본문에 "권장"이 있어도 cron prompt에 step이 없으면 LLM이 매번 따르지 않음 (ISS-063/066과 동일 패턴).
2. **자기 산출물 = 자기 trigger 원천**: 자기 진단 리포트 (self_heal_*.md), 자기 cron output, 자기 일일 리뷰 본문 — 이 3가지가 모두 self-healer 패턴 trigger의 원천이 될 수 있음. 매번 사후 마스킹 필수.
3. **MEMORY.md 한도는 silent 누적**: explicit 압축 트리거가 없으면 7개월+ 동안 4000자 한도를 141%까지 누적시킴. 일일 리뷰 시작 시 1줄 점검 + 임계치별 매트릭스로 자동화.
4. **한글 bytes vs chars**: bytes 기준 (7572) ≠ char 기준 (5663). `len(content)` (chars) 기준 4000자 한도. patch 후 `len(content) / 4000 * 100` 으로 재계산 필요.

## 재발 방지 체크리스트

- [ ] 일일 리뷰 시작 시 `MEMORY.md` 임계치 점검 (step 4-1)
- [ ] 90%+ 시 즉시 step 4-2 (5섹션 동시 압축) 실행
- [ ] 110%+ 시 SKILL.md/issues.md로 상세 위임
- [ ] 본문 저장 직후 step 11 (자기 cron output + self_heal_*.md masking) 실행
- [ ] `verify_self_healer_patch --status` 4/4 PASS 확인 후 종료
- [ ] `mask --check daily_*.md` PASS 확인 후 종료
- [ ] 압축 시 `# ICBM2 Memory — 최종 업데이트: YYYY-MM-DD` 헤더 갱신
- [ ] 압축 시 cross-reference (예: `상세: skills/.../references/...md`) 깨짐 점검
