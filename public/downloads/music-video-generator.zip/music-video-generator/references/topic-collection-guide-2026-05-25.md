# 뮤직비디오侯選 수집 가이드 (2026-05-25)

## 문제: DuckDuckGo 검색 차단

DuckDuckGo가 Reddit/X를 크롤링할 때频繁하게 `Please wait for verification` 차단.

**대안 Providers (우선순위순):**

| Provider | 사용 도구 | 안정성 |
|----------|----------|--------|
| MiniMax 웹 검색 | `mcp_minimax_web_search` | ✅ 최고 — 항상 작동 |
| cheezburger.com (aggregated) | `mcp_ddg_search_fetch_content` | ✅ 양호 — 유머 Aggregated content |
| ThunderDungeon | `mcp_ddg_search_fetch_content` | ✅ 양호 — "Wildest Reddit Posts" 시리즈 |

**사용하지 말 것:**
- `mcp_ddg_search_search`: Reddit/X 직접 검색 → 빈번한 CAPTCHA/차단
- Reddit 직접 크롤링 (`reddit.com/r/...`): JavaScript 검증 차단

## 추천 워크플로우 (2026-05-25 확인)

```
1. mcp_minimax_web_search("funny viral moments 2025") → 기본候選 추출
2. mcp_minimax_web_search("고양이 얼굴 인식 unlock smartphone") → 추가候選
3. cheezburger.com 유머 기사 fetch → 세부情节 추출
4.侯選 3~6개 구성 →家主님께 Telegram 전송
```

##侯選 기준 — ⚠️ 가장 중요: 한국 국내 한정 (2026-05-25)

**家主님이 명시적으로 해외 바이럴 주제를 거부하심:**
- ❌卢浮宫强盗, Coldplay Kiss Cam, Labubu狂気等
-家主님: "해외 주제는 공감이 안 되네"

**✅採用 기준:**
- 한국에서 발생한 실제 상황/사건
- 한국인이라면 공감/웃을 수 있는 주제
- 직장인 일상, 반려동물, 한국式尴尬/유머情景
- 예: "직장인 점심시간", "사진 찍을 때 눈 감는 사람", "강아지 산책 중 변"

**❌ 부적합:**
- 뉴스 전달용-topic, 건式주제 (무역협상, 펀드출시, 올림픽 등)
-家主님의 일상과 동떨어진 해외 상황

##侯選 전송 형식

```
🎬 뮤직비디오侯選 (오전)

아래 중 원하는 주제를 골라주세요:

1. [주제명] - 한줄 설명 (출처)
2. [주제명] - 한줄 설명 (출처)
3. [주제명] - 한줄 설명 (출처)
4. [주제명] - 한줄 설명 (출처)
5. [주제명] - 한줄 설명 (출처)
6. [주제명] - 한줄 설명 (출처)

번호를 선택해 주세요. 선택 후 수동으로 제작 진행됩니다.
```

**⚠️ 6개 이상 필수 — 3개는 부족 (2026-05-25家主님 직접 피드백 반영)**

##侯選 기준

✅採用: 유머/위트, 구체적 시나리오, 영상화 가능
❌ 부적합: 뉴스 전달용, 건式주제, 추상적 개념만

## 크론 주의사항 (2026-05-25)

`fcfd160352ff` (侯選 수집 크론, 10시):
- LLM 에이전트 기반 → multi-tool 실행 → 오래 걸리거나 silent fail 가능
- `cronjob(action='run')` 후 `last_status`가 `null`로 유지되는 경우 관찰됨
-家主님이 요청하면 **자가 직접 수집**하여 Telegram 전송하는 것이 더 안정적