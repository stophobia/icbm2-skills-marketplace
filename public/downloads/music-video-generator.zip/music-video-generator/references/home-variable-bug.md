# music_video_producer.py HOME 버그 수정 (2026-05-24)

## 문제
`name 'HOME' is not defined` 오류로侯選 처리 중 크래시

## 원인
line 705: `HOME` 변수 미정의
```python
review_script = os.path.join(HOME, ".hermes/scripts/music_video_review.py")
```

## 해결
```python
# 수정 후
review_script = os.path.join(os.path.expanduser("~"), ".hermes/scripts/music_video_review.py")
```

## 적용
`~/.hermes/scripts/music_video_producer.py` line 705