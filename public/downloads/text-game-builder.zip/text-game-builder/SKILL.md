---
name: text-game-builder
description: LLM이 GM(Game Master)인 텍스트 기반 AI 게임을 설계·구축하는 워크플로 — OpenCode / Claude Code / Hermes 같은 LLM 에이전트를 게임 운영자로 사용하는 턴제 인터랙티브 픽션. 컨텍스트 윈도우 한계를 넘는 메모리 아키텍처(3-tier), MCP 도구 기반 상태 관리, 장르별 플러그인 구조, 사용자 시드 선택 워크플로우 포함. "AI 게임 만들어줘", "LLM GM 게임", "턴제 전략 게임 빌더", "텍스트 RPG 엔진" 같은 요청에 발동.
version: 0.2.0
author: icbm2
metadata:
  hermes:
    tags: [Game, LLM, MCP, Architecture, Multi-repo, Genre-plugin, Seed-system]
trigger: "AI 게임/텍스트 RPG/턴제 전략 게임을 LLM 에이전트로 만들고 싶을 때. 'AI 게임 만들어줘', 'LLM이 GM인 게임', '턴제 전략 게임 빌더', '텍스트 RPG 엔진', 'OpenCode/Claude Code로 게임' 식 요청에 활성화."
last_updated: 2026-06-12
status: battle-tested-2sessions
---

# Text Game Builder (LLM GM 게임 설계 워크플로)

LLM이 Game Master로 동작하는 **텍스트 기반 AI 게임**을 설계하고 빌드하는 클래스 레벨 스킬. 플레이어는 인간, LLM은 세계 운영자. 컨텍스트 윈도우 한계 없이 무한 진행.

## 트리거 조건

다음 중 하나라도 해당되면 이 스킬 로드:

- "AI 게임 만들어줘", "LLM이 GM인 게임", "턴제 전략 게임 빌더"
- "텍스트 RPG 엔진 만들자", "OpenCode/Claude Code로 인터랙티브 픽션"
- "AI Dungeon 같은 거 만들자", "장르별 게임 여러 개"
- "컨텍스트 윈도우 무한인 게임", "장기 기억하는 AI GM"
- 시드(seed)로 세계관·시대·톤을 플레이어가 선택하는 게임

## ⚠️ 트리거 시 절대 놓치지 말 것

1. **브레인스토밍 우선** — 즉시 코딩 ❌. 시대/톤/엔티티/MVP 범위 등 결정 포인트를 2~3개 옵션으로 제시하고 사용자 선택 받기
2. **장르별 repo 분리** — 멀티 장르 시 각각 독립 GitHub repo + 공통 코어 1개. **코어 이름은 "core" ❌ — 장르 비종속 메타처럼 들리게** (예: `ai-gm` ❌ `ai-gm-core` ✅, `game-mesh` ✅, `story-engine` ✅)
3. **상태 = 도구 전용** — LLM이 숫자를 직접 못 만짐, MCP 도구 호출로만 변경 ("No silent fixes")
4. **3-tier 메모리** — verbatim / summary / deep archive (RAG)
5. **시드 = 사용자가 선택, 사전 지정 없음** — README에 "기본 시드: X" 섹션을 두지 말 것. 게임 시작 시 GM이 시대/톤/규모/국가를 묻고, "샘플 시드 옵션"은 부수적. "기본"이라는 단어가 들어가면 사용자가 "미리 정해진 거 아닌가?"로 짚는다 (2026-06-12 실전 검증).

## 🧠 핵심 아키텍처: 3-tier 메모리 + 도구 전용 상태

```
매 턴 LLM 입력 = [
  # Tier 0: 정적 (~1K, 캐시됨)
  SYSTEM: 시대/톤/세계관 + GM 규약 (halt protocol, "숫자는 도구로만")

  # Tier 1: 동적 필 (~2K, 매 턴 자동 주입)
  STATE_SUMMARY: 활성 전쟁, 진행 협상, 인물 상태 (JSON top-level)
  PINNED_LORE: 핵심 룰/경제/법률 (플레이어 고정 가능)

  # Tier 2: 최근 대화 (~3K, verbatim)
  RECENT_TURNS: 직전 5~10턴 원문

  # Tier 3: RAG 검색 (~1K, top-k=3~5)
  RAG_HITS: 챕터 요약, NPC 프로필, 과거 유사 사건

  # Tier 4: 동적 (도구 사용 시)
  TOOL_RESULTS: update_resource, search_history 등의 응답
]
```

총 ~7K tokens/turn — 대부분의 LLM이 여유 있게 처리.

## 🏗️ 데이터 모델 — 게임 디렉토리 구조

```
games/{game_id}/
├── world/                  # 정적 세계관 (Git 추적)
│   ├── overview.md         # [CHUNK: world_overview]
│   ├── factions/           # [CHUNK: faction]
│   ├── characters/         # [CHUNK: character]
│   ├── regions/            # [CHUNK: location]
│   ├── rules/              # [CHUNK: rules] (pinned 가능)
│   ├── economy.md
│   └── culture.md
├── state/                  # 동적 상태 (도구 전용)
│   ├── turn.json
│   ├── nations.json
│   ├── characters.json
│   ├── relations.json
│   └── active_wars.json
├── chapters/               # Tier 3 (장기 기억, RAG)
├── transcript/             # Tier 1 (verbatim, 손실 없음)
├── summaries/              # Tier 2 (자동 요약)
├── system_prompt.md
└── seed.json               # 시작 시드
```

## 🛠️ MCP 도구 규약 (필수 6종)

### 읽기 (passive)
- `read_state(entity_id)` — 특정 엔티티 상세
- `search_history(query, top_k)` — Tier 3 RAG
- `read_lore(chunk_path)` — lore 청크 전문
- `list_active_wars()` — 진행 중 전쟁

### 쓰기 (state 변경, 검증 필수)
- `update_resource(nation, type, delta, reason)` — 자원 증감
- `move_unit(unit_id, to_province)` — 군대 이동
- `declare_war(aggressor, defender, casus_belli)`
- `advance_turn(actions_taken)` — 턴 진행 + 자동 요약 트리거

### 메타
- `start_game(seed)` — 새 게임
- `save_snapshot()` / `load_snapshot(id)`
- `end_session()` — 챕터 요약 생성

## 📂 저장소 구조 (멀티 장르 시)

```
github.com/<user>/
├── <name>-core              # 공통 코어 (MCP 서버, 메모리, RAG)
├── <name>-strategy-war      # 전략/전쟁 장르
├── <name>-fantasy-rpg       # (향후) 판타지 RPG
├── <name>-sci-fi-explore    # (향후) SF 탐험
└── <name>-mystery-detective # (향후) 미스터리
```

장르별 독립 repo + 코어 의존 (npm 패키지 또는 git submodule).

## 🚀 워크플로 (Phase 0: 설계 + README)

### 1단계: 브레인스토밍 (대화형)
사용자 요청 받으면 즉시 코딩 금지. 결정 포인트를 2~3 옵션으로 제시:

- 장르 (전략/전쟁, 판타지, SF, 미스터리, 비주류)
- 메모리 아키텍처 (요약 압축, 계층적, RAG, 하이브리드, 상태 기계)
- 에이전트 환경 (OpenCode / Claude Code / Hermes 우선)
- 저장소 구조 (장르별 분리 / 모노레포 / 코어 + 플러그인)
- 진행 모델 (무한 / 1회 완결 / 분기형)
- 세션 단위 (1 게임 = 1 세션 / 자유 저장)
- 시대/톤/매직/맵 스케일/턴제↔자유/MVP 범위/언어/저장/시각화

각 결정에 추천 1개 + 사유 + 대안 1~2개 (브레인스토밍 원칙 — 사용자가 명시한 선호도).

### 2단계: 레퍼런스 조사 (필수, 함정 회피)
함정: 검색 1위 결과를 즉시 추천하지 말 것. 3~5개 후보를 비교표로 정리:

| 자료 | 시간 모델 | 메모리 핵심 | 상태 관리 | 우리 케이스 적합도 |
|------|----------|------------|----------|-----------------|
| 자료A | ... | ... | ... | ⭐⭐⭐⭐⭐ |
| 자료B | ... | ... | ... | ⭐⭐⭐ |

차원 차이(시간 모델, 결정 주기, 메모리 단위)를 명시적으로 분리해서 보여주기. 사용자가 "이거 맞아?"로 짚었을 때 방어 가능한지 검증. **"적합도 ⭐⭐⭐⭐⭐" 같은 단정은 함정** — "차용할 부분 + 안 맞는 부분"을 분리해서 솔직히 말하기 (2026-06-12 실전: MASMP는 "정확히 일치"라 단정했다가 사용자가 "RTS 아닌 턴제인데?"로 짚음 → "반만 맞음"으로 정정).

핵심 참조 3종 (2026-06-12 검증):
- LoreKit — 3-tier 메모리, No silent fixes, MCP 도구 패턴
- NarrativeEngine-P — chunk 분류, Chapter/Scene 아카이브, deep archive
- SillyTavern Lorebook — 키워드 트리거, 토큰 예산

### 3단계: 아키텍처 문서 작성
`~/.openclaw/workspace/<name>-architecture.md` 에 풀 디자인 저장 (repo 밖):
- 메모리 모델 + 차트
- 데이터 모델 + JSON 스키마
- MCP 도구 규약
- 시스템 플로우 다이어그램
- 단계별 실행 계획 (Phase 0~5)
- 참조 출처

### 4단계: Phase 0 — repo 생성 + README만
- `python-oss-bootstrap` 스킬의 "Phase 0 변형" 섹션 참조
- **코어 repo 이름 = 장르 비종속 메타로** (Pitfall #8). 예: `ai-gm` (O) vs `ai-gm-core` (X)
- 워크스페이스에 디렉토리 만들고 README + LICENSE + .gitignore 작성
- `git init` + 커밋 + `gh repo create --source --push` 한 번에
- **README 패턴 (장르 플러그인)**: "🎮 새 게임을 시작하세요" 큐레이션 섹션 + 4가지 결정 사항 표 + 샘플 시드 옵션(부수적) — 절대 "기본 시드: X"로 시작하지 말 것 (Pitfall #9)

### 4.5단계: README 검증
`mcp_ddg_search_fetch_content`로 GitHub에 푸시된 README를 **실제 렌더링된 모습**으로 확인. "기본 시드" 같은 단어가 메인 흐름을 차지하면 재작성. 사용자가 의도 표현을 짚기 전에 자가 검증할 것.

### 5단계: 실제 빌드 (다른 PC)
```bash
git clone <repo-url>
cd <repo-dir>
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
# Phase 1: JSON 스키마 → MCP 서버 골격 → 최소 도구 3개
```

## 🎯 장르별 엔티티 가이드

### ⚔️ 전략/전쟁 (검증 완료, 2026-06-12)
- nation, character, province, unit, war, treaty, event_chain
- 시간: 1턴 = 1계절
- 엔티티 차용: HOI4 (시간/연구), CK3 (인물/관계), EU4 (외교)
- **샘플 시드**: 중세 고구려 391 (광개토대왕 즉위 직후)
- **추천 톤**: 사실주의, 영토 확장, 다자 관계

### 🐉 판타지 RPG (README + 엔티티 스키마 검증, 2026-06-12)
- party (1~4인), character (PC + NPC), spell, quest, item, region
- 시간: 1턴 = 1일 (속도감)
- 엔티티 차용: D&D 5e, Baldur's Gate 3, Elden Ring
- **샘플 시드**: 드래곤 시대 1024 (변방 마을 샐로우스톤, Red Wyrm Kargad)
- **장르 특성**: 4가지 결정 = 서브장르(D&D풍/다크/무마법/동양/모더니즘) / 톤 / 스케일 / 캐릭터 빌드(종족+직업)
- **샘플 빌드 옵션**: 인간/엘프/드워프/하프링/오크/티플링 × 전사/마법사/도적/성직자/바드/레인저/팔라딘

### 🚀 SF 탐험 (README + 엔티티 스키마 검증, 2026-06-12)
- ship, crew, star_system, alien_species, mission, resource
- 시간: 1턴 = 1주 (탐험 페이스)
- 엔티티 차용: Mass Effect, Outer Wilds, FTL, The Expanse
- **샘플 시드**: 인류 진출기 2247 (EAS 유에시아호, Sedna-9 외곽)
- **장르 특성**: 4가지 결정 = 하드/소프트 SF / 톤(경이·고독·군사·카우보이) / 스케일 / 함선
- **리소스 모델**: 연료/식량/부품/데이터 (4축), 함선 시스템 상태 (엔진/쉴드/센서/무기/생명 유지)
- **세력 옵션**: 지구연방 / 화성공화국 / 베타사주 클랜 / 솔라마티 협회 / 독립 트레이더

### 🔍 미스터리/추리 (README + 엔티티 스키마 검증, 2026-06-12)
- case, suspect, clue, alibi, location, evidence, timeline
- 시간: 1턴 = 1시간(긴장) 또는 1일
- 엔티티 차용: Agatha Christie, Disco Elysium, Obra Dinn, LA Noire
- **샘플 시드**: 하버튼 저택의 죽음 1923 (잉글랜드 폭설 속 1총살, 11명 갇힘, 밀실)
- **장르 특화 정책**: **"진실은 추리 후에만 공개"** — `submit_deduction` MCP 도구가 결론 채점. GM은 플레이어가 명시적으로 추리 결론을 제출하기 전까지 진짜 범인을 공개 ❌. 단서/증거/알리바이만 공개.
- **장르 특성**: 4가지 결정 = 시대(1920s Poirot풍 / 1940s 누아르 / 1980s 법의학 / 현대 / 근미래 / 역사) / 톤(고전/누아르/다크/코지/코미디/심리) / 사건 규모(밀실/단편/연작/다지역) / 탐정

## 📁 첨부 파일

- `references/architecture-template.md` — ai-gm-core 디자인 문서 (전체 14KB, 차트 + JSON 스키마 + 도구 규약)
- `references/case-study-2026-06-12.md` — 세션 1부: 브레인스토밍 → 레퍼런스 조사 → 아키텍처 → 2개 repo 생성
- `references/case-study-2026-06-12-pt2.md` — 세션 2부: README 한글화 + 명명/시드 시스템 재설계 + gh CLI 함정
- `references/case-study-2026-06-12-pt3.md` — 세션 3부: 시드 교체 (알도리아→고구려) + 4개 장르 repo 일괄 생성 + About 한글화 + 토픽 일괄 추가
- `references/gh-cli-quirks.md` — gh CLI 비대화형 함정 모음 (repo rename, 인증, `add-topic` 등)
- `templates/seed-strategy-war.json` — 전략/전쟁 시드 템플릿 (Aldoria 1487)
- `templates/seed-strategy-war-goguryeo-391.json` — 전략/전쟁 시드 템플릿 (고구려 391, 검증된 한국 역사 시드 예시)
- `templates/system-prompt-strategy-war.md` — 전략/전쟁 GM 시스템 프롬프트 골격
- `templates/chunk-format.md` — `[CHUNK: TYPE -- NAME]` 마크다운 형식 가이드
- `templates/genre-plugin-readme-template.md` — 4개 장르 plugin repo에 공통 적용된 README 양식 (한/영 병기 + 4가지 결정 + 큐레이션 톤, 그대로 복제 가능)
- `templates/genre-plugin-about-description.md` — About description 작성 규칙 + 검증된 4개 예시 (한글화)

## ✅ 완료 체크리스트 (Phase 0 종료 시)

- [ ] 브레인스토밍으로 결정 6~10개 확정
- [ ] 레퍼런스 3개+ 비교표로 검증
- [ ] 아키텍처 문서 작성
- [ ] 코어 repo 생성 + 푸시
- [ ] 장르별 repo 1개+ 생성 + 푸시
- [ ] README에 Quick Start, 아키텍처, 로드맵 포함
- [ ] 다른 PC에서 `git clone`만으로 환경 구성 가능

## ⚠️ 검증된 함정 (Pitfalls)

1. 레퍼런스 매칭 단정 — 검색 1위를 "정확히 우리 케이스"라 단정 금지. 차원 차이 비교표로 검증.
2. 즉시 코딩 — "만들어줘" 받자마자 코드 금지. 브레인스토밍 1단계 필수.
3. 저장 = 코딩 = 작업 — "방향 정해지면 README만" 같은 요청 시 Phase 0 변형 사용.
4. 장르 1개로 시작 안 함 — 멀티 장르 약속이면 1개 장르라도 코어 분리 구조로 시작.
5. 상태를 LLM이 직접 수정 — 게임 수치는 무조건 MCP 도구 경유. LLM이 추론으로 "국고 줄었어" 금지.
6. MASMP/RTS 적용 함정 — 시간 모델이 다른 자료는 부분 차용만. 턴제 ↔ 실시간 섞으면 안 됨.
7. lore를 마크다운 자유 형식 — `[CHUNK: TYPE -- NAME]` prefix 강제. 분류 자동화 필수.
8. **코어 repo 이름에 "core" 붙이기** — "ai-gm-core"라 짓는 순간 사용자가 "전략 전용 GM 아닌가?"로 짚음. 코어의 본질은 "장르 비종속 메타 엔진"이므로 이름 자체에 그 성격이 드러나야 함. `ai-gm`, `game-mesh`, `story-engine` 같은 네이밍.
9. **"기본 시드: X" 섹션** — README 메인에 두면 "미리 정해진 거 아닌가?"라는 의도 표현이 사용자 쪽에서 나옴. "🎮 새 게임을 시작하세요" 큐레이션 섹션 + 4가지 결정 사항(시대/톤/규모/국가) 표 + 샘플 시드 옵션을 그 아래에 두는 구조.
10. **시드 교체 시 README에 흔적 5군데 남김** (2026-06-12 실전: 알도리아 → 고구려 교체 시 검증):
    1. 도입부 1~2줄 ("샘플 시드 (예: X)")
    2. 도입부 영문 ("Sample seeds (e.g. X)")
    3. 4가지 결정 사항 표의 시드 행
    4. "🌰 샘플 시드 미리보기" 섹션 통째
    5. 저장소 구조 트리의 `lore/seeds/<old-name>/` 디렉토리명
    6. 로드맵 Phase 1의 시드 디렉토리명
    → search_files로 패턴(`<old-name>|<OldName>|<영문명>`) 한 번에 검색 후 6군데 모두 갱신. 영문 토큰(kingdom-of-aldoria, queen-elisabet 등)도 JSON 예시 블록이 `<placeholder>`로 추상화돼 있으면 무관, 아니면 별도 갱신.
11. **시드 = 사용자가 선택, 절대 사전 지정 X** (Pitfall #9 강화) — sigco3111님 선호 신호: "미리 지정하지 말고, 게임시작시 사용자가 설정하고 시작하도록." 샘플 시드는 부수적. About description에도 "미리지정 시드 없음" 명시. 이중 안전장치.
12. **시드 콘텐츠가 시드 디렉토리에 격리** — 시드별 콘텐츠는 `lore/seeds/<seed-name>/{factions,characters,regions,spells,etc.}/` 하위에 위치. `lore/factions/` 같은 전역 디렉토리에 두면 시드 간 격리 깨짐 → RAG 검색이 다른 시드 콘텐츠 끌고 옴.

## 🌱 시드 시스템 (Seed System) — Phase 1+ 설계

시드 = 게임 시작 시 GM에게 사용자가 던지는 "시작점" 패키지. 시드 = 데이터, 시스템 = 엔진. 시드 교체로 다른 장르의 다른 세계를 굴릴 수 있다.

### 시드 디렉토리 컨벤션
```
lore/
├── rules/                    # 장르 공통 룰 (모든 시드에서 공유, 핀 고정)
│   ├── combat.md             # [CHUNK: rules]
│   ├── magic.md
│   ├── succession.md
│   └── ...
├── seeds/                    # 시드 모음 (각 시드 = 디렉토리)
│   ├── <seed-name>/          # 시드별 격리
│   │   ├── seed.json         # 시드 정의 (시작 시간, 플레이어 국가, 자원, 위협, 기회)
│   │   ├── overview.md       # 시드 개요 (시대·톤·분위기)
│   │   ├── factions/         # [CHUNK: faction]
│   │   ├── characters/       # [CHUNK: character]
│   │   ├── regions/          # [CHUNK: location]
│   │   ├── ... (장르별 추가: spells/, ships/, clues/, etc.)
│   └── _template/            # 새 시드 작성용 템플릿 (Phase 1)
└── _shared/                  # 시드 간 공유되는 청크 (예: 공통 룰, 공통 종족)
```

### 시드 = 사용자가 선택, README는 큐레이션 톤

README에 "기본 시드" 섹션 절대 금지. **"🎮 새 게임을 시작하세요"** 섹션 + 4가지 결정 사항 표 + 샘플 시드는 부수적으로.

```markdown
## 🎮 새 게임을 시작하세요 / Start a New Game

> 시작할 때 미리 정해진 설정은 없습니다. 게임 시작 시 GM이 당신에게 물어보고, 당신이 결정합니다.
> Nothing is preset. When you start, the GM will ask you and you'll decide.

### 4가지 결정 사항
| # | 결정 | 옵션 (예시) |
|---|------|------|
| 1 | 시대 / Era | 고대 → 중세 → 르네상스 → 산업혁명 → 근현대 |
| 2 | 톤 / Tone | 사실주의 / 저마법 / 신화 / 디스토피아 / 코미디 / 다크 |
| 3 | 스케일 / Scale | 소규모 / 중규모 / 대규모 |
| 4 | 당신의 국가 / Your nation | GM이 후보 제시 — 또는 직접 설계 |

### 샘플 시드 (바로 시작 가능) / Sample Seeds
| 시드 | 시대 | 톤 | 스케일 | 플레이어 국가 |
|------|------|-----|--------|---------------|
| **고구려 391** | 4세기 후반 | 사실주의·영토 확장 | 중규모 | 고구려 (광개토대왕 즉위 직후) |
| _(더 많은 시드 추가 예정)_ | | | | |

샘플 시드는 그냥 시작점입니다 — 본게임에 들어서면 톤·규칙·세력은 GM이 자유롭게 변주할 수 있어요.
```

### 시드 컨셉 추천 신호 (sigco3111님 검증)

| 선호 | 근거 |
|------|------|
| **한국 역사 시드** (예: 고구려 391) | 위키/문헌 풍부, 사실주의, sigco3111님 톤 |
| **실존 인물 중심** (광개토대왕 등) | 전략적 깊이, 다자 관계, 룸 가능성 |
| **명확한 위협 + 기회 동시 존재** | 게임 시작 시 플레이어에게 방향성 제시 |

→ 시드 컨셉 브레인스토밍 시 이 신호 활용.

## 📦 장르 repo 일괄 생성 워크플로우 (Phase 0 변형, 다중 장르 시)

4개 장르 repo를 한 세션에 생성할 때 (2026-06-12 실전 검증):

```bash
# 1. 코어 1개는 기존 패턴 (변경 없음)
# 2. 장르 plugin 3~4개 병렬 작성

# 로컬 구조: 워크스페이스에 N개 디렉토리
workspace/
├── ai-gm/                       # 메타 (이미 생성됨)
├── ai-gm-strategy-war/          # 장르 1 (이미 생성됨)
├── ai-gm-fantasy-rpg/           # 장르 2 (신규)
├── ai-gm-sci-fi-explore/        # 장르 3 (신규)
└── ai-gm-mystery-detective/     # 장르 4 (신규)
```

**각 디렉토리마다 동일한 6개 파일** (장르별 차이는 README + 샘플 시드 + 엔티티 스키마만):
- `README.md` (한/영 병기, 4가지 결정, 샘플 시드 미리보기)
- `LICENSE` (Apache 2.0 — 동일)
- `.gitignore` (동일)
- `games/.gitkeep`

**병렬 실행 명령** (모든 장르에 동시):
```bash
# 각 디렉토리에서
git init -b main
git add .
git -c user.name="..." -c user.email="..." commit -m "Initial commit: <장르명> genre plugin skeleton..."

# 각 repo 푸시 (병렬)
gh repo create sigco3111/<name> --public --description "..." --source ... --remote=origin --push
gh repo edit sigco3111/<name> --add-topic "tag1,tag2,tag3..."

# 메타 repo도 카탈로그 갱신 후 푸시
cd ai-gm && git commit -am "장르 카탈로그 갱신: 4개 장르 repo 모두 공개 링크"
```

### About description 작성 규칙 (한글화, 2026-06-12 검증)

**패턴**: `[장르 설명] — [코어 의존]. [톤 한 줄]. 샘플 시드: [시드명]. [정책].`

**좋은 예** (실제 적용):
- `ai-gm`: *"장르 비종속 AI 게임 마스터 공통 엔진. 게임 시작 시 GM이 사용자에게 설정을 묻고 시작 — 미리정해진 세계 없음. 장르 플러그인이 위에 얹힘."*
- `ai-gm-strategy-war`: *"전략/전쟁 장르 플러그인 — ai-gm 코어 기반. 턴제 그랜드 전략. 샘플 시드: 고구려 391. 게임 시작 시 GM이 시대·톤·규모·국가를 사용자에게 묻고 시작. 미리지정 시드 없음."*
- `ai-gm-fantasy-rpg`: *"판타지 RPG 장르 플러그인 — ai-gm 코어 기반. AI GM이 던전·도시·NPC 운영. 샘플 시드: 드래곤 시대 1024. 미리지정 시드 없음."*

→ 한글 description + 핵심 차별점 + 샘플 시드 + 정책 ("미리지정 X") 4요소 포함.

## 🔗 관련 스킬

- `auto-researcher` — 레퍼런스 매칭 함정 + 비교표 워크플로의 원천
- `python-oss-bootstrap` — Phase 0 변형 (README만 + gh repo create) 워크플로
- `canvas-static-site-pipeline` — 브레인스토밍 우선 + 장르별/사이트별 repo 구조 패턴
- `webwright` — 3-tier 메모리 영감 + OpenCode 최적화 (state = local workspace 컨셉 차용)
- `autonomous-coding-agents` — 다른 PC에서 Phase 1+ 작업 시 Codex/Claude Code/OpenCode 위임
