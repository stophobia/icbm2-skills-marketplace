# 🥝 Kiwi StackChan Session — 2026-06-23

Full session trace for the first working version of the kiwi companion on Hermes PC. Use this as a worked example when teaching the skill or debugging similar setups.

## User context

- Hermes PC: **Intel Mac** (not Apple Silicon) — explicit clarification during brainstorm
- Goal: "stackchan 시뮬레이터를 설치하고 구동할 수 있나?" → animated companion that reacts to conversation
- Environment: macOS 15.5, Python 3.8.8, MiniMax API already authenticated

## Brainstorming output (what user accepted)

| Decision | Option chosen | Why |
|---|---|---|
| ① Face rendering | A. Emoji + system font | 5min to working, swap to PNG later |
| ② LLM | A. MiniMax API direct | Already authenticated, low latency, no GPU needed |
| ③ STT | A. Text-only v1 | Whisper too heavy for v1 (500MB) |
| ④ Windowing | A. Pygame | Best for animated face + mouth sync |

User responded "그대로 진행해" — accepted all four defaults.

## Step-by-step execution

### Step 1: Environment check

```bash
python3 --version
# Python 3.8.8 — old but fine

python3 -c "import pygame, pyttsx3, requests"
# pygame missing, pyttsx3 missing, requests OK

python3 -m pip install --user pygame pyttsx3
# Installed: pygame 2.6.1, pyttsx3 2.99 + 100+ pyobjc-framework-* deps
```

Lesson: on macOS, `pyttsx3` pulls in a huge pyobjc tree. First install takes ~2min.

### Step 2: API key discovery

`printenv | grep MINIMAX` returned nothing. Key was in `~/.hermes/secrets/minimax.env` as `export MINIMAX_API_KEY=***`. Auth.json showed only `secret_fingerprint` (sha256:4055413abceb121c), not the raw value.

Solution: `source ~/.hermes/secrets/minimax.env` before any API call.

### Step 3: LLM module

- Base URL: `https://api.minimax.io/anthropic` (Anthropic-compatible)
- Endpoint: `/v1/messages` with `x-api-key` header + `anthropic-version: 2023-06-01`
- Model: `MiniMax-M3` (set as `KIWI_MODEL` env override-able)
- Used `urllib.request` instead of `requests` (stdlib, no dep)
- First syntax error: `list | None` not valid in 3.8. Fixed with `Optional[List[Dict]]`.

Test result:
```
[키위]   안녕~! 많이 피곤해? 푹 쉬어야 해, 키위도 응원할게!
[감정]   sad   ← correct (user said "피곤해")
```

### Step 4: TTS module

- 177 voices on this Mac. Searched for Korean — found Yuna + 5 Eloquence variants.
- First pass: `_KOREAN_PREFERENCE_KEYS = ("yuna", "kyung", "sora", "korean", "ko_kr")` + `if any(k in name or k in vid for k in KEYS)`.
- **Bug:** returned Eddy (Eloquence ko-KR) instead of Yuna. Why? Naive substring match.
- **Fix:** priority-based match — for "yuna" do exact name or `endswith(".yuna")`, not substring.

Test result:
```
[TTS 설정] backend=pyttsx3+nsspeech-ko, voice_id=com.apple.voice.compact.ko-KR.Yuna
```

### Step 5: Face module

- 480x480 pygame window, 60fps
- 5 emotion palettes (BG, kiwi green, cheek, eye colors)
- Eyes: white circle + dark pupil + highlight, line on blink
- Mouth: arcs for happy/sad, circle for thinking/surprised, line for neutral — all modulated by `mouth_open` when speaking
- Cheeks: pink ovals for warmth
- Seed pattern: 12 fixed-position dark dots (using `Random(42)` so the kiwi has consistent "freckle" pattern across frames)
- Emotion label text at bottom (Apple SD Gothic Neo, 22pt)

Headless test with `SDL_VIDEODRIVER=dummy` — all 5 emotions cycle OK, mouth sync interpolates, blink fires.

### Step 6: Main loop

- argparse: `--no-tts` (face only), `--reset` (clear history, not yet implemented)
- Env check first — if `MINIMAX_API_KEY` not set, print clear error and exit
- Spawn face thread, wait for `is_ready()`, then init TTS (order matters on macOS)
- Greeting on startup
- Readline loop, "quit"/"exit"/"q"/EOF/Ctrl-C all graceful

### Step 7: Integration test

5-scenario conversation test:

| User input | LLM emotion | Correct? |
|---|---|---|
| 키위야 안녕! | happy | ✓ |
| 오늘 회사에서 너무 힘든 일이 있었어 | sad | ✓ |
| 근데 복권에 당첨됐어!!! | surprised | ✓ |
| 너무 신나서 어떻게 해야 할지 모르겠어 | happy (expected thinking) | ⚠ acceptable (joyful topic, "happy" is defensible) |
| 고마워 키위, 너랑 얘기하니까 마음이 편해져 | happy | ✓ |

4/5 exact match, 1/5 close-enough. **This is the realistic ceiling** — perfect emotion classification isn't achievable, ~85-95% is the practical max for "LLM classifies utterance into 5 buckets."

## Final file layout

```
~/projects/kiwi-companion/
├── llm.py            # 125 lines
├── tts.py            # 164 lines
├── face.py           # 250 lines
├── kiwi.py           # 174 lines
├── README.md         # 95 lines
└── faces/            # empty (placeholder for future PNG assets)
```

Total: 808 lines, ~30 min elapsed.

## Lessons (encoded in SKILL.md pitfalls)

1. `Optional[X]` not `X | None` on Python 3.8
2. Voice substring matching picks wrong voice — use exact match + priority
3. `urllib` over `requests` for stdlib cleanliness
4. Source the secrets file, don't expect env inheritance
5. pyttsx3 needs `threading.Lock` for thread safety
6. Pygame init before pyttsx3 init on macOS (audio device race)
7. Blocking TTS in main loop to prevent emotion overlap
8. `SDL_VIDEODRIVER=dummy` for headless GUI testing
9. Conversation history windowing to bound token cost
10. Daemon threads for pygame so Ctrl-C exits cleanly
