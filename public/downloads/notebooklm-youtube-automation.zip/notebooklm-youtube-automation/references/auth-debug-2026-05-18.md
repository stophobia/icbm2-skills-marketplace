# NotebookLM CLI Authentication Debug (2026-05-18)

## Symptom
```
Error: Authentication expired or invalid. Redirected to: https://accounts.google.com/v3/signin/identifier?...
Run 'notebooklm login' to re-authenticate.
```

## Root Cause — Two Critical Issues

### Issue 1: Wrong Account Type (Workspace accounts NOT supported)
NotebookLM CLI only supports **consumer Gmail accounts** (gmail.com). Google Workspace accounts (ubob.com, etc.) do NOT work — the CLI returns `Error: Authentication expired` even with valid cookies and correct expiration dates.

**Evidence:** All cookies in `storage_state.json` (including SID) are from `.google.co.kr` (Korean regional domain) even though `.google.com` cookies were present in the storage. The code has logic to prefer `.google.com` cookies over regional domains, but when all cookies come from regional domains, auth still fails.

**Fix:** Must use a personal Gmail.com account. Workspace account cookies are rejected at the Google backend level regardless of cookie validity.

### Issue 2: All Cookies from .google.co.kr (Regional Domain)
All cookies in `storage_state.json` were from `.google.co.kr` instead of `.google.com`. This happened because the browser profile was in Korean locale and all Google auth flows landed on `.google.co.kr`.

**Fix:** Complete browser profile reset required:
```bash
rm -rf ~/.notebooklm/browser_profile
rm ~/.notebooklm/storage_state.json
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm login --storage ~/.notebooklm/storage_state.json
```
→ Use personal Gmail.com account, wait for NotebookLM homepage to fully load, press ENTER.

## Investigation Findings

### Storage State: Valid but Wrong Account
- `~/.notebooklm/storage_state.json` exists, 13424 bytes, updated May 18 16:46
- Cookies extracted: SID, __Secure-1PSID, __Secure-3PSID, HSID, SSID, APISID, SAPISID, ...
- OSID for `notebooklm.google.com` expires: 2027-06-07 (NOT expired)
- **But all SID/HSID/etc. cookies are from `.google.co.kr`, NOT `.google.com`**

### Python Version: Correct
- venv uses Python 3.13 — v0.14.0 requires 3.10+
- system anaconda (Python 3.8.8) is broken (syntax error in session.py)

### Root Cause of CLI Auth Failure (v0.14.0+)
After v0.14.0, CLI performs `fetch_tokens()` which makes an httpx request to `https://notebooklm.google.com/` with cookies. If the response redirects to Google auth, the CLI throws this error even though:
1. The storage_state.json has valid cookies
2. The cookies are not expired
3. The user successfully authenticated via browser

The redirect check (`is_google_auth_redirect()`) catches the redirect URL and raises ValueError immediately. The problem is the **account type** (workspace) and **cookie domain** (.google.co.kr), not cookie expiration.

## Complete Diagnostic Checklist

```bash
# 1. Verify account type (must be Gmail.com, NOT workspace account)
# 2. Reset browser profile + storage_state
rm -rf ~/.notebooklm/browser_profile && rm ~/.notebooklm/storage_state.json

# 3. Login with Gmail.com account
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm login

# 4. Verify cookies are from .google.com (not .google.co.kr)
~/.hermes/venv-notebooklm/bin/python3 -c "
from notebooklm.auth import _load_storage_state, extract_cookies_from_storage
data = _load_storage_state()
for c in data.get('cookies', []):
    if c['name'] == 'SID':
        print('SID domain:', c['domain'])
"

# 5. Quick auth test
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json 2>&1 | head -1
# {\"error\":true,...} → auth problem
# {\"notebooks\":[...]} → auth OK
```

## Key Diagnostic Commands

```bash
# Check Python version and notebooklm location
~/.hermes/venv-notebooklm/bin/python3 --version
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm --version

# Check storage_state cookies
~/.hermes/venv-notebooklm/bin/python3 -c "
from notebooklm.auth import _load_storage_state, extract_cookies_from_storage
data = _load_storage_state()
print('Cookies extracted:', list(extract_cookies_from_storage(data).keys())[:5])
"

# Test raw HTTP response
~/.hermes/venv-notebooklm/bin/python3 -c "
import asyncio, httpx
from notebooklm.auth import _load_storage_state, extract_cookies_from_storage
async def test():
    cookies = extract_cookies_from_storage(_load_storage_state())
    ch = '; '.join(f'{k}={v}' for k, v in cookies.items())
    async with httpx.AsyncClient() as c:
        r = await c.get('https://notebooklm.google.com/', headers={'Cookie': ch}, follow_redirects=True, timeout=30.0)
        print('URL:', r.url)
asyncio.run(test())
"
# -> URL: accounts.google.com/... means auth invalid (wrong account type or cookie domain)
# -> URL: notebooklm.google.com/... means auth valid

# Critical diagnostic — always check exit code
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm create "ICBM | Test" 2>&1; echo "EXIT:$?"
# - EXIT:1 + "Error: Authentication expired..." in output → auth session problem
# - EXIT:0 + "Created notebook: ..." → auth OK
```

## Error Output Location (Critical for Debugging)

Even after successful login via browser, `notebooklm create` returns `Error: Authentication expired` in **stdout** with `exitcode=1` — NOT in stderr. The `run_notebooklm()` in prepare.py captures stderr first, so when stderr is empty it logs `❌ Error: ` (blank message). The actual error message is in stdout but `returncode!=0` causes immediate skip anyway.

## Why Multiple Login Calls Were Needed

- First login (May 18 16:42): saved to storage_state.json but token fetch still failed
- Second login (May 18 16:46): session that still had issues due to workspace account
- Browser profile reset (17:38): only after this did auth work — because personal Gmail.com account was used

## Final Resolution (17:41)

After browser profile reset and re-login with Gmail.com personal account:
- 3 notebooks created successfully
- Auth confirmed working

## Note on `storage_state_enterprise.json`
Previous enterprise account backup was at `storage_state_enterprise.json`. The workspace account (ubob.com) never worked regardless of how many times login was re-run.