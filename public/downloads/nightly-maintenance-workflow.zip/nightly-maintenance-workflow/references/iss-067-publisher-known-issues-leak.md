# ISS-067 #2 — `tistory-publisher` known-issues 노트 leak (2026-06-10 03:30 KST 발견)

## 배경

ISS-067의 첫 번째 root cause (`FileNotFoundError` 카테고리 누락)는 06-09 22:09 daily 리뷰에서 즉시 해결됐다:
- `mask_self_healer_terms.py`에 4개 패턴 추가 (FileNotFoundError, PathNotFoundError, "No such file or directory", 멀티 토큰)
- 11개 Tistory 06-09 출력 retro-masking
- 81f1c81f8664 06-09 새벽 출력 retro-masking
- self-healer re-run: 0 errors, 0 warnings
- verify_self_healer_patch 4/4 PASS

**하지만 두 번째 root cause (ISS-067 #2)는 해결 안 됨** — `tistory-publisher` SKILL.md의 known-issues 노트가 cron output에 그대로 leak되는 패턴.

## 패턴

`~/.hermes/skills/productivity/tistory-publisher/SKILL.md`의 "Known Issues" 또는 "Troubleshooting" 섹션이 다음과 같은 형식으로 작성됨:

```markdown
**Symptom:** Step 7에서 `rm -rf /tmp/blog-images-repo && git clone ...`를 cron 모드(작업 디렉터리 = `~/.hermes/hermes-agent` 등)에서 실행하면, `rm -rf`가 현재 작업 디렉터리를 지워서 `fatal: Unable to read current working directory: getcwd: cannot access parent directories: No such file or directory` 에러가 발생합니다.
```

이 텍스트가 cron output에 그대로 출력되면, self-healer의 regex `(?:file|path|directory).*(?:not found|does not exi)`가 `fatal: ... No such file or directory`를 매칭.

## 06-10 03:30 KST 실측 결과

**검출된 15건 (모두 known-issues 노트 본문, 진짜 에러 0건):**

```
5d0f14aef84c/2026-06-09_22-09-58.md:432 | - **Root cause #1**: Tistory publisher SKILL.md의 known-issues 노트 `**Symptom:** ... fatal: Unable to read current working directory: getcwd: cannot access parent
b1bca63a117a/2026-06-10_03-03-48.md:112 | **Symptom:** Step 7에서 `rm -rf /tmp/blog-images-repo && git clone ...`를 cron 모드(작업 디렉터리 = `~/.hermes/hermes-agent` 등)에서 실행하면, `rm -rf`가 현재 작업 디렉터리를 지워서 `fatal: U
b1bca63a117a/2026-06-10_02-04-17.md:111 | (동일 패턴)
b1bca63a117a/2026-06-09_23-05-51.md:106 | (동일 패턴)
b1bca63a117a/2026-06-10_01-06-51.md:110 | (동일 패턴)
b1bca63a117a/2026-06-08_06-00-22.md:78 | (동일 패턴, 22:09 이전 — retro-masking 누락)
... 9 more (06-08/06-09 모두 같은 패턴)
```

**누락된 5개 파일 (06-09 22:09 retro-masking 시점 이후 생성):**
- `b1bca63a117a/2026-06-09_23-05-51.md` (06-09 22:09 + 1h56m 후)
- `b1bca63a117a/2026-06-10_00-04-38.md`
- `b1bca63a117a/2026-06-10_01-06-51.md`
- `b1bca63a117a/2026-06-10_02-04-17.md`
- `b1bca63a117a/2026-06-10_03-03-48.md` (06-10 03:30 27분 전)

## 판별 기준 (ISS-067 #2 vs 다른 패턴)

| 신호 | ISS-067 #2 | ISS-063 | 진짜 에러 |
|------|------------|---------|-----------|
| 매칭 잡 | b1bca63a117a (Tistory) | 5d0f14aef84c (일일 리뷰) | any |
| 매칭 라인 시작 | `**Symptom:**` / `**원인:**` / `**해결:**` | 자기 진단 단어 인용 | Traceback / fatal error |
| jobs.json 상태 | ok (consecutive_failures 0) | ok | failed 또는 last_status_error 길이 큼 |
| 매칭 라인 본질 | SKILL.md known-issues 노드 leak | daily 리뷰가 자기 진단 단어 인용 | 실제 stack trace |

## 권장 수정 (06-10 22:00 일일 리뷰)

1. **`mask_self_healer_terms.py` 호출** — 5개 누락 Tistory 출력 retro-masking:
   ```bash
   python3 ~/.hermes/skills/automation/memory-hygiene/scripts/mask_self_healer_terms.py \
     ~/.hermes/cron/output/b1bca63a117a/2026-06-{09_23,10_00,10_01,10_02,10_03}*
   ```

2. **`mask_self_healer_terms.py`에 라인 마커 추가**:
   ```python
   KNOWN_ISSUES_MARKERS = [
       r'^\*\*Symptom:\*\*',
       r'^\*\*원인:\*\*',
       r'^\*\*해결:\*\*',
       r'fatal: Unable to read current working directory',
       r'getcwd: cannot access parent directories',
   ]
   ```

3. **`tistory-publisher` SKILL.md의 known-issues 노드를 `references/` 파일로 격리** — SKILL.md 본문은 패턴 묘사만, 진단 출력은 `references/known-issues.md`로 분리. cron output이 SKILL.md 본문을 인용할 일이 없어짐.

4. **`cron_self_healer.py`의 regex 강화**:
   ```python
   # (변경 전)
   r'(?:file|path|directory).*(?:not found|does not exi'
   # (변경 후)
   r'(?<!Symptom:\*\* )(?:file|path|directory).*(?:not found|does not exi'
   # + 라인 시작이 **Symptom:/원인:/해결:면 drop
   ```

## 재발 감지

06-10 22:00 또는 06-11 03:30에 다시 `b1bca63a117a` 잡에서 `**Symptom:**` 매칭이 보이면 **ISS-068 즉시 등록** (3회 반복 임계는 06-10 03:30 / 22:00 / 06-11 03:30).

## 핵심 교훈

- **"해결됨 optimistic" 함정**: retro-masking은 시점 이전만 처리. live masking 파이프라인이 시점 이후 새 출력을 잡아야 함.
- **SKILL.md 본문이 cron output에 인용되면 leak 위험**: 진단 텍스트는 가급적 `references/`로 격리.
- **daily 리뷰의 ✅ 해결됨 선언은 24시간 모니터링 동반**: `tail -5 cron/output/$JOB_ID/*.md`로 시점 이후 새 출력 grep.
