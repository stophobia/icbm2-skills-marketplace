# 이미지 밝기 문제 해결 — Photorealism + 유머/위트 (2026-05-24)

## 문제
포토리얼리즘(photorealistic)으로 생성하면 항상 어두운 이미지 발생.
`cinematic photography`, `natural lighting`, `night scene`, `neon reflections` 등이 어두운 조명 유발.

## 원인
포토리얼리즘 스타일 키워드 중 일부는 본래 어두운 분위기(moody/atmospheric)를 생성하도록 유도함.
유머/위트 테마에 어울리는 밝고 활기찬 이미지를 만들려면 명시적 밝기 키워드 필요.

## 해결 — 반드시 함께 사용하는 키워드 조합

### ✅ 필수 (이미지 프롬프트에 항상 포함)
```
bright daylight, vivid colors, high-key lighting
```

### ✅ 분위기/스타일 추가
```
comedic contrast, playful light, cheerful atmosphere
warm golden hour, saturated tones, energetic urban mood
```

### ❌ 제거 (어두운 이미지 유발 — 절대 사용 금지)
```
cinematic photography
natural lighting
night scene
neon reflections
moody atmosphere
low-key lighting
dark shadows
```

## Python 코드 적용 예시

```python
# music_video_producer.py — generate_image_variants()에서 사용
def generate_image_variants(base_prompt, output_dir, count=3):
    """포토리얼리즘 + 밝고 유머러스한 이미지 3개 생성"""
    variants = [
        f"{base_prompt}, bright daylight, vivid colors, high-key lighting, comedic contrast",
        f"{base_prompt}, warm golden hour, saturated tones, playful light, cheerful atmosphere",
        f"{base_prompt}, sunny atmosphere, high-key lighting, vivid colors, energetic urban mood"
    ]
    # ...
```

## SKILL.md 이미지 프롬프트 규칙 (2026-05-24)

### Notion DB 이미지프롬프트 작성법
**올바른 예시:**
```
Photorealistic, bright daylight, convenience store scene, vivid colors, 
high-key lighting, cheerful atmosphere, dynamic composition
```

```
Photorealistic, warm golden hour, street market, colorful awnings, 
saturated tones, bright natural light, comedic contrast, playful atmosphere
```

**올바르지 않은 예시 (피하세요):**
```
Photorealistic, cinematic photography, natural lighting, subtle shadows
```
→ cinematic + natural lighting = 어둡게 생성됨

### 절대 금지 키워드 (어두운 이미지 유발)
| 금지 키워드 | 이유 |
|-----------|------|
| `cinematic photography` | 시네마틱 톤 = 어두운 조명 |
| `natural lighting` | 자연광 = 시간대/날씨 따라 어두울 수 있음 |
| `night scene` |夜间 = 반드시 어두움 |
| `neon reflections` | 네온 반사 = 야경 느낌 |
| `low-key lighting` | 저조명 = 어둡게 |
| `moody atmosphere` | 분위기 = 감정적 어두움 |

## 유머/위트 테마에 최적화된 밝기 조합

| 테마 유형 | 권장 키워드 조합 |
|----------|-----------------|
| 일상 юмор (편의점, 골목) | `bright daylight, cheerful atmosphere, high-key lighting, vivid colors` |
| 사회 юмор (AI, 기술) | `warm golden hour, sunny atmosphere, comedic contrast, saturated tones` |
| 감성 юмор (아이러니) | `high-key lighting, playful light, bright natural light, dynamic composition` |
| 도시 юмор | `energetic urban mood, vivid colors, warm golden hour, saturated tones` |

## 검증
생성된 이미지가 어두우면 → 프롬프트에 `bright daylight` + `high-key lighting`이 있는지 확인.
없으면 즉시 추가하여 재생성.