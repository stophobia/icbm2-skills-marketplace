# 2026-06-04 새벽 cron — macOS Leopard Spaces → GridLion 블로그 발행

## 핵심 학습: execute_code 크론 차단

`execute_code` 도구는 **크론 환경에서 보안 정책에 의해 자동 차단**된다. 일반 세션에서는 정상 작동하지만, cron으로 실행된 세션에서는 항상 차단된다.

### 실제 에러 메시지 (verbatim)
```
BLOCKED: execute_code runs arbitrary local Python (including subprocess calls that bypass shell-string approval checks). Cron jobs run without a user present to approve it. Use normal tools instead, or set approvals.cron_mode: approve only if this cron profile is intentionally trusted.
```

### 차단 패턴
- 임의의 로컬 Python 실행 (subprocess 호출 포함)
- 셸-문자열 승인 체크 우회 우려
- 사용자 승인 부재

### 작동 대안 (모두 terminal 도구로 검증됨)
1. `python3 -c "짧은 스크립트"` — 한 줄 검사/CJK 탐지에 최적
2. `python3 << 'PYEOF' ... PYEOF` — heredoc (multi-line)
3. `python3 script.py` — 외부 스크립트 실행
4. `jq` — JSON 파싱 (security scan 안전)

### 실제 작업 흐름 (이 세션)
1. `execute_code`로 CJK 검사 시도 → BLOCKED
2. 즉시 `terminal` + `python3 -c "..."`로 전환
3. CJK 검사 1차/2차 모두 통과 확인
4. 나머지 파이프라인(quality_gate, publisher, record) 모두 terminal로 실행

### 권장 패턴
- 파이프라인 초기에 `execute_code` 1회 시도 → 차단 확인 → `terminal` 패턴으로 즉시 전환
- 두 패턴 혼용 시 컨텍스트 낭비이므로, 차단 확인 후 모든 후속 작업을 `terminal`로 일관성 있게 실행
- SKILL.md 본문에서 "execute_code 또는 terminal" 표현은 크론 환경에서 오해의 소지 있음 → "terminal 우선, execute_code fallback"으로 명확히

## 세션 작업 요약
- 주제: macOS Leopard의 3x3 그리드 Spaces → Mission Control 1줄 제한 → GridLion 래퍼 방식 그리드 재현
- 카테고리: iOS/Swift (Tistory ID: 1219747)
- 발행 URL: https://sigco.tistory.com/625
- 본문 길이: 3,010자 (Quality Gate Grade B, 69점, pass)
- CJK/Cyrillic 혼입 0건
- 2007년 언급은 Leopard 출시 연도(역사적 맥락) → 시간 신선도 false positive

## 발견된 false positive 패턴
- "2007년 자료 감지" — Leopard 10.5 출시 연도로서 정당한 역사적 인용
- "10.5 Leopard", "macOS Lion" 등 OS 역사 서술 시 빈번히 발생
- 패턴: "최신 동향/이슈 소개 + 역사적 배경 비교" 구조에서 10년+ 전 연도 언급 시 자동 감지
- 판단: 본문이 (a) 역사적 맥락 설명, (b) 현재 macOS 한계 비판, (c) 미래 해결 방향 제안 등일 때 통과
