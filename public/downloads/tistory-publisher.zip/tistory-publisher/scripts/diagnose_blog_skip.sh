#!/bin/bash
# diagnose_blog_skip.sh
# Tistory 발행 skip 원인 자동 진단 스크립트 (2026-06-08 87차 추가)
#
# 사용법: bash ~/.hermes/skills/automation/tistory-publisher/scripts/diagnose_blog_skip.sh
# 출력: 카테고리별 토픽 수, dedup 누적, daily_counts, 파이프라인 상태
#
# cron이 "할당량 소진" / "주제 소진" 으로 skip할 때 사용자/운영자가
# 진짜 원인을 1초 안에 파악할 수 있도록 함.
#
# 반환값:
#   0 = 진단 완료, 발행 가능 상태
#   1 = Notion fallback DB가 비어있음 (--refresh-topics 필요)
#   2 = dedup 누적 과다 (>300개)
#   3 = daily_counts 비정상 (특정 카테고리 100+ 누적)

PIPELINE="$HOME/.hermes/scripts/blog_pipeline.py"
FALLBACK_CACHE="$HOME/.hermes/memory/fallback_topics_cache.json"
PUBLISHED_URLS="$HOME/.hermes/memory/published_urls.txt"
STATE_FILE="$HOME/.hermes/memory/blog_pipeline_state.json"
EXIT_CODE=0

echo "════════════════════════════════════════════════════════════"
echo "🔍 Tistory 발행 skip 진단 (2026-06-08)"
echo "════════════════════════════════════════════════════════════"

# 1. 파이프라인 status
echo ""
echo "── 1. 파이프라인 status ─────────────────────────────"
if [ -f "$PIPELINE" ]; then
    /usr/bin/python3 "$PIPELINE" --status 2>&1 | tail -20
else
    echo "⚠️  blog_pipeline.py 없음: $PIPELINE"
fi

# 2. Notion fallback cache 카테고리별 토픽 수
echo ""
echo "── 2. Notion 긱뉴스 fallback 캐시 (카테고리별 토픽 수) ──"
if [ -f "$FALLBACK_CACHE" ]; then
    /usr/bin/python3 << 'PYEOF'
import json
d = json.load(open('/Users/hjshin/.hermes/memory/fallback_topics_cache.json'))
t = d.get('topics', {})
print('  cached_at:', d.get('cached_at', 'N/A'))
for cat in ['AI/ML', 'iOS/Swift', '개발도구', '투자/경제', '아이디어', '기타', '개발팁']:
    n = len(t.get(cat, []))
    bar = '█' * min(n, 30) + '░' * max(0, 30 - n)
    flag = '⚠️ ' if n == 0 else '✅'
    print(f'  {flag} {cat:8s} {n:3d}개  {bar}')
total = sum(len(v) for v in t.values())
print(f'  총 {total}개')
import sys
sys.exit(1 if total == 0 else 0)
PYEOF
    if [ $? -ne 0 ]; then
        echo "  → 진단: Notion fallback DB가 비어있음. --refresh-topics 필요"
        EXIT_CODE=1
    fi
else
    echo "⚠️  캐시 파일 없음: $FALLBACK_CACHE"
    EXIT_CODE=1
fi

# 3. dedup 누적
echo ""
echo "── 3. Dedup 누적 ─────────────────────────────────────"
if [ -f "$PUBLISHED_URLS" ]; then
    URL_COUNT=$(wc -l < "$PUBLISHED_URLS" | tr -d ' ')
    echo "  published_urls.txt: ${URL_COUNT}개"
    if [ "$URL_COUNT" -gt 300 ]; then
        echo "  → 진단: dedup 누적 과다. 발행 가능한 새 긱뉴스 URL이 부족할 수 있음"
        if [ $EXIT_CODE -eq 0 ]; then EXIT_CODE=2; fi
    fi
else
    echo "  published_urls.txt 없음 (정상 — 첫 발행)"
fi

if [ -f "$HOME/.hermes/memory/published_topics.json" ]; then
    TOPIC_COUNT=$(/usr/bin/python3 -c "import json; print(len(json.load(open('/Users/hjshin/.hermes/memory/published_topics.json')).get('topics', [])))")
    echo "  published_topics.json: ${TOPIC_COUNT}개 (해시 누적)"
fi

# 4. daily_counts
echo ""
echo "── 4. 오늘 daily_counts ──────────────────────────────"
if [ -f "$STATE_FILE" ]; then
    /usr/bin/python3 << 'PYEOF'
import json
from datetime import datetime
d = json.load(open('/Users/hjshin/.hermes/memory/blog_pipeline_state.json'))
dc = d.get('daily_counts', {})
today = datetime.now().strftime('%Y-%m-%d')
counts = dc.get(today, {})
if not counts:
    print(f'  {today}: 발행 없음')
else:
    high_count = False
    for cat, n in counts.items():
        flag = '⚠️' if n >= 50 else '✅'
        print(f'  {flag} {cat}: {n}건')
        if n >= 50:
            high_count = True
    if high_count:
        import sys
        sys.exit(3)
PYEOF
    if [ $? -eq 3 ]; then
        EXIT_CODE=3
    fi
fi

# 5. 종합 진단
echo ""
echo "── 5. 종합 ──────────────────────────────────────────"
case $EXIT_CODE in
    0) echo "✅ 발행 가능 상태. cron 재실행 또는 다음 사이클 대기." ;;
    1) echo "🔴 Notion fallback DB 비어있음. --refresh-topics 실행 필요:"
       echo "   /usr/bin/python3 $PIPELINE --refresh-topics" ;;
    2) echo "🟡 dedup 누적 과다. --refresh-topics + 일부 published_urls.txt 정리 검토." ;;
    3) echo "🟡 특정 카테고리 daily_counts 과다. '기타' 제외 + 카테고리 분산 검토." ;;
esac
echo ""
echo "════════════════════════════════════════════════════════════"
exit $EXIT_CODE
