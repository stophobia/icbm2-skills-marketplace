# 음악 3분 보장 — 절대 규칙 (2026-05-25)

## 문제

家主님이 "음악을 3분 정도로 만들라"고 했는데 1분 미만으로 생성됨.

**원인:** mmx music CLI에는 `--duration` 파라미터가 없음. 가사의 양/구조가 길이를 결정.
가사가 짧으면 자동으로 짧은 음악이 생성됨.

## 해결: expand_lyrics() 자동 확장

`music_video_producer.py`에 구현된 `expand_lyrics()` 함수가 가사를 3분 분량으로 자동 확장:

```python
STRUCTURE_TAGS = ['Verse', 'Chorus', 'Bridge', 'Pre-Chorus', 'Intro', 'Outro']

def expand_lyrics(text, target_chars=1500):
    """짧은 가사를 3분 분량(~1500자)으로 자동 확장"""
    # 1. 구조 태그 [Verse], [Chorus] 등 인식하여 섹션 분리
    # 2. 섹션 반복 추가 (target_chars 도달 시 중지)
    # 3. 반복 시 태그에 번호: [Verse] → [Verse 2]
    # max 50 iterations
```

**목표:** 1,500자 이상 (3분 음악에 충분한 양)

## 3단계 검증 로직 (2026-05-25)

```python
def ensure_3min_lyrics(raw_lyrics):
    """가사 길이 보장: 3분 음악에 필요한 양까지 확장"""
    
    # Step 1: 최초 확장 (1500자 목표)
    lyrics = expand_lyrics(raw_lyrics, target_chars=1500)
    
    # Step 2: 1000자 미만 시 4분 재확장
    if len(lyrics) < 1000:
        print(f"  ⚠️ 가사 {len(lyrics)}자 — 4분 재확장")
        lyrics = expand_lyrics(raw_lyrics, target_chars=2000)
    
    # Step 3: 500자 미만 시 생성 차단 (단호하게)
    if len(lyrics) < 500:
        print(f"  ❌ 가사 {len(lyrics)}자 — 3분 미만 음악 생성 불가")
        print(" 家主님 확인 필요: 주제 가사 양 부족")
        return None  # 차단
    
    print(f"  ✅ 가사 {len(lyrics)}자 확보")
    return lyrics
```

**이 로직은 `mmx_music()` 호출 전에 반드시 실행되어야 함.**

## mmx music 호출 시 적용

```python
def mmx_music(prompt, raw_lyrics, output_path):
    lyrics = ensure_3min_lyrics(raw_lyrics)
    if lyrics is None:
        return False  #家主님께 차단 사유 보고
    
    # 한국어/영어 외 문자 필터링
    lyrics = filter_lyrics(lyrics)
    
    cmd = [
        "mmx", "music", "generate",
        "--api-key", os.environ.get("MINIMAX_API_KEY", ""),
        "--prompt", prompt,
        "--lyrics", lyrics,
        "--out", output_path
    ]
    # ...
```

##家主님의 3분 기준

- 3분 = 대략 180초
- mmx music CLI는 정확한 초를 보장하지 않음
- **대략 1500자+ 가사 = 3분+ 음악** (확인됨: 109자 → 1,591자로 확장 후 3분+ 생성)

## 절대 금지

- ❌ 가사 500자 미만에서 mmx music 호출
- ❌ expand_lyrics() 없이 raw_lyrics 직접 전달
- ❌家主님이 "3분"이라고明知하면서 짧은 가사로 진행