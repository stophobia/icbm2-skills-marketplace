#!/bin/bash
# hades 셋업 스크립트 (1회 실행)
# - Rust 툴체인 + hades 빌드 + Python env + KOSPI/KOSDAQ 전체 동기화
# - 소요시간: ~10분
# - 실행 후 cron에서 `hades <command> --format json` 바로 호출 가능
#
# 사용법:
#   chmod +x setup_hades.sh
#   ./setup_hades.sh

set -e

HADES_DIR="${HADES_DIR:-$HOME/hades}"
PYTHON_ENV_NAME="${PYTHON_ENV_NAME:-hades}"
PYTHON_BIN="$HOME/opt/anaconda3/envs/${PYTHON_ENV_NAME}/bin/python"

echo "🛠  hades 셋업 시작 (소요 ~10분)"
echo ""

# 1) Rust 툴체인
if ! command -v cargo &> /dev/null; then
  echo "[1/5] Rust 툴체인 설치..."
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y \
    --default-toolchain stable --profile minimal
  . "$HOME/.cargo/env"
else
  echo "[1/5] Rust 툴체인 이미 설치됨 ($(cargo --version))"
fi

# 2) hades 클론 + 빌드
if [ ! -d "$HADES_DIR" ]; then
  echo "[2/5] hades 클론..."
  git clone --depth 1 https://github.com/junhoyeo/hades.git "$HADES_DIR"
fi

echo "[2/5] hades 빌드 (첫 빌드 ~4분)..."
cd "$HADES_DIR"
. "$HOME/.cargo/env"
cargo build --release -p hades-cli

# 3) Python env
if [ ! -d "$HOME/opt/anaconda3/envs/${PYTHON_ENV_NAME}" ]; then
  echo "[3/5] conda env 생성..."
  conda create -n "$PYTHON_ENV_NAME" python=3.11 -y
fi

echo "[3/5] Python 의존성 설치..."
$HOME/opt/anaconda3/envs/${PYTHON_ENV_NAME}/bin/pip install --quiet pykrx pandas pyarrow tqdm

# 4) OHLCV 동기화 (KOSPI+KOSDAQ 전체)
echo "[4/5] OHLCV 데이터 동기화 (~5분, 41MB parquet)..."
$PYTHON_BIN "$HADES_DIR/scripts/sync_krx_data.py" --init 1

# 5) 검증
echo "[5/5] 검증..."
$HADES_DIR/target/release/hades ticker 005930

echo ""
echo "✅ 셋업 완료!"
echo "   바이너리: $HADES_DIR/target/release/hades"
echo "   데이터: $HADES_DIR/data/ohlcv/ ($(du -sh $HADES_DIR/data/ohlcv | cut -f1))"
echo ""
echo "다음 단계:"
echo "  $HADES_DIR/target/release/hades ohlcv 005930 --limit 5"
echo "  $HADES_DIR/target/release/hades backtest --market kospi --strategy momentum --top-k 30 --rotation weekly --from 2025-07-01 --to 2026-06-22"
