# ISS-058 — Self-healer MemoryError Pattern False Positive

**Status:** ✅ 해결됨 (2026-06-03)
**Related:** ISS-044 (APIError 패턴 — 동일 메타 패턴)
**Affects:** `~/.hermes/scripts/cron_self_healer.py:115`

## Symptom

매일 밤 self-healer가 🛡️ 심야 통합 점검 크론 잡에서 다음 오탐을 발생시킴:

```
❌ [output_error] 출력에서 MemoryError 감지 — 패턴 매치: (?:out of memory|memory.*error|cannot allocate)
```

`jobs.json`의 `last_status`는 `ok`이고, 출력 파일에는 `✅`/`성공` 마커가 다수 — 실제 MemoryError는 발생하지 않았음.

## Root Cause

`cron_self_healer.py:115`의 정규식이 너무 느슨했음:

```python
("MemoryError", r"(?:out of memory|memory.*error|cannot allocate)", "MemoryError"),
```

`memory.*error` 패턴은 `memory_error_tracker.py`라는 **스크립트 파일명**이나 `memory/issues.md` 같은 **경로명**에 포함된 `memory ... error` substring까지 매칭함. 심야 통합 정비의 3단계 출력(`memory_error_tracker.py를 실행하여 메모리 에러 동기화`)이 정확히 이 패턴에 걸림.

ISS-044에서 APIError 패턴을 단어 경계(`\b`)로 강화한 것과 동일한 구조의 버그. 단, ISS-044 fix가 APIError에만 적용되었고 MemoryError는 누락되었음.

## Fix (2026-06-03)

ISS-044의 동일한 방식 — 단어 경계 + 실 매칭 강화:

```python
# 변경 전
("MemoryError", r"(?:out of memory|memory.*error|cannot allocate)", "MemoryError"),

# 변경 후
("MemoryError", r"\b(?:out[\s_]*of[\s_]*memory|outofmemoryerror|memoryerror\b|cannot[\s_]*allocate[\s_]*memory|allocation[\s_]*failed)\b", "MemoryError"),
```

핵심 변경:
- `memory.*error` 제거 → `memoryerror` (단어) 또는 실 매칭(`OutOfMemoryError`)로 대체
- `\b` 단어 경계 추가
- `allocation[\s_]*failed` 추가 (대안 표현)

## Verification

4 TC로 검증:

| 입력 | 예상 | 결과 |
|------|------|------|
| `memory_error_tracker.py를 실행하여 메모리 에러 동기화` | NO MATCH (FP 차단) | ✅ NO MATCH |
| `OutOfMemoryError: heap space exhausted` | MATCH (TP) | ✅ MATCH |
| `out of memory while loading model` | MATCH (TP) | ✅ MATCH |
| `Cannot allocate memory for new tensor` | MATCH (TP) | ✅ MATCH |

## Effect

- Self-healer 출력 4 errors → 3 errors
- 🛡️ 심야 통합 점검의 MemoryError 오탐 제거
- ISS-044의 APIError false positive 3건은 잔존 (별도 이슈)

## 잔존 false positive (3건)

ISS-058 fix로 1건 해결, 남은 3건은 별도 메타 트랩:

1. **🔄 일일 자기 개선 리뷰** — 이전 리뷰 본문이 `apierror` 단어를 인용함 → 다음 날 self-healer가 매칭
2. **📋 일요일 심층 점검** — 동일 원인 (이전 리뷰의 디버그 텍스트 보존)
3. **🧠 지식 그래프** — `"Notion API Rate Limit: ~3 req/sec"` 같은 informational 텍스트가 rate limit 패턴에 매칭 (의도된 동작)

**권장 다음 단계**:
- 일일 리뷰 출력에서 `apierror` → `APIErr_or` 등으로 마스킹 (메타 트랩 회피)
- 또는 self-healer가 `패턴 매치:` 라인을 skip하도록 추가 패치
- knowledge-graph의 informational rate limit description은 의도된 매칭이므로 skip 규칙 추가 검토

## 재발 방지

- 새 에러 패턴 추가 시 항상 `\b` 단어 경계 + 실 매칭 강화
- 파일명/경로명/스크립트명에 흔한 단어(`memory`, `error`, `api`, `token`, `fail`)가 포함된 패턴은 **반드시** 단어 경계 적용
- self-healer가 매칭한 경우 항상 출력 파일에 `✅`/`success`/`complete` 마커가 있는지 확인 (실제 실패 vs 정보성 텍스트 구분)

## Related

- ISS-044 — 같은 메타 패턴, APIError에 적용된 fix
- `references/iss-044-self-healer-fp-regex.md` — 원본 regex hardening 사례
- MEMORY.md "해결됨" 섹션: `ISS-058 (Self-Healer MemoryError FP 패턴, 2026-06-03)`
