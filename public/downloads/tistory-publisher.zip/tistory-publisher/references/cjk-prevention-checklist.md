# CJK 혼입 방지 체크리스트 (2026-05-23, 70차 루프)

## 이번 세션에서 발견된 문제

### 제목 Chinese 혼입
- **예시:** `Google Search, AI 시대의 광고를重新定義하다`
- **원인:** GeekNews 원본(simionewillison.net) 기사를 참조할 때 Chinese 텍스트가 섞여 들어옴
- **문제:** 품질 게이트(`blog_quality_gate.py --file`)는 Markdown 파일만 검증하고, 제목은 별도 검증 없음

### GeekNews 기사 참조 시 Chinese/Japanese 혼입 경로
1. 기사 원본(simioneillison.net, HN 등)에 Chinese/Japanese 텍스트 포함
2. AI가 Markdown 작성 시 원본을 참조하면서 Chinese 표현을 그대로 사용
3. Markdown CJK 선검사 시 제목은 별도로 검증하지 않음
4. 제목에 Chinese/Japanese가 섞여 발행됨

## 방지 체크리스트

### 1단계: 제목 Korean-only 검증 (반드시!)
```python
import re
title = "Google Search, AI 시대의 광고를重新定義하다"
cjk = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', title))
if cjk:
    print(f"⚠️ 제목 CJK 발견: {cjk}")
    title = title.replace('重新定義', '다시 정의')
```

### 2단계: Markdown 작성 시
- GeekNews 원본 참조 시 **한국어 표현으로 번역 후 작성**
- Chinese/Japanese 텍스트를 그대로 복사·참조하지 말 것
- 공식 웹사이트(herdr.dev 등)를 참조할 때도 Japanese/Chinese 텍스트가 섞여 있으면 그대로 유입 가능 → **한국어 표현으로 번역 후 작성**

### 3단계: HTML 변환 후
- 제목 추출 후 CJK 검증
- comprehensive dict로 제거

## 루프별 발견 기록

### 69차 (2026-05-22): GeekNews 기사 참조 Chinese 혼입
| Chinese | Korean |
|---------|--------|
| 重新定義 | 다시 정의 |
| 你怎么看 |你怎么看 (삭제 또는 한국어 표현으로) |

### 70차 (2026-05-23): 공식 웹사이트 SSH 섹션 일본어 혼입
- **混入 경로:** Markdown 작성 시 herdr.dev 공식 웹사이트 SSH 설명 섹션에서 일본어 텍스트 직접 참조
- **발견 사례:** `瘦クライアントとしてローカルのHerdrからリモートに接続` → 한국어로 교체
- **대응:** Markdown CJK 선검사 1차에서 `'后'`, `'ロ'`, `'ル'`, `'モ'`, `'ト'`, `'リ'`, `'ラ'`, `'と'`, `'ア'`, `'台'`, `'ン'`, `'ク'`, `'か'`, `'ー'`, `'接'`, `'て'`, `'カ'`, `'に'`, `'続'`, `'イ'`, `'し'`, `'机'`, `'の'`, `'瘦'`, `'ら'`, `'时'` 26자 발견 → 종합 사전 + targeted 정제 후 제거 완료
- **HTML 변환:** CJK 루프 0회차 통과

## Chinese comma 혼입 + 코드 블록 파괴 (2026-05-29, 75차)
- **混入 경로:** Markdown 작성 시 Korean 문장 끝에 Chinese comma `、` 섞임
- **코드 블록 줄바꿈 파괴:** `markdown_to_tistory_html.py`가 `<pre><code>` 안 줄바꿈 파괴 → 한 줄로 붙음
- **대응:** 변환 후 Python으로 수동 복원 + Chinese comma 종합 사전 추가
- **신규 CJK:** `隐`(은), `权`(권), `私`(사), `界`(계)

## Katakana 누락 문자 (누적)
`ビ`(비), `ュ`(유), `レ`(레), `ク`(쿠), `カ`(카), `イ`(이), `ン`(은), `ー`(삭제)

## 단순 한자 단어 보정 (139차, 2026-06-14)
- **混入 사례:** `追问` (중국어 "추궁하다" = 한국어 "묻다")
- **混入 경로:** 긱뉴스 본문이 아닌 AI 작성 도중 중국어 단어 사용
- **대응:** v0.5 1차 patch에서 `追问` → `직접 묻고` 로 즉시 치환. 125차 中 + 从 사례와 동일 패턴
- **CJK 사전 추가:** `追问` (직접 묻고)
- **정량:** CJK 0건 28회 연속 (139차 누적)
- **교훈:** 단순 한자 단어(2~3자)도 CJK 패턴 `[一-鿿]` 에서 즉시 검출되며, 발견 즉시 한국어 patch 가능. 사전에 등록 안 된 단어라도 1차 patch에서 보정 후 누적 사전에 추가하면 됨
