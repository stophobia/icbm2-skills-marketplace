"""
Kiwi Companion - Face Module (template)
Pygame-based character face with emotion rendering, blinking, mouth sync.
Replace EMOTION_PALETTE and the face draw methods to customize.
"""
import math
import random
import time
from typing import Optional

import pygame


EMOTION_PALETTE = {
    "happy":     {"bg": (255, 244, 196), "kiwi": (143, 195, 80),  "cheek": (255, 156, 174), "eye": (40, 40, 40)},
    "sad":       {"bg": (210, 220, 240), "kiwi": (130, 175, 130), "cheek": (180, 200, 230), "eye": (50, 60, 90)},
    "thinking":  {"bg": (235, 230, 250), "kiwi": (160, 175, 120), "cheek": (200, 200, 230), "eye": (60, 50, 80)},
    "surprised": {"bg": (255, 230, 230), "kiwi": (180, 220, 100), "cheek": (255, 180, 180), "eye": (30, 30, 30)},
    "neutral":   {"bg": (240, 245, 240), "kiwi": (143, 195, 80),  "cheek": (255, 180, 180), "eye": (40, 40, 40)},
}


class KiwiFace:
    WINDOW_SIZE = 480
    FACE_RADIUS = 170
    EYE_OFFSET = 60
    EYE_RADIUS = 18
    BLINK_INTERVAL = (3.0, 5.5)

    def __init__(self):
        self.emotion = "neutral"
        self.speaking = False
        self.mouth_open = 0.0
        self.target_mouth = 0.0
        self._last_blink = time.time()
        self._next_blink = self._random_blink_delay()
        self._is_blinking = False
        self._blink_start = 0.0
        self._blink_duration = 0.15
        self._running = False
        self._ready = False
        self._window = None
        self._clock = None

    @staticmethod
    def _random_blink_delay() -> float:
        return random.uniform(*KiwiFace.BLINK_INTERVAL)

    def set_emotion(self, emotion: str):
        if emotion in EMOTION_PALETTE:
            self.emotion = emotion

    def set_speaking(self, speaking: bool, amplitude: float = 1.0):
        self.speaking = speaking
        self.target_mouth = max(0.0, min(1.0, amplitude))

    def request_quit(self):
        self._running = False

    def is_ready(self) -> bool:
        return self._ready

    def run(self):
        pygame.init()
        pygame.display.set_caption("🥝 Kiwi Companion")
        self._window = pygame.display.set_mode((self.WINDOW_SIZE, self.WINDOW_SIZE))
        self._clock = pygame.time.Clock()
        self._ready = True

        self._running = True
        while self._running:
            now = time.time()
            self._update(now)
            self._draw()
            pygame.display.flip()
            self._clock.tick(60)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self._running = False
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    self._running = False
        pygame.quit()

    def _update(self, now: float):
        self.mouth_open += (self.target_mouth - self.mouth_open) * 0.18
        if self._is_blinking:
            if now - self._blink_start > self._blink_duration:
                self._is_blinking = False
                self._next_blink = now + self._random_blink_delay()
        else:
            if now >= self._next_blink:
                self._is_blinking = True
                self._blink_start = now

    def _draw(self):
        palette = EMOTION_PALETTE[self.emotion]
        self._window.fill(palette["bg"])
        cx = cy = self.WINDOW_SIZE // 2

        pygame.draw.circle(self._window, palette["kiwi"], (cx, cy), self.FACE_RADIUS)
        pygame.draw.circle(
            self._window,
            tuple(min(255, c + 30) for c in palette["kiwi"]),
            (cx - 40, cy - 50), self.FACE_RADIUS - 40,
        )
        rng = random.Random(42)
        for _ in range(12):
            angle = rng.uniform(0, 2 * math.pi)
            dist = rng.uniform(60, self.FACE_RADIUS - 30)
            sx = int(cx + math.cos(angle) * dist)
            sy = int(cy + math.sin(angle) * dist)
            pygame.draw.circle(self._window, (60, 70, 40), (sx, sy), 2)

        pygame.draw.circle(self._window, palette["cheek"], (cx - 80, cy + 30), 25)
        pygame.draw.circle(self._window, palette["cheek"], (cx + 80, cy + 30), 25)

        self._draw_eye(cx - self.EYE_OFFSET, cy - 20, palette["eye"])
        self._draw_eye(cx + self.EYE_OFFSET, cy - 20, palette["eye"])
        self._draw_mouth(cx, cy + 70, palette["eye"])
        self._draw_emotion_label()

    def _draw_eye(self, x, y, color):
        if self._is_blinking:
            pygame.draw.line(self._window, color, (x - 20, y), (x + 20, y), 3)
        else:
            pygame.draw.circle(self._window, (255, 255, 255), (x, y), self.EYE_RADIUS)
            pygame.draw.circle(self._window, color, (x, y), self.EYE_RADIUS - 4)
            pygame.draw.circle(self._window, (255, 255, 255), (x - 5, y - 5), 4)

    def _draw_mouth(self, cx, cy, color):
        m = self.mouth_open
        if self.emotion == "happy":
            if self.speaking and m > 0.3:
                pygame.draw.ellipse(self._window, color, (cx - 30, cy - 5, 60, 20 + int(m * 15)), 2)
            else:
                pygame.draw.arc(
                    self._window, color,
                    (cx - 35, cy - 25, 70, 45),
                    math.pi * 0.15, math.pi - math.pi * 0.15, 4,
                )
        elif self.emotion == "sad":
            pygame.draw.arc(
                self._window, color,
                (cx - 30, cy + 5, 60, 30),
                math.pi + math.pi * 0.15, 2 * math.pi - math.pi * 0.15, 3,
            )
        elif self.emotion == "thinking":
            pygame.draw.circle(self._window, color, (cx, cy + 10), 5, 2)
        elif self.emotion == "surprised":
            radius = 12 + int(m * 18)
            pygame.draw.circle(self._window, color, (cx, cy), radius, 3)
            pygame.draw.circle(self._window, (40, 30, 50), (cx, cy), radius - 4)
        else:
            if self.speaking and m > 0.2:
                pygame.draw.ellipse(self._window, color, (cx - 20, cy - 3, 40, 8 + int(m * 12)), 2)
            else:
                pygame.draw.line(self._window, color, (cx - 15, cy + 5), (cx + 15, cy + 5), 3)

    def _draw_emotion_label(self):
        try:
            font = pygame.font.SysFont("Apple SD Gothic Neo", 22, bold=True)
        except Exception:
            font = pygame.font.Font(None, 24)
        labels = {
            "happy": "🥝 😊 happy", "sad": "🥝 😢 sad",
            "thinking": "🥝 🤔 thinking", "surprised": "🥝 😮 surprised",
            "neutral": "🥝 😐 neutral",
        }
        text = font.render(labels.get(self.emotion, self.emotion), True, (60, 60, 60))
        rect = text.get_rect(center=(self.WINDOW_SIZE // 2, self.WINDOW_SIZE - 30))
        self._window.blit(text, rect)


def demo():
    import threading
    face = KiwiFace()
    t = threading.Thread(target=face.run, daemon=True)
    t.start()
    while not face.is_ready():
        time.sleep(0.05)
    emotions = ["neutral", "happy", "sad", "thinking", "surprised"]
    idx = 0
    while True:
        try:
            face.set_emotion(emotions[idx % len(emotions)])
            for j in range(20):
                face.set_speaking(True, amplitude=0.3 + 0.7 * abs(math.sin(j / 3.0)))
                time.sleep(0.08)
            face.set_speaking(False)
            time.sleep(1.5)
            idx += 1
        except KeyboardInterrupt:
            face.request_quit()
            break


if __name__ == "__main__":
    demo()
