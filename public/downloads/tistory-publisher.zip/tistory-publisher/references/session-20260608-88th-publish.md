# 88차 발행 세션 노트 (2026-06-08) — 14단계 워크플로우 실전 검증

## 발행 결과
- **글 번호**: 677
- **제목**: LLM이 내 소프트웨어 엔지니어링 커리어를 잠식하고 있다 — 10년차 시니어가 본 세 기둥의 붕괴와 생존 전략
- **카테고리**: AI/ML (1219746)
- **태그**: 7개 (AI, LLM, 소프트웨어엔지니어, 커리어, ChatGPT, Claude, 디버깅)
- **quality_gate 등급**: A (76/100)
- **CJK 잔재**: 0건 (Markdown 1차 / HTML 1차 / clean_cjk 루프 모두 0)

## 14단계 워크플로우 실전 검증 — 모두 통과

| # | 단계 | 도구 | 결과 |
|---|------|------|------|
| 1 | `blog_pipeline.py` | terminal | selected_topic 수신 (GeekNews human-in-the-loop) |
| 2 | `mcp_ddg_search_fetch_content` | MCP | 18,426자 긱뉴스 본문 fetch |
| 3 | `write_file /tmp/blog_post.md` | file | 10,482 bytes 한국어 초안 |
| 4 | `python3 -c "re.findall(...)"` | terminal | CJK 0건 |
| 5 | `markdown_to_tistory_html.py` | terminal | 6,088 bytes HTML 변환 |
| 6 | `python3 -c "clean_cjk loop"` | terminal | iter 1에서 CJK 잔재 없음 → 즉시 종료 |
| 7 | `rm -rf + git clone` | terminal `workdir=/tmp` | 클론 성공 (cwd 분리) |
| 8 | `curl picsum` | terminal `workdir=/tmp/blog-images-repo` | 800x400 53KB JPEG |
| 9 | `git add/commit/push` | terminal `workdir=/tmp/blog-images-repo` | c94e151..741ba3b |
| 10 | `<h1>` 앞에 figure 삽입 | terminal `python3 -c` | 6,323 bytes |
| 11 | `blog_quality_gate.py --title --file` | terminal | A 76점 (Decision: pass) |
| 12 | `tistory_publisher.py` | terminal | https://sigco.tistory.com/677 + OG 썸네일 |
| 13 | `blog_pipeline.py --record TOPIC TITLE URL` | terminal | dedup 기록 완료 (3인자 시그니처 확인) |
| 14 | `rm -f` 정리 | terminal | OK |

## ⚠️ 88차 신규 관찰 신호 (frontmatter "트렌드 비교형 false positive + grade JSON 키 검증"과 연결)

### 1. `blog_quality_gate.py` JSON 키 위치 — `head -30`이 안전
**Symptom:** `tail -50`으로 grade/decision을 보려 했지만 JSON이 길어서 잘림. `head -30`으로 재호출해서 `grade: "A"` 확인.
**원인:** JSON 최상위 키는 `total_score`, `grade`, `decision`, `breakdown` 순으로 출력되고, `breakdown` 안에 `content/readability/originality/seo` 4개 카테고리. `total_score`가 30번째 줄 부근.
**해결:** `head -30` (또는 `head -25`)을 표준 호출 패턴으로 사용. tail은 breakdown 내부 detail만 보여줌.

**표준 검증 명령어 (89차~ 사용 권장):**
```bash
python3 ~/.hermes/scripts/blog_quality_gate.py \
  --title "제목" --file /tmp/blog_tistory.html \
  --tags "..." --category "카테고리명" 2>&1 | head -30
```
→ `total_score`, `grade`, `decision`을 한 번에 확인.

### 2. `has_conclusion: false` false positive — "요약" 섹션을 conclusion으로 안 침
**Symptom:** 본문에 `## 요약: 핵심 포인트 5가지` 섹션이 분명히 있는데 quality_gate breakdown에서 `"has_conclusion": false`로 판정.
**원인:** 게이트가 H2 헤더 텍스트에 "결론" 또는 "마무리" 같은 키워드를 기대하는 듯, "요약"으로는 매칭 안 됨. (코드 미확인 — 추측)
**영향:** 76점 → 80점대로 갈 수도 있었던 점수 누락. decision은 여전히 `pass` (grade A 유지).
**해결 (89차~ 권장):** 본문 마지막 H2를 다음 중 하나로:
- `## 결론: 핵심 정리` 또는
- `## 마무리: 향후 전망`

기존 `## 요약` 자리에 `## 결론` 사용하면 됨. 또는 `## 요약과 결론`처럼 두 키워드 모두 포함.

### 3. `has_intro: true` — 1차 도입 섹션 정상 인식
88차 본문 첫 H2는 `## 도입: LLM이 가져온 충격, 그리고 우리가 놓치고 있는 것` — 게이트가 정상 인식. 1단계 도입 H2에 "도입" 또는 "서론" 키워드 사용 권장 유지.

### 4. readability 감점 — 평균 문장 71자
**Symptom:** 86개 문장, 평균 71.186자 → readability 점수 11/20 (max 20).
**원인:** 한국어 평균 문장 길이 가이드라인 미준수 (권장 40~60자).
**해결 (89차~ 권장):** 단문 섞기 — 한 H2 섹션에 4~5문장, 그중 1~2개는 20~30자 단문. 또는 한 문단을 2개로 쪼개기. 80점대 진입하려면 필수.

## 88차 코드 변경 사항
- 없음 (워크플로우 검증 세션)

## 다음 세션 (89차~) 권장 액션
1. `blog_quality_gate.py` 소스 확인 → `has_conclusion`이 어떤 헤더 키워드를 매칭하는지 검증 (코드 grep)
2. 매칭 키워드가 "결론"이라면, 89차 발행 글에 `## 결론: ...` 사용 → has_conclusion true 확인
3. readability 20/20을 위해 단문 30% + 중문 50% + 장문 20% 비율로 작성

## 발행 통계 (88차 시점)
- 누적 발행 URL: 382 → 383
- 누적 topic dedup: 435
- 오늘 발행 카테고리: AI/ML
- Tistory 최신 글: https://sigco.tistory.com/677
