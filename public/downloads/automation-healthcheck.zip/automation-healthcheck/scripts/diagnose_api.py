#!/usr/bin/env python3
"""
외부 API 네트워크 진단 스크립트
automation-healthcheck §2의 "000/timeout → 6단계 진단"을 한 번에 실행.

Usage:
    python3 diagnose_api.py <host> [host2 ...]
    python3 diagnose_api.py api.telegram.org api.github.com

출력:
    1단계 DNS → 2단계 IPv4/IPv6 → 3단계 IP 핑 → 4단계 환경 프록시 →
    5단계 시스템 프록시 → 6단계 hosts 변조
    → 종합 판정: 정상 / 토큰 문제 / 네트워크 차단 / DNS 차단 / DNS 스푸핑

설계:
    - 한 호스트당 10~15초 소요 (timeout 누적)
    - 회사망에서 흔히 보는 패턴: 1~3단계 모두 막힘, 4~6단계 정상
    - 이 조합이 나오면 "방화벽 IP 차단"으로 확정 판정
"""
import json
import os
import platform
import re
import socket
import subprocess
import sys
import time


def run(cmd, timeout=10):
    """subprocess.run wrapper with timeout + error capture."""
    try:
        out = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        return out.returncode, out.stdout, out.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"
    except Exception as e:
        return 1, "", str(e)


def step1_dns(host):
    rc, out, _ = run(f"nslookup {host}", timeout=8)
    ips = re.findall(r"Address: (\S+)", out)
    # 192.168.1.1 같은 로컬 라우터 IP 제외
    ips = [ip for ip in ips if not ip.startswith(("192.168.", "10.", "127."))]
    if not ips:
        return False, [], "DNS 해결 실패"
    return True, ips, "정상"


def step2_curl(host):
    """IPv4/IPv6 둘 다 시도."""
    r4_rc, _, _ = run(f"curl -s -m 6 -4 -o /dev/null -w '%{{http_code}}' https://{host}/", timeout=10)
    r6_rc, _, _ = run(f"curl -s -m 6 -6 -o /dev/null -w '%{{http_code}}' https://{host}/", timeout=10)
    return r4_rc, r6_rc


def step3_ping(ip):
    rc, out, _ = run(f"ping -c 2 -W 3 {ip}", timeout=10)
    # "2 received" 또는 "0.0% packet loss" = 정상
    if "0.0% packet loss" in out or "1 received" in out or "2 received" in out:
        return True, "정상"
    return False, "100% loss"


def step4_env_proxy():
    rc, out, _ = run("env | grep -iE 'proxy|PROXY' | grep -v '_=' || true", timeout=3)
    return bool(out.strip()), out.strip() or "(없음)"


def step5_system_proxy():
    if platform.system() != "Darwin":
        return False, "(macOS 아님 — scutil 미실행)"
    rc, out, _ = run("scutil --proxy", timeout=3)
    if "HTTPSEnable : 1" in out or "HTTPEnable : 1" in out:
        return True, "시스템 프록시 활성"
    return False, "정상 (프록시 강제 아님)"


def step6_hosts_spoof(host):
    rc, out, _ = run(f"grep -i {host.split('.')[0]} /etc/hosts 2>/dev/null || true", timeout=3)
    if out.strip():
        return True, f"hosts 변조 의심: {out.strip()}"
    return False, "정상 (hosts 변조 없음)"


def diagnose(host):
    """6단계 진단 후 종합 판정."""
    print(f"\n{'='*60}")
    print(f"대상: {host}")
    print(f"{'='*60}")

    # 1단계: DNS
    t0 = time.time()
    dns_ok, ips, dns_msg = step1_dns(host)
    print(f"[1] DNS: {dns_msg} (소요 {time.time()-t0:.1f}s)")
    if not dns_ok:
        return "DNS 차단", "DNS 서버/도메인 자체가 차단됨. 8.8.8.8 임시 사용 또는 ISP 문의"

    ip = ips[0]
    print(f"    → IP: {ip}")

    # 2단계: IPv4/IPv6
    t0 = time.time()
    r4, r6 = step2_curl(host)
    print(f"[2] HTTPS: IPv4={r4} IPv6={r6} (소요 {time.time()-t0:.1f}s)")

    # 3단계: IP 핑
    t0 = time.time()
    ping_ok, ping_msg = step3_ping(ip)
    print(f"[3] IP 핑: {ping_msg} (소요 {time.time()-t0:.1f}s)")

    # 4~6단계: 환경 진단
    env_bad, env_msg = step4_env_proxy()
    sys_bad, sys_msg = step5_system_proxy()
    hosts_bad, hosts_msg = step6_hosts_spoof(host)
    print(f"[4] 환경 프록시: {env_msg}")
    print(f"[5] 시스템 프록시: {sys_msg}")
    print(f"[6] hosts 변조: {hosts_msg}")

    # === 종합 판정 ===
    # HTTPS는 timeout, IP 핑 100% loss, 프록시 정상, hosts 정상
    if (r4 == "000" or r4 == "124") and (r6 == "000" or r6 == "124") and not ping_ok and not env_bad and not sys_bad and not hosts_bad:
        return "방화벽 IP 차단", (
            "회사/학교망이 IP 대역 자체를 패킷 단위로 차단 중.\n"
            "    → 핫스팟(LTE/5G) 또는 회사 승인 VPN 사용 권장\n"
            "    → SOCKS5/VPS 터널은 회사 보안 정책 위반 가능성 높음"
        )
    if hosts_bad:
        return "DNS 스푸핑", "hosts 파일에 매핑 발견. 악성코드 의심 → /etc/hosts 점검 및 EDR 스캔"
    if env_bad or sys_bad:
        return "프록시 강제", f"환경/OS 프록시 활성. HTTPS_PROXY 환경변수 또는 시스템 설정으로 우회 가능"

    if r4 == "200" or r4.startswith("3"):
        return "정상 (토큰 점검 필요)", f"HTTPS {r4} 응답. 토큰/자격증명 별도 확인"
    if r4 == "000" and ping_ok:
        return "HTTPS 차단 (IP는 OK)", "IP는 라우팅되지만 HTTPS만 차단. SNI 필터링 의심"
    return "알 수 없음", f"r4={r4} r6={r6} ping={ping_ok}. 추가 점검 필요"


def main():
    if len(sys.argv) < 2:
        print("Usage: diagnose_api.py <host> [host2 ...]", file=sys.stderr)
        sys.exit(2)
    results = {}
    for host in sys.argv[1:]:
        verdict, action = diagnose(host)
        results[host] = {"verdict": verdict, "action": action}
        print(f"\n  ▶ 판정: {verdict}")
        print(f"  ▶ 처방: {action}")
    # JSON도 출력 (자동화 파이프라인용)
    print(f"\n{'='*60}")
    print("[JSON RESULT]")
    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
