---
name: daily-self-review
cron: 23:00 KST (매일)
first_run: "2026-04-07"
description: ICBM2 매일 자기 개선 리뷰 — 당일 세션 분석, 스킬 개선, 메모리 정리
version: 1.0.5
author: ICBM2
metadata:
  hermes:
    tags: [self-improvement, daily-review, cron, automation]
    last_updated: "2026-06-02"
---

# ICBM2 매일 자기 개선 리뷰

## 개요

매일 밤 당일 활동을 분석하여 자기 개선 포인트를 도출하고, 새로운 패턴을 스킬로 저장하며, 메모리를 최적화합니다.

## 실행 방법

크론 잡에서 실행 시 자동으로 아래 프로세스를 따릅니다.

### ⚠️ Pitfall: Python 버전 불일치

ICBM2 환경에서 시스템 기본 Python은 **3.8.8**이지만, 일부 스크립트는 Python 3.10+ 구문(`list | None` 타입 유니온 등)을 사용합니다.

**증상:** `TypeError: unsupported operand type(s) for |: 'type' and 'NoneType'`

**해결:** 스크립트 호출 시 명시적 Python 3.10 경로 사용:
```bash
/usr/local/bin/python3.10 ~/.hermes/scripts/<script>.py
```

**이슈 추적:** ISS-036 관련

## 수행 절차

### 1. 당일 세션 검색 (session_search)

- 오늘 날짜의 모든 세션을 검색
- 주요 활동 요약 (어떤 작업을 했는지)
- 도구 사용 빈도 파악
- 에러/실패 사례 수집
- **주인님 피드백 파싱**: 세션에서 주인님이 부정적 반응(수정 요청, 불만, "다시 해", "아니야" 등)을 보인 부분 식별

### 2. 새로운 패턴 감지

다음 조건을 만족하면 새 스킬 생성을 검토:
- 5번 이상의 툴 콜이 포함된 복잡한 작업
- 이전 세션에서 유사한 작업이 반복된 패턴
- 새로운 해결법을 발견한 경우 (디버깅, 워크어라운드)
- **반복되는 주인님 요청 패턴** → 프롬프트/메모리에 반영 권장

### 3. 스킬 건강도 점검

- 오늘 사용된 스킬 목록 확인
- 사용 중 문제가 있었던 스킬이 있으면 **즉시 patch 실행** (검토만 하지 말 것)
- 스킬 내용이 구식이 된 것이 있는지 검토
- **스킬 경로 유효성**: 스킬이 참조하는 파일/스크립트 경로가 실제로 존재하는지 확인

### 4. 메모리 정리

- 당일 새로 추가된 메모리 항목 검토
- 중복되거나 더 이상 유효하지 않은 메모리 **즉시 제거**
- 중요한 새 사실이 메모리에 누락되었는지 확인 → 누락 시 **즉시 추가**
- 메모리 용량이 90% 이상이면 우선순위로 정리

### 5. .learnings/ Self-Improvement 분석 ⭐

`.learnings/`에 기록된 학습/에러/피처 리퀘스트를 분석하여 자가 학습한다.

#### 5-1. Learnings 분석
```bash
python3 ~/.hermes/scripts/learnings_analyzer.py analyze
```

#### 5-2. 승격 후보 자동 승격
```bash
python3 ~/.hermes/scripts/learnings_analyzer.py promote
```

#### 5-3. 승격된 항목을 Hermes memory에 등록
promotion_log.jsonl의 항목을 읽어서:
- target="memory" → memory(action="add", target="memory", ...)
- target="user" → memory(action="add", target="user", ...)
- target="skill" → skill_manage(action="create", ...)
중복 확인 후 등록한다.

#### 5-4. 30일 이상 된 완료 항목 정리
```bash
python3 ~/.hermes/scripts/learnings_analyzer.py cleanup
```

### 6. 크론 잡 상태 확인

- 오늘 실행된 크론 잡들의 성공/실패 확인
- 실패한 잡이 있으면 **자가 치유 스크립트 실행** (dry-run 금지):
  ```
  python3 ~/.hermes/scripts/cron_self_healer.py
  ```
  ⚠️ `--dry-run` 금지 — dry-run은 진단만 하고 수정을 적용하지 않음. 반드시加标志运行.
- `memory/cron_quality.md` 확인하여 전체 크론 품질 점수 확인
- **⚠️ Self-healer 오탐 주의 (ISS-044, 2026-06-02)**: `cron_self_healer.py`의 APIError 패턴 `r"\b(?:api[\s._-]*(?:error|failed)|rate[\s._]*limit(?:\s*exceeded)?|http\s*(?:401|403|404|429|500|502|503)\s*(?::|\s+(?:unauthorized|forbidden|not\s*found|server\s*error|bad\s*gateway|service\s*unavailable|too\s*many\s*requests|internal\s*server\s*error))|authentication\s*failed|invalid\s*api\s*key)\b"`은 다음을 의도적으로 감지함:
  - `api error`, `api_failed`, `rate limit exceeded`, `HTTP 401 Unauthorized: ...`, `HTTP 500 Internal Server Error`, `authentication failed`, `invalid api key` 등 실제 에러
  - 단어 경계(`\b`)와 표준 HTTP 상태 텍스트 매칭으로 "Notion API 401 Unauthorized fallback" 같은 **doc reference 內 401 언급**은 더 이상 매칭하지 않음
  - 단, `"Notion API Rate Limit: ~3 req/sec"` 같은 **informational rate limit description**은 여전히 매칭됨 (의도된 동작 — rate limit 논의 자체는 신호로 가치가 있음)
  - **확인 방법**: `grep -i "api.*error\|✅\|❌\|complete\|success" <job_output>.md`
  - **실패 판단 기준**: 출력에 `✅`/`success`/`complete` 가 있으면 실제 성공. `❌`/`failed` 만으로 판단하지 말 것 — Self-healer가 `❌`를 찍어도 해당 줄이 정보성 텍스트일 수 있음
  - **오탐 대표 사례**:
    - Tistory 발행 출력의 `"✅ Markdown CJK 제거"` — 정상 동작을 설명하는 텍스트, 실패 아님
    - `"notion-401-troubleshooting.md"` — 파일 경로에 포함된 "401" → APIError 오탐
    - `"HTTP 429: usage limit exceeded"` — 실제 Rate Limit이긴 하나 transient한 경우的自癒 가능
- 실패 원인이 프롬프트 내 경로 오류인지, API 문제인지 분류
- **출력 파일 블로트 정리**: 출력 파일이 50개 이상인 크론 잡은 3일 이상된 파일 자동 삭제:
  ```bash
  # 예: Tistory 발행 출력 정리
  find ~/.hermes/cron/output/<job_id>/ -name "*.md" -mtime +3 -delete
  ```

### 7. 학습 갭 체크 (Learning Gap Tracker) ⭐

ICBM2가 대화 중 알지 못했던 것들을 추적하는 시스템.

```bash
# 미해결 학습 갭 목록 확인
python3 ~/.hermes/scripts/learning_gap_tracker.py list --status open

# 통계 확인
python3 ~/.hermes/scripts/learning_gap_tracker.py stats

# 일일 리뷰용 내보내기
python3 ~/.hermes/scripts/learning_gap_tracker.py export --format markdown
```

- encounter_count ≥ 2인 갭을 **우선 학습 대상**으로 표시
- 해결된 갭이 있으면 통계에 반영
- 30일 이상 된 해결 갭 정리: `python3 ~/.hermes/scripts/learning_gap_tracker.py cleanup --days 30`
- **세션 중 "모르겠습니다"/"확실하지 않습니다" 표현이 있었다면 해당 갭을 추가:**
  ```bash
  python3 ~/.hermes/scripts/learning_gap_tracker.py add --topic "주제" --context "맥락" --severity medium
  ```

### 8. 피드백 루프 분석

- `python3 ~/.hermes/scripts/feedback_collector.py stats` 실행
- 당일 수집된 피드백 분석 (correction/positive/preference)
- **당일 세션에서 주인님 교정/피드백을 발견한 경우 feedback_collector.py에 기록:**
  ```bash
  python3 ~/.hermes/scripts/feedback_collector.py add --category correction --content "내용" --resolved true --resolution "해결방법"
  ```
- **반복 패턴 감지**: `python3 ~/.hermes/scripts/feedback_collector.py insights` 실행
  - 동일 카테고리의 피드백이 3회 이상이면 MEMORY에 영구 규칙으로 저장
- 긍정적 피드백 → 해당 행동 강화 (스킬/설정에 반영)
- 부정적 피드백 → 시스템 수정 필요시 즉시 `skill_manage(action='patch')` 실행
- 30일 이상 된 피드백: `python3 ~/.hermes/scripts/feedback_collector.py archive` 실행

### 9. 개선 액션 아이템 생성

분석 결과를 바탕으로 **즉시 실행 가능한** 액션 아이템 생성:
- 🔴 즉시 수정 (해당 항목을 **바로 실행**하여 다음 리뷰까지 해결)
- 🟡 개선 권장 (구체적인 수정 방안 포함)
- 🟢 새로운 시도 (실행 계획과 예상 효과 포함)

**중요: 액션 아이템은 목록만 만들지 말고, 🔴 항목은 즉시 실행하여 해결 상태로 만들 것.**

## 출력 형식

```
==================================================
🔄 ICBM2 일일 자기 개선 리뷰 — YYYY-MM-DD
==================================================

━━━ 📊 오늘의 활동 요약 ━━━
- 세션 수: N
- 주요 작업: ...
- 도구 사용: terminal(12), search(5), ...

━━━ 🔍 새로운 패턴 ━━━
- [발견/없음] 설명

━━━ 🛠️ 스킬 점검 ━━━
- 사용된 스킬: ...
- 개선 필요: ...

━━━ 🧠 메모리 정리 ━━━
- 추가: N건
- 정리: N건
- 누락 의심: ...

━━━ 🎓 학습 갭 ━━━
- 미해결: N건 (우선순위 높은 것 N건)
- 오늘 해결: N건
- 반복 토픽: ...

━━━ ⚙️ 크론 잡 상태 ━━━
- 정상: ...
- 실패: ...

━━━ ✅ 개선 액션 ━━━
- 🔴 ...
- 🟡 ...
- 🟢 ...

━━━ 💡 내일의 목표 ━━━
- ...
```

## 저장 위치

- 리포트: `memory/reports/daily_YYYY-MM-DD.md`

## 관련

- `weekly-self-report` — 주간 종합 리포트 (이 일일 리뷰 데이터를 활용)

## References (세션별 디테일)

- [`references/iss-044-self-healer-fp-regex.md`](references/iss-044-self-healer-fp-regex.md) — Self-healer APIError 패턴 오탐 문제 및 regex fix 검증 테스트 케이스 (6→2 FP)
- [`references/iss-027-cron-output-bloat-cleanup.md`](references/iss-027-cron-output-bloat-cleanup.md) — Cron 출력 파일 누적 정리 (3일+ 자동 삭제)
