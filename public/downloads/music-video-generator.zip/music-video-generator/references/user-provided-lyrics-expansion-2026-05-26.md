#家主님 제공 원본 가사 → 3분 이상 확장 파이프라인 (2026-05-26)

## 문제
家主님으로부터 받은 원본 가사(1,200자)는 mmx music 생성 시 짧은 음악(30~60초)으로 결과. 3분 영상을 만드려면 2,000자+ 확장 필수.

## 해결:家主님 원본 가사 보존 확장 패턴

家主님 가사의 **섹션 구조**와 **본문 내용을 정확히 보존**하면서 Hook First 구조로 재배열 + 반복 추가.

###家主님 원본 가사 파싱 (2026-05-26)
```python
import re

#家主님이 제공한 괄호 태그 형식:
// (Intro: ...) (Verse 1: ...) (Chorus: ...) ...

# 섹션 추출
STRUCTURE_TAGS = ['Verse', 'Chorus', 'Bridge', 'Pre-Chorus', 'Intro', 'Outro']

def parse_original_lyrics(raw):
    """家主님 원본 가사의 섹션 본문을 정확히 보존"""
    sections = {}
    current_tag = None
    current_content = []
    
    for line in text.split('\n'):
        line = line.strip()
        if not line:
            continue
        tag_match = re.match(r'^\(([^:]+):', line)
        if tag_match:
            tag_marker = tag_match.group(1).strip()
            #家主님이 제공한 괄호 태그에서 섹션 감지
            for st in STRUCTURE_TAGS:
                if st.lower() in tag_marker.lower():
                    if current_tag and current_content:
                        sections[current_tag] = '\n'.join(current_content)
                    current_tag = st
                    # 괄호와 태그 마커 제거 후 가사 내용만 추출
                    content = re.sub(r'^\([^)]+\)\s*', '', line)
                    current_content = [content]
                    break
        elif current_tag:
            current_content.append(line)
    
    if current_tag and current_content:
        sections[current_tag] = '\n'.join(current_content)
    
    return sections

#家主님 가사 본문 변수에 정확히 저장
INTRO_TEXT = "자, 다들 주목! 여기 AI에게 자리 내어준 직장인들의 특별한 파티! ..."
VERSE1_TEXT = "아침에 출근했더니 내 자리에 돌아가는 낯선 냉각팬 소리 ..."
```

###家主님 원본 본문 직접 사용
```python
#家主님이 제공한 실제 가사 본문 변수로 정확히 저장
INTRO_TEXT = "자, 다들 주목! 여기 AI에게 자리 내어준 직장인들의 특별한 파티! 준비됐어? 오늘 한번 신나게 놀아보자!"
VERSE1_TEXT = "아침에 출근했더니 내 자리에 돌아가는 낯선 냉각팬 소리 팀장님은 헛기침하며 짐 쌀 종이 박스를 건네주네 남들보다 조금 일찍 시대를 앞서갔을 뿐! ..."

#家主님의 모든 Verse/Chorus/Bridge/etc 본문을 정확한 변수에 저장
# 자동 파싱으로 섹션을 reuse하면家主님의 세밀한 차이(각 버전별 가사)가 유실됨
```

### Hook First 구조 재배열
```python
lines = []
lines.append("[Chorus]")  # Hook First - 후렴 먼저
lines.append(CHORUS3_TEXT)  #家主님 Chorus 3 (통장 잔고 버전)을 후렴으로
lines.append(f"[Intro]\n{INTRO_TEXT}")
lines.append(f"[Verse 1]\n{VERSE1_TEXT}")
lines.append(f"[Pre-Chorus]\n{PRECHORUS_TEXT}")
lines.append(f"[Chorus]\n{CHORUS1_TEXT}")
# ...家主님 본문을 정확히 배치
```

###FFprobe 음악 길이 확인
```bash
ffprobe -v error -show_entries format=duration music.mp3
# → duration=250.096327 (4분 10초)

# 3분 목표(1800자+)에 도달하면 mmx music이 자동 3분+ 생성
#家主님 원본 1,200자 → 2,080자 확장 → 4분 10초 음악 확인
```

## 핵심 lesson
1. **家主님 가사 본문 보존**: 자동 파싱 대신家主님이 괄호 태그로 구분한 본문을 직접 변수에 저장
2. **Hook First**:家主님이 제공한 Chorus歌词를 가장 먼저 배치
3. **확장 목표**: 1800~2200자 (2,000자 근처면 3분+ 음악 생성 확인)
4. **음악 길이 ffprobe 확인**: mmx music 완료 후 `ffprobe -v error -show_entries format=duration music.mp3`

## 관련 파일
-家主님 제공 원본 가사: `~/.hermes/music_videos/direct_input/lyrics_expanded.txt` (2,080자)
- 생성된 음악: `~/.hermes/music_videos/direct_input/music.mp3` (4분 10초 확인)
