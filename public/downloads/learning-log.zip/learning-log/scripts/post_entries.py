#!/usr/bin/env python3
"""learning-log Notion DB writer.

Posts weekly learning entries to Notion DB (33c76f2e-9097-8184-b51e-fa09efcf6d4d).
Edit the `entries` list with this week's learnings, then run:

    python3 scripts/post_entries.py

The script pre-validates the Notion token via GET /v1/users/me before
posting, and gracefully reports each entry's success/failure with a final
summary line.
"""
import os
import json
import subprocess
import sys
from datetime import datetime, timezone, timedelta

TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
DB_ID = "33c76f2e-9097-8184-b51e-fa09efcf6d4d"
NOTION_API = "https://api.notion.com/v1"
NOTION_VERSION = "2022-06-28"
CATEGORIES = ["iOS/Swift", "AI/ML", "Automation", "Infra", "Other"]


def today_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")


def check_token(tk: str) -> bool:
    """Validate token via /v1/users/me. Returns True if valid."""
    env = dict(os.environ)
    env["NTK"] = tk
    r = subprocess.run(
        f"curl -s --max-time 10 {NOTION_API}/users/me "
        f'-H "Authorization: Bearer *** '
        f'-H "Notion-Version: {NOTION_VERSION}"',
        shell=True, capture_output=True, text=True, env=env
    )
    try:
        resp = json.loads(r.stdout)
        return resp.get("object") == "user"
    except Exception:
        return False


def post_entry(tk: str, entry: dict, today: str) -> tuple[bool, str]:
    if entry["Category"] not in CATEGORIES:
        return False, f"INVALID_CATEGORY ({entry['Category']})"
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": entry["Name"]}}]},
            "Date": {"date": {"start": today}},
            "Category": {"select": {"name": entry["Category"]}},
            "Summary": {"rich_text": [{"text": {"content": entry["Summary"]}}]},
            "URL": {"url": entry.get("URL")},
        },
    }
    with open("/tmp/notion_entry.json", "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    env = dict(os.environ)
    env["NTK"] = tk
    r = subprocess.run(
        f"curl -s -X POST --max-time 20 {NOTION_API}/pages "
        f'-H "Authorization: Bearer *** '
        f'-H "Notion-Version: {NOTION_VERSION}" '
        f'-H "Content-Type: application/json" '
        f"-d @/tmp/notion_entry.json",
        shell=True, capture_output=True, text=True, env=env
    )
    try:
        resp = json.loads(r.stdout)
    except Exception as e:
        return False, f"PARSE_ERROR ({r.stdout[:100]})"
    if resp.get("object") == "page":
        return True, resp.get("id", "")
    return False, resp.get("message", "unknown")[:120]


# Edit this list with the week's learning entries. Each entry is a dict with:
#   Name (str, required)    - Title, concise topic name
#   Category (str, required) - One of CATEGORIES
#   Summary (str, required) - 1-2 sentence core takeaway
#   URL (str, optional)     - Reference link
ENTRIES: list[dict] = []


def main() -> int:
    if not os.path.exists(TK_PATH):
        print("❌ NOTION_TOKEN_MISSING:", TK_PATH)
        return 1
    with open(TK_PATH) as f:
        tk = f.read().strip()

    if not check_token(tk):
        print("❌ NOTION_TOKEN_INVALID — reissue integration at notion.so/my-integrations")
        return 2

    today = today_kst()
    print(f"[{today}] Posting {len(ENTRIES)} entries to Notion DB...")

    success, failed = 0, 0
    for entry in ENTRIES:
        ok, detail = post_entry(tk, entry, today)
        marker = "✅" if ok else "❌"
        print(f"  {marker} [{entry['Category']}] {entry['Name']} → {detail}")
        if ok:
            success += 1
        else:
            failed += 1

    print(f"\n=== Summary ===\nSuccess: {success}/{len(ENTRIES)}\nFailed: {failed}\nDate: {today}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
