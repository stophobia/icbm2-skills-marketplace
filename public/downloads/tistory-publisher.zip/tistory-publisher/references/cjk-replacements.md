# CJK 정제 사전 (누적)

## 개요
`markdown_to_tistory_html.py` 변환 후 HTML에서 CJK 문자를 제거하는 데 사용되는 사전이다.
루프 잔여 문자는 매번 이 파일에 누적 등록되며, 70차 이상 누적되어 SKILL.md를 비대하게 만드는主要原因이다.

## 사용법
```python
import re, json, os

with open(os.path.join(os.path.dirname(__file__), 'cjk-replacements.json')) as f:
    replacements = json.load(f)

for old, new in replacements.items():
    html = html.replace(old, new)
```

## JSON 구조
```json
{
  "h Hiragana": {"い": "이", "と": "토", ...},
  "katakana": {"ー": "", "ン": "은", ...},
  "chinese_nation_company": {"美国": "미국", "英國": "영국", ...},
  "chinese_words": {"记录": "기록", "实时": "실시간", ...},
  "chinese_single": {"委": "위", "國": "국", ...},
  "korean_hanja_corruption": {"쾨": "쾌", "개": "개"}
}
```

## 70차 이상 누적 잔여 문자 (최종 목록)

### Chinese Simplified 단일자 (60차~70차)
`认`, `迟`, `谁`, `开`, `公`, `查`, `好`, `沿`, `途`, `歹`, `询`, `开`, `认`, `迟`, `谁`

### Chinese Traditional/한자 (60차~70차)
`構`, `众`, `很`, `造`, `革`, `槛`, `考`, `有`, `背`, `え`, `拥`, `威`, `コ`, `ド`, `マ`

### Hiragana (누적 누락)
`せ`, `わ`, `ね`, `の`, `ず`, `へ`

### Russian/Cyrillic (CJK regex 밖)
`с`, `и`, `т`, `у`, `а`, `ц`, `е`, `р`, `о`, `л`, `д`, `ь`, `н`, `я`, `п`, `ж`

### Korean Hanja (Unicode 범위 밖 — U+CDF0 등)
`쾨` → `쾌` (Korean Hanja Compatibility block → CJK로 변환됨)

## ⚠️ Korean word boundary corruption 주의사항

CJK 정제 시 multi-character Korean 치환은 Korean word boundary corruption을 유발할 수 있다.

**문제 발생 패턴:**
```python
# ❌ 이렇게 하지 말 것 — 공백 소실로 Korean 단어 합쳐짐
'毕': '졸업'  # "##졸업식에서" → "##졸업업식에서"

# ✅ 올바른 방식 — 빈 문자열로 제거하거나, 단일 character Korean만 사용
'毕': ''      # 제거만 수행
'者': '글'   # 단일 character Korean만 치환
```

**대응 절차:**
1. Markdown 변환 직후, HTML CJK cleaning **이전**에 Korean corruption check 실행
2. multi-character Korean 치환 후 공백 손실 여부 확인
3. 합쳐진 Korean 단어 발견 시 `korean_corruption_patterns`로 별도 복구

## 루프 잔여 히스토리 (참고용 — SKILL.md에 기록하면 비대해짐)

| 차수 | 날짜 | 발견 문자 | 비고 |
|------|------|----------|------|
| 69차 | 2026-05-22 | - | 종합 사전 정제 |
| 70차 | 2026-05-23 | 者,化,的,毕,变,业,记 | Korean word boundary corruption 동반 |