# 세션 마이닝 — session_search로 금주 학습 추출하기

`session_search`로 주간 자동화 세션을 식별해 학습 항목을 도출하는 실전 패턴.

## 1. 2단계 전략이 정답

scroll 모드(`session_id + around_message_id`)는 **메시지 ID를 정확히 알 때만** 작동.
추측 값은 전부 `not in session_id` 에러 반환.

```python
# ❌ 거의 실패
session_search(session_id="cron_xxx", around_message_id=30)  # ID 30은 추측일 뿐
session_search(session_id="cron_xxx", around_message_id=10)
```

**실용적 우회**:
- Step A: browse 모드 (`limit=15`) — 최근 세션 ID 목록 확보
- Step B: `query=` discover 모드 (`sort=newest`) — bookend_start/bookend_end에서 핵심 추출

## 2. query= 결과가 매우 길 때 — persisted-output 처리

`session_search(query="...", limit=5)` 결과는 매치 1개당 수십~수백 KB. 컨텍스트 보호를 위해 1500 chars로 truncate되고 `/var/folders/.../hermes-results/call_function_*.txt`에 풀 데이터 저장됨.

**발견 방법**:
- 출력 프리뷰에 "persisted-output" 표시
- full path가 같은 줄에 노출됨

**읽기**:
```bash
# read_file로 직접 열면 됨 (read_file은 500줄 기본, 더 필요하면 offset/limit)
read_file path="/var/folders/r2/.../call_function_xxx.txt"
```

**구조적 추출** (python3 -c로):
```bash
python3 -c "
import json
with open('/var/folders/r2/.../call_function_xxx.txt') as f:
    data = json.load(f)
for r in data.get('results', []):
    print(r.get('session_id'), '|', r.get('when'), '|', r.get('snippet','')[:200].replace(chr(10),' '))
"
```

이 패턴이 핵심 — snippet 200자 + ID만 추출하면 컨텍스트 폭발 없이 10개+ 세션을 한 번에 훑을 수 있음.

## 3. bookend에서 진짜 학습 추출

세션의 `match_message_id`만 보면 매치된 한 줄 snippet만 보임. 학습 항목을 만들려면:
- `bookend_start` — 크론 job의 입력 (스킬 호출 + 사용자 instruction)
- `bookend_end` — 그 세션의 최종 출력 리포트
- `messages` (anchor ±5) — 매치된 컨텍스트의 진짜 본문

## 4. 카테고리 힌트 매핑 (W23 검증된 학습-도출 패턴)

| 세션 prefix | skill | 학습 카테고리 | 비고 |
|-------------|-------|-------------|------|
| `cron_81f1c81f8664_...` (03:30 KST) | nightly-maintenance | Automation (self-healer 오탐) | false positive 패턴 분류 |
| `cron_d7bd4309bbf0_...` (15:30 KST) | llm-wiki | Infra (broken wikilink) | Wiki lint 결과 활용 |
| `cron_582ecc59aaee_...` (10:00 KST) | agent-benchmark-tracker | AI/ML (신모델 점수) | leaderboard 스크래핑 결과 |
| `cron_7995f1387b79_...` (16:00 KST) | weekly-tech-digest | Automation (Tistory 발행) | sigco.tistory.com/580 |
| `cron_b1bca63a117a_...` (19:00/20:00 KST) | tistory-publisher | Automation (대량 발행) | 일일 12건 패턴 |
| `cron_5d0f14aef84c_...` (22:00 KST) | daily-self-review | Automation (메타 분석) | 학습 후보지만 cron self-healer 오탐 빈번 |

## 5. 한 사이클 실전 예시 (W23, 2026-06-07)

```
1. session_search(limit=15)  → 10개 세션 ID 확보
2. session_search(query="llm-wiki Tistory weekly", sort=newest)  → 8개 세션 매치
3. python3 -c "import json; ..."  → session_id/when/snippet 테이블 추출
4. 위에서 cron_d7bd4309bbf0_20260607_153020 식별 → bookend에서 W23 리포트 추출
5. cron_582ecc59aaee_20260607_100033 식별 → bookend에서 Benchmark 결과 추출
6. cron_81f1c81f8664_20260607_033052 식별 → ISS-059~063 false positive 해소 추출
7. 6개 학습 항목 Notion POST → 6/6 성공
```

## 6. 발견된 함정 정리

- **persisted-output 경로는 매번 다름** — `mtime`이나 prefix로 식별 불가. 출력 프리뷰의 `Full output saved to:` 줄에서 경로 그대로 복사.
- **python3 -c "..." 안의 f-string + bash here-doc**은 syntax error 잘 남 — `read_file`이나 `write_file`로 별도 파일 만들고 `python3 /tmp/...` 호출이 안전.
- **Unicode(한글) entry name**이 bash heredoc + f-string 조합에서 깨질 수 있음 — `scripts/post_entries.py`처럼 별도 파일 + `ensure_ascii=False`가 안전.
