# YouTube Upload — 스크립트 실행 문제 해결 (2026-05-23)

## 문제: google-api-python-client 설치 실패

### 증상
```bash
pip install google-api-python-client
# → InvalidVersion: '4.0.0-unsupported' (pyodbc 충돌)
```

### 원인
사용자 conda 환경의 `pyodbc` 패키지가坏了 version 문자열을 가지고 있어 pip의 의존성 파싱이 실패함.

### 해결: 독립 venv 생성
```bash
python3 -m venv /tmp/yt_upload_venv
/tmp/yt_upload_venv/bin/pip install --upgrade pip
/tmp/yt_upload_venv/bin/pip install google-api-python-client google-auth-oauthlib
```

### 실행
```bash
/tmp/yt_upload_venv/bin/python3 ~/.hermes/scripts/yt_upload.py \
  /path/to/video.mp4 \
  --title "제목" \
  --description "설명" \
  --tags "태그1,태그2" \
  --privacy public
```

## yt_upload.py 인자 순서
**positional** arg: `file_path` (첫 번째)
flags: `--title`, `--description`, `--tags`, `--category`, `--privacy`, `--shorts`