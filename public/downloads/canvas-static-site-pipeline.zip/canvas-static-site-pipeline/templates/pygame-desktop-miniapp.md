# pygame 데스크탑 미니앱 보일러플레이트 (2026-06-23 kiwi 패턴)

pygame + LLM + TTS 결합 데스크탑 미니앱 (키위/스택챈/마스코트 동반자) 시작할 때 이 보일러플레이트를 `cp` + 수정해서 사용. 3대 크래시 함정 (NSWindow/main thread, mixer race, SDLTimer race) 모두 해결된 상태.

## 디렉토리 구조

```
{my-ai-companion}/
├── llm.py          # LLM API 호출 + 감정 태그 파싱 (워크플로우 자유)
├── tts.py          # pyttsx3 + 한국어 음성 + say 폴백
├── face.py         # pygame 얼굴 윈도우 (메인 스레드 전용)
├── kiwi.py         # 메인 루프 + LLM/TTS 워커 스레드
├── run.sh          # conda 환경 + 키 로드 + 실행 래퍼
├── README.md       # 사용 가이드
└── preview/        # PNG 미리보기 디렉토리
```

## 1. `llm.py` — LLM 호출 + 감정 태그 파싱

```python
"""
{my-companion} - LLM Module
LLM API 호출 + 감정 태그 파싱.
"""
import os
import re
import json
import urllib.request
import urllib.error
from typing import Optional, List, Dict

# 감정 태그 정규식 — LLM 응답 끝에 [emotion:xxx] 형태
EMOTION_RE = re.compile(r"\[emotion:\s*(happy|sad|thinking|surprised|neutral)\s*\]", re.IGNORECASE)
VALID_EMOTIONS = {"happy", "sad", "thinking", "surprised", "neutral"}

SYSTEM_PROMPT = """너의 이름은 '{캐릭터이름}'이야.

[성격]
- 다정하고 명랑하지만, 사용자의 감정에 공감할 줄 알아
- 한국어로 대화 (존댓말 기본)
- 답변은 1~3문장으로 짧고 자연스럽게
- 가끔 '{시그니처}' 말투

[감정 표현 — 매우 중요]
**모든 답변의 마지막 줄에 반드시 다음 중 하나의 감정 태그를 1개만 붙여라** (대괄호):
[emotion:happy] [emotion:sad] [emotion:thinking] [emotion:surprised] [emotion:neutral]

규칙:
- 이전 대화와 무관하게 매번 새 응답마다 1개 태그를 반드시 붙인다
- 사용자의 감정이 강하면 그에 맞춰 태그를 선택한다
- 절대 빼먹지 마
"""

# API 설정 (Hermes 환경: ~/.hermes/secrets/{provider}.env에서 로드)
BASE_URL = os.environ.get("{PROVIDER}_API_HOST", "https://api.example.com") + "/anthropic/v1/messages"
MODEL = os.environ.get("KIWI_MODEL", "{model-name}")


def call_llm(user_text: str, conversation: Optional[List[Dict]] = None) -> Dict:
    """LLM API 호출 + 텍스트/감정 태그 분리."""
    api_key = os.environ.get("{PROVIDER}_API_KEY")
    if not api_key:
        raise RuntimeError(
            "{PROVIDER}_API_KEY 환경변수 없음. "
            "실행 전: source ~/.hermes/secrets/{provider}.env"
        )

    if conversation is None:
        conversation = []
    messages = list(conversation) + [{"role": "user", "content": user_text}]

    payload = {
        "model": MODEL,
        "max_tokens": 512,
        "system": SYSTEM_PROMPT,
        "messages": messages,
    }

    req = urllib.request.Request(
        BASE_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"LLM API HTTP {e.code}: {body[:300]}")

    raw_text = ""
    for block in data.get("content", []):
        if block.get("type") == "text":
            raw_text += block.get("text", "")

    emotion = "neutral"
    match = EMOTION_RE.search(raw_text)
    if match:
        emotion = match.group(1).lower()
        if emotion not in VALID_EMOTIONS:
            emotion = "neutral"
    text = EMOTION_RE.sub("", raw_text).strip()

    return {"text": text, "emotion": emotion, "raw": raw_text}


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("사용법: python3 llm.py '안녕'")
        sys.exit(1)
    r = call_llm(" ".join(sys.argv[1:]))
    print(f"[키위] {r['text']}  [{r['emotion']}]")
```

## 2. `tts.py` — pyttsx3 + 한국어 음성

```python
"""
{my-companion} - TTS Module
pyttsx3 wrapper with Korean voice preference + say fallback.
"""
import os
import shutil
import subprocess
import threading
from typing import Optional

try:
    import pyttsx3
    PYTTSX3_AVAILABLE = True
except ImportError:
    PYTTSX3_AVAILABLE = False

# macOS 한국어 음성 우선순위: Yuna (compact, 자연스러움) > Kyung > Eloquence ko-KR
_KOREAN_PREFERENCE_KEYS = ("yuna", "kyung", "ko-kr.yuna", "ko_kr.yuna")


def _find_korean_voice(engine):
    """우선순위대로 한국어 음성 찾기. 단순 substring은 Eddy 등 매칭 위험."""
    voices = engine.getProperty("voices")
    if not voices:
        return None
    for keyword in _KOREAN_PREFERENCE_KEYS:
        for v in voices:
            name = (getattr(v, "name", "") or "").lower()
            vid = (getattr(v, "id", "") or "").lower()
            if keyword == "yuna":
                if name == "yuna" or vid.endswith(".yuna") or "ko-kr.yuna" in vid:
                    return v
            elif keyword in name or keyword in vid:
                return v
    return None


class CompanionSpeaker:
    """TTS wrapper. pyttsx3 우선, 실패 시 macOS `say` 폴백."""

    def __init__(self, rate: int = 180, volume: float = 1.0):
        self.rate = rate
        self.volume = volume
        self.engine = None
        self.voice_id = None
        self.backend = "none"
        self._lock = threading.Lock()  # pyttsx3는 thread-unsafe

        if PYTTSX3_AVAILABLE:
            try:
                self.engine = pyttsx3.init()
                self.engine.setProperty("rate", rate)
                self.engine.setProperty("volume", volume)
                voice = _find_korean_voice(self.engine)
                if voice:
                    self.voice_id = voice.id
                    self.engine.setProperty("voice", voice.id)
                    self.backend = "pyttsx3+yuna"
            except Exception as e:
                print(f"[tts] pyttsx3 초기화 실패: {e}")
                self.engine = None

    def say(self, text: str, blocking: bool = False):
        if not text:
            return
        if self.engine is None:
            self._say_fallback(text, blocking)
            return
        with self._lock:
            try:
                self.engine.say(text)
                if blocking:
                    self.engine.runAndWait()
                else:
                    threading.Thread(target=self._run_and_wait_safe, daemon=True).start()
            except Exception as e:
                print(f"[tts] 발화 실패, 폴백: {e}")
                self._say_fallback(text, blocking)

    def _run_and_wait_safe(self):
        with self._lock:
            try:
                self.engine.runAndWait()
            except Exception:
                pass

    def _say_fallback(self, text: str, blocking: bool):
        """macOS `say` 명령어 폴백."""
        say_bin = shutil.which("say")
        if not say_bin:
            print(f"[{text}]")
            return
        for voice in ["Yuna", "Kyung", ""]:
            cmd = [say_bin]
            if voice:
                cmd += ["-v", voice]
            cmd.append(text)
            try:
                if blocking:
                    subprocess.run(cmd, check=True, timeout=60)
                else:
                    subprocess.Popen(cmd)
                return
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                continue
        print(f"[{text}]")

    def stop(self):
        with self._lock:
            if self.engine:
                try:
                    self.engine.stop()
                except Exception:
                    pass

    def describe(self) -> str:
        return f"backend={self.backend}, voice_id={self.voice_id or 'default'}, rate={self.rate}"
```

## 3. `face.py` — pygame 얼굴 윈도우 (메인 스레드 전용)

```python
"""
{my-companion} - Face Module
Pygame 얼굴 윈도우. macOS NSWindow 제약 때문에 메인 스레드에서만 호출.

크래시 3대 함정 회피:
1. pygame.init() 금지 — mixer/audio 자동 init되어 pyttsx3와 race
2. pygame.time.Clock() 금지 — SDLTimer 스레드가 메인 스레드와 race
3. pygame.display.set_mode()는 메인 스레드에서만 (별도 스레드 금지)

대신:
- pygame.display.init() + pygame.font.init()만 명시 호출
- time.sleep()으로 메인 루프 throttle
"""
import math
import os
import random
import threading
import time
from typing import Optional

import pygame


# 감정별 외형 정의 (Stackchan 스타일: 흰 박스 + 검은 디스플레이 + 흰 픽셀)
EMOTION_PALETTE = {
    "happy":     {"bg": (235, 240, 245), "body": (252, 252, 252), "body_shadow": (210, 215, 220),
                  "display": (10, 10, 15), "display_tint": (30, 25, 20),
                  "pixel": (255, 255, 255), "label_bg": (255, 220, 100)},
    "sad":       {"bg": (220, 230, 240), "body": (245, 248, 252), "body_shadow": (200, 210, 220),
                  "display": (15, 18, 28), "display_tint": (35, 45, 65),
                  "pixel": (220, 230, 240), "label_bg": (140, 170, 210)},
    "thinking":  {"bg": (230, 228, 240), "body": (248, 245, 252), "body_shadow": (205, 200, 215),
                  "display": (12, 12, 18), "display_tint": (45, 35, 55),
                  "pixel": (240, 235, 245), "label_bg": (200, 180, 220)},
    "surprised": {"bg": (245, 235, 230), "body": (252, 250, 248), "body_shadow": (215, 205, 200),
                  "display": (15, 12, 10), "display_tint": (50, 30, 25),
                  "pixel": (255, 245, 235), "label_bg": (255, 200, 180)},
    "neutral":   {"bg": (240, 242, 245), "body": (250, 250, 252), "body_shadow": (210, 212, 218),
                  "display": (12, 12, 15), "display_tint": (25, 25, 30),
                  "pixel": (245, 245, 250), "label_bg": (210, 215, 220)},
}


class CompanionFace:
    """얼굴 윈도우. 메인 스레드 init_pygame → tick() 루프."""

    WINDOW_SIZE = 480
    BLINK_INTERVAL = (3.0, 5.5)

    def __init__(self):
        self.emotion = "neutral"
        self.speaking = False
        self.mouth_open = 0.0
        self.target_mouth = 0.0
        self._last_blink = time.time()
        self._next_blink = self._random_blink_delay()
        self._is_blinking = False
        self._blink_start = 0.0
        self._blink_duration = 0.15
        self._window = None
        self._ready = False
        self._quit_requested = False
        self._initialized = False

    @staticmethod
    def _random_blink_delay() -> float:
        return random.uniform(*CompanionFace.BLINK_INTERVAL)

    def set_emotion(self, emotion: str):
        if emotion in EMOTION_PALETTE:
            self.emotion = emotion

    def set_speaking(self, speaking: bool, amplitude: float = 1.0):
        self.speaking = speaking
        self.target_mouth = max(0.0, min(1.0, amplitude))

    def request_quit(self):
        self._quit_requested = True

    def is_ready(self) -> bool:
        return self._ready

    def is_quit_requested(self) -> bool:
        return self._quit_requested

    def init_pygame(self) -> bool:
        """pygame 초기화 + 윈도우 생성. 메인 스레드에서만."""
        if self._initialized:
            return True
        try:
            import os
            os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
            # mixer/audio/time 명시 init 안 함 (크래시 방지)
            pygame.display.init()
            pygame.font.init()

            pygame.display.set_caption("🔔 {캐릭터이름} Companion — ESC to quit")
            self._window = pygame.display.set_mode((self.WINDOW_SIZE, self.WINDOW_SIZE))
            self._initialized = True
            self._ready = True
            print(f"[face] pygame 윈도우 생성: {self.WINDOW_SIZE}x{self.WINDOW_SIZE}, driver={pygame.display.get_driver()}")
            return True
        except Exception as e:
            print(f"[face] pygame 초기화 실패: {e}")
            return False

    def tick(self) -> bool:
        """한 프레임 처리. 메인 스레드에서 호출."""
        if not self._initialized or self._window is None:
            return False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self._quit_requested = True
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                self._quit_requested = True
        if self._quit_requested:
            return False

        self._update(time.time())
        self._draw()
        pygame.display.flip()
        return True

    def shutdown(self):
        if self._initialized:
            try:
                pygame.quit()
            except Exception:
                pass
            self._initialized = False

    def _update(self, now: float):
        self.mouth_open += (self.target_mouth - self.mouth_open) * 0.18
        if self._is_blinking:
            if now - self._blink_start > self._blink_duration:
                self._is_blinking = False
                self._next_blink = now + self._random_blink_delay()
        else:
            if now >= self._next_blink:
                self._is_blinking = True
                self._blink_start = now

    def _draw(self):
        palette = EMOTION_PALETTE[self.emotion]
        self._window.fill(palette["bg"])

        # 본체 (둥근 모서리 흰 박스) + 그림자
        body_rect = pygame.Rect(60, 60, self.WINDOW_SIZE - 120, self.WINDOW_SIZE - 120)
        shadow = body_rect.copy(); shadow.y += 8
        pygame.draw.rect(self._window, palette["body_shadow"], shadow, border_radius=20)
        pygame.draw.rect(self._window, palette["body"], body_rect, border_radius=20)
        pygame.draw.rect(self._window, palette["body_shadow"], body_rect, 2, border_radius=20)

        # 디스플레이 (검은 사각형)
        display_rect = pygame.Rect(110, 110, self.WINDOW_SIZE - 220, self.WINDOW_SIZE - 220)
        pygame.draw.rect(self._window, palette["display"], display_rect, border_radius=12)
        inner_rect = display_rect.inflate(-4, -4)
        pygame.draw.rect(self._window, palette["display_tint"], inner_rect, border_radius=8)

        # 흰 픽셀 얼굴
        self._draw_face(inner_rect, palette["pixel"])
        # 감정 라벨
        self._draw_emotion_label(body_rect, palette)

    def _draw_face(self, display_rect, color):
        cx, cy = display_rect.centerx, display_rect.centery
        eye_y = display_rect.y + display_rect.height // 3
        mouth_y = display_rect.y + (display_rect.height * 2) // 3
        self._draw_eyes(cx, eye_y, color)
        self._draw_mouth(cx, mouth_y, color)

    def _draw_eyes(self, cx, cy, color):
        eye_offset = 30
        if self._is_blinking:
            for side in (-1, 1):
                ex = cx + side * eye_offset
                pygame.draw.line(self._window, color, (ex - 15, cy), (ex + 15, cy), 5)
            return

        if self.emotion == "happy":
            # ^ ^ (픽셀 점들)
            for side in (-1, 1):
                ex = cx + side * eye_offset
                points = []
                for i in range(11):
                    t = i / 10.0
                    x = ex - 15 + int(30 * t)
                    y_offset = int(-10 * math.sin(math.pi * t))
                    points.append((x, cy + y_offset))
                for x, y in points:
                    pygame.draw.circle(self._window, color, (x, y), 2)

        elif self.emotion == "sad":
            # ; ;
            pygame.draw.line(self._window, color, (cx - eye_offset - 14, cy), (cx - eye_offset + 14, cy), 5)
            pygame.draw.line(self._window, color, (cx + eye_offset - 14, cy), (cx + eye_offset + 14, cy), 5)
            for i, dy in enumerate([12, 22, 30]):
                r = 3 if i < 2 else 2
                pygame.draw.circle(self._window, color, (cx - eye_offset - 12, cy + dy), r)

        elif self.emotion == "thinking":
            pygame.draw.line(self._window, color, (cx - eye_offset - 12, cy), (cx - eye_offset + 12, cy), 5)
            pygame.draw.circle(self._window, color, (cx + eye_offset, cy), 3)

        elif self.emotion == "surprised":
            pygame.draw.circle(self._window, color, (cx - eye_offset, cy), 14, 4)
            pygame.draw.circle(self._window, color, (cx + eye_offset, cy), 14, 4)

        else:  # neutral
            pygame.draw.circle(self._window, color, (cx - eye_offset, cy), 6)
            pygame.draw.circle(self._window, color, (cx + eye_offset, cy), 6)

    def _draw_mouth(self, cx, cy, color):
        m = self.mouth_open
        if self.emotion == "happy":
            if self.speaking and m > 0.3:
                pygame.draw.ellipse(self._window, color,
                                    (cx - 40, cy - int(m * 14) - 2, 80, 12 + int(m * 22)), 4)
            else:
                # 픽셀 점 (위로 볼록 ∪)
                points = []
                for i in range(21):
                    t = i / 20.0
                    x = cx - 55 + int(110 * t)
                    y_offset = int(-25 * math.sin(math.pi * t))
                    points.append((x, cy + y_offset))
                for x, y in points:
                    pygame.draw.circle(self._window, color, (x, y), 3)
                pygame.draw.circle(self._window, color, points[10], 4)

        elif self.emotion == "sad":
            # 픽셀 점 (아래로 볼록 ∪)
            points = []
            for i in range(21):
                t = i / 20.0
                x = cx - 30 + int(60 * t)
                y_offset = int(15 * math.sin(math.pi * t))
                points.append((x, cy + y_offset))
            for x, y in points:
                pygame.draw.circle(self._window, color, (x, y), 3)

        elif self.emotion == "thinking":
            pygame.draw.line(self._window, color, (cx - 14, cy), (cx + 14, cy), 4)

        elif self.emotion == "surprised":
            radius = 10 + int(m * 16)
            pygame.draw.circle(self._window, color, (cx, cy), radius, 4)

        else:  # neutral
            for i in range(11):
                t = i / 10.0
                x = cx - 20 + int(40 * t)
                y_offset = int(-6 * math.sin(math.pi * t))
                pygame.draw.circle(self._window, color, (x, cy + y_offset), 2)

    def _draw_emotion_label(self, body_rect, palette):
        # macOS 폰트 후보 6개 순차 시도
        font = None
        for font_name in ["Apple SD Gothic Neo", "AppleGothic", "Helvetica"]:
            try:
                f = pygame.font.SysFont(font_name, 20, bold=True)
                test = f.render("HI", True, (0, 0, 0))
                if test.get_width() > 10:
                    font = f
                    break
            except Exception:
                continue
        if font is None:
            font = pygame.font.Font(None, 22)

        labels = {
            "happy": "HAPPY", "sad": "SAD", "thinking": "THINKING",
            "surprised": "SURPRISED", "neutral": "NEUTRAL",
        }
        text = font.render(labels.get(self.emotion, self.emotion), True, (60, 60, 60))
        text_rect = text.get_rect()
        label_w = text_rect.width + 40
        label_h = text_rect.height + 16
        label_x = body_rect.centerx - label_w // 2
        label_y = body_rect.bottom + 12

        pygame.draw.rect(self._window, palette["label_bg"],
                         (label_x, label_y, label_w, label_h), border_radius=12)
        pygame.draw.rect(self._window, palette["body_shadow"],
                         (label_x, label_y, label_w, label_h), 1, border_radius=12)
        self._window.blit(
            text,
            (label_x + (label_w - text_rect.width) // 2,
             label_y + (label_h - text_rect.height) // 2),
        )
```

## 4. `kiwi.py` — 메인 루프 + LLM/TTS 워커

```python
#!/usr/bin/env python3
"""
{my-companion} - 메인 실행 스크립트

메인 스레드: pygame 윈도우 + 키보드 입력 + 렌더링
워커 스레드: LLM 호출 + TTS 발화
"""
import argparse
import os
import queue
import sys
import threading
import time
from typing import List, Dict, Optional

import face
import llm
from tts import CompanionSpeaker


event_queue: "queue.Queue[Dict]" = queue.Queue()


def llm_worker(user_text: str, conversation: List[Dict], max_history: int):
    """워커 스레드: LLM 호출 + TTS 발화. 결과를 큐로 메인 스레드 통지."""
    try:
        event_queue.put({"type": "thinking_start"})
        result = llm.call_llm(user_text, conversation=conversation[-max_history:])
        text = result["text"]
        emotion = result["emotion"]

        event_queue.put({"type": "emotion", "emotion": emotion, "text": text})

        event_queue.put({"type": "speaking_start"})
        speaker.say(text, blocking=False)
        event_queue.put({"type": "speaking_end", "text": text, "emotion": emotion})

    except Exception as e:
        event_queue.put({"type": "error", "message": str(e)})


def main():
    parser = argparse.ArgumentParser(description="{my-companion}")
    parser.add_argument("--no-tts", action="store_true", help="음성 출력 끄기")
    parser.add_argument("--max-history", type=int, default=20)
    args = parser.parse_args()

    if not os.environ.get("{PROVIDER}_API_KEY"):
        print("[오류] {PROVIDER}_API_KEY 환경변수 없음.")
        print("실행 전: source ~/.hermes/secrets/{provider}.env")
        sys.exit(1)

    face_obj = face.CompanionFace()
    global speaker
    speaker = CompanionSpeaker()

    if not face_obj.init_pygame():
        print("[치명] pygame 초기화 실패. 종료합니다.")
        sys.exit(1)

    import select
    stdin_fd = sys.stdin.fileno()

    def stdin_has_data():
        return select.select([stdin_fd], [], [], 0.0)[0]

    def read_stdin_line():
        if not stdin_has_data():
            return None
        line = sys.stdin.readline()
        return line.rstrip("\n") if line else ""

    conversation: List[Dict] = []
    is_thinking = False

    print()
    print("=" * 50)
    print(f"🥝 {my-companion} 데스크탑 미니앱")
    print("=" * 50)
    print(f"  - 얼굴: pygame ({face_obj.WINDOW_SIZE}x{face_obj.WINDOW_SIZE})")
    print(f"  - LLM:  {llm.MODEL}")
    print(f"  - TTS:  {speaker.describe()}")
    print(f"  - 종료: ESC 또는 윈도우 X")
    print("=" * 50)
    print()

    greeting = "안녕~! 나는 {캐릭터이름}이야. 오늘 기분 어때?"
    face_obj.set_emotion("happy")
    print(f"[{캐릭터이름}] {greeting}")
    if not args.no_tts:
        speaker.say(greeting, blocking=False)
    conversation.append({"role": "assistant", "content": greeting})

    try:
        while not face_obj.is_quit_requested():
            try:
                while True:
                    ev = event_queue.get_nowait()
                    if ev["type"] == "thinking_start":
                        is_thinking = True
                        face_obj.set_emotion("thinking")
                        face_obj.set_speaking(False)
                    elif ev["type"] == "emotion":
                        face_obj.set_emotion(ev["emotion"])
                    elif ev["type"] == "speaking_start":
                        face_obj.set_speaking(True, amplitude=0.7)
                    elif ev["type"] == "speaking_end":
                        face_obj.set_speaking(False)
                        conversation.append({"role": "assistant", "content": ev["text"]})
                    elif ev["type"] == "error":
                        is_thinking = False
                        face_obj.set_emotion("sad")
                        print(f"\n[오류] {ev['message']}")
            except queue.Empty:
                pass

            line = read_stdin_line()
            if line is not None and line.strip() and not is_thinking:
                user_text = line.strip()
                conversation.append({"role": "user", "content": user_text})
                if len(conversation) > args.max_history * 2:
                    conversation = conversation[-args.max_history * 2:]

                t = threading.Thread(
                    target=llm_worker,
                    args=(user_text, conversation, args.max_history),
                    daemon=True,
                )
                t.start()
                is_thinking = True
                face_obj.set_emotion("thinking")
                face_obj.set_speaking(False)

            if not face_obj.tick():
                break
            time.sleep(0.005)

    except KeyboardInterrupt:
        pass
    finally:
        face_obj.set_emotion("neutral")
        if not args.no_tts:
            speaker.say("잘 가~!", blocking=False)
        time.sleep(0.8)
        face_obj.shutdown()
        speaker.stop()


if __name__ == "__main__":
    main()
```

## 5. `run.sh` — conda 환경 + 키 로드 래퍼

```bash
#!/bin/bash
# {my-companion} 실행 스크립트
# conda 환경 자동 활성화 + API 키 로드 + 실행

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

CONDA_ENV_PYTHON="/Users/{user}/opt/anaconda3/envs/{env_name}/bin/python"
CONDA_BASE="/Users/{user}/opt/anaconda3"

if [ ! -x "$CONDA_ENV_PYTHON" ]; then
    echo "[오류] conda 환경 없음: $CONDA_ENV_PYTHON"
    echo "생성: $CONDA_BASE/bin/conda create -y -n {env_name} python=3.11 pip"
    echo "     $CONDA_BASE/envs/{env_name}/bin/pip install pygame pyttsx3 requests"
    exit 1
fi

# Hermes secret에서 API 키 로드
SECRETS_FILE="$HOMEnset -a
# shellcheck disable=SC1090
source "$SECRETS_FILE"
set +a
else
    echo "[경고] $SECRETS_FILE 없음. API 키 없이 실행됩니다."
fi

echo "🥝 {my-companion} (Python $($CONDA_ENV_PYTHON -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')) 실행"
exec "$CONDA_ENV_PYTHON" "$SCRIPT_DIR/kiwi.py" "$@"
```

## 6. `README.md` — 사용 가이드

```markdown
# 🥝 {my-companion}

{my-companion} 데스크탑 동반자 시뮬레이터.

## 설치

```bash
# conda 환경
conda create -y -n {env_name} python=3.11 pip
conda activate {env_name}
pip install pygame pyttsx3 requests

# API 키 로드 (Hermes 환경)
source ~/.hermes/secrets/{provider}.env
```

## 실행

```bash
bash run.sh
```

옵션:
- `--no-tts`: 음성 없이 텍스트만
- 종료: ESC 또는 윈도우 X

## 단독 테스트

```bash
# LLM 모듈
python3 llm.py "안녕!"

# TTS 모듈
python3 tts.py "안녕하세요"

# 얼굴 모듈 (감정 순환 데모)
python3 face.py
```
```

## 사용 체크리스트

이 보일러플레이트로 새 프로젝트 시작 시:

1. **위 4개 파일을 프로젝트 디렉토리에 복사** (`llm.py`, `tts.py`, `face.py`, `kiwi.py`)
2. **플레이스홀더 교체**:
   - `{캐릭터이름}` → 예: "키위", "마스", "또치"
   - `{PROVIDER}_API_KEY` → 예: "MINIMAX_API_KEY"
   - `{PROVIDER}_API_HOST` → 예: "https://api.minimax.io"
   - `~/.hermes/secrets/{provider}.env` → 실제 provider
   - `{my-companion}` → 프로젝트명
   - `{user}` → 실제 macOS 사용자명
   - `{env_name}` → conda 환경명
3. **`llm.py`의 SYSTEM_PROMPT** 캐릭터 성격에 맞게 수정
4. **헤드리스 PNG 미리보기**로 얼굴 검증:
   ```bash
   SDL_VIDEODRIVER=dummy python3 -c "
   import sys; sys.path.insert(0, '.')
   import face, pygame
   f = face.CompanionFace()
   f.init_pygame()
   for em in ['happy','sad','thinking','surprised','neutral']:
       f.set_emotion(em); f.set_speaking(False); f._update(0); f._draw()
       pygame.image.save(f._window, f'preview/kiwi_{em}.png')
   "
   open preview/
   ```
5. **`bash run.sh`로 실제 GUI 실행** 후 동작 확인
6. **macOS 크래시 발생 시** `references/pygame-desktop-simulator.md` 참조

## 한계

- pyttsx3 + macOS는 한국어 자연스러움에서 `say -v Yuna`보다 떨어짐. 더 자연스러운 한국어 TTS가 필요하면 `say` 직접 호출로 폴백
- PNG 미리보기는 `pygame.draw.arc` 결과를 vision이 잘못 해석할 수 있음 → 이 보일러플레이트는 **픽셀 점 방식** 사용 (arc 안 씀)
- 표정 5종(happy/sad/thinking/surprised/neutral)만 정의 — 더 추가하려면 `EMOTION_PALETTE` + `_draw_eyes/_draw_mouth` 분기 추가
