# 0회차 CJK 정제 — 한국어 전용 작성 패턴 (Best Practice)

## 핵심 원칙

**가장 깔끔한 발행은 Markdown 작성 단계에서 한국어 전용 텍스트를 생성하는 것이다.**

CJK cleaning 루프, Cyrillic 정제, Korean Hanja corruption 체크가 모두 불필요해진다.

---

## 2026-06-03 실전 검증 (geo-seo-claude 블로그 글)

| 단계 | 결과 |
|------|------|
| Markdown 1차 CJK 검사 | **0개** |
| HTML 변환 후 CJK cleaning 루프 | **0회차 통과** (별도 정제 불필요) |
| Cyrillic 검사 | 0개 (한국어 only 작성이 자동 차단) |
| Korean Hanja corruption | 없음 |
| Markdown→HTML 변환 후 | 즉시 발행 가능 |

**결과:** 발행 시간 약 50% 단축, 품질 게이트 Grade S (87점) 통과.

---

## 작성 규칙

### ✅ DO

1. **검색 결과/기사 원문을 복사할 때** Korean-only로 번역한 후 붙여넣기
2. **한자음은 한국어만 사용:**
   - `美國` → `미국`
   - `株式會社` → `주식회사`
   - `責任者` → `책임자`
3. **영어 단어는 자연스러운 한국어 문장으로 결합:**
   - `GEO는 AI 검색 엔진에 최적화하는 작업이다` (X)
   - `GEO는 AI 검색 엔진에 콘텐츠가 인용되도록 최적화하는 작업이다` (O)
4. **Markdown 작성 후 1차 CJK 검사 실행:**
   ```python
   import re
   cjk = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', md))
   if cjk:
       print(f"⚠️ CJK 발견: {cjk}")
   else:
       print("✅ CJK 0개 — 변환 진행")
   ```
5. **0개 확인 후에만 `markdown_to_tistory_html.py`로 변환 진행**

### ❌ DON'T

1. **검색 결과를 그대로 복사** — Chinese/Japanese 원문이 섞여 들어옴
2. **일본어 단어를 한국어 텍스트 사이에 자연스럽게 삽입** (예: `推奨する 방식` → `권장하는 방식`)
3. **영어-한자 혼용 표기** (예: `AI의 規模` → `AI의 규모`)
4. **고유명사를 한자로 표기** (예: `東京` → `도쿄`)

---

## 자동 검사 스크립트 (Markdown 작성 직후 실행)

```python
import re

with open('/tmp/blog_post.md', 'r', encoding='utf-8') as f:
    md = f.read()

# CJK 검사
cjk = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', md))
if cjk:
    print(f"⚠️ CJK 발견: {sorted(cjk)}")
    print(f"   개수: {len(cjk)}자")
else:
    print("✅ CJK 0개")

# Cyrillic 검사 (CJK regex 밖)
cyrillic = set(re.findall(r'[\u0400-\u04FF]', md))
if cyrillic:
    print(f"⚠️ Cyrillic 발견: {sorted(cyrillic)}")
else:
    print("✅ Cyrillic 0개")

# 텍스트 길이 확인
text_only = re.sub(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff\u0400-\u04FF]', '', md)
text_only = re.sub(r'[#*\-\[\]\(\)\|`>]', '', text_only)
text_only = re.sub(r'\s+', '', text_only)
print(f"순수 텍스트: {len(text_only)}자")
```

**출력 예시 (best case):**
```
✅ CJK 0개
✅ Cyrillic 0개
순수 텍스트: 2436자
```

이 상태이면 HTML 변환 직후 CJK cleaning 루프 0회차로 통과한다.

---

## 시간 비교

| 패턴 | CJK cleaning 소요 시간 | 발행 실패 위험 |
|------|------------------------|----------------|
| **0회차 패턴 (한국어 전용 작성)** | 0초 (스킵) | 거의 없음 |
| 1-2회차 패턴 (사전 정제로 해결) | 5-10초 | 낮음 |
| 3-5회차 패턴 (루프 + 2차 정제) | 30-60초 | 중간 |
| 6회차+ 패턴 (장기 루프 + 수동 patch) | 2-5분 | 높음 |

**결론:** Markdown 작성 시점에 5분을 더 투자하면 발행 시 5분을 절약한다. (그리고 품질도 더 좋아진다.)

---

## 70차 교훈과의 연결

70차 세션에서 발견된 Korean text corruption 패턴:
- "很有意思하다" → "有意思하다" → "하다." (순차 문자 제거)

이 패턴의 근본 원인은 **Markdown 작성 시 모델이 한자를 직접 생성**한 것이다. 0회차 패턴을 따르면 이런 corruption 자체가 발생하지 않는다.

상세: `references/korean-text-corruption-patterns.md`, `references/cjk-72nd-batch.md` 참조.
