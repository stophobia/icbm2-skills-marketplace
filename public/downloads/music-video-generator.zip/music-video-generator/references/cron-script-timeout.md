# Cron Script Timeout + Music Video Cron 모니터링 (2026-05-24)

## 문제: 20시 뮤직비디오 크론이 120초 타임아웃으로 실패

**증상:**
- Cron job status: `error`
- 출력: `Script timed out after 120s: /Users/hjshin/.hermes/scripts/music_video_producer.py`
- 스크립트 자체는 정상 동작 중인데 크론이 조기 종료됨

**원인:** `no_agent` 모드 크론의 기본 스크립트 타임아웃이 120초
- 음악/이미지 생성은 각 120초+ 소요 → 2개候選 처리 시 120초 내에 완료 불가

## 해결: HERMES_CRON_SCRIPT_TIMEOUT 환경변수

```bash
# ~/.hermes/.env에 추가
HERMES_CRON_SCRIPT_TIMEOUT=600
```

**적용 위치 3가지 (우선순위):**
1. 환경변수 `HERMES_CRON_SCRIPT_TIMEOUT` (here) ← 지금 사용한 방법
2. config.yaml: `cron.script_timeout_seconds: 600`
3. hermes CLI: `hermes config set cron.script_timeout_seconds 600`

**설정 소스 확인:** `_get_script_timeout()` in `scheduler.py`
```python
def _get_script_timeout() -> int:
    # 1. _SCRIPT_TIMEOUT 모듈 변수 (patched)
    # 2. HERMES_CRON_SCRIPT_TIMEOUT 환경변수
    # 3. cron.script_timeout_seconds (config.yaml)
    # 4. _DEFAULT_SCRIPT_TIMEOUT (120초)
    return _DEFAULT_SCRIPT_TIMEOUT  # fallback: 120초
```

## 크론 상태 확인 패턴

**주의:** `cronjob(action='list')`의 `last_status`는 마지막 스케줄 실행 기준
**수동 트리거는 `last_run_at`만 갱신하고 `last_status`를 갱신하지 않음**

```
# last_status = "error"이지만 실제로는 실행 중
cronjob list → a77ee904fa61.last_status = "error"
ps aux | grep music_video_producer → PID 존재 (실행 중)
```

**올바른 모니터링:**
```bash
# 1. 프로세스 확인
ps aux | grep music_video_producer | grep -v grep

# 2. 출력 파일 timestamps 확인 (업데이트되면 완료)
ls -lt ~/.hermes/cron/output/a77ee904fa61/

# 3. gateway.log에서 cron 실행 로그
tail -100 ~/.hermes/logs/gateway.log | grep -i "cron\|a77ee\|music"
```

## 현재 Cron 설정 (a77ee904fa61)

```yaml
job_id: a77ee904fa61
name: "🎬 뮤직비디오 제작 및 업로드 (오후 8시)"
script: music_video_producer.py
no_agent: true
schedule: "0 20 * * *"  # 매일 20:00
deliver: origin
```

**Notion DB ID 주의:**
- 검색으로 찾은正确 ID: `36976f2e-9097-81e1-a373-e06f2da6e99c`
- API가 URL 인코딩 시 double-dash 발생 → 404 오류 같지만 실제로는 정상 동작
- 검색 API로 DB 존재 확인 가능:
  ```
  POST https://api.notion.com/v1/search
  {"query": "뮤직비디오", "filter": {"property": "object", "value": "database"}}
  ```

## 관련 파일

- 스크립트: `~/.hermes/scripts/music_video_producer.py`
- 타임아웃 설정: `~/.hermes/.env` (HERMES_CRON_SCRIPT_TIMEOUT=600)
- 크론 스케줄러: `~/.hermes/hermes-agent/cron/scheduler.py` (_get_script_timeout)
- Notion DB: `36976f2e-9097-81e1-a373-e06f2da6e99c` (🎵 뮤직비디오 주제)