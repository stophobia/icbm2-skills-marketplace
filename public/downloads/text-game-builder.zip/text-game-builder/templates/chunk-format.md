# Lore Chunk 형식 가이드

## 마크다운 형식 (필수)

모든 lore 파일은 첫 줄에 `[CHUNK: TYPE -- NAME]` prefix를 가져야 합니다. RAG 인덱서가 이걸로 자동 분류합니다.

```markdown
# [CHUNK: faction -- Kingdom of Aldoria]

왕국건국 200년. 북부 대륙 최대의 군주국...

## Government
입헌군주제, 의회(Yalthra)가 군주를 견제...

## Military
상비군 35,000명, 징집 가능 80,000명. 북부 산맥 요새화...
```

## 지원되는 TYPE 목록

NarrativeEngine-P와 호환되는 11개 카테고리:

| TYPE | 용도 | 예시 |
|------|------|------|
| `world_overview` | 세계관 총론 | 대륙 구조, 시대, 마법 체계 |
| `faction` | 국가/세력 | 왕국, 공화국, 기사단, 카르텔 |
| `location` | 지역/도시/장소 | 도시, 요새, 산맥, 항구 |
| `character` | 인물 (NPC/PC) | 군주, 장군, 영주, 스파이 |
| `power_system` | 마법/기술 체계 | 마법 진영, 기술 트리, 마나 법칙 |
| `economy` | 경제 시스템 | 화폐, 무역로, 작물, 자원 |
| `event` | 사건 | 전쟁, 조약, 반란, 의식 |
| `relationship` | 관계 | 우호도, 동맹, 적대, 혈연 |
| `rules` | 게임 룰 (pinned 가능) | 전투 규칙, 계승법, 외교 의전 |
| `culture` | 문화/종교 | 관습, 신앙, 언어, 예술 |
| `misc` | 기타 | 분류 애매한 항목 |

## 파일 구조 예시

```
world/
├── overview.md                    # [CHUNK: world_overview]
├── factions/
│   ├── kingdom-of-aldoria.md     # [CHUNK: faction]
│   ├── khanate-of-volgar.md      # [CHUNK: faction]
│   └── ...
├── characters/
│   ├── queen-elisabet.md         # [CHUNK: character]
│   ├── prince-aldric.md          # [CHUNK: character]
│   └── ...
├── regions/
│   ├── capital-aldoria.md        # [CHUNK: location]
│   └── ...
├── rules/
│   ├── succession.md             # [CHUNK: rules] (pinned)
│   ├── warfare.md                # [CHUNK: rules] (pinned)
│   ├── diplomacy.md              # [CHUNK: rules] (pinned)
│   └── economy.md                # [CHUNK: rules] (pinned)
├── economy.md                    # [CHUNK: economy]
└── culture.md                    # [CHUNK: culture]
```

## Pinned vs Unpinned

- **Pinned (Tier 1 자동 주입)**: `rules/` 디렉토리의 모든 chunk, `world_overview`
- **Unpinned (Tier 3 RAG 검색)**: `faction`, `character`, `location`, `event` 등

## 작성 팁

1. **chunk는 독립적** — 다른 chunk 참조 시 `[NAME]` 형식만 쓰고 본문 복제 안 함
2. **첫 줄은 항상 prefix** — RAG 인덱서가 헤더 인식
3. **섹션은 `## ` (h2) 이상** — h1은 prefix 라인
4. **인물 chunk는 relations 명시**:
   ```markdown
   ## Relations
   - liege: kingdom-of-aldoria
   - spouse: prince-aldric
   - rival: duke-morthred
   ```
5. **rules chunk는 예시 포함**:
   ```markdown
   ## Succession
   1순위: 직계 장남
   2순위: 직계 차남
   3순위: 의회(Yalthra) 결정
   
   예시: 1487년 엘리자벳이 후사 없이 승하하면 → 2순위 알드릭 황자
   ```
