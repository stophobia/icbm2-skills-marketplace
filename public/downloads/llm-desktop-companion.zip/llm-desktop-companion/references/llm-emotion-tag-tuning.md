# LLM 감정 태그 시스템 프롬프트 튜닝 가이드

LLM 응답에 메타데이터(감정, 표정, 액션)를 심어 파싱하는 패턴. 검증된 시스템 프롬프트 + 한계 + 폴백 전략.

## ✅ v1 패턴: 끝에 태그 강제

```python
SYSTEM_PROMPT = """너의 이름은 '키위'야. ...

[감정 표현 — 매우 중요]
**모든 답변의 마지막 줄에 반드시 다음 중 하나의 감정 태그를 1개만 붙여야 한다** (대괄호):
[emotion:happy]    — 기쁨, 즐거움, 신남
[emotion:sad]      — 슬픔, 위로
[emotion:thinking] — 생각 중, 의문
[emotion:surprised]— 놀라움, 반전
[emotion:neutral]  — 일반 인사

규칙:
- 이전 대화와 무관하게 매번 새 응답마다 1개 태그를 반드시 붙인다
- 사용자의 감정이 강하면 그에 맞춰 태그를 선택한다
- 태그를 빼먹지 않는다 — 절대 빼먹지 마
"""
```

### 파싱

```python
import re
EMOTION_RE = re.compile(r"\[emotion:\s*(happy|sad|thinking|surprised|neutral)\s*\]", re.IGNORECASE)
VALID_EMOTIONS = {"happy", "sad", "thinking", "surprised", "neutral"}

def parse_response(raw_text):
    match = EMOTION_RE.search(raw_text)
    emotion = match.group(1).lower() if match else "neutral"  # 폴백
    if emotion not in VALID_EMOTIONS:
        emotion = "neutral"
    text = EMOTION_RE.sub("", raw_text).strip()
    return {"text": text, "emotion": emotion, "raw": raw_text}
```

## 📊 검증된 정확도 (MiniMax-M3 기준, 2026-06-23)

| 시나리오 | 컨텍스트 길이 | 정확도 |
|----------|-------------|--------|
| 단일 호출 (턴 1) | 0~2K | **5/5 (100%)** |
| 3~4턴 누적 | 2K~6K | **3/4 (75%)** — 1개가 neutral로 폴백 |
| 5~7턴 누적 | 6K~10K | **2/5 (40%)** — 다수 neutral 폴백 |

**결론**: 짧은 대화는 완벽, 길어질수록 태그 출력 빈도 감소. **폴백은 필수**.

## ⚠️ 검증된 한계: 컨텍스트 길이 + 태그 약화

### 증상
- 시스템 프롬프트에 "절대 빼먹지 마"라고 강조해도 4~6턴 이후 무시
- 응답 본문 길어질수록 태그 생략 경향
- Chat-tuned 모델에서 더 두드러짐

### 원인
- 모델의 instruction following이 컨텍스트 길이 증가에 따라 약해짐
- 긴 시스템 프롬프트(>500 토큰)는 끝부분 무시 경향
- Few-shot 예시가 본문 분량을 늘려서 역효과

## 🛠️ v2 대응 (우선순위 순)

### 대응 1: 폴백 "neutral" (무조건)
```python
emotion = match.group(1) if match else "neutral"
```
- 장점: 표정이 항상 "neutral"로라도 바뀜 (정지 ❌)
- 단점: 다양성 감소
- v1에서 사용. **이것만으로도 충분히 동작**.

### 대응 2: 키워드 백업 분류 (단어 사전)
```python
EMOTION_KEYWORDS = {
    "happy": ["기뻐", "좋아", "신나", "축하", "최고", "행복", "ㅋㅋ", "🎉", "♥"],
    "sad": ["슬퍼", "힘들", "외로", "그리워", "ㅠㅠ", "ㅜㅜ", "위로"],
    "thinking": ["생각", "음...", "글쎄", "어떻게", "왜", "어디", "뭐지"],
    "surprised": ["헐", "대박", "와!", "진짜?!", "우와", "놀라"],
}

def classify_keywords(text, fallback="neutral"):
    scores = {e: sum(1 for kw in kws if kw in text) for e, kws in EMOTION_KEYWORDS.items()}
    best = max(scores, key=scores.get)
    return best if scores[best] > 0 else fallback

# LLM 태그가 없거나 "neutral"이면 키워드 분류
emotion = result["emotion"]
if emotion == "neutral" or not result.get("tag_present"):
    emotion = classify_keywords(text)
```

- 장점: LLM 호출 0, 빠름, 결정론적
- 단점: 신조어/문맥 못 잡음, 영어 혼용 약함
- LLM 태그 + 키워드 **두 신호 voting**으로 정확도 ↑

### 대응 3: 2차 LLM 분류 (가장 robust)
```python
CLASSIFY_PROMPT = """다음 텍스트의 감정을 분류하라. 하나만 답하라.
옵션: happy / sad / thinking / surprised / neutral

텍스트: {text}
감정:"""

def classify_with_llm(text):
    # 짧은 텍스트 + 짧은 프롬프트 → LLM도 잘 따름
    r = llm.call_llm(CLASSIFY_PROMPT.format(text=text), max_tokens=10)
    return r["text"].strip().lower()
```

- 장점: 90%+ 정확도
- 단점: API 호출 +1, 비용 +1, 지연 +500ms

## 📊 전략 선택 가이드

| 상황 | 추천 |
|------|------|
| 데모 / 프로토타입 | v1 (폴백만) |
| 실제 사용 / 다회 대화 | v1 + 키워드 백업 |
| 다국어 / 전문 도메인 | v1 + 2차 LLM |
| 비용 민감 | v1 + 키워드 (LLM 호출 0) |

## 🧪 테스트 시나리오 5종 (v1 검증용)

```python
SCENARIOS = [
    ("키위야 안녕!", "happy"),
    ("오늘 회사에서 너무 힘든 일이 있었어", "sad"),
    ("방금 복권 1등 됐어!!!", "surprised"),
    ("너랑 얘기하니까 마음이 편해져", "happy"),
    ("그건 좀 생각해봐야 할 것 같아", "thinking"),
]
```

## 🔗 관련

- MiniMax-M3 모델: Anthropic 호환 API, `https://api.minimax.io/anthropic/v1/messages`
- 폴백 정책: `references/llm-fallback-chain.md` (miniMax → NIM gpt-oss-120b)
- Emotion 정규식: case-insensitive, multiline 가능 (`re.MULTILINE | re.IGNORECASE`)