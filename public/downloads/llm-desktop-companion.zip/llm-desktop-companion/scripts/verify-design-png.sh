#!/bin/bash
# 디자인 검증 — PNG 자동 생성 + vision_analyze 호출 가이드
# StackChan 스타일 얼굴 디자인 변경 후 항상 실행

set -e

cd "$(dirname "$0")/../.."
PREVIEW_DIR="$HOME/projects/kiwi-companion/preview"
mkdir -p "$PREVIEW_DIR"

echo "=== 1. 모든 표정 PNG 생성 ==="
/Users/hjshin/opt/anaconda3/envs/kiwi/bin/python << 'PYEOF' 2>&1 | tail -25
import sys, os
sys.path.insert(0, '.')
os.environ['SDL_VIDEODRIVER'] = 'dummy'
import face, pygame

out_dir = os.path.expanduser('~/projects/kiwi-companion/preview')
f = face.KiwiFace()
f.init_pygame()

emotions = ['happy', 'laughing', 'funny', 'sad', 'angry', 'cry',
            'thinking', 'surprised', 'shocked', 'winking', 'cool',
            'loving', 'embarrassed', 'kissy', 'confident', 'relaxed',
            'delicious', 'sleepy', 'silly', 'confused', 'neutral']

for emotion in emotions:
    f.set_emotion(emotion)
    f.set_speaking(False)
    f._update(0)
    f._draw()
    pygame.display.flip()
    pygame.image.save(f._window, f'{out_dir}/kiwi_{emotion}.png')
    print(f'✓ {emotion}')
f.shutdown()
PYEOF

echo ""
echo "=== 2. PNG 출력 위치 ==="
echo "$PREVIEW_DIR"
ls -la "$PREVIEW_DIR" | head -5
echo "총 $(ls $PREVIEW_DIR/kiwi_*.png 2>/dev/null | wc -l)개 표정 PNG"

echo ""
echo "=== 3. vision_analyze 호출 예시 ==="
cat << 'EOF'
# 가장 중요한 표정(happy, sad, cool 등) 하나만 검증
# mcp__minimax__understand_image로 확인:

# happy 검증:
python3 -c "
from hermes_tools import mcp
result = mcp('minimax', 'understand_image', {
    'image_source': '$PREVIEW_DIR/kiwi_happy.png',
    'prompt': '이 표정이 happy로 잘 느껴지나요? 라벨이 HAPPY인데 표정이 슬프거나 모호해 보이나요?'
})
print(result)
"

# 모든 표정 일괄 검증은 vision 비용이 크므로 3-5개 핵심만
# - happy: 라벨=기쁨, 의도=웃음 → 일치 확인
# - sad: 라벨=슬픔, 의도=찡그림 → 일치 확인
# - cool: 라벨=쿨, 의도=선글라스 → 일치 확인
# - surprised: 라벨=놀람, 의도=O O → 일치 확인
# - confused: 라벨=혼란, 의도=X X → 일치 확인
EOF
