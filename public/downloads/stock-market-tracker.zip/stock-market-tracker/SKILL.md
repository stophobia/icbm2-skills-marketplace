---
name: stock-market-tracker
description: 한국/미국 주식 시장 데이터 수집, 포트폴리오 추적, 뉴스 기반 시황 분석 자동화
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [Stock, Investment, KOSPI, KOSDAQ, Portfolio, Korean, Automation]
prerequisites:
  pip_packages:
    - pykrx
    - yfinance
    - pandas
---

# 주식 시장 추적 스킬

## 개요

한국(KOSPI/KOSDAQ) 및 미국(S&P500/NASDAQ) 주식 시장 데이터를 자동으로 수집하고, 주인님의 포트폴리오를 추적하며, 시황 분석 브리핑을 제공합니다.

## 데이터 소스

### 1. pykrx — 한국거래소 데이터

KRX 및 네이버 증권에서 한국 주식/채권 데이터를 스크래핑합니다. API 키 불필요.

```python
from pykrx import stock

# 코스피 종목 코드
kospi_tickers = stock.get_market_ticker_list(market="KOSPI")
# 코스닥 종목 코드
kosdaq_tickers = stock.get_market_ticker_list(market="KOSDAQ")

# 특정 종목 OHLCV (시가/고가/저가/종가/거래량)
df = stock.get_market_ohlcv("005930", start="20260401")  # 삼성전자

# 특정 종목 현재가
price = stock.get_market_price("005930")  # 삼성전자

# 코스피 지수
kospi = stock.get_index_ohlcv("0001", start="20260401")  # KOSPI

# 투자자별 매매동향
foreign = stock.get_exhaustion_rates_of_foreign_investment("005930")

# PER/PBR/ROE 등
fundamental = stock.get_market_fundamental("005930")
```

### 2. yfinance — 글로벌 시장 데이터

야후 파이낸스에서 글로벌 주식/지수/ETF 데이터를 가져옵니다. API 키 불필요.

```python
import yfinance as yf

# 미국 지수
sp500 = yf.Ticker("^GSPC")  # S&P 500
nasdaq = yf.Ticker("^IXIC")  # NASDAQ

# 한국 지수 (ETF 기반)
ewy = yf.Ticker("EWY")  # iShares MSCI Korea ETF

# 특정 종목
aapl = yf.Ticker("AAPL")
hist = aapl.history(period="1mo")

# 글로벌 시장 요약
indices = yf.download(["^GSPC", "^IXIC", "^KS11", "^KQ11"], period="5d")
```

### 3. 뉴스 기반 시황

`search` 도구로 경제 뉴스를 수집하여 시황 분석에 활용:
- "KOSPI 시황", "코스피 전망", "미국 주식 시장" 등 키워드 검색

### 4. hades (junhoyeo/hades) — 한국 주식 백테스트 엔진 🚀

**pykrx 단독으론 부족한 영역** (백테스트, 외국인 수급 메트릭, 섹터별 모멘텀 등)을
**hades** (https://github.com/junhoyeo/hades) Rust CLI로 보강. MIT, AI 친화적(JSON 기본).

#### 설치

```bash
# 1) Rust 툴체인 (한 번만, ~500MB)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y \
  --default-toolchain stable --profile minimal
. "$HOME/.cargo/env"

# 2) hades 바이너리 빌드 (~4분, 한 번만)
git clone --depth 1 https://github.com/junhoyeo/hades.git ~/hades
cd ~/hades && cargo build --release -p hades-cli
# 결과: ~/hades/target/release/hades (11MB 단일 실행파일)

# 3) Python 의존성 (pykrx + pandas + pyarrow + tqdm)
# USER.md의 conda env 정책 따라 새 env 생성 권장
conda create -n hades python=3.11 -y
~/opt/anaconda3/envs/hades/bin/pip install pykrx pandas pyarrow tqdm

# 4) OHLCV 데이터 일회 동기화 (KOSPI+KOSDAQ 전체 ~5분, 41MB parquet)
cd ~/hades && ~/opt/anaconda3/envs/hades/bin/python scripts/sync_krx_data.py --init 1
```

#### 호출 패턴 (4종 명령, 모두 <60ms)

```bash
HADES=~/hades/target/release/hades

# 1) 티커 정보
$HADES ticker 005930
# → {"symbol":"005930","market":"KOSPI","data_available":true,
#    "first_date":20241230,"last_date":20260622,"total_bars":357,"last_close":353500}

# 2) OHLCV (limit 또는 from/to)
$HADES ohlcv 005930 --limit 30
$HADES ohlcv 005930 --from 2025-01-01 --to 2025-06-30 --format csv

# 3) 백테스트 (5종 전략 × 4종 필터 × weekly/monthly rotation)
$HADES backtest --market kospi --strategy momentum --top-k 10 \
  --rotation weekly --from 2025-07-01 --to 2026-06-22 --filter moderate
# → config + results (total_return_pct, num_trades, avg_stocks_passed 등)

# 4) 외국인 수급 (foreign_flow parquet 사전 동기화 필요 — 함정 #1)
$HADES foreign-flow 005930 --days 30
```

#### 우리 cron에 끼우는 법 (subprocess 파싱)

```python
import subprocess, json

def hades(cmd, timeout=60):
    r = subprocess.run(
        ['~/hades/target/release/hades'] + cmd,
        capture_output=True, text=True, timeout=timeout
    )
    if r.returncode != 0:
        return {'error': r.stderr, 'rc': r.returncode}
    return json.loads(r.stdout)

# 일일 삼성전자 스냅샷
data = hades(['ticker', '005930'])
msg = f"삼성전자 {data['last_date']} 종가 {data['last_close']:,}원"

# 백테스트 결과를 Notion에 기록
bt = hades(['backtest', '--market', 'kospi', '--strategy', 'momentum',
            '--top-k', '30', '--rotation', 'weekly',
            '--from', '2025-07-01', '--to', '2026-06-22',
            '--filter', 'moderate'], timeout=120)
# bt['results']['total_return_pct'], bt['results']['num_trades']
```

#### hades JSON 스키마 (안정, 파싱 무리 없음)

| 명령 | 최상위 키 | 비고 |
|---|---|---|
| `ticker` | symbol, market, data_available, first_date, last_date, total_bars, last_close | |
| `ohlcv` | symbol, bars[] | bars 안에 date, open, high, low, close, volume, amount |
| `backtest` | config{}, results{total_return_pct, final_value, initial_capital, num_trades, avg_stocks_passed} | |
| `foreign-flow` | symbol, period_days, metrics (없으면 null) | metrics null = foreign_flow parquet 미동기화 |
| `list` | market, count, symbols[] | |

#### ⚠️ hades 함정 3개 (2026-06-23 실측)

1. **외국인 수급 parquet 자동 생성 X** — `hades foreign-flow`는 `data/foreign_flow/`에 parquet이
   없으면 `metrics: null` 반환. `scripts/sync_foreign_flow.py` + `KRX_ID/KRX_PW` env vars 필요.
   KRX 비회원(개인) 한정. **OHLCV는 자동 동기화되지만 외국인 수급은 별도 작업**.

2. **백테스트 윈도우 짧으면 trade=0** — 데이터 시작일 12-30인 상태에서 6개월 윈도우 + top-10
   모멘텀이면 시그널이 안 채워져서 `num_trades: 0, total_return_pct: 0.0` 나옴.
   **권장: 모멘텀 1년+, top-30+ weekly rotation**. 실측: 1년 weekly top-30 → 540 trades 정상.

3. **빌드 4분 + 데이터 5분 = 첫 실행 10분** — CI/cron에서 매번 빌드 X.
   **바이너리 + 데이터는 1회 셋업, cron은 `hades backtest ... | jq` 형태로 호출만**.

#### 의존성 정리

| 컴포넌트 | 크기 | 비고 |
|---|---|---|
| `~/.cargo` (rustup) | ~500MB | 영구, 다른 도구도 활용 가능 |
| `~/hades/target/release/hades` | 11MB | 단일 정적 실행파일 |
| `~/hades/data/ohlcv/*.parquet` | 41MB | 2,600+ 종목 × 243일치 |
| `~/hades/data/foreign_flow/` | (옵션) | KRX 로그인 필요 |
| `~/opt/anaconda3/envs/hades/` | ~200MB | pykrx + pandas + pyarrow + tqdm |

#### 다음 단계 옵션

- **A. 그대로 끼우기** (10분) — `stock-market-tracker` cron의 일일 시황 발송 직전에
  `hades ticker <portfolios>` 한 줄 subprocess 추가, JSON 파싱해서 메시지에 종가/등락률 삽입
- **B. MCP 래퍼** (30분) — `hades`를 MCP 서버로 감싸서 Hermes가 tool로 호출
  → 컨트리뷰트(PR) vs 독립 래퍼(사용자 repo) 결정 필요
- **C. 둘 다** — A로 데이터 흐름 입증 후 B로 정식화

상세 실측 기록: `references/hades-integration.md`

## 주요 종목 코드

### 한국 (pykrx용)

| 종목 | 티커 | 설명 |
|------|------|------|
| 삼성전자 | 005930 | 코스피 대표 |
| SK하이닉스 | 000660 | 반도체 |
| LG에너지솔루션 | 373220 | 2차전지 |
| NAVER | 035420 | IT/플랫폼 |
| 카카오 | 035720 | IT/플랫폼 |
| 현대차 | 005380 | 자동차 |
| 기아 | 000270 | 자동차 |
| KB금융 | 105560 | 금융 |
| 삼성바이오로직스 | 207940 | 바이오 |
| HMM | 011200 | 해운 |

### 미국 (yfinance용)

| 종목 | 티커 | 설명 |
|------|------|------|
| S&P 500 | ^GSPC | 미국 대표 지수 |
| NASDAQ | ^IXIC | 기술주 지수 |
| KOSPI | ^KS11 | 한국 종합주가지수 |
| KOSDAQ | ^KQ11 | 한국 코스닥지수 |
| 애플 | AAPL | Big Tech |
| 엔비디아 | NVDA | AI/GPU |
| 테슬라 | TSLA | 전기차 |

## 기능

### 1. 일일 시황 브리핑

매일 아침(장 마감 후) 다음 데이터를 수집하여 브리핑:

```
📈 ICBM2 주식 시황 — MM월 DD일

🇰🇷 한국 시장
• KOSPI: 2,6xx.xx (▲x.xx% / ▼x.xx%)
• KOSDAQ: xxx.xx (▲x.xx%)
• 외국인 매매: +x,xxx억 원
• 주요 종목: 삼성전자 ▲x% / SK하이닉스 ▼x%

🇺🇸 미국 시장 (전일)
• S&P 500: 5,xxx.xx (▲x.xx%)
• NASDAQ: xx,xxx.xx (▲x.xx%)

📰 오늘의 주요 이슈
• (뉴스 요약 3건)

📊 포트폴리오 현황
• (관심 종목 변동률)
```

### 2. 관심 종목 추적

주인님이 관심 있는 종목 목록을 관리하고 일일 변동을 추적합니다.

**상태 파일:** `memory/portfolio.md`

```markdown
# 관심 종목 포트폴리오

## 관심 종목
| 종목 | 시장 | 티커 | 매입가 | 목표가 | 메모 |
|------|------|------|--------|--------|------|
| 삼성전자 | KOSPI | 005930 | - | - | 주력 관심 |
| SK하이닉스 | KOSPI | 000660 | - | - | AI 반도체 |

## 일일 기록
### 2026-04-07
• 삼성전자: 75,000원 (▲1.2%)
• SK하이닉스: 180,000원 (▼0.5%)
```

### 3. 급등락 종목 알림

pykrx로 급등락 종목을 모니터링:

```python
from pykrx import stock

# 급등 종목 (등락률 TOP 10)
tickers = stock.get_market_ticker_list()
df = stock.get_market_price(tickers[:50])
top_gainers = df.nlargest(10, '등락률')
```

### 4. 테마별 동향

특정 테마(AI, 반도체, 2차전지 등)의 관련 종목 그룹을 추적합니다.

## 실행 방법

### 수동 실행
```
주인님에게 "시황 알려줘" 또는 "삼성전자 주가"라고 요청받으면:
1. pykrx/yfinance로 최근 데이터 수집
2. 뉴스 검색으로 시황 맥락 파악
3. 포트폴리오 상태 파일 확인
4. 브리핑 메시지 작성
```

### 자동 실행 (크론)
```
매일 평일 18:30 KST — 한국 장 마감 후 시황 브리핑
deliver: origin (텔레그램)
```

## 주의사항

- pykrx는 KRX/네이버 웹 스크래핑 기반이므로, 사이트 구조 변경 시 동작 불가 가능성
- yfinance는 야후 파이낸스 API 기반, rate limit 주의
- 장시간(15:30~16:00 KST)에는 데이터 갱신 지연 가능
- 투자 조언이 아닌 정보 제공 목적으로만 사용
- 주말/공휴일에는 전일 종가 기준으로 표시

## 상태 관리

- **포트폴리오 파일:** `memory/portfolio.md`
- 20KB 초과 시 `state_file_manager.py`로 자동 압축

## 참고 자료

- `references/hades-integration.md` — hades 실측 결과, 3개 함정, 통합 패턴 3종, 백엔드 비교표
- `templates/setup_hades.sh` — 1회 셋업 스크립트 (rustup + 빌드 + Python env + 데이터 동기화, ~10분)
