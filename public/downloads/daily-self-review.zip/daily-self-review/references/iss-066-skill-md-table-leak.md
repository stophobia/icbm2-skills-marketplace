# ISS-066 — SKILL.md 본문 "교육용 raw trigger 표"가 cron output에 leak되는 self-trigger

## 클래스-수준 함정 (CRITICAL)

`daily-self-review` SKILL.md v1.0.9의 **"출력 가드 규칙" 섹션**은 self-healer가 매칭하는 raw trigger 단어(`api error`, `apierror`, `rate limit`, `out of memory`, `401`~`503`, `Bearer <token>`)를 **교육용으로** 표 안에 보존한다. 이건 의도된 설계다 (v1.0.8 노트 명시).

문제는 **일일 리뷰가 본문을 작성할 때 SKILL.md 본문 표를 그대로 복사**하면, cron output에 raw trigger가 잔존 → 다음 날 self-healer가 매칭 → FP.

## 증상 (2026-06-08 실전)

일일 리뷰 cron output (`~/.hermes/cron/output/5d0f14aef84c/2026-06-07_22-09-00.md`) line 132, 134, 165:

```markdown
| `api error` / `apierror` / `api failed` | `api␣err␣or` |
| `rate limit` | `rate␣limit` |
| `out of memory` / `memoryerror` | `memory␣issue` |
```

- `verify_self_healer_patch.py`의 `META_MARKERS`는 "패턴 매치:" / "self-healer" / "iss-062" 같은 **디버그 라인**만 drop
- 위의 "출력 가드 표" 라인은 메타 마커가 없어서 살아남음 → self-healer regex `r"\bapi[\s._-]*(?:error|failed)\b"` 가 매칭
- **1건 FP 감지** (어제 daily review 본인에 대한 self-trigger)

## 왜 메타 마커로 못 막나

verify의 META_MARKERS는 다음 패턴만 인식:

```python
META_MARKERS = (
    "패턴 매치:",
    r"\b(?:api[\s._-]*(?:error|failed)",
    "self-healer", "self_healer", "self_heal", "self-heal",
    "self trigger", "self_trigger", "self-quote", "self_quote",
    "iss-044", "iss-058", "iss-059", "iss-062",
    "notion api", "api rate", "rate limit", "rate_limit",
    "공통 효과", "doc reference", "substring은 더 이상",
    "오탐 대표", "false positive", "memory error", "out of memory",
    "memoryissue", "memory\u2423issue",
)
```

`"출력 가드 규칙"`, `"가드 표"`, `"마스킹된 형태"`, `"원본"`, `"마스킹"` 같은 일반 단어는 메타 마커에 없음. 즉 **메타 마커 필터는 self-healer 자기 디버그 출력만 drop**하지, "raw trigger를 포함하는 모든 라인"을 drop하지는 않는다.

## 즉시 fix (2026-06-08 적용)

`mask_self_healer_terms.py`로 cron output 1회 적용:

```bash
python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py \
  ~/.hermes/cron/output/5d0f14aef84c/2026-06-07_22-09-00.md > /tmp/masked.md
cp /tmp/masked.md ~/.hermes/cron/output/5d0f14aef84c/2026-06-07_22-09-00.md
python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py --check \
  ~/.hermes/cron/output/5d0f14aef84c/2026-06-07_22-09-00.md
# → ✅ PASS
```

이 fix는 **저장된 파일에 사후 적용** — LLM이 매번 따르지 않아도 cron output이 다음 날 self-healer를 오염시키지 않음.

## 근본 fix (v1.0.10 권장)

**방안 A — 출력 템플릿에서 SKILL.md 본문 표/예시 섹션 자동 strip**

일일 리뷰 cron prompt에 명시:

```markdown
## 출력 템플릿 (v1.0.10+)
본문 작성 시 다음 섹션은 SKILL.md 본문에서 복사하지 말 것 (메타 마커 필터로 drop 안 됨):
- "## ⚠️ 출력 가드 규칙" 헤더 + 다음 H2까지
- "## ⚠️ Pitfall:" 헤더 + 다음 H2까지 (raw trigger 단어 포함 가능성)
- 검증 예시 / "원본" / "마스킹된 형태" 표

대신 **마스킹된 형태** (예: `api␣err␣or`, `<HTTP-code>`, `Bearer <redacted>`) 만 본문에 적을 것
또는 raw 검증 예시가 필요하면 `docs/validation-log.md` 같은 별도 파일에 분리
```

**방안 B — verify META_MARKERS 강화**

`verify_self_healer_patch.py`의 META_MARKERS에 추가:

```python
META_MARKERS = META_MARKERS + (
    "출력 가드 규칙",   # SKILL.md 본문 섹션 헤더
    "가드 표",
    "마스킹된 형태",
    "원본 | 마스킹",   # 표 헤더
    "validation-log",  # 검증 예시 파일명
)
```

**방안 C — cron prompt 9단계 silent fail 차단**

```markdown
### 9단계 (v1.0.10+ silent fail 차단)

마스킹 step + --check + **실패 시 raise**:

\`\`\`bash
python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py \\
  ~/.hermes/memory/reports/daily_$(date '+%Y-%m-%d').md > /tmp/daily_masked.md
\`\`\`

**반드시 exit code 확인**:
- exit=0 + --check PASS → 진행
- exit≠0 OR --check FAIL → **즉시 raise** (silent fail 방지). Python 3.8 호환성 (ISS-065) 확인.
```

## 재발 감지 — 일일 리뷰 시작 시

```bash
# 1) 일일 리뷰 1단계에서 verify (기존 6단계 첫 항목)
python3 ~/.hermes/skills/automation/nightly-maintenance-workflow/scripts/verify_self_healer_patch.py --status
```

- **PASS** (4/4 jobs clean) → 정상 진행
- **FAIL** (1/4 jobs FP) → **ISS-066 재발 의심**:
  1. 어느 잡의 어느 파일이 FP인지 식별 (`check_fps.py` 같은 ad-hoc 스크립트)
  2. 해당 파일 retro-masking
  3. `mask_self_healer_terms.py` import 정상 작동 확인 (ISS-065 silent fail 가능성)

## 일일 리뷰 본문 작성 체크리스트 (v1.0.10+)

작성자가 **출력 전에 1회 자가 검증**:

- [ ] 본문에 `apierror`, `api error`, `api failed` 같은 단어가 **backtick 안에라도** 없는가? → 있으면 마스킹된 형태 (`api␣err␣or`) 로 치환
- [ ] 본문에 `rate limit` 단어가 단독으로 있는가? → 있으면 `rate␣limit` 로 치환
- [ ] 본문에 `out of memory` / `memoryerror` 단어가 단독으로 있는가? → 있으면 `memory␣issue` 로 치환
- [ ] 본문에 `401`~`503` 숫자가 단독으로 있는가? → `<HTTP-code>` 로 치환
- [ ] 본문에 `Bearer <token>` 형식이 있는가? → `Bearer <redacted>` 로 치환
- [ ] raw 검증 예시가 정말 필요하면 본문이 아닌 `~/.hermes/docs/validation-log.md` 같은 별도 파일에 적었는가?

## 관련

- ISS-062: Self-healer 메타 출력 self-trigger (4차 patch, 2026-06-05)
- ISS-063: SKILL.md doc vs cron prompt drift (v1.0.9 patch 원인, 2026-06-07)
- ISS-065: `from __future__ import annotations` silent import fail (2026-06-08)
- `references/iss-062-self-healer-meta-output.md`
- `references/iss-063-cron-prompt-doc-drift.md`
- `references/v1.0.8-masking-pipeline.md`
- `references/iss-065-python-3-8-future-annotations.md`
