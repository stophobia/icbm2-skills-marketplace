# 아키텍처 문서 템플릿

이 템플릿은 `ai-gm-core` (2026-06-12 세션)에서 검증된 풀 디자인 문서 형식입니다. 새 게임 빌더 시작 시 이 형식으로 `~/.openclaw/workspace/<name>-architecture.md`에 작성하세요.

## 권장 섹션 순서

1. **컨셉 한 줄** — 무엇이고 왜 필요한지
2. **핵심 설계 원칙** — 3~5개 (각 1문장)
3. **매 턴 컨텍스트 구조** — 코드 블록으로 Tier 0~4
4. **데이터 모델** — 게임 디렉토리 트리 + JSON 스키마
5. **MCP 도구 규약** — 읽기/쓰기/메타 카테고리별 표
6. **시스템 플로우 다이어그램** — ASCII 박스 다이어그램
7. **저장소 구조** — 코어 + 플러그인 멀티 repo 트리
8. **단계별 실행 계획** — Phase 0~5 + 각 phase의 status
9. **참조 출처** — URL + 각 자료의 활용법

## 체크리스트

- [ ] 데이터 모델에 Chunk 분류 규칙 명시
- [ ] MCP 도구별로 부수효과(side effects) 명시
- [ ] 자동화 파이프라인 트리거 조건 (턴 종료 / 10턴 / 챕터 종료 / 토큰 한계)
- [ ] Phase 0에서 산출되는 파일 목록 (README, LICENSE, .gitignore, 선택적 system_prompt.md)

## 검증된 풀 예시

`/Users/hjshin/.openclaw/workspace/ai-gm-architecture.md` (14KB)
- 5개 핵심 설계 원칙 (P1~P4, 모두 출처 명시)
- 4-Tier 컨텍스트 구조
- 7-엔티티 JSON 스키마 (nation, character, province, unit, war, treaty, event_chain)
- 13개 MCP 도구 (읽기 5 / 쓰기 5 / 메타 4)
- ASCII 시스템 플로우 다이어그램
- Phase 0~4 로드맵
- 5개 참조 출처 (LoreKit, NarrativeEngine-P, SillyTavern, Anthropic, ACON)

## 절대 빠지면 안 되는 것

- **"AI는 숫자를 만지지 않는다"** 원칙을 P1에 명시 (출처: LoreKit)
- **Chunk prefix 형식** (`[CHUNK: TYPE -- NAME]`) — 분류 자동화의 전제
- **Phase 0 = 설계 + README**, **Phase 1+ = 다른 PC** — 작업 경계 명확화
