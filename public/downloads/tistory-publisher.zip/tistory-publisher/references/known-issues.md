# Tistory Publisher Known Issues

## 🔴 이미지 + 개행 누락 (High Priority — 2개월+ 미해결)
**추적:** learning-gap-tracker `lg-20260420-001` (high)
**발생:** 2026-04-20 21시 첫 보고
**증상:** 발행된 글에서 이미지가 표시되지 않고, 개행(line break)이 완전히 사라짐
**현재 상태:** 우회적으로 Picsum 이미지 + 수동 개행 처리 중. 근본 원인 미확인.
**분석 필요:** `markdown_to_tistory_html.py`의 HTML 생성 로직 — Tistory CMS에 올리는 HTML의 `<img>` 태그와 `<br>` 태그 처리 방식

---

## 🟡 Japanese Katakana 정제 누락
**발견일:** 2026-05-22, 69차 루프
**증상:** 제목에 Japanese Katakana 혼입 (`コントロール`, `ターミナル` 등)
**원인:** CJK 종합 사전 Katakana 항목에 미등록 문자 존재
**누락 확인 문자:**
| 문자 | 발음 | 유입 경로 |
|------|------|----------|
| `ビ` | 비 | コントロール 등 |
| `ュ` | 유 | ターミナル 등 |
| `レ` | 레 | Various Katakana terms |
**현재 대응:** targeted final-pass로 제거 중
**해결책:** 종합 사전 Katakana 항목에 위 문자 추가

---

## 🟡 제목 Japanese 혼입
**발견일:** 2026-05-21 20시
**증상:** 제목 생성 시 Japanese 텍스트가 섞여 들어감
**원인:** 제목 생성 프롬프트에 Korean-only 검증 미실행
**해결책:** 제목 생성 단계에 Korean-only 검증 추가

---

## 📝 출력 파일 블로트
**문제:** Tistory 발행 cron (`b1bca63a117a`) 출력 파일이 50개 이상 축적
**해결:** 3일 이상 `.md` 파일 자동 삭제
```bash
find ~/.hermes/cron/output/b1bca63a117a/ -name "*.md" -mtime +3 -delete
```