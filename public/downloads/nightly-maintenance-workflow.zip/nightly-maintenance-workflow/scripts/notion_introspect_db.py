#!/usr/bin/env python3
"""Notion DB schema introspector — prints property names + types.

Used by nightly-maintenance-workflow 4단계 (Notion 정비 리포트 기록) to
verify the Maintenance DB schema before composing the page payload.
First POST 400 회피용 (06-22 03:30 실측).

Usage:
    python3 notion_introspect_db.py <database_id>

Token read at runtime from ~/.hermes/secrets/notion_token.txt — no
Bearer literal in this file (ISS-061 회귀 방지).
"""
import json
import sys
import urllib.request
from pathlib import Path


def main(db_id: str) -> int:
    token_path = Path.home() / ".hermes/secrets/notion_token.txt"
    token = token_path.read_text().strip()

    req = urllib.request.Request(
        f"https://api.notion.com/v1/databases/{db_id}",
        headers={"Authorization": "Bearer " + token, "Notion-Version": "2022-06-28"},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            db = json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        print(f"HTTP {e.code}: {e.reason}", file=sys.stderr)
        print(e.read().decode()[:500], file=sys.stderr)
        return 1
    except Exception as e:
        print(f"ERR: {e}", file=sys.stderr)
        return 1

    print("Properties:")
    for name, prop in db.get("properties", {}).items():
        extra = ""
        if prop.get("type") == "select":
            opts = prop.get("select", {}).get("options", [])
            extra = " options=" + str([o["name"] for o in opts])
        print(f"  - {name}: type={prop.get('type')}{extra}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: notion_introspect_db.py <database_id>", file=sys.stderr)
        sys.exit(2)
    sys.exit(main(sys.argv[1]))
