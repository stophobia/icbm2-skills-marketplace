# Tistory 장애 복구 레퍼런스

> 이 파일은 `tistory-publisher` 스킬의 일부입니다. 발행 장애 시의 복구 절차를 기록합니다.

## 장애 복구 절차

### 1. 장애 확인
```bash
# 크론 잡 로그 확인
tail -n 50 ~/.hermes/logs/cron.log | grep "<job_id>"
```

### 2. 수동 발행
```bash
python3 ~/.hermes/scripts/tistory_publisher.py \
  --title "제목" \
  --content "<p>HTML 내용</p>" \
  --tags "태그1,태그2" \
  --visibility public
```

## Known Issues

| 문제 | 해결 |
|------|------|
| HTTP 403 (일일 공개 발행 한도 초과) | --visibility private로 발행 후 Tistory 관리자에서 공개로 전환 |
| HTTP 500 / 세션 만료 | 새 쿠키 복사 후 ~/.hermes/secrets/tistory.env 갱신 |
| 빈글이 발행됨 | tistory_publisher.py 버전 확인 (Git sync 3:30 AM) |
