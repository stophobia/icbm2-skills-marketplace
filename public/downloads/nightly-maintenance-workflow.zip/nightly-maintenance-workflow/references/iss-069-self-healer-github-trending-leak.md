# ISS-069 — Self-Healer FP 4회째 메타 트랩: GitHub Trending 잡 신규 경로 (2026-06-14 등록)

## 요약

**발견일:** 2026-06-14 03:30 KST
**상태:** 🟡 진행중
**심각도:** 🟡 경고
**등록 근거:** SKILL.md "메모리 업데이트 규칙" 3회 반복 임계는 ISS-068에서 이미 도달. ISS-069는 **3번째 잡이 trap 공급원으로 전환**한 **신규 경로** (확장 이벤트)로 별도 등록.
**관련:** ISS-062/063/065/066/067/068 — Self-Healer FP 메타 트랩 시리즈 6번째

## 누적 카운트 (06-14 03:30 확정)

| 날짜 | FP 에러 수 | 누적 | 임계 | 매칭 잡 |
|------|----------|------|------|---------|
| 06-10 03:30 | 2 | 1 | - | b1bca63a117a Tistory |
| 06-12 03:30 | 2 | 2 | - | 5d0f14aef84c + b1bca63a117a |
| 06-13 03:30 | 2 | 3 | ✅ ISS-068 등록 | 5d0f14aef84c + 81f1c81f8664 (신규) |
| **06-14 03:30** | **3** | **4** | **⚠️ ISS-069 등록 (확장)** | 5d0f14aef84c + 81f1c81f8664 + **26b0579a45f (GitHub Trending, 신규)** |

## 06-14 03:30 매칭 디테일

### 잡 1: `5d0f14aef84c` (일일 자기 개선 리뷰) — TimeoutError
- 매칭 라인: `5d0f14aef84c/2026-06-13_22-*.md` 일일리뷰 자기 진단 본문
- **분류:** ISS-063 계열 (자기 진단 본문)
- jobs.json: `consecutive_failures: 0` ✅

### 잡 2: `81f1c81f8664` (심야 통합 점검) — TimeoutError
- 매칭 라인: `81f1c81f8664/2026-06-13_03-33-28.md` 어제 self_heal 리포트 인용
- **분류:** ISS-068 계열 (자기 리포트 leak)
- jobs.json: `consecutive_failures: 0` ✅

### 잡 3: `26b0579a45f` (GitHub Trending + Release 모니터) — TimeoutError 🆕 신규 잡
- 매칭 라인: GitHub Trending 잡 자기 자신의 출력에 self-healer trigger 단어 (`TimeoutError`, `api error`) 가 informational 텍스트로 leak
- **분류:** ISS-069 (3번째 trap 공급 잡)
- jobs.json: `consecutive_failures: 0` ✅

## ISS-069 고유 패턴 정의

### 왜 ISS-068 5차 patch의 라인 마커로도 차단 못했나

ISS-068 권고 마커 (이 reference에 정리됨):
- `**Symptom:**` / `**원인:**` / `**해결:**` (Tistory)
- `TimeoutError N건 매칭 모두 자기 진단` (심야통합)
- `⚠️ timeout (N일 연속)` (일일리뷰)

`26b0579a45f` (GitHub Trending) 케이스:
- GH Trending 잡의 자기 진단 표 (`| 09:00 | GH Trending | 🟡 timeout (2일 연속) |`) 가 **다른 잡의 일일리뷰 표에 인용**됨
- 즉, **트랩의 원천은 일일리뷰 잡의 표**이지만, **GH Trending 잡이 trap 결과를 자기 출력에 다시 인용**하면서 GH Trending 잡이 매칭 잡으로 올라옴
- **순환 참조**: 일일리뷰 표 → 심야통합 리포트 → GH Trending 잡 본문 → self-healer regex

### ISS-069 패턴 식별 기준

1. self-healer errors ≥ 3 (06-14 케이스: 3 errors)
2. 매칭 잡 3개: `5d0f14aef84c` (일일리뷰) + `81f1c81f8664` (심야통합) + `26b0579a45f` (GitHub Trending)
3. 매칭 라인이 **일일리뷰의 GH Trending timeout 진단 표**를 직접/간접 인용
4. `26b0579a45f`의 `last_ok` 최근, `consecutive_failures: 0`
→ **ISS-069 패턴 — GitHub Trending 잡이 trap 공급망에 추가, 6차 patch + 진단 표 격리 권장**

## patch 권장 (06-14 22:00 일일 리뷰)

### 1. mask_self_healer_terms.py 라인 마커 추가 (ISS-068 권고 + 1개)

기존 마커에 추가:
```python
# ISS-069 — 일일리뷰 GH Trending 진단 표 행 마커
'| 09:00 | GH Trending',          # 5d0f14aef84c 일일리뷰 진단 표
'GH Trending 모니터 |',            # self-heal 리포트 인용
'| ⚠️ timeout (',                 # GH Trending timeout 진단 셀
'🟡 timeout (',                   # GH Trending timeout 진단 셀 (이모지 변형)
```

### 2. cron_self_healer.py 5차 patch (ISS-068 권고 + ISS-069 확장)

`KNOWN_ISSUES_MARKERS`에 추가:
```python
# ISS-069 — 일일리뷰 GH Trending 진단 표 leak
'| 09:00 | GH Trending',
'GH Trending 모니터 |',
'🟡 timeout (', '⚠️ timeout (',
```

### 3. daily-self-review SKILL.md 진단 표 격리 (신규 권장)

`daily-self-review` SKILL.md의 "**심야 점검 결과**" 표 안에 다음 행은 cron output에 직접 출력하지 말 것:
- `| 09:00 | GH Trending | 🟡 timeout (2일 연속) |`
- `| 09:00 | GH Trending | ⚠️ 43개 (전일 timeout 회피) |`

대신 `references/iss-069-diagnosis-tables.md`로 격리, 일일리뷰 본문에서는 "GH Trending timeout 이슈 진행중, 상세: references/iss-069-diagnosis-tables.md" 한 줄로 단축.

### 4. 검증 (06-15 03:30)

```bash
python3 scripts/cron_self_healer.py 2>&1 | grep -E 'errors|fixes'
```
- ISS-068/069/067 #2/063 계열 0건 → patch 성공 ✅
- 1건 이상 → 6차 patch 미흡, 추가 마커 + 7차 patch 검토

## 누적 임계 추적 (ISS-068 + ISS-069 동시)

| 날짜 | FP 에러 수 | 누적 | 임계 | 매칭 잡 |
|------|----------|------|------|---------|
| 06-10 | 2 | 1 | - | b1bca63a117a |
| 06-12 | 2 | 2 | - | 5d0f14aef84c + b1bca63a117a |
| 06-13 | 2 | 3 | ✅ ISS-068 | 5d0f14aef84c + 81f1c81f8664 (신규) |
| 06-14 | 3 | 4 | ⚠️ ISS-069 | + 26b0579a45f (신규) |
| 06-15 (예정) | ? | - | 0건 = ✅ | patch 적용 시 0건 예상 |
| 06-16 (예정) | ? | - | 0건 안정 | 4일째 안정 시 ISS-068/069 ✅ |

## 부록: 06-14 03:30 Notion API shell escaping 함정

`terminal`에서 `$(cat file)` + `Bearer ${TOKEN}` 조합은 multi-line `\` 라인 연속을 쓰면 heredoc이 중간에 잘려 SyntaxError 발생 (실측):

```text
/bin/bash: eval: line 12: unexpected EOF while looking for matching `'`
/bin/bash: eval: line 12: syntax error: unexpected end of file
```

**해결 (검증됨, 06-14 03:30)**: 1줄 single-line `&&` 체이닝, 또는 `python3 + urllib.request` 폴백(#2) 사용.

1줄 single-line 예시:
```bash
TOKEN=*** ~/.hermes/secrets/notion_token.txt | tr -d '\n') && curl -s -X POST "https://api.notion.com/v1/pages" -H "Authorization: Bearer *** -H "Notion-Version: 2022-06-28" -H "Content-Type: application/json" --data-binary @/tmp/payload.json -o /tmp/resp.json
```

**중요:** `Bearer ${TOKEN}` 변수 사용 시 마스킹 함정(ISS-061)을 피하려면 **반드시 `Bearer ${TOKEN}` 형태 (따옴표 없이, 변수명 마스킹 자동 우회)** — 절대 `Bearer xxx` 평문 literal 금지.

## 관련 reference

- `references/iss-068-self-healer-integration-review-leak.md` — 5차 patch 상세 (이 reference의 patch 권고에 통합)
- `references/iss-067-publisher-known-issues-leak.md` — 4번째 메타 트랩
- `references/iss-063-self-healer-daily-review-fp.md` — 2번째 메타 트랩
- SKILL.md "ISS-064 — Notion 토큰 일시 회복 가설 폐기" — 환경 이슈 패턴
- `memory/issues.md` 06-14 발견 섹션 — ISS-069 row
- `memory/MEMORY.md` "알려진 이슈" — ISS-069 진행중 추가됨 (06-14)
