---
name: llm-wiki
description: "Karpathy's LLM Wiki — build and maintain a persistent, interlinked markdown knowledge base. Ingest sources, query compiled knowledge, and lint for consistency."
version: 2.1.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [wiki, knowledge-base, research, notes, markdown, rag-alternative]
    category: research
    related_skills: [obsidian, arxiv, agentic-research-ideas]
    config:
      - key: wiki.path
        description: Path to the LLM Wiki knowledge base directory
        default: "~/wiki"
        prompt: Wiki directory path
---

# Karpathy's LLM Wiki

Build and maintain a persistent, compounding knowledge base as interlinked markdown files.
Based on [Andrej Karpathy's LLM Wiki pattern](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f).

Unlike traditional RAG (which rediscovers knowledge from scratch per query), the wiki
compiles knowledge once and keeps it current. Cross-references are already there.
Contradictions have already been flagged. Synthesis reflects everything ingested.

**Division of labor:** The human curates sources and directs analysis. The agent
summarizes, cross-references, files, and maintains consistency.

## When This Skill Activates

Use this skill when the user:
- Asks to create, build, or start a wiki or knowledge base
- Asks to ingest, add, or process a source into their wiki
- Asks a question and an existing wiki is present at the configured path
- Asks to lint, audit, or health-check their wiki
- References their wiki, knowledge base, or "notes" in a research context

## Wiki Location

**The wiki lives at `~/wiki`** (not `~/.hermes/llm-wiki/` — that directory is empty/unused).

```bash
# Verify before starting
ls ~/wiki/SCHEMA.md   # must exist
```

When the skill injects `wiki.path`, it resolves `~/wiki` to the actual home directory.
If orientation reads fail (SCHEMA.md not found), check `~/wiki` first before assuming
the wiki doesn't exist.

Falls back to `~/wiki` default. The resolved path is injected when this
skill loads — check the `[Skill config: ...]` block above for the active value.

The wiki is just a directory of markdown files — open it in Obsidian, VS Code, or
any editor. No database, no special tooling required.

## Architecture: Three Layers

```
wiki/
├── SCHEMA.md           # Conventions, structure rules, domain config
├── index.md            # Sectioned content catalog with one-line summaries
├── log.md              # Chronological action log (append-only, rotated yearly)
├── raw/                # Layer 1: Immutable source material
- `raw/articles/` — Web articles, clippings
- `raw/papers/` — PDFs, arxiv papers
- `raw/transcripts/` — Meeting notes, interviews
- `raw/assets/` — Images, diagrams referenced by sources
├── entities/           # Layer 2: Entity pages (people, orgs, products, models)
├── concepts/           # Layer 2: Concept/topic pages
├── comparisons/        # Layer 2: Side-by-side analyses
├── queries/            # Layer 2: Filed query results worth keeping
└── references/         # Skill-internal: case studies, runbooks, deep-dive notes
└── patch-disaster-case-studies.md — Real-world patch failures in this skill with safe patterns
```

**Layer 1 — Raw Sources:** Immutable. The agent reads but never modifies these.
**Layer 2 — The Wiki:** Agent-owned markdown files. Created, updated, and
cross-referenced by the agent.
**Layer 3 — The Schema:** `SCHEMA.md` defines structure, conventions, and tag taxonomy.

## Resuming an Existing Wiki (CRITICAL — do this every session)

When the user has an existing wiki, **always orient yourself before doing anything**:

① **Read `SCHEMA.md`** — understand the domain, conventions, and tag taxonomy.
② **Read `index.md`** — learn what pages exist and their summaries.
③ **Scan recent `log.md`** — read the last 20-30 entries to understand recent activity.

```bash
WIKI="${wiki_path:-$HOME/wiki}"
# Orientation reads at session start
read_file "$WIKI/SCHEMA.md"
read_file "$WIKI/index.md"
read_file "$WIKI/log.md" offset=<last 30 lines>
```

Only after orientation should you ingest, query, or lint. This prevents:
- Creating duplicate pages for entities that already exist
- Missing cross-references to existing content
- Contradicting the schema's conventions
- Repeating work already logged

For large wikis (100+ pages), also run a quick `search_files` for the topic
at hand before creating anything new.

## Initializing a New Wiki

When the user asks to create or start a wiki:

1. Determine the wiki path (from config, env var, or ask the user; default `~/wiki`)
2. Create the directory structure above
3. Ask the user what domain the wiki covers — be specific
4. Write `SCHEMA.md` customized to the domain (see template below)
5. Write initial `index.md` with sectioned header
6. Write initial `log.md` with creation entry
7. Confirm the wiki is ready and suggest first sources to ingest

### SCHEMA.md Template

Adapt to the user's domain. The schema constrains agent behavior and ensures consistency:

```markdown
# Wiki Schema

## Domain
[What this wiki covers — e.g., "AI/ML research", "personal health", "startup intelligence"]

## Conventions
- File names: lowercase, hyphens, no spaces (e.g., `transformer-architecture.md`)
- Every wiki page starts with YAML frontmatter (see below)
- Use `[[wikilinks]]` to link between pages (minimum 2 outbound links per page)
- When updating a page, always bump the `updated` date
- Every new page must be added to `index.md` under the correct section
- Every action must be appended to `log.md`

## Frontmatter
  ```yaml
  ---
  title: Page Title
  created: YYYY-MM-DD
  updated: YYYY-MM-DD
  type: entity | concept | comparison | query | summary
  tags: [from taxonomy below]
  sources: [raw/articles/source-name.md]
  ---
  ```

## Tag Taxonomy
[Define 10-20 top-level tags for the domain. Add new tags here BEFORE using them.]

Example for AI/ML:
- Models: model, architecture, benchmark, training
- People/Orgs: person, company, lab, open-source
- Techniques: optimization, fine-tuning, inference, alignment, data
- Meta: comparison, timeline, controversy, prediction

Rule: every tag on a page must appear in this taxonomy. If a new tag is needed,
add it here first, then use it. This prevents tag sprawl.

## Page Thresholds
- **Create a page** when an entity/concept appears in 2+ sources OR is central to one source
- **Add to existing page** when a source mentions something already covered
- **DON'T create a page** for passing mentions, minor details, or things outside the domain
- **Split a page** when it exceeds ~200 lines — break into sub-topics with cross-links
- **Archive a page** when its content is fully superseded — move to `_archive/`, remove from index

## Entity Pages
One page per notable entity. Include:
- Overview / what it is
- Key facts and dates
- Relationships to other entities ([[wikilinks]])
- Source references

## Concept Pages
One page per concept or topic. Include:
- Definition / explanation
- Current state of knowledge
- Open questions or debates
- Related concepts ([[wikilinks]])

## Comparison Pages
Side-by-side analyses. Include:
- What is being compared and why
- Dimensions of comparison (table format preferred)
- Verdict or synthesis
- Sources

## Update Policy
When new information conflicts with existing content:
1. Check the dates — newer sources generally supersede older ones
2. If genuinely contradictory, note both positions with dates and sources
3. Mark the contradiction in frontmatter: `contradictions: [page-name]`
4. Flag for user review in the lint report
```

### index.md Template

The index is sectioned by type. Each entry is one line: wikilink + summary.

```markdown
# Wiki Index

> Content catalog. Every wiki page listed under its type with a one-line summary.
> Read this first to find relevant pages for any query.
> Last updated: YYYY-MM-DD | Total pages: N

## Entities
<!-- Alphabetical within section -->

## Concepts

## Comparisons

## Queries
```

**Scaling rule:** When any section exceeds 50 entries, split it into sub-sections
by first letter or sub-domain. When the index exceeds 200 entries total, create
a `_meta/topic-map.md` that groups pages by theme for faster navigation.

### log.md Template

```markdown
# Wiki Log

> Chronological record of all wiki actions. Append-only.
> Format: `## [YYYY-MM-DD] action | subject`
> Actions: ingest, update, query, lint, create, archive, delete
> When this file exceeds 500 entries, rotate: rename to log-YYYY.md, start fresh.

## [YYYY-MM-DD] create | Wiki initialized
- Domain: [domain]
- Structure created with SCHEMA.md, index.md, log.md
```

## Core Operations

### 1. Ingest

When the user provides a source (URL, file, paste), integrate it into the wiki:

① **Capture the raw source:**
   - URL → use `web_extract` to get markdown, save to `raw/articles/`
   - PDF → use `web_extract` (handles PDFs), save to `raw/papers/`
   - Pasted text → save to appropriate `raw/` subdirectory
   - Name the file descriptively: `raw/articles/karpathy-llm-wiki-2026.md`

② **Discuss takeaways** with the user — what's interesting, what matters for
   the domain. (Skip this in automated/cron contexts — proceed directly.)

③ **Check what already exists** — search index.md and use `search_files` to find
   existing pages for mentioned entities/concepts. This is the difference between
   a growing wiki and a pile of duplicates.

④ **Write or update wiki pages:**
   - **New entities/concepts:** Create pages only if they meet the Page Thresholds
     in SCHEMA.md (2+ source mentions, or central to one source)
   - **Existing pages:** Add new information, update facts, bump `updated` date.
     When new info contradicts existing content, follow the Update Policy.
   - **Cross-reference:** Every new or updated page must link to at least 2 other
     pages via `[[wikilinks]]`. Check that existing pages link back.
   - **Tags:** Only use tags from the taxonomy in SCHEMA.md

⑤ **Update navigation:**
   - Add new pages to `index.md` under the correct section, alphabetically
   - Update the "Total pages" count and "Last updated" date in index header
   - Append to `log.md`: `## [YYYY-MM-DD] ingest | Source Title`
   - List every file created or updated in the log entry

⑥ **Report what changed** — list every file created or updated to the user.

A single source can trigger updates across 5-15 wiki pages. This is normal
and desired — it's the compounding effect.

### 2. Query

When the user asks a question about the wiki's domain:

① **Read `index.md`** to identify relevant pages.
② **For wikis with 100+ pages**, also `search_files` across all `.md` files
   for key terms — the index alone may miss relevant content.
③ **Read the relevant pages** using `read_file`.
④ **Synthesize an answer** from the compiled knowledge. Cite the wiki pages
   you drew from: "Based on [[page-a]] and [[page-b]]..."
⑤ **File valuable answers back** — if the answer is a substantial comparison,
   deep dive, or novel synthesis, create a page in `queries/` or `comparisons/`.
   Don't file trivial lookups — only answers that would be painful to re-derive.
⑥ **Update log.md** with the query and whether it was filed.

### 3. Lint

When the user asks to lint, health-check, or audit the wiki:

① **Orphan pages:** Find pages with no inbound `[[wikilinks]]` from other pages.
```python
# Use execute_code for this — programmatic scan across all wiki pages
import os, re
from collections import defaultdict
wiki = "<WIKI_PATH>"
# Scan all .md files in entities/, concepts/, comparisons/, queries/
# Extract all [[wikilinks]] — build inbound link map
# Pages with zero inbound links are orphans
```

② **Broken wikilinks:** Find `[[links]]` that point to pages that don't exist.

③ **Index completeness:** Every wiki page should appear in `index.md`. Compare
   the filesystem against index entries.

④ **Frontmatter validation:** Every wiki page must have all required fields
   (title, created, updated, type, tags, sources). Tags must be in the taxonomy.

⑤ **Stale content:** Pages whose `updated` date is >90 days older than the most
   recent source that mentions the same entities.

⑥ **Contradictions:** Pages on the same topic with conflicting claims. Look for
   pages that share tags/entities but state different facts.

⑦ **Page size:** Flag pages over 200 lines — candidates for splitting.

⑧ **Tag audit:** List all tags in use, flag any not in the SCHEMA.md taxonomy.

⑨ **Log rotation:** If log.md exceeds 500 entries, rotate it.

⑩ **Report findings** with specific file paths and suggested actions, grouped by
   severity (broken links > orphans > stale content > style issues).

⑪ **Append to log.md:** `## [YYYY-MM-DD] lint | N issues found`

## Working with the Wiki

### Searching

```bash
# Find pages by content
search_files "transformer" path="$WIKI" file_glob="*.md"

# Find pages by filename
search_files "*.md" target="files" path="$WIKI"

# Find pages by tag
search_files "tags:.*alignment" path="$WIKI" file_glob="*.md"

# Recent activity
read_file "$WIKI/log.md" offset=<last 20 lines>
```

When the user asks to sync Notion Dev News to the wiki (cron job pattern):

1. **Run the collector script** — `python3 ~/.hermes/scripts/notion_news_to_wiki.py`
2. **Read the output** — it tells you how many new items and what to do
3. **Idempotency check** — search recent `log.md` entries for the item titles. If all items in the digest were processed in the most recent sync entry, log a no-op and stop. (See "Idempotency" pitfall below.)
4. **Orient on the wiki** — always read SCHEMA, index, and recent log first
5. **Check existing pages before creating** — use `search_files` or `ls` to avoid duplicates
   - Qwen → entities/qwen.md (update, don't recreate)
   - Gemini → entities/gemini.md (update, don't recreate)
   - News about tools already in index → skip
   - **Namespace siblings** — if the new name shares a prefix with existing pages (`oh-my-*`, `qwen*`, `claude-code-*`), list siblings and check whether this is a fork/spinoff before creating.
6. **Fetch content** for new entities using `mcp_ddg_search_fetch_content`
7. **Verify wikilink targets exist** before writing — for every `[[link]]` you plan to add, `ls` the relevant directory (entities/, concepts/, comparisons/, queries/) and confirm the slug exists. Convert non-existent links to plain text or CREATE the target page first. This is the #1 source of broken wikilinks in this workflow.
8. **Create new entity pages** — 5 required fields in frontmatter, [[wikilinks]] to 2+ existing pages
9. **Update existing pages** — append new section, bump `updated`, add source URL
10. **Update index.md** — add new pages **alphabetically** (verify neighbor order before patching), update header date/count. See "Alphabetical insertion" pitfall.
11. **Append to log.md** — single batch entry with all created/updated/skipped items
12. **Report** — bullet list of created/updated pages

**Common skipping rules (apply strictly to avoid wiki bloat):**
- Personal project promotions ("I built this and want to share") → skip
- Tools already registered in previous sync → skip, note as "already registered"
- Items outside the owner's interest domain → skip with reason
- **Single video tutorials** (YouTube content where the article describes video without showing the actual content/script) → skip — insufficient detail to extract entity/concept
- **Single hardware-specific use cases** (e.g., "Mac mini + Qwen 3.5 running locally") → skip — single data point, no new concept/pattern
- **Tools with insufficient content** (articles with vague descriptions, no specifics on capabilities or architecture) → skip — Wiki registration requires substantive info

**Idempotency (critical for cron runs):** the collector script may return the
same items on re-runs if the Notion DB is not marked. Before starting, search
`log.md` for the recent sync entries and their item titles — if every item in
the digest already appears in the most recent log entry, log a no-op entry
(`## [YYYY-MM-DD] ingest | no-op — N items already processed on <date>`) and
stop. The collector script SHOULD mark processed items in Notion (e.g. set a
`Processed` checkbox or append to a `Wiki-synced` log). If it doesn't, file a
skill patch / upstream report — do not silently re-ingest.

**Namespace sibling check (avoid reinventing the wheel):** when the new item's
name shares a prefix with existing pages, scan for siblings before creating.
- `oh-my-harness` arriving → check for `oh-my-agent`, `oh-my-customcode`, etc.
- `qwen-3-7` arriving → check for `qwen`, `qwen3-6-27b`, `qwen3-7-max`
- This both informs cross-references AND catches the case where the "new" tool
  is actually a fork/spinoff of an existing one (consolidate, don't duplicate).

**Alphabetical insertion in index.md is mandatory and case-sensitive on the
lowercased form.** Before patching, read the current neighbors and pick the
exact insertion point. Common footguns:
- `n` comes before `t`, NOT after — `notebooklm-canvas` goes after `nvidia-nim`,
  before `natnest`/`oh-my-*`, NOT after `talkmode`/`tokenmon`/`tokenova`
- Hyphens sort BEFORE letters in some orderings, AFTER in others. The wiki
  convention (set in SCHEMA.md) is: lowercase, hyphens preserved, sort
  character-by-character. Verify with the actual neighbors in `index.md`.
- If uncertain, do ONE large patch that lists all new entities together in the
  correct order, rather than multiple near-each-other patches.

**Reading the collector script output:**
The script at `~/.hermes/scripts/notion_news_to_wiki.py` outputs structured guidance:
```
## Notion Dev News → LLM Wiki 동기화
날짜: YYYY-MM-DD
신규 항목: N건

### 오늘 추가된 뉴스/기사
1. [카테고리]  제목
   URL: https://...

## 지시사항
### 1. 취향 분석
...
### 2. LLM Wiki에 등록
...
```
The output itself contains the skip criteria and ingestion instructions — follow it exactly rather than improvising.

### Archiving

When content is fully superseded or the domain scope changes:
1. Create `_archive/` directory if it doesn't exist
2. Move the page to `_archive/` with its original path (e.g., `_archive/entities/old-page.md`)
3. Remove from `index.md`
4. Update any pages that linked to it — replace wikilink with plain text + "(archived)"
5. Log the archive action

### Obsidian Integration

The wiki directory works as an Obsidian vault out of the box:
- `[[wikilinks]]` render as clickable links
- Graph View visualizes the knowledge network
- YAML frontmatter powers Dataview queries
- The `raw/assets/` folder holds images referenced via `![[image.png]]`

For best results:
- Set Obsidian's attachment folder to `raw/assets/`
- Enable "Wikilinks" in Obsidian settings (usually on by default)
- Install Dataview plugin for queries like `TABLE tags FROM "entities" WHERE contains(tags, "company")`

If using the Obsidian skill alongside this one, set `OBSIDIAN_VAULT_PATH` to the
same directory as the wiki path.

### Obsidian Headless (servers and headless machines)

On machines without a display, use `obsidian-headless` instead of the desktop app.
It syncs vaults via Obsidian Sync without a GUI — perfect for agents running on
servers that write to the wiki while Obsidian desktop reads it on another device.

**Setup:**
```bash
# Requires Node.js 22+
npm install -g obsidian-headless

# Login (requires Obsidian account with Sync subscription)
ob login --email <email> --password '<password>'

# Create a remote vault for the wiki
ob sync-create-remote --name "LLM Wiki"

# Connect the wiki directory to the vault
cd ~/wiki
ob sync-setup --vault "<vault-id>"

# Initial sync
ob sync

# Continuous sync (foreground — use systemd for background)
ob sync --continuous
```

**Continuous background sync via systemd:**
```ini
# ~/.config/systemd/user/obsidian-wiki-sync.service
[Unit]
Description=Obsidian LLM Wiki Sync
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/path/to/ob sync --continuous
WorkingDirectory=/home/user/wiki
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
```

```bash
systemctl --user daemon-reload
systemctl --user enable --now obsidian-wiki-sync
# Enable linger so sync survives logout:
sudo loginctl enable-linger $USER
```

This lets the agent write to `~/wiki` on a server while you browse the same
vault in Obsidian on your laptop/phone — changes appear within seconds.

## Pitfalls

- **Never modify files in `raw/`** — sources are immutable. Corrections go in wiki pages.- **Always orient first** — read SCHEMA + index + recent log before any operation in a new session.
  Skipping this causes duplicates and missed cross-references.
- **Always update index.md and log.md** — skipping this makes the wiki degrade. These are the
  navigational backbone.
- **Don't create pages for passing mentions** — follow the Page Thresholds in SCHEMA.md. A name
  appearing once in a footnote doesn't warrant an entity page.
- **Don't create pages without cross-references** — isolated pages are invisible. Every page must
  link to at least 2 other pages.
- **Frontmatter is required** — it enables search, filtering, and staleness detection.
- **Tags must come from the taxonomy** — freeform tags decay into noise. Add new tags to SCHEMA.md
  first, then use them.
- **Keep pages scannable** — a wiki page should be readable in 30 seconds. Split pages over
  200 lines. Move detailed analysis to dedicated deep-dive pages.
- **Ask before mass-updating** — if an ingest would touch 10+ existing pages, confirm
  the scope with the user first.
- **Rotate the log** — when log.md exceeds 500 entries, rename it `log-YYYY.md` and start fresh.
  The agent should check log size during lint.
- **Handle contradictions explicitly** — don't silently overwrite. Note both claims with dates,
  mark in frontmatter, flag for user review.
- **When patching index.md for multiple new entries, use unique context per patch** — if you try to patch the same "before/after" pair twice in one session (e.g., adding two entries near the same existing line), `replace_all=false` may match the first replacement and then fail to find a unique match for the second. Solution: patch each entry with enough surrounding context to be unique, or batch multiple new entries into a single larger patch.
- **Never invent `[[wikilinks]]` to pages that don't exist.** Every `[[link]]` you write is a promise to the next agent (and the user, in Obsidian's graph view) that a page exists at that slug. If you write `[[categories/coding-agent-tools]]` because it sounds like a good organizational idea, you've added a broken wikilink. Two safe patterns:
  - If a real page exists, link to it (`[[oh-my-agent]]`).
  - If a "category" page would be useful, CREATE the page first (or note in the entity's "분류" section that a category page is pending, and use plain text not a wikilink).
  - **Pre-write verification step**: before writing any entity page, run `ls ~/wiki/entities/ ~/wiki/concepts/ ~/wiki/comparisons/ ~/wiki/queries/` and check each `[[wikilink]]` slug against the actual file list. Convert non-existent slugs to plain text BEFORE writing — not after. Broken wikilinks are noise the next lint run has to clean up.
  - Lint step ② (broken wikilinks) will catch these, but it's much better to not create them in the first place.
- **Adding a new section header to an existing page (e.g. "### 13. 바이브 코딩") is fine, but read the file end-to-end first** — if the page already has 12 numbered sections, your new one is 13, not the next free number you remember. Skim the bottom of the file before patching.
- **Patching a file to "insert section N+1 between section N-1 and section N" is the most common patch-disaster pattern** in this skill. The risk: `old_string` is the unique anchor that includes section N's header (because that's the only distinctive text near the end of the file), but `new_string` is just the new section N+1 — so the patch *deletes* section N's header while inserting section N+1. The result is a structurally broken file. Three safe patterns:
  - **Append at end of file** — read the file, find the last `### N.` header + its first line. Patch by replacing those last lines with `### N. first line` + blank line + `### N+1. (new section)`. The new_string must include the last section's original text so it isn't lost.
  - **Insert before an existing section** — `old_string` = the EXISTING section's header + its first line. `new_string` = `### N+1. (new section content)` + blank line + (the existing section's header + first line, verbatim). This preserves the existing section and inserts above it.
  - **Never** craft an `old_string` that spans across two sections with the intent of "splitting" them. The patch tool does string replacement — it has no concept of section boundaries.
  - **Always re-read the patched file** after the patch to verify section count and headers survived. One re-read after a structural patch is cheap insurance.
- **Concept pages can be created from a single source if the concept is named in industry coverage** (e.g. "Vibe Coding" is a recognized term in 2026 coverage). But the threshold still applies: 1 source = concept must be *central* to that source, not a passing phrase. If unsure, prefer adding a section to an existing concept page (e.g. `[[ai-agents-trends-2026]]`) over creating a new concept page.
- **Cross-references must be bidirectional eventually.** When you add `[[oh-my-harness]]` to `oh-my-agent`'s "관련 도구" section, also check whether `oh-my-harness`'s page links back. The cron sync doesn't enforce this — only lint does. For new pages, link forward AND link back from any closely-related page you touched.
- **No-op detection before creating duplicate pages** — when the collector script returns N items, search `log.md` for the most recent sync entry. If every item title appears in that single recent entry, this is a re-run caused by the Notion DB not being marked processed (a known issue with `notion_news_to_wiki.py`). Log a no-op entry (`## [YYYY-MM-DD] ingest | no-op — N items already processed on <date>`) and stop. Don't re-fetch content, don't re-create pages, don't re-update sections. The raw source files for those items will already exist from the previous sync; the entity/concept pages will already exist. Verify by `ls raw/articles/` and `grep` in the most recent log entry.
- **Backlink verification after creating a new entity** — beyond linking forward, immediately patch the top 2-3 most-related existing pages (parent company page, closest concept page, closest sibling entity) to add a backlink. Otherwise the new page is a dead-end (orphan) until the next lint catches it. This is a 1-patch-per-page effort that keeps the graph dense and the next lint clean.
- **When adding a single bullet to a "관련/유사 도구" or similar list, anchor `old_string` on the LAST EXISTING BULLET, not on the section header + blank line** — section headers like `## 관련/유사 도구` are not unique across the wiki, and a trailing blank line is the patch tool's easiest accidental-replacement target. Result of the wrong anchor: the patch replaces the blank line with `## header\n## header\n- new bullet`, duplicating the header. Detection: re-read the patched file end-to-end. Recovery: second patch that matches the duplicated header pair and removes one. See `references/patch-disaster-case-studies.md` Case 4.
- **"Notion JS-only" sources are still Wiki-worthy** — when `mcp_ddg_search_fetch_content` returns "JavaScript must be enabled" (Notion 93-byte response) or similar, do NOT silently skip. If the title is an industry-recognized term AND the concept is already scattered across existing wiki pages, **consolidate**: (1) save `raw/articles/<concept>-YYYY-MM-DD.md` with metadata only and `fetch_status: not_extracted`; (2) create a `concepts/<concept>.md` synthesizing the existing scattered mentions with `[[wikilinks]]` back to them; (3) add backlinks from the scattered pages. See `references/patch-disaster-case-studies.md` Case 5.
- **Alphabetical insertion into index.md — verify the FULL position, not just immediate neighbors** — when adding an entry, read the surrounding 3-4 lines on each side and confirm the new entry's first character lands in the right gap. Common footguns: `loop-` after `local-` (sort by full string), `production-` after `project-` (`pr` matches, sort by `o` vs `r`), `gpt-5-5` before `gemini-*` (numeric vs alpha). Re-read after patching to catch ordering violations. See `references/patch-disaster-case-studies.md` Case 6.
