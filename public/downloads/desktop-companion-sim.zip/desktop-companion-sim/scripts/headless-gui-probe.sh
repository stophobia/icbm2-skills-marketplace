#!/usr/bin/env bash
# headless-gui-probe.sh
# Validate a pygame-based GUI module without a display.
# Usage: headless-gui-probe.sh /path/to/your_module.py
#
# Runs your module under SDL_VIDEODRIVER=dummy so:
# - pygame initializes without a display server
# - all pygame.draw.* calls execute
# - threading is exercised
# - any import/syntax/runtime errors fire immediately
#
# Exits non-zero if the module fails, zero if it runs to completion or
# runs in a loop (we kill after 5s).

set -euo pipefail

MODULE="${1:?Usage: $0 <module.py>}"

if [[ ! -f "$MODULE" ]]; then
  echo "ERROR: $MODULE not found" >&2
  exit 2
fi

echo "=== Headless GUI probe ==="
echo "Module: $MODULE"
echo "Driver: $SDL_VIDEODRIVER"
echo

# Run with timeout. If the module is a daemon-threaded main loop, the timeout
# will kill it; that's expected. We check for clean exit OR for timeout-killed.
SDL_VIDEODRIVER=dummy timeout 5s python3 "$MODULE" || {
  rc=$?
  if [[ $rc -eq 124 ]]; then
    echo "[OK] Module ran for 5s under dummy driver (loop detected, killed by timeout)"
    exit 0
  else
    echo "[FAIL] Module exited with code $rc"
    exit $rc
  fi
}

echo "[OK] Module exited cleanly"
