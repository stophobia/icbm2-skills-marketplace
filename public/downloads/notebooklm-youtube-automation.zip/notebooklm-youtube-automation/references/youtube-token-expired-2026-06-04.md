# YouTube OAuth 토큰 만료 트러블슈팅 (2026-06-04 실측)

## 증상

`notebooklm_upload.py --approved` 실행 시 4개 업로드(2주제 × 일반+Shorts)가 **동시에** 다음 오류로 실패:

```
❌ 업로드 실패: ('invalid_grant: Token has been expired or revoked.', {'error': 'invalid_grant', 'error_description': 'Token has been expired or revoked.'})
```

`notebooklm list`, `prepare`, `download video`, FFmpeg Shorts 변환은 **모두 정상** 완료 — YouTube API 호출 단계에서만 깨짐.

## 1차 진단

```python
import pickle
c = pickle.load(open("/Users/hjshin/.hermes/secrets/youtube_token.pickle", "rb"))
print(c.valid, bool(c.refresh_token))  # False, True
```

→ access_token 만료 + refresh_token 존재. refresh 시도하면 갱신될 것으로 기대.

## 2차 진단 — refresh_token도 폐기됨

```python
from google.auth.transport.requests import Request
c.refresh(Request())
# → ❌ invalid_grant: Token has been expired or revoked.
```

이 상태가 되는 원인:
1. 사용자가 Google 계정 설정에서 수동으로 앱 접근 권한을 **revoke** 했거나
2. 토큰을 6개월 이상 사용하지 않아 Google이 **자동 폐기**했거나
3. client_secret을 재발급 받아 client_id가 바뀌었거나

어느 경우든 **refresh_token은 영구 폐기**되어 재사용 불가 → 풀 OAuth 플로우 필요.

## 해결 (PTY 필수)

```bash
# 시스템 python3 (google-auth 설치된 venv 환경) — refresh + OAuth 모두 처리
source ~/.hermes/venv-notebooklm/bin/activate
python3 ~/.hermes/scripts/youtube_token_refresh.py
```

스크립트가 자동으로:
1. 현재 토큰 상태 출력
2. `youtube_token.pickle.expired.bak` 백업
3. refresh_token 선제 시도 → 실패 감지
4. `InstalledAppFlow.run_local_server(port=0)`로 PTY OAuth 플로우 실행
5. 브라우저 URL 출력 → **사용자가 Google 로그인**
6. 새 토큰 저장

`terminal` 도구에서 호출 시 **반드시 `pty=true`** 옵션 사용 (없으면 OAuth 콜백 서버가 응답 못 받음).

## 주의사항

- **만료된 토큰은 자동 백업됨** (`*.expired.bak`) — 디버깅용으로 보존
- **PTY 없이 OAuth 실행하면 hang** — `run_local_server`가 콜백 대기에 멈춤
- **port=0**으로 OS가 빈 포트 자동 할당 (충돌 방지)
- `~/.hermes/venv-notebooklm` 외 다른 venv에서 실행 시 `google-auth-oauthlib` 미설치 가능 — 시스템 pip 또는 해당 venv에 설치 필요

## 재발 방지

- 새 토큰 발급 시 `InstalledAppFlow` 기본값 사용 (이미 `access_type=offline` + `prompt=consent` 포함) — `refresh_token`이 항상 재발급됨
- 6개월 이상 미사용 토큰은 Google이 폐기할 수 있음 — 주기적 사용 권장
- 토큰 만료 시점 모니터링: `creds.expiry`가 7일 이내로 다가오면 사전 갱신 (현재 자동화 없음, 필요 시 cron 추가 고려)

## 재업로드 동작

토큰 갱신 후 `--approved` 재실행 시:
- 노트북 ID는 캐시되어 재사용
- 영상 파일이 보존돼 있으면 재다운로드 스킵 (그렇지 않으면 재다운로드, ~10초)
- Shorts도 재변환
- 4/4 업로드 정상 완료 확인 (2026-06-04 실측, 16:44 → 16:45, 1분)
