# Remove-AI-Watermarks 블로그 글 발행 요약 (69차)

## 세션 개요

- **날짜:** 2026-05-22 03:00 KST
- **주제:** Remove-AI-Watermarks - 이미지에서 AI 워터마크를 제거하는 CLI와 라이브러리
- **카테고리:** AI/ML
- **품질:** Grade S (87.0점)
- **발행 URL:** https://sigco.tistory.com/475

## Markdown CJK 정제 기록

**1차 선검사:** `埋`, `扩`, `に`, `円`, `楕`, `注`, `ま`, `よ`, `る`, `赞`, `散`, `込`, `完`, `め`, `入`, `后`, `潜`, `成`, `れ` (18자)

**종합 사전 정제 후 잔여:** `埋`, `扩`, `に`, `円`, `楕`, `注`, `ま`, `よ`, `る`, `赞`, `散`, `込`, `完`, `め`, `入`, `后`, `潜`, `成`, `れ`

**Targeted final pass (2차):** 위 18자를 개별 치환 후 잔여 0자

## HTML 변환

- **markdown_to_tistory_html.py 출력:** 6418 bytes
- **CJK cleaning 루프:** 0회차 통과 (잔여 없음)
- **Korean text corruption check:** 이상 없음

## 주요 발견

1. **Gemini Sparkle 로고 제거:** 알파 블렌딩 역연산 (NCC 디텍터 + 그래디언트 마스크 인페인팅), ~0.05s/이미지, GPU 불필요
2. **SynthID 제거:** SDXL 기반扩散 재생성 (2026년 5월부터 SDXL이 기본값, 이전 SD-1.5는 v2 미처리)
3. **지원 서비스:** Gemini/Nano Banana (Sparkle+SynthID+C2PA), DALL-E 3 (C2PA), GPT Image 2 (C2PA, 픽셀 워터마크는 공개 디텍터 없음), Stable Diffusion (DWT+PNG text), Adobe Firefly (Content Credentials), Midjourney (EXIF+XMP), StableSignature (Meta), TreeRing
4. **Smart Face Protection:** YOLO로 사람 탐지 → 원본 얼굴 추출 → 인페인팅 후 부드러운 타원 마스크로 블렌딩
5. **Analog Humanizer:** 필름 그레인 + 색수차注入 → AI 이미지 분류기 우회
6. **법적 고려:** AI 출처 정보 속일 의도 제거는 법률/DMCA/플랫폼 약관 위반 가능

## 기술적 참고

- **공식 웹:** raiw.cc (웹에서 바로 사용 가능)
- **설치:** `pipx install git+https://github.com/wiltodelta/remove-ai-watermarks.git` 또는 `uv tool install`
- **Python 3.10+**, CUDA/MPS GPU 권장 (CPU juga 가능)
- **보이지 않는 워터마크 첫 실행 시:** 약 2GB 모델 자동 다운로드