# Cron Script Timeout 증가 방법 (2026-05-24)

## 문제
`no_agent` 모드 크론 잡이 120초 타임아웃으로 실패 — 이미지 3장 생성(360초) + 음악 생성(300초)이 120초 내에 완료 불가

## 원인
`hermes-agent/cron/scheduler.py`의 `_DEFAULT_SCRIPT_TIMEOUT = 120` (초)

Timeout 우선순위:
1. 모듈 레벨 `_SCRIPT_TIMEOUT` (패치 값)
2. 환경변수 `HERMES_CRON_SCRIPT_TIMEOUT`
3. config.yaml `cron.script_timeout_seconds`
4. 기본값 120초

## 해결책

### 방법 1: 환경변수 설정 (권장 — 즉시 적용)
```bash
# ~/.hermes/.env에 추가
HERMES_CRON_SCRIPT_TIMEOUT=600
```

### 방법 2: config.yaml 수정
```yaml
cron:
  script_timeout_seconds: 600  # 600초 = 10분
```

### 방법 3: hermes CLI
```bash
hermes config set cron.script_timeout_seconds 600
```

## 적용 대상 크론
- `a77ee904fa61`: 뮤직비디오 제작 (no_agent 모드) — 600초 충분
- 다른 `no_agent` 크론도 同様 적용

## 검증
```bash
source ~/.hermes/.env && echo $HERMES_CRON_SCRIPT_TIMEOUT  # 600 출력 확인
```