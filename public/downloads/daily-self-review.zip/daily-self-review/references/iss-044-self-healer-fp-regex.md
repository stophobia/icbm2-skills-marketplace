# ISS-044: cron_self_healer.py APIError False Positive Regex

## 문제

`cron_self_healer.py`의 APIError 패턴이 정상 출력의 키워드를 실제 에러로 오탐하여
매일 자기 개선 리뷰에서 6개+ 크론이 동시에 "실패"로 표시됨. 실제 실패는 0건.

## 오탐 트리거 (실제 관측 사례)

| 트리거 텍스트 | 출처 | False Positive 이유 |
|---|---|---|
| `notion-401-troubleshooting.md` (파일 경로) | Tistory 출력 內 references 목록 | "401"이 API 에러 코드로 오탐 |
| `Notion API 401 Unauthorized fallback` | 같은 doc reference 內 | "Unauthorized"가 auth 에러로 오탐 |
| `HTTP 403 (일일 공개 발행 한도 초과)` | Tistory troubleshooting 표 | "HTTP 403"이 에러로 오탐 (실은 가이드) |
| `올바른 CJK 제거 방식 (치환 ❌, 제거 ✅)` | Tistory 출력 | "❌"가 실패로 오탐 |
| `Notion API Rate Limit: ~3 req/sec` | KG 출력 | "rate limit"이 실제 에러로 오탐 (실은 설명) |
| `HTTP 429: usage limit exceeded` | 이전 daily review 텍스트 | self-referential 매칭 (실제 rate limit 가능성도 있음) |

## 해결: ISS-044 Regex Fix (2026-06-02)

**변경 전** (오탐 多):
```python
("APIError", r"(?:api.*(?:error|401|403|429|500)|unauthorized)\b", "APIError")
```

**변경 후** (오탐 大幅 감소, 6→2):
```python
("APIError", r"\b(?:api[\s._-]*(?:error|failed)|rate[\s._]*limit(?:\s*exceeded)?|http\s*(?:401|403|404|429|500|502|503)\s*(?::|\s+(?:unauthorized|forbidden|not\s*found|server\s*error|bad\s*gateway|service\s*unavailable|too\s*many\s*requests|internal\s*server\s*error))|authentication\s*failed|invalid\s*api\s*key)\b", "APIError")
```

### 매칭 전략

1. **단어 경계 `\b`** — "401 Unauthorized" 같은 mention의 단어 경계 확인
2. **separator `[\s._-]`** — `api_error`, `api-error`, `api error`, `api_failed` 모두 매칭
3. **HTTP status는 표준 status text 동반** — `HTTP 401:` 또는 `HTTP 401 Unauthorized`, `HTTP 500 Internal Server Error` 등. `HTTP 403 (가이드)` 같은 괄호 설명은 매칭 안 함
4. **status code 범위 확장** — 401/403/404/429/500/502/503 (502 Bad Gateway, 503 Service Unavailable 추가)
5. **rate limit phrase** — "rate limit", "rate_limit", "rate limit exceeded" 모두 매칭
6. **한 단어 매칭 제거** — "unauthorized" 단독은 더 이상 매칭 안 함 (HTTP context 필요)

## 검증 테스트 케이스 (17/18 PASS)

```python
import re
P = r'\b(?:api[\s._-]*(?:error|failed)|rate[\s._]*limit(?:\s*exceeded)?|http\s*(?:401|403|404|429|500|502|503)\s*(?::|\s+(?:unauthorized|forbidden|not\s*found|server\s*error|bad\s*gateway|service\s*unavailable|too\s*many\s*requests|internal\s*server\s*error))|authentication\s*failed|invalid\s*api\s*key)\b'

# False Positive (should NOT match):
assert not re.search(P, 'Notion API 401 Unauthorized fallback', re.I)  # PASS
assert not re.search(P, 'references/notion-401-troubleshooting.md', re.I)  # PASS
assert not re.search(P, '올바른 CJK 제거 방식', re.I)  # PASS
assert not re.search(P, 'http 403 (일일 공개 발행 한도 초과)', re.I)  # PASS
assert not re.search(P, '| http 500 | 쿠키 만료 |', re.I)  # PASS

# True Positive (should match):
assert re.search(P, 'OpenAI API error: invalid api key', re.I)  # PASS
assert re.search(P, 'HTTP 401 Unauthorized: invalid token', re.I)  # PASS
assert re.search(P, 'HTTP 500 Internal Server Error', re.I)  # PASS
assert re.search(P, 'HTTP 404 Not Found: /api/missing', re.I)  # PASS
assert re.search(P, 'Invalid API key provided', re.I)  # PASS
assert re.search(P, 'Authentication failed for user', re.I)  # PASS
assert re.search(P, 'api_failed to call', re.I)  # PASS
assert re.search(P, 'rate limit exceeded', re.I)  # PASS
assert re.search(P, 'HTTP 502 Bad Gateway upstream', re.I)  # PASS

# Edge case (acceptable miss): HTTP 429 returned by server (비표준 표현)
```

## 남은 False Positive (수용 가능, 2건)

ISS-044 fix 후에도 남는 2건:
1. **5d0f14aef84c (daily review)** — 이전 리뷰의 regex 자체를 문서화한 텍스트가 매칭됨 (self-referential)
2. **388898171a79 (KG)** — "Notion API Rate Limit: ~3 req/sec" — informational documentation, 실제 에러는 아니지만 rate limit 논의는 signal로 가치 있음

**판단**: 추가 튜닝은 false negative risk 증가. 2건은 수동 검증으로 처리.

## 적용 방법

1. `~/.hermes/scripts/cron_self_healer.py` line 106의 APIError 패턴을 변경
2. 검증: `python3 -c "import re; print(bool(re.search(NEW_PATTERN, 'Notion API 401 Unauthorized fallback', re.I)))"` → False
3. 실제 self-healer 재실행: `python3 ~/.hermes/scripts/cron_self_healer.py`
4. ISS-044를 `MEMORY.md`의 ✅ 해결됨으로 이동

## 후속 액션

- [x] Regex fix 적용 (2026-06-02)
- [x] SKILL.md 업데이트
- [x] cron_quality.md 22:00 entry 추가
- [x] MEMORY.md ISS-044 해결됨 표시
- [ ] 다음 daily review에서 false positive 추가 발생 여부 모니터링
- [x] ISS-058 (MemoryError 동일 패턴) 발견 및 fix (2026-06-03) — `references/iss-058-self-healer-memory-fp.md` 참조

## 일반화: Self-healer Regex Hardening 방법론 (2026-06-03 종합)

ISS-044 (APIError) + ISS-058 (MemoryError)에서 동일하게 적용된 hardening 패턴:

1. **단어 경계 `\b` 필수** — substring 매칭은 항상 false positive를 만든다 (`memory.*error` → `memory_error_tracker.py` 매칭, `api.*error` → `notion-401-troubleshooting.md` 매칭)
2. **구분자 정규화 `[\s._-]`** — `api error`, `api_error`, `api-error`, `api.error`, `api_failed` 모두 동일하게 매칭
3. **컨텍스트 강제** — "HTTP 401" 단독은 매칭 안 함, 반드시 status text(Unauthorized/Forbidden 등) 동반해야 매칭. "memory error" 단독은 매칭 안 함, "OutOfMemoryError" 또는 "out of memory" 같은 실 매칭만
4. **구체적 어휘 우선** — 일반 단어("unauthorized", "memory")보다 구체적 어휘("Invalid API key", "Cannot allocate memory") 우선
5. **변경 후 반드시 검증** — FP 1건 차단 + TP 3건 이상 매칭 확인 (Python `re` 모듈로 4 TC 실행)

### 새 에러 패턴 추가 시 체크리스트

- [ ] `\b` 단어 경계 사용
- [ ] 일반 단어 회피, 구체적 어휘 사용
- [ ] 4 TC 검증 (FP 1+ / TP 3+)
- [ ] 매칭된 경우 출력 파일에 `✅`/`success` 마커가 있는지 확인하는 보조 검증
- [ ] "패턴 매치:" 같은 메타 디버그 라인을 self-healer가 출력에 찍을 때 self-trigger 위험 검토
