# 번역 API 레퍼런스 (MyMemory)

GitHub Trending Description의 영어→한국어 번역에 사용된 패턴 상세.

## 선택한 API: MyMemory
- **URL**: `https://api.mymemory.translated.net/get?q=<text>&langpair=en|ko`
- **장점**: API 키 불필요, 1일 5000자 무료, 즉시 사용 가능
- **단점**: 일 5000자 초과 시 "MYMEMORY WARNING"이 응답에 섞여 나옴, 분당 요청 제한

## 구현 패턴 (재사용 가능)

```python
_TRANSLATE_CACHE = {}

def translate_to_korean(text, max_len=400):
    if not text or not text.strip():
        return text
    text = text.strip()
    if len(text) > max_len:
        text = text[:max_len]
    if text in _TRANSLATE_CACHE:
        return _TRANSLATE_CACHE[text]
    # 이미 한글이면 패스스루
    if any('\uac00' <= ch <= '\ud7a3' for ch in text):
        _TRANSLATE_CACHE[text] = text
        return text
    try:
        resp = requests.get(
            "https://api.mymemory.translated.net/get",
            params={"q": text, "langpair": "en|ko"},
            timeout=8,
        )
        if resp.status_code == 200:
            data = resp.json()
            translated = data.get("responseData", {}).get("translatedText", "")
            # 한도 초과 경고가 번역문에 섞이는 경우 원문 유지
            if translated and "MYMEMORY WARNING" not in translated.upper() and "QUERY LENGTH LIMIT" not in translated.upper():
                _TRANSLATE_CACHE[text] = translated
                return translated
    except Exception:
        pass
    _TRANSLATE_CACHE[text] = text
    return text
```

## 왜 이렇게 만들었나
1. **캐시(dict)**: 같은 description이 Notion 저장 + Telegram 요약 양쪽에서 호출됨 → 2번째는 0ms
2. **한글 패스스루**: 한국어 repo description이 들어왔을 때 재번역하는 낭비 방지
3. **잘못된 응답 필터**: MyMemory는 한도 초과 시 *번역문 자리에* 경고 텍스트를 넣어 보내는데, 이걸 그대로 저장하면 Description이 "MYMEMORY WARNING..."이 됨. upper() 비교로 차단
4. **try/except + 원문 fallback**: 외부 API 장애가 크론 실패로 이어지지 않게
5. **max_len=400**: MyMemory 한 요청 권장 길이 + 응답 품질. 더 길면 잘림

## 성능 측정 (실측, 2026-06-05)
- 첫 호출: ~1.2초
- 캐시 히트: ~0.003ms
- 40개 트렌딩 × 첫 실행 = 약 50초 추가 (9시 KST cron, 허용 범위)

## 일 5000자 한도 대응
GitHub Trending description은 보통 30~150자라 40개 × 100자 = 4,000자 정도. 1회 cron 실행은 한도 내.
**한도 초과 시 대안**:
- **LibreTranslate** (self-host 가능, API 키 선택) — 더 긴 텍릿 지원
- **DeepL Free API** (월 50만자 무료, 키 필요) — 품질 최고
- **OpenAI/Anthropic API** (품질 최상, 비용 발생) — 릴리즈 노트처럼 의미 보존이 중요한 경우

## 릴리즈 노트는 번역하지 않는 이유
- GitHub 릴리즈 body는 markdown + 체크리스트 + 이슈 트래커 + 코드펜스
- 줄 단위 번역 시 마크다운 구조 깨짐 (예: `- [ ]` 체크박스)
- `한국어 설명을 보고 다시 영문 마크다운으로 만드는` 비가역 변환이라 검색/참조용 가치 손실
- 트렌딩 description은 한 줄 평문이라 번역 안전

## 다른 스킬에서 재사용 시
이 패턴은 다른 "영어 소스 → 한국어 출력" 자동화(해외 뉴스 크롤링, Reddit/HN 다이제스트, 논문 요약)에서도 그대로 사용 가능.
번역 함수만 `references/`로 추출해 import하는 형태로 리팩토링 가능 (현 시점엔 inline 복제로 충분).
