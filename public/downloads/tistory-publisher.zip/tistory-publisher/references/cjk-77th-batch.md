# 77차 추가 발견 사항 (2026-05-30)

## markdown_to_tistory_html.py code block newline 삭제 (반복 발생)

세션마다 반복되는 문제. 변환 후 `<pre><code>` 블록 안의 줄바꿈이 사라져 commands가 한 줄로 합쳐짐.

**fix 패턴:**
1. `grep -n "pre><code" file.html` 또는 `re.findall(r'<pre><code>(.*?)</code></pre>', html, re.DOTALL)`로 각 블록 content 확인
2. 연속된 commands 사이의 `\n` 복원 (문자열 치환)
3. "instally" → "install\ndevflow" (단어 합쳐짐 경우) 주의
4. 변환 직후 code block 개수 확인 — 0개면 변환 실패 가능성

## Duplicate paragraph (중복 단락)

첫 번째 단락이 2번 반복됨. grep으로 "동일한 텍스트가 2번 나타나는" 것을 확인 후 제거.

**발생 패턴:**
```html
<p>동일한 텍스트</p>
<p>동일한 텍스트</p>
```
→ 첫 번째만 남기고 제거

## Korean text corruption 후처리의 놓침

CJK cleaning 후에도 특정 한국어 문장이 깨지는 경우가 있음:
- "에이전트가모" → "에이전트가 떠나도"
- "따라하는 도구" → "주목할 만한 도구"

→ HTML 변환 직후 Korean corruption check를 별도로 실행할 것

## Code block fix 복기 (실시간 적용)

```python
# Block 1: harness commands (instally → install + devflow)
html = html.replace('harness installdevflow', 'harness install\ndevflow')

# Block 2: devflow status# → devflow status\n#
html = html.replace('devflow status# →', 'devflow status\n# →')

# Block 3: devflow handoff generate# → devflow handoff generate\n#
html = html.replace('devflow handoff generate# →', 'devflow handoff generate\n# →')

# Block 5: # Codex/Claude ...# 에이전트가 → # Codex/Claude...\n# 에이전트가
html = html.replace('시작)# 에이전트가', '시작)\n# 에이전트가')
```