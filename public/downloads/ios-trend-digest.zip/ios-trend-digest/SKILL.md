---
name: ios-trend-digest
description: iOS/Swift 기술 트렌드를 매일 Notion에 기록 — HN, r/iOSProgramming, Apple 개발자 뉴스에서 수집
version: 1.0.0
author: icbm2
metadata:
  hermes:
    tags: [iOS, Swift, Trend, Notion, Daily]
prerequisites:
  secret_files: [notion_token.txt]
---

# iOS/Swift 트렌드 Digest

매일 iOS/Swift 관련 기술 트렌드를 Notion DB에 기록합니다.

## Notion DB

- **DB ID:** `33c76f2e-9097-8112-84f6-c60096cc0e11`
- **DB명:** iOS Trend
- **속성:** Name(title), Date(date), Category(select), URL(url)
- **카테고리 옵션:** Swift, SwiftUI, UIKit, AI/ML, Tool, Apple, Other

## 실행 단계

### 1. 뉴스 수집

다음 소스에서 당일 iOS/Swift 관련 주요 뉴스/글을 수집:

```bash
# Hacker News (iOS, Swift, Apple 관련)
# 검색: site:news.ycombinator.com iOS OR Swift OR SwiftUI OR Xcode OR "Apple Developer"

# Reddit r/iOSProgramming 최신글
# https://www.reddit.com/r/iOSProgramming/hot/.json

# Apple 개발자 뉴스
# https://developer.apple.com/news/
# ⚠️ 페이지가 매우 큼 (~100KB) — start_index로 pagination 필요
# 예: fetch_content(url, start_index=0, max_length=8000) 후 추가 페이지 필요시 start_index=6000, 12000... 반복
```

#### ⚠️ 검색 소스 우선순위 (2026-06 검증)

`ddg_search` (DuckDuckGo)는 봇 차단으로 종종 빈 결과를 반환한다. **폴백 체인:**

1. `mcp_minimax_web_search` (가장 안정적, 기본 사용 권장)
2. `ddg_search_search` (차단될 때가 많음, 보조)
3. `fetch_content` (URL을 직접 알고 있을 때 — 예: developer.apple.com/news/)

검색어 패턴 (효과 검증됨):
- `"iOS Swift Apple WWDC 2026 latest news"`
- `"SwiftUI Xcode 17 release 2026"`
- `"Apple developer news June 2026 iOS 19"`
- `"Apple Intelligence Foundation Models API WWDC26"`
- `"Swift 6.2 release 2026 concurrency"`
- `"SwiftUI Liquid Glass design WWDC26"`

### 2. Notion에 기록

각 트렌드 항목을 Notion DB에 페이지로 생성:

```python
import os, json, subprocess
from datetime import datetime, timezone, timedelta

# Notion API Token (보안: 파일에서 직접 읽기, 환경변수 사용 안 함)
with open(os.path.expanduser("~/.hermes/secrets/notion_token.txt")) as f:
    tk = f.read().strip()

DB_ID = "33c76f2e-9097-8112-84f6-c60096cc0e11"
today = datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")
```
# payload를 JSON 파일로 저장 후 curl로 전송
payload = {
    "parent": {"database_id": DB_ID},
    "properties": {
        "Name": {"title": [{"text": {"content": "제목"}}]},
        "Date": {"date": {"start": today}},
        "Category": {"select": {"name": "Swift"}},
        "URL": {"url": "https://..."}
    }
}
with open("/tmp/notion_entry.json", "w") as f:
    json.dump(payload, f, ensure_ascii=False)

env = dict(os.environ)
env["NTK"] = tk
r = subprocess.run(
    f'curl -s -X POST --max-time 15 https://api.notion.com/v1/pages -H "Authorization: Bearer $NTK" -H "Notion-Version: 2022-06-28" -H "Content-Type: application/json" -d @/tmp/notion_entry.json',
    shell=True, capture_output=True, text=True, env=env
)
```

### 3. 품질 기준

- **최소 3개, 최대 7개** 항목 기록
- WWDC 시즌(6월)에는 Apple 관련 비중 높임
- 중대한 업데이트(iOS 버전, Xcode 버전, Swift 버전)는 최우선
- 각 항목에 1-2문장 요약을 페이지 본문에 추가
- **URL 속성은 항상 기록** (참고 링크가 없으면 Apple 공식 문서 관련 URL이라도 반드시 기록)
- 한국어로 작성

### 4. 완료 확인

기록된 항목 수와 DB URL을 출력하여 확인.

## 시크릿 파일

- Notion Token: `~/.hermes/secrets/notion_token.txt`

## 실행 환경 주의사항 (크론 모드)

- `execute_code`는 **크론 모드에서 차단**된다 (subprocess 우회 우려). Python 작업은 다음 패턴 사용:
  1. `write_file`로 스크립트 작성 (`/tmp/<name>.py`)
  2. `terminal(command="python3 /tmp/<name>.py")`로 실행
- 단, `write_file`에 **Bearer 토큰을 평문으로 쓰면 마스킹 → SyntaxError**가 발생한다. **반드시 환경변수(`NTK`, `MMKEY` 등)로 주입**하고 스크립트에서 `os.environ["NTK"]`로 읽어 `-H "Authorization: Bearer *** 패턴 사용.
- `terminal`에 큰따옴표 + f-string을 섞으면 EOF 매칭 오류가 잦다. 가능하면 Python 스크립트 안에 subprocess로 호출하되, 위 환경변수 패턴을 지킬 것.

상세 예시 코드는 `references/cron-execution-pattern.md` 참조.

## 참고 자료

검색 폴백 체인, URL 선정, Notion 응답 검증 등 실전 팁은 `references/cron-execution-pattern.md` 참조.
