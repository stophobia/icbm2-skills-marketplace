# 뮤직비디오 검수 강제화 — 절대 규칙 (2026-05-25)

## 문제

Cron이 자동으로 YouTube에 직접 업로드하는 문제가 발생함.
`music_video_producer.py`의 `upload_youtube()` 함수가 실제 업로드를 실행했고,
검수 단계가 생략됨.

## 해결: upload_youtube() 더미화

`music_video_producer.py`의 `upload_youtube()` 함수는 **더미로 교체됨**:

```python
def upload_youtube(video_path, title, description):
    # ⚠️ music_video_producer.py에서 직접 호출하면 건너뜀
    print("  ⚠️ upload_youtube() 직접 호출 감지됨 — 건너뜀")
    print("  📝 검수 요청만 전송됩니다.家主님이 '업로드' 확인하면 --approved 모드로 업로드")
    return "PENDING_REVIEW", False
```

**실제 업로드는 `music_video_review.py --approved`模式下만 가능.**

## 검수 워크플로우 (강제)

```
20:00 Cron 실행
  → mmx image/music/FFmpeg 합성
  → music_video_review.py --review 실행
    → ngrokunnel 시작
    →家主님께 검수 링크 Telegram 전송
  →家主님이 영상 확인 후 '업로드' 입력
  → ICBM2가 music_video_review.py --approved 실행
    → 실제로 YouTube 업로드
```

**절대 금지:** `music_video_producer.py`에서 `upload_youtube()`를 직접 호출하여 검수 없이 업로드.

##家主님이 '업로드' 확인하는 방법

Telegram에서 검수 메시지 수신 후:
- `업로드` (또는 `confirm`, `yes`, `확인`) 입력 → ICBM2가 `--approved` 실행
- `수정` 또는 `수정 요청` 입력 → 제목/설명 변경 후 재검토

## 검수 데이터 저장소

```python
# ~/.hermes/memory/music_video_review.json
{
    "date": "2026-05-25 20:15",
    "video_file": "video_wave_20260525_201500.mp4",
    "short_file": "short_20260525_201500.mp4",
    "title": "주제명",
    "description": "...",
    "topic_name": "주제명",
    "mood": "밝은",
    "review_url": "https://abc123.ngrok.io",
    "approved": False
}
```

家主님이 '업로드' 확인하면 `approved=True`로 업데이트 후 업로드 실행.

## ngrok vs Cloudflare (2026-05-25)

- Cloudflare Tunnel: **완전 폐기** (Error 1033 빈번)
- ngrok 3.x 사용 (port 8765)
- ngrok.com 무료 계정의 authtoken 필요:
  ```bash
  ngrok config add-authtoken <your-authtoken>
  ```

## Shorts 파일명 문제 (2026-05-25)

이전: Shorts 파일명을 `video_wave_{timestamp}.mp4`에서 파싱하여 `_short.mp4` suffix 사용
문제: 잘못된 파일명이 사용됨 (예: `video_wave_20260525_201500_short.mp4`)

**현재:** `--short` 인자로 올바른 파일명 전달:
```bash
python3 music_video_review.py --review \
  --video video_wave_20260525_201500.mp4 \
  --short short_20260525_201500.mp4 \
  --title "주제명" ...
```

`review_data["short_file"]`에 올바른 파일명 저장 → `--approved`에서 올바른 파일 사용.