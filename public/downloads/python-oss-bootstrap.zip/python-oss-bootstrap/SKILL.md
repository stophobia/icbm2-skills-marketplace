---
name: python-oss-bootstrap
description: "sigco3111 GitHub에 작은 Python OSS 라이브러리/CLI를 부트스트랩하는 전체 워크플로 — 저장소 생성 → pyproject.toml 골격 → 소스 스텁 → pytest → README/CHANGELOG/CONTRIBUTING → GitHub Actions CI + action.yml → v태그 푸시 → About 한글화. hwp2md, md-doctor로 실전 검증됨."
trigger: "Python 라이브러리/CLI 신규 프로젝트를 sigco3111 GitHub에 처음 만들 때, 또는 다른 사람의 '새 Python OSS 시작' 요청을 처리할 때. '서브프로젝트 만들어줘', 'OSS 부트스트랩', 'pyproject.toml 골격 만들어줘' 같은 요청에 활성화."
last_updated: 2026-06-09
status: battle-tested
---

# Python OSS 부트스트랩 워크플로

sigco3111 GitHub 조직에 **작고 마른 Python OSS**를 한 세션에 띄우는 검증된 10단계 레시피. `hwp2md`(v1.0.0)와 `md-doctor`(v0.1.0)에서 실전 검증.

## 트리거 조건

다음 중 하나라도 해당되면 이 스킬을 로드:

- "Python 라이브러리/CLI 새 프로젝트 만들어줘"
- "sigco3111/[name] 저장소 만들어줘"
- "hwp2md처럼 [name] 만들어줘"
- "서브프로젝트 부트스트랩"
- "pyproject.toml 골격 + CLI 엔트리포인트 + GitHub Action 한 번에"

## 10단계 레시피

### 1단계: GitHub 저장소 생성

```bash
gh repo create sigco3111/<name> --public \
  --description "<한글 한 줄 설명 — 영문은 나중에>" \
  --license MIT
cd ~/Documents
git clone https://github.com/sigco3111/<name>.git
```

### Phase 0 변형: "코드는 다른 PC에서, 이 PC에선 README + 라이선스만"

다음 경우 1~7단계를 생략하고 Phase 0만 실행:
- "계획만 세우고", "방향 정해지면 저장소/README만 만들어줘", "다른 PC에서 작업" 식 명시 요청
- 1개가 아니라 **여러 repo**를 한 번에 (예: 코어 + 장르 플러그인 N개)
- 코드 작성은 사용자 본인이 다른 PC에서 직접

**Phase 0 변형 레시피**:

1. **워크스페이스에 디렉토리 만들기** (이 PC)
   - 경로: `~/.openclaw/workspace/<name>/` (기존 작업물과 격리)
2. **파일 3종**:
   - `README.md` (이 스킬 8단계의 README 가이드 적용, 단 "Quick Start"는 "Phase 1+ 작업은 다른 PC에서"로 안내)
   - `LICENSE` (Apache 2.0 또는 MIT)
   - `.gitignore` (장르별 차이 — 게임 데이터는 `games/*/` gitignore)
3. **`git init -b main` + 커밋** (한 번에)
4. **`gh repo create --public --source=<dir> --remote=origin --push`** (한 번에 repo 생성 + 푸시)
5. (선택) 아키텍처 결정 문서는 `~/.openclaw/workspace/` 에 별도 `.md` 로 저장 (repo에 안 들어감)

**검증된 사례**: `ai-gm-core` + `ai-gm-strategy-war` 2개 repo를 한 세션에서 5분 안에 GitHub public 생성 완료 (2026-06-12).

**장르별 repo 구조 (AI 게임/멀티 플러그인 시)**: 코어 1개 + 플러그인 N개 → 각각 독립 repo, 공통 로직은 코어에. 플레이스홀더 디렉토리는 `.gitkeep` 사용.

### 2단계: 부트스트랩 파일 3종 (`.gitignore`, `pyproject.toml`, `pytest.ini`)

**`.gitignore`**: Python 표준 (캐시, venv, .egg-info, .pytest_cache, .mypy_cache, .ruff_cache, .idea, .vscode, .DS_Store)

**`pyproject.toml`**: setuptools 백엔드. **⚠️ 함정: `authors`에 `email` 넣으면 PEP 621 위반으로 `pip install -e .` 깨짐**. 이메일은 `name`만 또는 `idn-email` 형식(예: `[email protected]`은 OK, `[email protected]` 같은 일반 형식도 OK). 안전하게 가려면:
```toml
authors = [{ name = "sigco3111" }]
```
이메일은 GitHub 프로필에서 가져오므로 README/CONTRIBUTING에만 적기.

**`pytest.ini`**: `testpaths = tests` + `addopts = "-v --tb=short"`

### 3단계: 도메인 모델 분리 (순환 import 방지)

**⚠️ 함정: `core.py` ↔ `checks/` (또는 `parsers/`, `backends/`) 간 순환 import**.

해결 정석: `models.py` (또는 `types.py`)에 **모든 모듈이 의존하는 핵심 타입**을 모아두고, `core`와 `checks` 모두 `models`만 직접 import. `core`가 `default_checks()` 같은 함수를 호출해야 할 때는 **함수 내부 lazy import**.

```python
# models.py — 순환 import 방지의 핵심
@dataclass(frozen=True)
class Diagnosis: ...
class Severity(str, Enum): ...

# core.py
from models import Diagnosis  # 직접 의존 OK
def _default_registry():  # lazy import
    from checks import default_checks
    return default_checks()
```

`core` ↔ `checks` ↔ `plugins` 같은 다방향 의존이 예상될 때 이 패턴을 **처음부터 적용** (나중에 분리하려면 모듈 다 뒤져야 함).

### 4단계: 소스 스텁 (`src/<pkg>/`)

표준 4계층:
```
src/<pkg>/
├── __init__.py        ← 공개 API re-export
├── __main__.py        ← `python -m <pkg>` 진입점
├── cli.py             ← argparse 기반 커맨드
├── core.py            ← 메인 로직 + I/O
├── models.py          ← 도메인 타입
├── exceptions.py      ← 예외 계층 (BaseError → 구체 에러)
└── <sub>/             ← 플러그인 영역 (체크, 파서, 백엔드 등)
    ├── __init__.py    ← BaseInterface + Registry + default_set()
    └── <impl1>.py     ← 스텁(0.1.0) 또는 활성(0.2.0+)
```

`src/` 레이아웃 권장 (테스트가 import 경로 = 사용자가 쓸 경로).

### 5단계: 예외 계층 (처음부터 만들기)

```python
class <Pkg>Error(Exception): ...
class ParseError(<Pkg>Error): ...
class UnreadableFileError(<Pkg>Error): ...
class CheckConfigError(<Pkg>Error): ...
```

모든 라이브러리 예외는 `<Pkg>Error` 서브클래스로 → 사용자가 `except <Pkg>Error` 한 줄로 잡을 수 있음.

### 6단계: CLI (`cli.py`)

표준 옵션 5종 + 부속 명령 1종:
- `-o/--output` (파일/stdout)
- `--format` (text/json/github — GitHub Actions 워크플로용)
- `--min-severity` (info/warning/error)
- `--fail-on` (위와 동일 + `never`)
- `--checks` / `--list` (플러그인 선택)
- `--version`

**⚠️ 함정: `argparse` 위치 인자(예: `path`)를 `nargs="?"` 로 만들지 않으면 `--list-checks` 같은 부속 명령을 쓸 수 없음**. 부속 명령이 있을 거 같으면 처음부터:
```python
parser.add_argument("path", type=Path, nargs="?", default=None)
# main()에서 path is None 체크
```

**GitHub Actions 워크플로 출력 포맷**: `::warning file=F,line=L::msg%0A` — `f"{msg.replace(chr(10), '%0A')}"` 잊지 말 것.

### 7단계: pytest 스모크 테스트 (6~16개)

**Fixture 우선**: `tmp_path`에 마크다운/HWP/CSV 등 픽스처 inline 작성. 외부 파일 의존 최소화.

**카테고리 4종 균형**:
1. 도메인 모델 (불변성, enum 순서)
2. 코어 함수 (성공 + 실패 케이스)
3. CLI (text/json/github 출력, 부속 명령)
4. 예외 (UnreadableFileError, ParseError)

**데모 출력 확인**: `tests/` 외에도 실제 CLI로 한 번 돌려보고 exit code 확인:
```bash
md-doctor /tmp/sample.md  # exit 0 또는 1
md-doctor /no/path        # exit 2 (사용자 오류는 2, 발견 이슈는 1)
```

### 8단계: README/CHANGELOG/CONTRIBUTING

**README.md**:
- `<1-2줄 한글 슬로건>` + 영문 부록 (`<a id="english"></a>` 앵커)
- "왜 이게 필요한가?" — 기존 도구의 갭 4가지
- 설치 (zero-deps 강조 or extras 표시)
- 빠른 시작 (CLI 4~6 예시 + Python API 1 블록)
- 검사/모듈 표 (0.1.0 활성 / 0.2.0+ 예정 분리)
- GitHub Action 사용 예시
- 사용 사례 4~6개 (시나리오형, "이럴 때 쓰세요" 톤)
- 로드맵 (0.1.0 ✅ → 1.0.0)
- 감사의 말

**CHANGELOG.md**: [Keep a Changelog](https://keepachangelog.com) 형식. 0.1.0 섹션에 Added/Notes만 있어도 충분.

**CONTRIBUTING.md**: "새 검사 모듈 추가" 튜토리얼 (BaseCheck 상속 4단계) — 다른 사람도 PR 보내기 쉽게.

### 9단계: GitHub Actions + action.yml

**`.github/workflows/ci.yml`**: 매트릭스 `python-version: ["3.9", "3.10", "3.11", "3.12"]` + 단계:
1. `actions/checkout@v4`
2. `actions/setup-python@v5` (cache: pip, cache-dependency-path: pyproject.toml)
3. `pip install -e ".[dev]"`
4. `ruff check src tests`
5. `mypy src || true` (0.1.0은 점진적 타이핑)
6. `pytest -v --tb=short`
7. `md-doctor --version` (스모크 CLI)

**`action.yml`**: composite action. 다른 사람이 `uses: sigco3111/<name>@v1` 으로 쓸 수 있게. inputs 4~5개, `runs.using: composite`, Python setup + pip install + 실행.

### 10단계: 커밋/푸시/태그/About 한글화

```bash
git add -A
git commit -m "feat: initial project skeleton (v0.1.0)

- <공개 API 요약>
- <CLI 요약>
- <예외 계층>
- <활성 모듈>
- <스텁 모듈>
- <테스트 N개 통과>
- <CI/Action>"
git push -u origin main

git tag -a v0.1.0 -m "v0.1.0 - ..."
git push origin v0.1.0

# GitHub About 한글화 (저장소 description)
gh repo edit sigco3111/<name> --description "<한글 한 줄>"
```

## ⚠️ 검증된 함정 (Pitfalls)

1. **`authors` 이메일** — PEP 621 위반. `name`만 쓰기.
2. **순환 import** — `models.py` 분리 + lazy import. **처음부터** 적용.
3. **argparse 위치 인자** — 부속 명령과 동시 사용하려면 `nargs="?"`.
4. **GitHub Actions 워크플로 출력** — `\n` → `%0A` 치환.
5. **테스트 conftest 충돌** — `pyproject.toml`에 `[tool.pytest.ini_options]` + 별도 `pytest.ini` 둘 다 있으면 "ignoring pytest config in pyproject.toml!" 경고. **하나만** 사용 (보통 `pyproject.toml` 안에).
6. **PEP 621 호환 setuptools** — setuptools ≥ 68 필요. 0.1.0에서는 `requires = ["setuptools>=68", "wheel"]` 명시.
7. **stdlib only 첫 릴리즈** — `dependencies = []` 로 시작. 0.2.0+에서 옵션 의존성 추가. 이게 "zero-deps" 마케팅 포인트.

## ✅ 완료 체크리스트

세션 종료 전 확인:
- [ ] `pytest` → 6개+ 모두 통과
- [ ] `md-doctor --version` (또는 해당 CLI) → 정상 출력
- [ ] `gh repo view sigco3111/<name>` → description 한글 + license MIT
- [ ] 저장소 페이지에 README/CHANGELOG/CONTRIBUTING/license 뱃지 렌더링
- [ ] v0.1.0 태그 푸시됨
- [ ] 다른 PC에서 `git clone && pip install -e ".[dev]" && pytest` 한 번에 동작

## 📁 첨부 파일

이 스킬에는 다음 지원 파일이 함께 들어 있음:
- `references/case-studies.md` — hwp2md, md-doctor 실전 사례 + 시퀀스
- `templates/pyproject-minimal.toml` — 안전한 시작점 (이메일 함정 회피)
- `templates/pytest-minimal.ini` — 표준 pytest 설정
- `scripts/bootstrap.sh` — `python-oss-bootstrap <name> "<한글 설명>"` 한 줄 실행
