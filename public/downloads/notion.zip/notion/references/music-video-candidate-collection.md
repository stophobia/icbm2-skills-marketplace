# Reddit/X侯選 수집 파이프라인 — 2026-05-25

## 개요

매일 오전 10시 Cron으로 실행되는 뮤직비디오侯選 수집 파이프라인.

## 소스

| 소스 | 주소 | 특징 |
|------|------|------|
| r/funny | https://www.reddit.com/r/funny/hot.json | 유머/상황 comedy |
| r/mildlyinteresting | https://www.reddit.com/r/mildlyinteresting/hot.json | 기이하지만 공감 |
| r/therewasanattempt | https://www.reddit.com/r/therewasanattempt/hot.json | 시도 자체가 웃김 |
| r/nottheonion | https://www.reddit.com/r/nottheonion/hot.json | 뉴스인데 웃김 |
| strangedaysnews.com | https://www.strangedaysnews.com/ | 바이럴 사건 수집 |
| funnytimes.com | https://funnytimes.com/news-of-the-weird-may-2026/ | News of the Weird 월간 |

##侯選 기준

| ✅ 수집 | ❌ 불필합 |
|--------|---------|
| 유머/위트好笑元素 | 뉴스 전달용-topic |
| 구체적 시나리오 (실제 벌어진 이상한 상황) | 추상적 명사 only |
| 영상화 가능성 | dry한 설명/논의 |

## Reddit JSON API 사용 패턴

```bash
# old.reddit.com 우회 (www.reddit.com은 rate limit 걸림)
curl -s "https://old.reddit.com/r/$sub/hot.json?limit=8" \
  -H "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36" \
  | jq -r '.data.children[].data | {title, score, selftext: (.selftext[0:400]), permalink}'
```

## Notion侯選 DB 저장 (2026-05-25 발견)

**DB ID가 두 개 있음 — 각각 역할이 다름:**

| ID | 용도 | 구하는 방법 |
|----|------|-----------|
| `data_source_id` | 행 조회 `POST /v1/data_sources/{id}/query` | search 결과의 `id` |
| `parent.database_id` | 페이지 생성 `POST /v1/pages` | `GET /v1/databases/{id}` → `.parent.database_id` |

**작업 순서:**
```bash
# 1. Search로 data_source_id 찾기
curl -s -X POST "https://api.notion.com/v1/search" \
  -H "Authorization: Bearer $NOTION_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -d '{"query": "뮤직비디오 주제", "filter": {"value": "data_source", "property": "object"}}' \
  | jq '.results[0].id'  # → data_source_id

# 2. data_source_id로 parent.database_id 찾기
curl -s "https://api.notion.com/v1/databases/{DATA_SOURCE_ID}" \
  -H "Authorization: Bearer $NOTION_KEY" \
  -H "Notion-Version: 2025-09-03" \
  | jq '.parent.database_id'  # → 실제 page creation용 ID

# 3. 페이지 생성 시 parent.database_id 사용
curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer $NOTION_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -d '{"parent": {"database_id": "PARENT_DATABASE_ID"}, "properties": {...}}'
```

**증상:** `POST /v1/pages` 시 404 → `parent.database_id` 대신 `data_source_id`를 사용한 것.

## Known DB IDs (2026-05-25)

| DB | data_source_id | parent.database_id |
|----|---------------|-------------------|
| 🎵 뮤직비디오 주제 | `36976f2e-9097-81e1-bb34-000b13fb3627` | `36976f2e-9097-81e1-a373-e06f2da6e99c` |

## Telegram 전송

```python
import requests

msg = """🎬 뮤직비디오侯選 (오후)

아래 중 원하는 주제를 골라주세요:

1. {주제명} — {한줄설명}
2. {주제명} — {한줄설명}
...

번호를 선택해 주세요.
(예: 3번이면 3만 보내면 됩니다)"""

requests.post(f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage", json={
    "chat_id": CHAT_ID,
    "text": msg,
    "parse_mode": "Markdown"
}, timeout=10)
```

## selection.json 관리

`~/.hermes/music_videos/selection.json`에侯選 전체 저장 (家主님 선택 대기):

```json
{
  "date": "2026-05-24",
  "generated_at": "2026-05-24T21:49:00+09:00",
  "topics": [...],
  "selected": [],
  "selection_numbers": [],
  "auto_mode": false
}
```

家主님 선택 후 선택된 주제를 `music-video-generator` 파이프라인으로 진행.