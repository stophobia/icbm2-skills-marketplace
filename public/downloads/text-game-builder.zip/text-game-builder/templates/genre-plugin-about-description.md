# Genre Plugin About Description 작성 규칙

> **GitHub repo About description + topics는 README만큼 중요합니다.** 검색·탐색에서 사용자가 처음 보는 정보예요. 2026-06-12에 4개 장르 repo + 메타 1개에 적용해서 검증된 규칙.

## About description 4요소 패턴

**패턴**: `[장르 한 줄 설명] — [코어 의존성]. [톤/특징 한 줄]. 샘플 시드: [시드명]. [정책].`

| # | 요소 | 예시 |
|---|------|------|
| 1 | 장르 한 줄 설명 | "전략/전쟁 장르 플러그인" |
| 2 | 코어 의존성 | "ai-gm 코어 기반" |
| 3 | 톤/특징 한 줄 | "턴제 그랜드 전략" 또는 "AI GM이 던전·도시·NPC 운영" |
| 4 | 샘플 시드 명시 | "샘플 시드: 고구려 391" |
| 5 | 정책 명시 (필수) | "미리지정 시드 없음" |

→ 4요소 + 정책 = 약 100~150자 한글. 한 줄에 다 들어감.

## 검증된 5개 예시 (그대로 사용 가능)

### 1. ai-gm (메타)
```
장르 비종속 AI 게임 마스터 공통 엔진. 게임 시작 시 GM이 사용자에게 설정을 묻고 시작 — 미리정해진 세계 없음. 장르 플러그인이 위에 얹힘.
```

**구성**:
- 장르: "장르 비종속 AI 게임 마스터 공통 엔진"
- 의존성: (메타라 코어 의존 언급 불필요)
- 톤: (메타라 톤 언급 불필요)
- 샘플 시드: (메타라 시드 없음, 대신 "미리정해진 세계 없음"으로 대체)
- 정책: "미리정해진 세계 없음"

### 2. ai-gm-strategy-war
```
전략/전쟁 장르 플러그인 — ai-gm 코어 기반. 턴제 그랜드 전략. 샘플 시드: 고구려 391. 게임 시작 시 GM이 시대·톤·규모·국가를 사용자에게 묻고 시작. 미리지정 시드 없음.
```

**구성**: 장르 / 의존성 / 톤 / 시드 / 정책 + **4가지 결정 키워드** (시대·톤·규모·국가) 명시.

### 3. ai-gm-fantasy-rpg
```
판타지 RPG 장르 플러그인 — ai-gm 코어 기반. AI GM이 던전·도시·NPC 운영. 샘플 시드: 드래곤 시대 1024. 미리지정 시드 없음.
```

### 4. ai-gm-sci-fi-explore
```
SF 탐험 장르 플러그인 — ai-gm 코어 기반. 함장 시점 성간 탐험. 샘플 시드: 인류 진출기 2247. 미리지정 시드 없음.
```

### 5. ai-gm-mystery-detective
```
미스터리/탐정 장르 플러그인 — ai-gm 코어 기반. 추리 + 심문 + 단서 추적. 샘플 시드: 하버튼 저택의 죽음 1923. 미리지정 시드 없음.
```

## Topics (장르별 10개)

**공통 6개** (모든 장르):
- `ai-game-master`
- `llm`
- `mcp`
- `genre-plugin`
- `korean`
- `text-game`

**장르별 차별 토큰 4~5개**:

| 장르 | 차별 토픽 |
|------|----------|
| ai-gm (메타) | `ai-game-master, mcp, llm, text-game, turn-based-strategy, rpg-engine, korean, open-source, game-engine, context-engineering` |
| ai-gm-strategy-war | `strategy-game, grand-strategy, turn-based, ai-game-master, llm, mcp, genre-plugin, korean, text-game, campaign` |
| ai-gm-fantasy-rpg | `fantasy-rpg, rpg, adventure, ai-game-master, llm, mcp, genre-plugin, korean, text-game, tabletop, open-source` |
| ai-gm-sci-fi-explore | `sci-fi, space-exploration, ai-game-master, llm, mcp, genre-plugin, korean, text-game, starship, ftl` |
| ai-gm-mystery-detective | `mystery, detective, noir, ai-game-master, llm, mcp, genre-plugin, korean, text-game, investigation, clue` |

→ 공통 6개로 **검색 시 ai-gm 계열**임을 알리고, 차별 4~5개로 **장르 특성** 노출.

## gh repo edit 명령 패턴

```bash
# description + topics 한 번에
gh repo edit sigco3111/<repo> \
  --description "<4요소 description>" \
  --homepage "https://github.com/sigco3111/<link-repo>" \
  --add-topic "tag1,tag2,tag3,tag4,tag5,tag6,tag7,tag8,tag9,tag10"
```

**`--add-topic` 플래그는 누적** (덮어쓰기 ❌). 한 번 호출에 여러 토픽 가능.

## 검증

`gh api repos/sigco3111/<repo>` 로 description + topics 적용 확인:
```bash
gh api repos/sigco3111/ai-gm-strategy-war | grep -E '"name"|"description"|"topics"'
```

또는 `mcp_ddg_search_fetch_content` 로 GitHub 페이지 실제 모습 확인 (Pitfall #9 검증과 동일).
