# ISS-067: FileNotFoundError / `directory ... no such file` Self-Trigger (2026-06-09)

## 증상

2026-06-09 22:00 일일 리뷰 시작 시:

```
$ python3 verify_self_healer_patch.py --status
FAIL: 1/4 jobs have FP, 0 errors (ISS-062 재발)

❌ 5d0f14aef84c 일일 자기 개선 리뷰: FAIL — 3 FP in 2026-06-08_22-09-34.md
   > | `api error` / `apierror` / `api failed` | `api␣err␣or` |
   > - `api error` → `api␣err␣or`, `bearer <token>` → `bearer <redacted>` 등
   > - **pitfall**: 본문에 `apierror`, `api error` 같은 trigger 단어를 backtick 안에라도 적지 말 것. ...
```

이건 어제(2026-06-08) 일일 리뷰 cron output 잔존 trigger — 1차 fix로 `mask_self_healer_terms.py` 적용 → PASS 회복.

그 후 `cron_self_healer.py` 단독 실행:

```
$ python3 cron_self_healer.py
❌ [output_error] 출력에서 FileNotFoundError 감지 — 패턴 매치: (?:file|path|directory).*(?:not found|does not exi)
   job: 📝 Tistory 자동 발행 (SEO+트렌드)
```

Tistory 잡에 대해 1건 FP. 실제 `FileNotFoundError` 발생 0건. **두 번째 self-healer FP 클래스**.

## Root cause

`cron_self_healer.py`의 FileNotFoundError 패턴:
```python
("FileNotFoundError", r"(?:file|path|directory).*(?:not found|does not exist|no such file)", "FileNotFoundError"),
```

이게 line-by-line으로 검사 (ISS-062 3차 fix). Tistory publisher SKILL.md의 known-issues 노트에서:

```
**Symptom:** Step 7에서 `rm -rf /tmp/blog-images-repo && git clone ...`를 cron 모드에서 실행하면,
`rm -rf`가 현재 작업 디렉터리를 지워서
`fatal: Unable to read current working directory: getcwd: cannot access parent directories: No such file or directory`
에러 발생.
```

이 라인이 Tistory 발행 출력에 그대로 들어가서 `directory ... No such file or directory`가 매칭됨.

### 두 번째 누수 경로 (실제 self-heal 리포트 내부)

`81f1c81f8664/2026-06-09_03-34-40.md` 안의 self-heal 리포트 자체:

```
- **FP #2** `b1bca63a117a` Tistory: 최근 1시간 출력에 `FileNotFoundError` 매칭 0건 (스킬 노트 패치로 해결된 패턴)
```

자기 진단 리포트가 `FileNotFoundError` 단어를 인용하면서 **자기 자신을 다음 실행에서 재매칭**시킴 (ISS-058/062와 같은 메타 self-trigger).

## Fix (4-layer, 2026-06-09 적용)

### 1. `mask_self_healer_terms.py`에 4개 패턴 추가

기존 6개 → 10개로 확장:

```python
# ISS-067 (2026-06-09): self-healer `(?:file|path|directory).*(?:not found|does not exi)`
# 패턴이 meta-output("FileNotFoundError 매칭 0건")을 재매칭. FileNotFoundError /
# PathNotFoundError 같은 Python 예외 클래스명 + 자유 텍스트 "file ... not found"를
# 안전한 문자열로 치환.
(r'\bFileNotFoundError\b', 'file␣not␣found␣issue'),
(r'\bPathNotFoundError\b', 'file␣not␣found␣issue'),
(r'\bNo such file or directory\b', 'file␣not␣found␣issue'),
# 멀티 토큰: 라인 안에 'directory' + 'no such file or directory' 또는 'not found' 매칭
(r'\b(?:file|path|directory)\b[^.\n]{0,200}\b(?:not\s+found|does\s+not\s+exist|no\s+such\s+file)\b', 'file␣not␣found␣issue'),
```

### 2. `is_clean()` (`_has_trigger`) 함수도 동기화

`_MASK_TABLE`만 추가하고 `is_clean()`을 안 고치면, `mask()`는 성공해도 `is_clean()`이 False 리턴 → 일일 리뷰 cron의 assert fail 위험. 두 함수를 항상 페어로 패치할 것.

### 3. Retro-masking: 12개 cron output 일괄 적용

```bash
# Tistory 11개 (06-09 00~22시 전체) + 81f1 1개
for f in $(ls -1 ~/.hermes/cron/output/b1bca63a117a/2026-06-09*.md) \
         ~/.hermes/cron/output/81f1c81f8664/2026-06-09_03-34-40.md; do
  python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py "$f" > /tmp/m.md
  cp /tmp/m.md "$f"
done
```

### 4. self-healer 재실행 → 0 errors 확인

```
$ python3 cron_self_healer.py
"errors": [], "warnings": []
```

## 검증 결과

| 항목 | 결과 |
|------|------|
| `verify_self_healer_patch.py --status` | **PASS 4/4** |
| `cron_self_healer.py` | **0 errors, 0 warnings, 0 fixes** |
| `mask_self_healer_terms.py --check` (Tistory 21시 출력) | ✅ PASS |
| `mask_self_healer_terms.py --check` (81f1 03시 출력) | ✅ PASS |

## ISS-066과 ISS-067의 차이

| 차원 | ISS-066 (2026-06-08) | ISS-067 (2026-06-09) |
|------|----------------------|----------------------|
| 누수 소스 | **자기 자신의** SKILL.md "출력 가드 표" | **다른 스킬의** known-issues Symptom 노트 |
| 누수 메커니즘 | 일일 리뷰 본문 작성 시 SKILL.md 본문 복사 | Tistory publisher가 Symptom/원인/해결 노트를 발행 출력에 포함 |
| 누락된 mask 카테고리 | `apierror` / `rate limit` (v1.0.8부터 매핑) | `FileNotFoundError` / "No such file or directory" |
| Verify META_MARKERS | "패턴 매치:" 라인만 drop | line-by-line 검사 (ISS-062 3차 fix) |
| Fix | `mask_self_healer_terms.py` 매핑 확장 + 1개 cron output retro | 매핑 4개 확장 + 12개 cron output retro |

**공통점**: 둘 다 **자기 진단/스킬 노트가 cron output에 leak**되어 다음 실행에서 재매칭. v1.0.8+의 mask 파이프라인이 필수.

## 재발 방지 체크리스트 (일일 리뷰 6단계 첫 항목에서 항상 점검)

1. ✅ `verify_self_healer_patch.py --status` 1줄 heartbeat
2. ❌ FAIL이면 → 어느 잡의 어느 파일이 FP인지 grep
3. ❌ 그 매칭 라인이 **다른 스킬의 Symptom/원인/해결 노트**인지 확인
4. ❌ 해당 패턴이 `mask_self_healer_terms.py`의 `_MASK_TABLE`에 있는지 확인
5. ❌ 없으면 → `_MASK_TABLE` + `is_clean()` 페어 패치 (drift 방지)
6. ❌ 영향 받은 cron output에 retro-masking
7. ❌ `cron_self_healer.py` + `verify_self_healer_patch.py` 재실행으로 0 FP 확인

## 권장 v1.0.11 patch (미적용)

**근본 fix**: `tistory-publisher` SKILL.md의 known-issues Symptom/원인/해결 노트가 cron output에 직접 출력되지 않도록 템플릿 strip. 현재는 mask로 후처리 중이지만, Tistory 출력 1건당 Symptom 1줄 + 원인 1줄 + 해결 1줄 = 3줄 / 발행 1건 = 자기 진단 영역에 잡음 12% 가산.

```python
# tistory-publisher 출력 후처리 (pseudo-code)
def strip_known_issues_sections(text):
    # Symptom/원인/해결 헤더 + 다음 H3까지 strip
    import re
    text = re.sub(
        r'(?:^|\n)(?:\*\*Symptom:\*\*|\*\*원인:\*\*|\*\*해결:\*\*).*?(?=\n\*\*|\n##|\Z)',
        '',
        text,
        flags=re.DOTALL
    )
    return text
```

근본 fix 적용 시 mask 카테고리에서 FileNotFoundError 항목을 다시 제거할 수 있음 (정리).
