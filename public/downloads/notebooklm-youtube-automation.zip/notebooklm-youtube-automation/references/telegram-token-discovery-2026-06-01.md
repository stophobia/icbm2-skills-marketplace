# Telegram Token 발견 기록 (2026-06-01)

## 상황
`notebooklm_selection.py`의 Telegram 전송이 `curl: (3) URL using bad/illegal format or missing URL`로 실패.侯選 목록은 stdout 마커로 정상 전달 중.

## 원인

### Placeholder Token File
`~/.hermes/secrets/telegram_bot_token.txt`의 실제 내용:
```
# ⚠️ ICBM2 Telegram Bot Token
# 이 파일이 없으면 NotebookLM 크론 잡의 Telegram 알림이 비활성화됩니다.
# Telegram BotFather에서 토큰을 발급받아 아래에 입력하세요.
# 발급 후 파일 내용을 토큰으로 교체하세요.
PLACEHOLDER_TOKEN_REPLACE_WITH_REAL
```

이 파일은 **template/placeholder**이며, 실제 봇 토큰이 아닙니다.

### 실제 Telegram Bot Token 출처
Hermes gateway의 `load_gateway_config()` (`gateway/config.py:1263`):
```python
telegram_token = os.getenv("TELEGRAM_BOT_TOKEN")
if telegram_token:
    telegram_config = _enable_from_env(Platform.TELEGRAM)
    telegram_config.token = telegram_token
```

실제 토큰은 **`TELEGRAM_BOT_TOKEN` 환경변수**에서 로드됩니다. `telegram_bot_token.txt` 파일은 사용되지 않습니다.

### 환경변수 확인
```bash
env | grep TELEGRAM
```
```
TELEGRAM_ALLOWED_CHATS=
HERMES_SESSION_KEY=agent:main:telegram:dm:8359527845
HERMES_CRON_AUTO_DELIVER_PLATFORM=telegram
TELEGRAM_REACTIONS=false
```

참고: `TELEGRAM_BOT_TOKEN` 환경변수는 이 세션에서 비어있습니다. Hermes agent 내부적으로는 gateway config에서 로드됩니다.

##侯選 전송 실패해도侯選가 도착하는 이유

`notebooklm_selection.py`의 오류 처리 로직:
```python
if curl_result != 0:
    print("⚠️ 텔레그램 전송 실패 — 크론 에이전트가 이 내용을 전달합니다")
    print("===== NOTEBOOKLM侯選 =====")
    print(message)
    print("=====侯選 END =====")
```

**curl 실패 → stdout 마커 출력 → 크론 에이전트가 마커 내용물을 추출하여 전달**

이것이 정상적인 동작입니다.侯選 목록이 Telegram에 도착하면 **항상 이 fallback 경로**를 통한 것입니다.

## 디버깅 체크리스트

1.侯選가 마커와 함께 stdout에 출력되는가?
   - Yes → fallback 경로 정상,侯選 전달 성공
   - No → `notebooklm_selection.py` 실행 자체가 실패

2.侯選 목록이 Telegram에 도착했는가?
   - Yes → 모든 것이 정상 (placeholder token은 영향을 주지 않음)
   - No → Telegram Bot Token이 유효하지 않거나, Hermes agent의 Telegram 연동 문제

3.`telegram_bot_token.txt`를 실제 토큰으로 교체해도 되는가?
   - 교체해도 `notebooklm_selection.py`의 curl 호출에는 영향 없음 (이 파일을 읽지 않음)
   - 실제로 유효해지려면 Hermes gateway config의 `TELEGRAM_BOT_TOKEN` env var를 설정해야 함
