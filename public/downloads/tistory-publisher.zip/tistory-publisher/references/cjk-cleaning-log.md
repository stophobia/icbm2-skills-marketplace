# CJK Cleaning 잔여 문자 기록 (40차 이후)

## 40차 루프 잔여 (2026-05-14 밤 cron — 시니어 개발자 전문성 전달 블로그 글)

markdown_to_tistory_html.py 변환 + CJK cleaning 루프 2회차 안정화 후 잔여 12자 → 별도 2차 정제로 제거 완료.

| 문자 | 유니코드 | 출처 추정 | 치환 |
|------|----------|-----------|------|
| 判 | U+5224 | "판단" Chinese 혼입 | 판 |
| 优 | U+4F18 | "우수" Chinese 혼입 | 우 |
| 物 | U+7269 | "물질" Chinese 혼입 | 물 |
| 凌 | U+51CC | "능가" Chinese 혼입 | 능 |
| 訓 | U+8A13 | "훈련" Chinese 혼입 |훈 |
| 层 | U+5C42 | "층별" Chinese 혼입 | 층 |
| 做 | U+505A | "작업" Chinese 혼입 | 작 |
| 晨 | U+6668 | "새벽" Chinese 혼입 | 신 |
| 劲 | U+52B2 | "근력" Chinese 혼입 | 근 |
| 断 | U+65AD | "단절" Chinese 혼입 | 단 |
| 致 | U+81F4 | "치밀" Chinese 혼입 | 치 |
| 导 | U+5F15 | "도입" Chinese 혼입 | 도 |

**원인:** "专业性(전문화)", "判断力(판단력)", "实力(실력)" 등 Chinese 표현이 한국어 단어 사이에 개별 한자로 분해残留. 专业性→전문+화성/判断力→判断+려 조합이 깨지면서 잔여 발생.

**예방:** CJK cleaning 후 루프 안정화 여부와 관계없이 잔여 CJK가 있으면 반드시 전체 누적 dict로 2차 정제 실행.

---

## 39차 루프 잔여 (2026-05-14 저녁 cron — MacBook Neo 블로그 글)

markdown_to_tistory_html.py 변환 + CJK cleaning 루프 2회차 안정화 후 잔여 16자 → 2차 정제 별도 dict로 제거 완료.

| 문자 | 유니코드 | 출처 추정 | 치환 |
|------|----------|-----------|------|
| 房 | U+623F | "플랫폼" 작성 중/plast房 → plast파 혼입 | 방 |
| 起 | U+8D77 | 한자 섞어 쓴 표현에서 유입 | 기 |
| 音 | U+97F3 | "영"과 혼동 | 음 |
| 料 | U+6599 |/plast료 혼입 | 료 |
| 购 | U+8D2D | "구매" Chinese 섞어 씀 | 구 |
| 压 | U+538B | 압房 혼입 | 압 |
| 敌 | U+654C | "적"과 혼동 | 적 |
| 点 | U+70B9 | "문제"와 혼동 | 점 |
| 感 | U+611F | "감"과 혼동 | 감 |
| 足 | U+8DB3 | "족"과 혼동 | 족 |
| 频 | U+9891 | "빈번" Chinese 섞어 씀 | 빈 |
| 塑 | U+585A | "플라스틱"에서/plast →/plast소 혼입 | 소 |
| 文 | U+6587 | "문제" Chinese 혼입 | 문 |
| 碾 | U+78D8 | Chinese 표현에서 유입 | 년도 |
| 植 | U+690D | "식물" Chinese 혼입 | 식 |
| 力 | U+529B | "역력" Chinese 혼입 | 력 |

**원인:** Markdown 원문 작성 단계에서 한국어 텍스트 사이에 Chinese 문자를 섞어 씀. 특히 "plástica" (라틴어/중국어 혼용)를 작성하거나, 한국어 단어를 생각하면서 Chinese를 동시에 써버리는 패턴.

**예방:** Markdown 작성 시 한국어-only 유지. Google 검색 결과나 기사 원문 복사 시 Chinese 문자가 함께 올 수 있으므로 주의.

---

## 38차 루프 잔여 (2026-05-14 저녁 cron — Code w/ Claude 블로그 글)

markdown_to_tistory_html.py 변환 + CJK cleaning 루프 2회차 안정화 후 잔여:

| 문자 | 유니코드 | 출처 | 치환 |
|------|----------|------|------|
| 年 | U+5E74 (CJK) | Simon Willison live blog 원문 | 년 |
| 间 | U+95F4 (CJK) | 同上 | 간 |
| 当 | U+5F53 (CJK) | 同上 | 당 |
| 时 | U+65F6 (CJK) | 同上 | 시 |
| 成 | U+6210 (CJK) | 同上 | 성 |

**원인:** 위 문자들이 Simon Willison live blog의 "当地时间"(현지 시간)라는 표현에서 개별 한자로 분해되어 루프에서 놓쳤다. `当地时间`는 단어 단위로 처리되어야 하나, 개별 문자 치환이優先되어 조합 누락.

**단어 단위 사전 업데이트 필요:**
```python
'当地时间': '현지 시간',
```

## Korean Hanja ↔ Chinese 혼용 잔여 (38차)

| 패턴 | 출처 | 수동 수정 |
|------|------|-----------|
| `당지시간` | 当+地+时+間 개별 치환 후残留 | → `현지시간` |
| `ypothetical` | markdown 변환 중 'h' 문자 누락 | → `hypothetical` |
| `협작리며완성임무` | 개별 한자 치환 후 문자열 합체 | → `협업하며 완수하는` |
| `오늘년` | Mercado Libre 연도 오인 | → `올해` |
| `приложение` | **Cyrillic** — CJK regex로 탐지 불가 | → `애플리케이션` |

## ⚠️ CRITICAL: Cyrillic/Mixed-Script 감지 안 되는 문제

현재 CJK cleaning regex는 `\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff` 만 탐지 → **Cyrillic (U+0400-U+04FF) 탐지 불가.**

**모든 비한국어/non-Latin 스크립트 탐지:**
```python
def has_foreign_script(text):
    return bool(re.search(r'[\u0400-\u04FF\u0600-\u06FF\u4E00-\u9FFF\u3040-\u309F\u30A0-\u30FF\uAC00-\uD7AF\u1100-\u11FF]', text))
```

## 권장 Final Sweep 패턴

루프 안정화 후 반드시 실행:
```python
# 1) 모든 비한국어/non-Latin 스크립트 탐지
foreign = set(re.findall(r'[\u0400-\u04FF\u0600-\u06FF\u4E00-\u9FFF\u3040-\u309F\u30A0-\u30FF]', html))
if foreign:
    print(f"⚠️ 잔여 스크립트 문자: {foreign}")

# 2) Korean Hanja corruption 체크
for pat in ['开发', '发表', '韩', '中', '文']:
    if pat in html:
        print(f"⚠️ Korean Hanja corruption: {pat}")

# 3) 한국어 사이에 끼어든非한국어 체크
suspicious = re.findall(r'[가-힣]+[^\s가-힣]+[가-힣]+', html)
if suspicious:
    print(f"⚠️ Mixed in Korean: {suspicious[:5]}")
```
