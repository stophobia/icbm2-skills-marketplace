# CJK Cleaning Loop History — AI-native 조직 블로그 글

**68차 루프 (2026-05-21 저녁 cron)**

## 제목 CJK 오염 — 새로운 실패 모드

### 증상
Markdown 본문과 HTML 출력은 CJK cleaning 루프를 통과했지만, **제목(title)은 별도 검증 없이 tistory_publisher로 직접 전달**되어 일본어 문자가 포함된 채로 발행됨.

### 실제 사례
- 제목: `위계에서 인텔리전스로 — 잭 도시가描绘る AI-native 조직의 새로운 패러다임`
- `描绘る` = Japanese verb "묘회다" (U+7EV6 描, U+7E44 绘, U+308B る katakana/hiragana blend)
- 종합 사전에 개별 문자(描, 绘, る)는 있었으나 결합형 `描绘る`은 미등재

### 원인
1. 제목 생성 시점(model의 텍스트 출력)에서 Japanese/Chinese 문자가 섞여 들어옴
2. Markdown CJK 선검사는 본문 파일만 검증 — `--title` 인자는 검증 대상이 아님
3. HTML 변환 CJK cleaning도 마찬가지로 본문 HTML만 처리
4. tistory_publisher.py는 title 인자를 API payload에 그대로 삽입 — 별도 정제 없음

### 해결책 (적용 전까지)
제목 생성/전달 시 다음 Python 정제 함수를 반드시 적용:

```python
import re

def clean_title(title):
    """제목에서 CJK 문자 제거 — 빈 문자열 치환 방식"""
    cjk = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', title))
    for c in cjk:
        title = title.replace(c, '')
    return title.strip()

# 사용 예시
title = clean_title(title)
# → "위계에서 인텔리전스로 — 잭 도시가 AI-native 조직의 새로운 패러다임"
```

### 향후 방지 체계
1. 제목 생성 직후 CLI `--title` 전달 전 `clean_title()` 적용
2. 또는 blog_pipeline.py 출력 JSON title 필드에 자동 적용
3. tistory_publisher.py에서 API 호출 직전 title 정제 추가 (가장 확실)

---

## 68차 루프 요약

| 항목 | 내용 |
|------|------|
| 주제 | AI-native 조직 (잭 도시 트위터 창업자) |
| 제목 오염 | `描绘る`(묘회る) 일본어 동사 |
| 발견 시점 | 발행 완료 후 제목 확인 |
| 정제 결과 | 제거 완료 (targeted final-pass) |
| 발행 URL | https://sigco.tistory.com/469 |
| 품질 등급 | A (71점) |

---

## 이전 루프 요약 (최근 5개)

| 차수 | 날짜 | 주제 | 주요 CJK 발견 | 정제 횟수 |
|------|------|------|--------------|----------|
| 67차 | 2026-05-20 | LLM의 지난 6개월 | Chinese 복합어 대량 유입 | 1차 완료 |
| 66차 | 2026-05-20 | Emergence World | 虚/拟/主/流 | targeted pass |
| 65차 | 2026-05-19 | AI 구독 시한폭탄 | 传统/主流/要求 | targeted pass |
| 64차 | 2026-05-19 | Malta OpenAI 파트너십 | 槛/考/有/背/え/拥 | targeted pass |
| 63차 | 2026-05-19 | (이전 세션) | — | — |