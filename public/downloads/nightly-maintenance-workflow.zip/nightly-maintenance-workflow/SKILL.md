---
name: nightly-maintenance-workflow
description: ICBM2 심야 통합 정비 자동화 워크플로우 — 에러 모니터링 → 자가치유 → 메모리 동기화 → Notion 보고 순차 실행. 매일 03:30 크론으로 자동 실행.
tags: [automation, cron, maintenance, healthcheck, ICBM2]
---

# ICBM2 심야 통합 정비 워크플로우

## 개요

매일 03:30에 실행되는 통합 정비 크론 잡용 스킬입니다. 4단계 파이프라인을 순차 실행합니다.

## 트리거 조건

- **자동:** `hermes cron` 스케줄 (03:30 매일)
- **수동:** 이 스킬을 로드하고 아래 단계를 순차 실행

## 파이프라인 (4단계)

### 1단계: 에러 모니터링

```bash
python3 ~/.hermes/scripts/cron_error_monitor.py
```

- 크론 잡 상태(CRITICAL/WARNING/OK) 스캔
- Stale(장시간 미실행) 크론 감지
- 스크립트 무결성 점검
- 시크릿 파일 존재 확인

**출력 예시:**
```json
{"summary": {"total": 18, "ok": 5, "warning": 4, "critical": 9}}
```

### 2단계: 통합 정비 (자가치유)

```bash
python3 ~/.hermes/scripts/cron_self_healer.py
```

- 1단계 결과를 기반으로 자동修復 시도
- `error_monitor_state.json` 읽고 자가치유 대상 판단
- Fix 적용 후 보고서 저장: `memory/self_heal_YYYY-MM-DD.md`

**⚠️ APIError 감지의 False Positive 패턴 (매우 중요):**

Self-Healer가 출력에서 APIError 패턴을 감지하더라도, `cron_error_monitor.py`의 jobs 상태가 모두 **"ok"**인 경우가 있습니다. 이 경우:

- 감지된 패턴: `(?:api.*(?:error|failed|401|403|429|500)|unauthori`
- 실제 원인: 스크립트 출력(ex: 로깅 메시지, AI 모델 응답 텍스트 등)에 정규표현식이 매치된 것
- jobs 상태: 모두 "ok" — 실제 크론 실패가 아님
- 조치: **수정 불가, 무시함** — 패턴 매치 로직의 가양성(false positive) 문제로 기록

**⚠️ Self-Healer output_error False Positive — 반복되는已知 패턴 (매우 중요):**

Self-Healer는 매심야 실행 시마다 output_error를 감지합니다. 패턴은 반복됩니다:
- **ISS-044 계열 (2026-05-23~):** APIError 4~6건 + TimeoutError 2건 → 모든 jobs 상태 "ok" → Fixes 0건
- 반복 기록: ISS-044 → ISS-046 → ISS-050 → ISS-052 → ISS-058 → **ISS-059 (2026-06-04, APIError 3건)**

**자동 판별 기준:**
1. `cron_error_monitor.py`의 jobs 상태가 **모두 "ok"**인가? → 대부분 Yes → False positive
2. 감지된 에러가 **출력 텍스트에 포함된 에러 메시지 키워드**인가? (예: Python 예외 스택 트레이스, AI 모델 응답 내 "error", 로깅의 "API Error" 등)
3. **빈 출력(empty)**이 아닌가? → 빈 출력이면 실제 에러 가능성 있음

**처리:**
- False positive이 감지되면 → ISS-058 (또는 다음 번호)로 기록, Fixes 0건
- Fixes > 0이면 → 실제修復 발생 → 주인님께 알림
- **이 패턴은夜的 매일 발생하므로** 매번 새로운 ISS-NNN 할당 대신 "ISS-XXX 반복"으로 기록

### Self-Healer 판별 기준 (핵심 — 반드시熟読)
| Jobs 상태 | 감지 패턴 | 해석 | 조치 |
|-----------|----------|------|------|
| ok | APIError + 빈 출력 아님 | ✅ False positive — 무시 | 패턴 매치 로직 가양성, 기록만 |
| ok | HTTP 429 + 빈 출력 | ⚠️ **실제 rate limit** | ISS-NNN 등록, 주인님 알림 |
| ok | TimeoutError + jobs ok | ⚠️ 진행중 이슈 | ISS-NNN 등록, jobs.json 재확인 |
| failed | qualquer | ❌ 실제 실패 | 수정 대상 |

**실제 에러 사례 (2026-05-28):**
- 🔴 GitHub Trending + Release 모니터: HTTP 429, 빈 출력, 2회 연속(05-27~05-28 09:00 KST) → ISS-048
- 🔴 API Key 만료 감시: HTTP 429, 빈 출력, 2회 연속(05-27~05-28 09:00 KST) → ISS-049

**자가치유 가능한 예:** 출력 파일 bloat 정리, 시크릿 파일 생성, 스크립트 문법 오류修正
**자가치유 불가(정상 동작):** APIError/MemoryError 패턴이jobs "ok"에서 감지될 때 — 이는 크론 실패가 아니라 스크립트 출력에 에러 키워드가 포함된 것

**출력 예시:**
```json
{"summary": {"total_jobs": 18, "healthy_jobs": 16, "total_errors": 2, "fixes_applied": 0}}
```

### 3단계: 메모리 에러 동기화

```bash
python3 ~/.hermes/scripts/memory_error_tracker.py
```

- 최근 72시간 크론 출력 에러 스캔
- `memory/issues.md`와 `MEMORY.md` 동기화
- 새 에러 카테고리 → ISS-NNN으로 추가
- 해결된 이슈 → ✅ 해결됨 표시

**출력 예시:**
```json
{"new_issues": {}, "resolved_issues": {"Stock Market": 1}, "needs_memory_update": true}
```

### 4단계: Notion 정비 리포트 기록

> **재사용 가능한 스크립트:**
> - `scripts/post_notion_maintenance_report.sh` — 4단계를 한 줄로 처리 (cron 모드 호환, `execute_code` 불필요). 2026-06-04 검증.
> - `~/.hermes/scripts/post_notion_report.py` — 4단계를 스크립트 하나로 처리 (구버전).
> 이 스킬의 파이프라인을 직접 실행할 때는 아래 수동 절차를 따르세요.

1. **Notion DB 프로퍼티 조회** (매 실행 시 권장 — 스키마는 변경될 수 있음):
   ```bash
   TOKEN=*** ~/.hermes/secrets/notion_token.txt) && \
     curl -s -X GET "https://api.notion.com/v1/databases/33c76f2e-9097-8198-bd1b-c3ea3cfbbae8" \
       -H "Authorization: Bearer *** -H "Notion-Version: 2022-06-28" \
       -o /tmp/db_schema.json
   ```
   그리고 `python3 -c "import json; print(json.dumps(json.load(open('/tmp/db_schema.json'))['properties'], ensure_ascii=False, indent=2))"` 로 확인.

   **Maintenance DB (2026-06-04 확인된 실제 프로퍼티):**
   - `수리 항목 수` (number)
   - `요약` (rich_text)
   - `날짜` (date)
   - `점검 항목` (multi_select — 옵션: "크론잡 상태", "API 연결", "에러 모니터링", "자가치유", "메모리 점검", "Notion 기록", "Error Monitor", "Self-Healer" 등)

   ⚠️ **title 프로퍼티가 없을 수 있음** — 2026-06-04 점검 시 `이름` title 프로퍼티가 존재하지 않았음. 페이로드는 title 없이 보내도 정상 생성되며, 페이지가 Notion에 추가되지만 DB 기본 정렬 키만 사용. 검증된 페이로드 예시는 아래 3번 참조.
   ⚠️ **한글 프로퍼티명 주의**: 잘못된 이름으로 보내면 `validation_error` 반환. 매번 `GET /databases/{id}`로 실제 이름 확인 권장.

2. **Notion API Key:** `~/.hermes/secrets/notion_token.txt`

3. **페이지 생성 — terminal + curl + JSON 파일 방식 (cron에서 검증됨, 2026-06-04)**:

   ```bash
   # (a) 페이로드를 /tmp/notion_payload.json에 작성
   cat > /tmp/notion_payload.json <<'PAYLOAD_EOF'
   {
     "parent": {"database_id": "33c76f2e-9097-8198-bd1b-c3ea3cfbbae8"},
     "properties": {
       "날짜": {"date": {"start": "2026-06-04T03:30:00+09:00"}},
       "수리 항목 수": {"number": 0},
       "요약": {"rich_text": [{"type": "text", "text": {"content": "한 줄 요약"}}]},
       "점검 항목": {"multi_select": [
         {"name": "에러 모니터링"},
         {"name": "자가치유"},
         {"name": "메모리 점검"},
         {"name": "Notion 기록"}
       ]}
     },
     "children": [
       {"object":"block","type":"heading_2","heading_2":{"rich_text":[{"type":"text","text":{"content":"📊 점검 요약"}}]}},
       {"object":"block","type":"bulleted_list_item","bulleted_list_item":{"rich_text":[{"type":"text","text":{"content":"불릿 1"}}]}}
     ]
   }
   PAYLOAD_EOF

   # (b) POST
   TOKEN=*** ~/.hermes/secrets/notion_token.txt) && \
     curl -s -X POST "https://api.notion.com/v1/pages" \
       -H "Authorization: Bearer *** \
       -H "Notion-Version: 2022-06-28" \
       -H "Content-Type: application/json" \
       -d @/tmp/notion_payload.json -o /tmp/notion_resp.json
   ```

   결과 확인:
   ```bash
   python3 -c "import json; d=json.load(open('/tmp/notion_resp.json')); \
     print('PAGE_ID:', d.get('id')); print('URL:', d.get('url')); print('OBJECT:', d.get('object'))"
   ```

### ⚠️ Notion API 호출 시 주의사항 (2026-06-04 업데이트)

- **❌ `execute_code`는 cron 모드에서 BLOCKED됨** — 메시지: `BLOCKED: execute_code runs arbitrary local Python (including subprocess calls that bypass shell-string approval checks). Cron jobs run without a user present to approve it.` 4단계는 반드시 `terminal` + `curl` + JSON 파일 방식으로 처리.
- **❌ `terminal`의 `curl | python3` 파이프 사용 금지** — security scan이 HIGH (`tirith:curl_pipe_shell` 패턴)로 차단함. JSON 파일로 출력한 뒤 별도 `python3 -c` 또는 `python3 파일` 호출로 읽기.
- **✅ 검증된 폴백 (2026-06-04)**: `curl -o /tmp/resp.json` + `python3 -c` (파이프 없이) 조합. 이 스킬 본문 3번 절차.
- **DB 필드 타입은 미리 확인할 것** — `multi_select`를 `rich_text`로 보내면 400 validation_error 반환. 최초 1회 `GET /databases/{id}`로 프로퍼티 목록 조회 후 올바른 타입 사용
- **select 필드**: `{"select": {"name": "값"}}`
- **multi_select 필드**: `{"multi_select": [{"name": "값1"}, {"name": "값2"}]}`
- **rich_text 필드**: `{"rich_text": [{"text": {"content": "값"}}]}`
- **number 필드**: `{"number": 정수}`
- **title 필드 (있다면)**: `{"title": [{"text": {"content": "값"}}]}` — Maintenance DB는 2026-06-04 기준 title 없음

## 메모리 업데이트 규칙

| 상황 | 조치 |
|------|------|
| Stock Market 등无害エ唎解決 | ISS-014 → ✅ 해결됨 |
| 새 에러 카테고리 3회 이상 반복 | `issues.md`에 ISS-NNN 추가 |
| MEMORY.md와 불일치 | MEMORY.md의 `알려진 이슈`同步 업데이트 |
| `needs_memory_update: true` | 실제 파일만 갱신 |

### issues.md 업데이트 시 주의사항

- `*마지막 업데이트:` 행이 2개 이상にならないよう, 업데이트 전에 기존 행을 삭제할 것
- `patch` 모드 사용 시 `replace_all=false`면 여러 매치에서 실패할 수 있음 — 충분한 문맥을 포함할 것
- 날짜 패턴: `*마지막 업데이트: YYYY-MM-DD HH:MM*`으로 grep 검색 가능
- **issues.md 최하단 날짜 섹션(pattern: `## 🆕 YYYY-MM-DD 발견`)이 여러 개 있을 수 있음** — 정확한 행 번호로 patch하거나, 가장 마지막 섹션 끝에 정확히 붙일 수 있는 고유 문자열 사용. `old_string`이 파일 내 중복되면 2개 이상 매치로 patch 실패 → 더 긴 고유 문맥(상위 테이블 전체 등) 사용

**🆕 2026-05-23 발견 이슈 업데이트 (참고용):**

ISS-037 (Self-Healer APIError false positive): issues.md의 날짜 섹션에서 `old_string`을 정확히 일치시키려면 **파일 내 가장 긴 고유 범위**(예: `*마지막 업데이트: YYYY-MM-DD HH:MM*\n\n## 🆕 YYYY-MM-DD 발견` 전체)를 포함시켜 patch하세요. 그래도 중복 매치 시 `terminal` + Python 치환을 사용:
```python
with open("/Users/hjshin/.hermes/memory/issues.md") as f:
    content = f.read()
content = content.replace(OLD_TEXT, NEW_TEXT, 1)  # 1회만 치환
with open("/Users/hjshin/.hermes/memory/issues.md", "w") as f:
    f.write(content)
```

## 핵심 종속성

```
cron_error_monitor.py → writes state → cron_self_healer.py (reads state)
                                          ↓
                              memory_error_tracker.py (reads cron outputs)
                                          ↓
                              Notion API (posts report)
```

## 예상 결과 (정상 시)

- 모든 시스템 정상: "모든 시스템 정상" 보고
- 문제 발견: 주인님께 알림 + Notion에 상세 기록
- 자동修復 실패: 자가치유报告中标注"자동修復 불가"

## ⚠️ Stale 크론 — 대부분은 정상입니다 (매우 중요)

**03:30 심야 점검 시 9개 잡이 stale로 표시되는 이유:**

크론 에러 모니터는 "마지막 실행으로부터 6시간 이상 경과"를 stale로 판단합니다.
03:30에 실행되면:
- 하루 1회 스케줄(예: `30 3 * * *`)은昨夜 03:30에 실행 → 정확히 24h 경과 → 무조건 stale ⚠️
- 하루 다회 스케줄(예: `0 19,20,21,22...`)은最終実行가 새벽 이전 → 수시간 경과 → stale
- 실제로는 **"다음 스케줄 대기 중"** 이지故障이 아닙니다

**판별법 (매년 확인 필요 없음):**
- Stale + 심야 시간대(02:00~04:00) + 하루 1회 스케줄 → ✅ 정상
- Stale + 업무시간대(09:00~18:00) + 하루 다회 스케줄 → ❌ 진짜 문제 가능 → `cron-stale-triage` 스킬로 분류

**핵심 규칙:** Stale 보고에서 critical 수가 많으면 → `cron-stale-triage` 스킬로 교차 검증 먼저. 대부분의 "critical"은 허상 경보.

## ⚠️ 일반적인 Stale 크론 원인 (실제 문제만)

| 원인 | 증상 | 해결 |
|------|------|------|
| gateway_timeout (1800s) | 심야 점검 / 일일 자기 개선 10~24시간 미실행 | `hermes gateway restart` |
| Notion API 토큰 만료 | Knowledge Graph APIError unauthorized | 토큰 갱신 |
| 폴링 타임아웃 | NotebookLM 8개 에러 지속 | 폴링 로직 자체 점검 필요 |
| Stock Market 스크립트 | 단일 에러,周末/휴일 폐장 아님 | 확인 필요 (ISS-015) |

## 관련 스킬
- `cron-stale-triage` — Stale 알림 교차 검증 (이 스킬보다 상세한 triage 절차 포함, Stale이 많을 때 먼저 실행)
- `automation-healthcheck` — 수동 헬스체크 (互补: 자동 vs 수동)
- `memory-error-tracker` — 3단계 상세 (이 스킬에서 호출)
- `daily-self-review` — 매일 22:00 자기 개선 리뷰 (별도 스케줄)

## Case References
- `references/github-429-rate-limit-case.md` — GitHub Trending + API Key 감시 HTTP 429 (2026-05-27~28) 실제 에러 사례. 빈 출력+429+2회 연속이면 rate limit로 진단.
