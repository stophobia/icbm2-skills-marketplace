# 세션 #2 노트: StackChan 스타일 + 20개 표정 + 라이선스 정리 (2026-06-23)

## 사용자 요청 흐름

1. **첫 요청**: "에르메스 PC에 stackchan 시뮬레이터를 설치하고 구동할 수 있나?"
2. **Intel Mac 확인** → Apple Silicon 전용 앱(StackChan World) 불가 → Python 키위 동반자 v1 결정
3. **v1 구현**: 4-모듈(llm/tts/face/main) + bash run.sh 래퍼
4. **3차례 크래시 + 수정**:
   - 크래시 #1: `pygame.init()` → 오디오 race → display.init()/font.init() 명시
   - 크래시 #2: NSWindow 메인 스레드 제약 → 메인 스레드 init + 워커 큐
   - 크래시 #3: `pygame.time.Clock()` → SDLTimer race → Clock 제거, time.sleep
5. **사용자**: "직접실행해봐" → bash run.sh로 실제 GUI 검증
6. **사용자**: "키위와 채팅은 되는데, 얼굴은 안보임" → 진단 모드 추가 → mixer init: False
7. **사용자**: "밝은 원형 하이라이트 너무 거슬림, 한글 폰트 깨짐" → 본체/눈 하이라이트 제거, 라벨 영문화, 한글 폰트 순차 시도
8. **사용자 이미지**: M5Stack StackChan 9개 표정 사진 → "이런 느낌으로 심플하게 만들어줘"
9. **사용자**: "A로 해줘" (흰 박스 + 검은 디스플레이 + 흰 픽셀 얼굴)
10. **사용자**: "판매중인 M5Stack StackChan 얼굴 리소스 받아올 수 있을까?" → 라이선스 조사
11. **사용자**: "Gitshaoxiang MIT 알고리즘 직접 참고" → 20개 표정 + CREDITS.md

## 핵심 결정 포인트 + brainstorm

각 단계에서 2~3 옵션 + 추천으로 사용자에게 제시. 사용자가 "그대로 진행해"로 확정.

| 단계 | 옵션 | 사용자 선택 |
|---|---|---|
| 캐릭터 스타일 | A: 미니멀 / B: 풀세트(안테나) / C: 사실적 | A |
| 눈 스타일 | 1: 단순 / 2: 흰눈+동자+하이라이트 / 3: OLED | 2 |
| 표정 표현 | a: 눈만 / b: 눈+입 / c: 전부 | b |
| 키위 본체 | i: 단색 / ii: 씨앗 / iii: 점박이 | ii |
| 외형 | A: 흰박스+검은디스플레이 / B: 키위 원형 / C: 키위 갈색+검은 | A |
| 자산 출처 | A: MIT 알고리즘 / B: SVG 직접 / C: NC-SA | A |

## 디자인 결정 — 3단계 진화

### v1: pygame primitive 도형
- 키위 본체 = 큰 갈색 원 + 씨앗 점 + 분홍 볼
- 감정별 색상 팔레트
- 표정 만족도: 사용자가 "별로네" 반응

### v2: StackChan 흰 박스 (메인 디자인)
- 흰 박스 본체 (둥근 모서리 + 그림자)
- 검은 디스플레이 (둥근 모서리)
- 흰 픽셀 얼굴
- 하단 둥근 라벨 (감정별 색상)
- 표정 만족도: 8.5/10 (cool 표정 기준)

### v3: 20개 표정 확장
- MIT 알고리즘 차용 (이름/구조만)
- 픽셀 점 sin 곡선 렌더링 (pygame.arc 금지)
- 모든 표정 100% 자체 디자인

## 디버깅 사례 — 3차례 크래시

### 크래시 #1: NSWindow 메인 스레드 제약
- **증상**: `pygame.error: NSWindow should only be instantiated on the main thread!`
- **Thread 0**: `pgEvent_New` → `PyDict_SetItemString` → NSWindow
- **해결**: face.py의 `run()`을 별도 스레드에서 호출 ❌ → 메인 스레드에서 `init_pygame()` + `tick()` 루프 ✅
- **워커 스레드 = LLM/TTS만** (pygame 호출 안 함)

### 크래시 #2: pygame.init() 오디오 race
- **증상**: EXC_BAD_ACCESS, AudioQueue/AQConverter/IOThread 비동기 스레드 다수 활성화
- **원인**: `pygame.init()` = SDL_INIT_AUDIO 자동 init → pyttsx3와 오디오 디바이스 경합
- **해결**: `pygame.init()` ❌ → `pygame.display.init() + pygame.font.init()` ✅ (오디오 명시 안 init)
- **추가**: `os.environ["SDL_AUDIODRIVER"] = "dummy"` 환경변수 사전 설정

### 크래시 #3: pygame.time.Clock() 타이머 race
- **증상**: Thread 10 SDLTimer 활성화, pgEvent_New에서 PyDict NULL deref
- **원인**: `pygame.time.Clock()` 인스턴스화 → SDL_TimerThread 생성 → 메인 스레드와 race
- **해결**: Clock 사용 ❌ → 메인 루프의 `time.sleep(0.005)` throttle ✅
- **활성 비동기 스레드 0개** (NSEventThread = AppKit 메인만)

## pygame.arc 좌표계 함정

3차례 같은 함정:
- 코드: `arc(rect, 0.15*π, 0.85*π, 5)` — 0~π이라 위로 볼록 ∩
- 실제 그림: 위로 볼록 ∩ (맞음)
- vision_analyze: "아래로 휜 슬픈 표정"으로 잘못 해석 (3번 연속)

**결론**: vision이 arc/원 기반 그래픽을 50% 확률로 잘못 해석. 픽셀 점 sin 곡선은 95%+ 정확히 해석.

→ **face.py _draw_mouth/_draw_eye에서 pygame.arc 완전 제거, 픽셀 점 + sin 곡선만 사용**

## 라이선스 조사 결과

| 출처 | LICENSE | 차용 가능 |
|---|---|---|
| m5stack/StackChan/firmware | MIT | ✅ (코드 구조) |
| stack-chan/stack-chan | Apache-2.0 | ✅ (JS 코드) |
| stack-chan/m5stack-avatar | 없음 | ❌ All Rights Reserved |
| Gitshaoxiang/xiaozhi-esp32-avatar | MIT | ✅ (이름/구조/알고리즘) |
| 커뮤니티 fan art | 미명시/ARR | ❌ |

**차용한 것**: 20개 표정 명명 규칙, 매핑 구조, sin 곡선 알고리즘
**차용 안 한 것**: 픽셀 좌표, 색상 팔레트, 디자인 PNG

**CREDITS.md 작성**: MIT 저작자 + 라이선스 전문 + 변경 사항 명시

## 사용자 피드백 (수정 신호)

| 사용자 발화 | 의도 | 학습 |
|---|---|---|
| "별로네" | v1 디자인 불만 | StackChan 디자인 차용 필요 |
| "밝은 원형 하이라이트가 너무 거슬림" | 단순화 선호 | 도형 장식 최소화 |
| "한글 폰트가 깨짐" | 이모지/한글 pygame 지원 안 함 | 영문 라벨 + 깨끗한 폰트 선택 |
| "스택챈은 귀여운데, 이건 별로" | 디자인 톤 차이 | 픽셀 아트 + 흰 박스 StackChan 스타일 |
| "Gitshaoxiang MIT 알고리즘 참고" | 깨끗한 오픈소스 차용 | License-Safe Borrowing 원칙 |

## 환경 디버깅 노트

- **Hermes 내부 Python**: 3.8 (시스템 Python) — pygame 미설치
- **사용자 터미널 (base)**: conda 3.9 — base pip 죽음 (InvalidVersion)
- **해결**: conda 환경 분리 `kiwi` (Python 3.11) + pygame/pyttsx3/requests 설치
- **bash run.sh 래퍼**: conda activate 자동화 + Hermes secrets 자동 source
- **헤드리스 검증**: `SDL_VIDEODRIVER=dummy` + stdin 파이프 → 통합 파이프라인 테스트

## 라이브러리 의존성 트리

```
kiwi-companion/
├── System Python 3.11 (conda env)
│   ├── pygame 2.6.1 (display + font 명시 init)
│   ├── pyttsx3 2.99 (Yuna 한국어 음성)
│   └── requests 2.34 (LLM API)
├── macOS 시스템
│   ├── NSApplication (메인 스레드)
│   ├── NSSpeechSynthesizer (Yuna 보이스)
│   └── AppleGothic / Yuna 폰트
└── MiniMax-M3 (Anthropic 호환 API)
```

## 핵심 파일 변경 이력

| 파일 | v1 | v2 | v3 (현재) |
|---|---|---|---|
| face.py | 원형 키위 primitive | StackChan 흰 박스 | 20개 표정 + 픽셀 점 |
| llm.py | 5개 감정 | 시스템 프롬프트 강화 | 20개 감정 태그 |
| kiwi.py (main) | 동기 stdin | 메인 스레드 + 워커 큐 | (동일 유지) |
| run.sh | 없음 | conda 자동화 래퍼 | (동일 유지) |
| CREDITS.md | 없음 | 없음 | MIT 표기 |

## 다음 세션 메모

- 사용자는 **brainstorming 우선 + 2~3 옵션 + 추천** 패턴 일관되게 선호
- 디자인 작업에서 **vision_analyze 시각 검증** 매우 효과적
- **license-first 조사** 자동화 (curl + LICENSE raw URL)가 새 자산 요청 시 1차 액션
- **픽셀 점 sin 곡선** = 안전 렌더링 (pygame.arc 좌표계 함정 회피)
- macOS 3대 pygame race condition (init/clock/thread) — 추가 세션에서도 동일 패턴으로 확인 가능

## 검증된 환경 (2026-06-23 v3)

| 항목 | 값 |
|---|---|
| OS | macOS 15.5 (Intel Mac) |
| Python | 3.11 (conda env: kiwi) |
| pygame | 2.6.1 (display + font만 init) |
| pyttsx3 | 2.99 + Yuna 음성 |
| LLM | MiniMax-M3 (20개 감정 태그) |
| 얼굴 | 480x480 pygame, 흰 박스 + 검은 디스플레이 |
| 표정 | 21개 (20 감정 + 깜빡임) |
| 활성 비동기 스레드 | 0개 |
