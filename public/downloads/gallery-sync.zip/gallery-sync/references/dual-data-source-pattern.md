# Gallery Dual-Data-Source Pattern (2026-05-24)

## 问题现象
index.html 하단에 하드코딩된 `GALLERY_DATA` 배열이 gallery_data.json과 동기화되지 않아서:
- 카드에 이미지 없음 (`images: []` 빈 배열)
- 모달에 이미지 안 뜸 (getImageSrc 미호출)
- 실제 데이터와 불일치 발생

## 근본 원인
```
gallery_data.json (진실) ← Ajax fetch로 동적 로딩
       ↑ 불일치
index.html 내장 GALLERY_DATA (하드코딩) ← 페이지 로드 시 즉시 사용
```

## 해결 흐름
1. gallery_data.json 수정 → 항상 이것이 진실
2. `bash ~/.hermes/scripts/gallery_build.sh` 실행
   - JSON 유효성 검증
   - images 배열 빈 배열 检测
   - index.html 내장 데이터 자동 동기화
   - Git 자동 커밋 & 푸시
3. GitHub Pages 배포 확인 (1~2분 소요)

## build.sh 검증 로직 요약
```bash
# 1. JSON 유효성
python3 -c "import json; json.load(open('gallery_data.json'))"

# 2. 빈 images 배열检测
for entry in data['entries']:
    if not entry.get('images'):
        print(f"❌ [{entry['date']}] - images 배열 비어있음!")
        sys.exit(1)

# 3. index.html GALLERY_DATA 치환
# 4. Git commit & push
```

## Self-Healer false positive 참고
cron_self_healer.py의 `r"(?:api.*(?:error|401|403|429|500)|unauthorized)"` 패턴이
파일 경로의 "401"도 APIError로 오탐하는问题:
- `~/.hermes/memory/notion-401-troubleshooting.md` → 경로에 "401" 포함
- 이런 경우 jobs.json의 실제 상태를 직접 확인해야 함
- 개선 가능: `r"\b(?:api.*(?:error|failed)|unauthorized|rate\s*limit)\b"` (단어 경계 추가)