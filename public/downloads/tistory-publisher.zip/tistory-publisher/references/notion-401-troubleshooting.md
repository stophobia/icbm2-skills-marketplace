# Tistory Publisher — Notion 401 Troubleshooting Reference

## Symptom

```
Notion API error (POST databases/34276f2e-9097-811e-ab69-f8759ecf0be7/query): HTTP Error 401: Unauthorized
```

All Notion operations fail with 401 during `blog_pipeline.py` execution.

## Root Cause

Notion integration token has expired or been invalidated. Common causes:
- Token rotation by user
- Notion API key regeneration
- Integration access revoked on Notion workspace

## Impact on blog_pipeline.py

When Notion is unavailable:
1. `select_top12_geeknews()` fails → returns empty list
2. Active topics cannot be marked as used/deactivated in Notion
3. New topics cannot be added to Notion DB
4. Final output: `{"status": "skip", "reason": "'기타' 카테고리의 긱뉴스 주제와 트렌드 주제 모두 소진되었습니다"}`

## Workaround (Current Session — 2026-05-19)

`--refresh-topics` falls back to RSS-only mode:
1. Fetches GeekNews RSS directly from `https://news.hada.io/rss`
2. Extracts 12 latest topics
3. Does NOT persist to Notion (fails silently)
4. Returns topics JSON with `"added": 0, "failed": 12`

The pipeline then uses the in-memory topic list for selection, bypassing Notion completely.

## Verification

```bash
# Test Notion API directly
curl -X POST "https://api.notion.com/v1/databases/34276f2e-9097-811e-ab69-f8759ecf0be7/query" \
  -H "Authorization: Bearer $NOTION_TOKEN" \
  -H "Notion-Version: 2022-06-28" \
  -H "Content-Type: application/json" \
  -d '{"page_size": 1}' \
  -w "\nHTTP_STATUS:%{http_code}\n"
```

Expected: `HTTP_STATUS:200`. If `401` → token invalid.

## Fix

1. Go to https://www.notion.so/my-integrations
2. Select the integration (ICBM blog)
3. Click "Show API key" → Regenerate
4. Update the token in `~/.hermes/secrets/notion.env` or environment variable `NOTION_TOKEN`
5. Re-invite integration to the database if access was revoked

## Session Log (2026-05-19)

- 06:00 KST cron: Notion 401 errors → fallback to RSS-only mode → successfully published "Apple Silicon은 OpenRouter보다 비용이 더 든다" (sigco.tistory.com/445)
- Notion topics refresh via `--refresh-topics` showed `added: 0, failed: 12`
- Pipeline still selected topic from RSS-derived list, bypassing Notion completely