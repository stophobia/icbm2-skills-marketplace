last_updated: 2026-06-16

# macOS 비공식 CLI 도구 통합 (kmsg / MCP / AX 트리 접근)

> macOS GUI 앱을 **macOS Accessibility (AX) API**로 제어하는 비공식 CLI 도구들 — `kmsg` (카카오톡), `kbfuse` (Karabiner), `skhd`, `hammerspoon` 등 — 을 Python에서 subprocess로 wrapping할 때의 비-자명한 함정과 검증된 패턴.

## 트리거

다음 작업 중 하나라도 해당되면 이 문서 참고:
- "macOS GUI 앱을 자동화하는 Python CLI 만들어줘"
- "MCP 서버를 Python stdio 클라이언트로 통합해줘"
- "kmsg / kmsg-mcp / slakh / hammerspoon 같은 도구를 wrapping해줘"
- "AX (Accessibility) 트리에 접근하는 외부 도구 호출"
- "subprocess로 GUI 도구 호출 시 hang / timeout / 빈 응답"

## 핵심 함정 4가지 (kakao-summary 2026-06-16 실전 추출)

### 함정 1: PTY 할당 필수 — `subprocess.run` no-TTY는 hang

macOS 비공식 CLI 도구 (kmsg 류)는 **PTY (pseudo-terminal) 할당이 없으면** 다음 문제가 발생:
- `subprocess.run(..., text=True)` → 카톡 AX 트리 접근 거부 → 30초+ hang
- `subprocess.run(..., capture_output=True)` → 동일
- 응답은 빈 stdout, stderr도 비어있음 (디버깅 어려움)

**해결**: `pty.openpty()`로 master/slave fd 쌍 만들고 subprocess에 slave fd 연결:

```python
import pty
import os
import subprocess

def call_with_pty(cmd: list[str], timeout: int = 30) -> str:
    master_fd, slave_fd = pty.openpty()
    proc = None
    try:
        proc = subprocess.Popen(
            cmd,
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            close_fds=True,
        )
        os.close(slave_fd)
        slave_fd = -1  # type: ignore
        output_bytes = b""
        while True:
            try:
                chunk = os.read(master_fd, 4096)
            except OSError:
                break
            if not chunk:
                break
            output_bytes += chunk
        proc.wait(timeout=timeout)
        return output_bytes.decode("utf-8", errors="replace")
    except subprocess.TimeoutExpired:
        if proc:
            try: proc.kill()
            except Exception: pass
        raise
    finally:
        try: os.close(master_fd)
        except OSError: pass
        if slave_fd != -1:  # type: ignore
            try: os.close(slave_fd)  # type: ignore
            except OSError: pass

# 사용
out = call_with_pty(["kmsg", "read", "단톡방", "--limit", "20", "--json"])
data = json.loads(out)  # 정상 동작
```

**대안 — `-i` (interactive) 플래그로 PTY 암묵적 할당**: 일부 도구는 `-i` 또는 `--interactive`로 PTY 모드 강제 가능. kmsg는 PTY 자동 할당이 안 되어 위 패턴 필수.

**fallback ladder** (안 되면 한 단계씩):
1. `pty.openpty()` (위 코드) — 90% 해결
2. `subprocess.Popen(..., shell=True)` — PTY 없이 호출 (kmsg는 실패)
3. `osascript` bridge — AppleScript로 우회 (macOS native)
4. 사용자가 수동으로 메시지 복사 (최후 수단)

### 함정 2: MCP `initialize` 핸드셈 필수

MCP (Model Context Protocol) 서버를 stdio JSON-RPC으로 호출할 때, `tools/call`을 바로 보내면:

```json
{"error": {"code": -32002, "message": "Server not initialized"}}
```

**정확한 순서** (MCP 2024-11-05 명세):
1. `initialize` 요청 (응답 받음)
2. `notifications/initialized` (notification, 응답 없음)
3. 그 다음 `tools/call` / `resources/read` 등

```python
def start(self):
    self._proc = subprocess.Popen(
        [self.python_bin, "-u", self.server_path],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, bufsize=1,
    )
    # 1) initialize
    init = self._send_request("initialize", {
        "protocolVersion": "2024-11-05",
        "capabilities": {},
        "clientInfo": {"name": "my-tool", "version": "0.1.0"},
    })
    # 2) initialized notification
    self._send_notification("notifications/initialized", {})

def _send_notification(self, method: str, params: dict):
    if self._proc is None or self._proc.stdin is None:
        raise UnavailableError()
    self._proc.stdin.write(json.dumps({
        "jsonrpc": "2.0", "method": method, "params": params,
    }) + "\n")
    self._proc.stdin.flush()
```

**⚠️ 한 줄 빠뜨리면 모든 도구 호출 실패** — initialize 빼먹고 tools/call만 보내면 "Server not initialized" 또는 `-32002` 에러.

**재사용**: kmsg-mcp / filesystem-mcp / github-mcp / postgres-mcp / 모든 MCP 서버 wrapping 시 동일.

### 함정 3: kmsg-mcp PROCESS_TIMEOUT — kmsg CLI 직접 호출이 fallback

**증상**: kmsg-mcp 서버가 subprocess 안에서 `kmsg read`를 호출할 때 20초 타임아웃 자주 발생. 카톡 창이 백그라운드이거나, AX 트리 접근 차단.

**원인 추정**:
- kmsg-mcp가 자체 subprocess로 kmsg 호출 → PTY 미할당
- 또는 카톡 창이 background인데 AX 트리 접근 거부

**fallback 패턴** — kmsg-mcp 우회, kmsg CLI 직접 호출:

```python
# kakao-summary의 kmsg_cli_client.py
import subprocess, json
import pty
import os

class KmsgCliClient:
    def read(self, chat: str, limit: int = 20) -> list[RawMessage]:
        # PTY 모드로 kmsg CLI 직접 호출 (kmsg-mcp 우회)
        master_fd, slave_fd = pty.openpty()
        proc = subprocess.Popen(
            [self.kmsg_bin, "read", chat, "--limit", str(limit), "--json"],
            stdin=slave_fd, stdout=slave_fd, stderr=slave_fd, close_fds=True,
        )
        os.close(slave_fd)
        # ... PTY read loop (함정 1 코드) ...
        return self._parse_json_output(output, chat)
```

**장점**: kmsg-mcp 설치/설정 불필요, kmsg CLI 한 줄로 끝. **단점**: cursor/page 미지원 (kmsg-mcp도 결국 limit=100) — **과거 시점 데이터 (어제) fetch 불가**.

### 함정 4: argparse subparser + positional `nargs="?"` 충돌

`parser.add_argument("chat", nargs="?")` + `add_subparsers` 공존 시, **chat 이름에 특수문자(`[`, `]`, `x`, 공백)**가 있으면 argparse가 subparser 이름을 무시하고 chat을 COMMAND로 잘못 매칭.

**증상**:
```bash
$ kakao-summary sync "[코드팩토리] x 클로드 코드" --target 100
kakao-summary: error: argument COMMAND: invalid choice: '[코드팩토리] x 클로드 코드'
(choose from 'sync', 'summarize', 'status', 'chats')
```

**해결**: positional `chat` 제거, 모든 서브 명령에 `--chat` 필수 옵션:

```python
parser = argparse.ArgumentParser(prog="kakao-summary")
subparsers = parser.add_subparsers(dest="command", required=False)

sync_p = subparsers.add_parser("sync")
sync_p.add_argument("--chat", required=True, help="채팅방 이름")  # ← --chat, required
sync_p.add_argument("--target", type=int, default=1000)

sum_p = subparsers.add_parser("summarize")
sum_p.add_argument("--chat", required=True)  # ← --chat
# ... 다른 옵션들 ...

# 단축 사용 패턴 (`mytool <chat>`) 포기
```

**재사용**: 외부 입력 (단톡방 이름, URL, 파일 경로) 에 사용자 자유 텍스트가 들어가는 모든 argparse CLI. **예방**: 처음부터 `nargs="?"` 회피.

## 검증된 macOS 권한 안내 패턴

### 시스템 설정 deep link로 권한 페이지 한 번에 열기

```bash
# 손쉬운 사용 (Accessibility) — PTY wrapping 도구에 필요
open "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"

# 화면 기록 (Screen Recording) — OCR fallback에 필요
open "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture"

# 전체 디스크 접근 (Full Disk Access) — 파일 직접 읽기에 필요
open "x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles"

# Fallback (deep link 안 먹으면)
open "/System/Library/PreferencePanes/UniversalAccessPref.prefPane"
```

**macOS 13+ Ventura에서 동작**. 사용자가 5번 클릭 절약. **재사용**: 손쉬운 사용, 화면 기록, 전체 디스크 접근, 카메라, 마이크, 연락처 등 모든 macOS 권한 안내.

### 사용자에게 안내할 때 한 줄

> "시스템 설정 → 개인정보 보호 및 보안 → 손쉬운 사용 → `+` → `Cmd+Shift+G` → `/usr/local/bin/kmsg` 입력 → 이동 → kmsg 추가 → 토글 켜기. 터미널 앱도 추가 (`/Applications/Terminal.app` 또는 iTerm2)."

## kmsg / kmsg-mcp / skhd / hammerspoon 통합 시 결정 트리

| 도구 종류 | 추천 통합 방식 | PTY 필요? | initialize 핸드셈? | 권한 필요 |
|---|---|---|---|---|
| **kmsg** (kakao CLI) | `pty.openpty()` + `subprocess.Popen` | ✅ 필수 | N/A (CLI) | 손쉬운 사용 |
| **kmsg-mcp** (MCP 서버) | stdio JSON-RPC + initialize | ❌ (no-TTY에서 잘 됨) | ✅ 필수 | 손쉬운 사용 |
| **skhd** (Karabiner hotkey) | `subprocess.run` | ❌ | N/A | 손쉬운 사용 |
| **hammerspoon** (Lua bridge) | `subprocess.run` + Lua 스크립트 | ❌ | N/A | 손쉬운 사용 |
| **Karabiner-Elements** | JSON 설정 파일 직접 편집 | ❌ | N/A | 없음 |
| **yabai** (tiling wm) | `subprocess.run` | ❌ | N/A | 손쉬운 사용 |

## 검증된 의존성 uninstall 절차

kmsg / kmsg-mcp 같은 비공식 도구를 uninstall할 때:

```bash
# 1. 의존성 확인 (transitive deps 사전 점검)
brew deps channprj/tap/kmsg --installed
# 출력 예: python@3.13, ripgrep, fzf
# → 다른 용도로 쓰는지 확인 후 필요시 `brew install python@3.13` 등 재설치 예약

# 2. uninstall (transitive deps 자동 정리될 수 있음)
brew uninstall channprj/tap/kmsg

# 3. 잔재 정리
trash ~/Library/Logs/Homebrew/kmsg
trash ~/Library/Caches/Homebrew/kmsg--1.260606.1
trash ~/.local/share/kmsg-mcp/
trash ~/.cache/<package-name>/

# 4. 검증
which kmsg  # → 없음
find ~ -maxdepth 5 -iname "*kmsg*"  # → 의도된 파일만 남음
```

**⚠️ transitive deps 부작용**: `brew uninstall`이 **다른 formula를 같이 제거**할 수 있음. kmsg uninstall 시 python@3.13 (74MB), ripgrep, fzf 자동 제거된 사례 (2026-06-16). **예방 필수**.

## 진단 도구 — kmsg 연결성 빠른 점검

```bash
# 1. Accessibility 권한
kmsg  # 첫 줄에 "Accessibility Permission: ✓ Granted" 또는 "✗ Not Granted"

# 2. 카톡 실행 확인
kmsg status  # "KakaoTalk: ✓ Running"

# 3. 채팅방 목록 (친구/메타 스캔)
kmsg chats  # "Found N chat(s)"

# 4. 특정 채팅방 메시지 읽기 (PTY 필요)
kmsg read "단톡방 이름" --limit 20 --json  # 정상 동작 확인
```

**이 4개 모두 통과하면 kakao-summary 같은 wrapping 도구가 동작할 가능성 95%**.

## AX 트리 한계 — 정직한 제약

**macOS 비공식 도구로 절대 못 하는 것**:
- **과거 시점 데이터 스크롤**: kmsg-mcp/kmsg 모두 "최근 N개"만 노출. 단톡방 1000개 중 100개만 보임. 어제 대화는 못 읽음. → **사용자 요구 "어제 단톡방 정리"가 본질적으로 불가능**
- **카톡 공식 API 부재**: OAuth/공개 API 없음. macOS 비공식 AX 트리 의존
- **카카오톡 업데이트 시 깨짐**: AX 트리 구조 바뀌면 kmsg 동작 안 함. 업그레이드 후 첫 1~2주는 불안정
- **다국어 UI 변경**: 영문/한글/일본어 카톡 UI 각각 다르게 동작. kmsg가 모든 로케일 지원하는지 검증 필요

**해결책**:
- kakao-summary는 "오늘 데이터"만 가능. "어제"는 사용자 직접 export.
- **wrapping OSS 첫 부트스트랩 전에 wrapping 대상 도구의 한계 명확히 파악** — 사용자가 원하는 것을 못 주면 그 OSS는 가치가 없음
- **kakao-summary 사례 (2026-06-16)**: 1세션 만에 decommission. 사용자가 "어제 데이터" 요구했으나 kmsg가 못 줌 → 5단계 절차로 제거

## 다른 OSS에 적용 시 체크리스트

새 macOS 비공식 CLI 도구 wrapping OSS 부트스트랩 시:

- [ ] wrapping 대상 도구의 **한계** 파악 (최근 N개 / 페이지네이션 / 과거 시점)
- [ ] 사용자 요구사항이 그 한계 **안에 있는지** 확인
- [ ] **PTY 할당** 패턴 (`pty.openpty()`) — stdio JSON-RPC, subprocess CLI 모두
- [ ] MCP 서버면 **initialize 핸드셈** 3단계 (initialize → initialized → tools/call)
- [ ] 시스템 설정 **deep link** 안내 (`open x-apple.systempreferences:...`)
- [ ] `which <tool>` + `kmsg status` 류 **연결성 점검 명령** README에 명시
- [ ] uninstall 절차 + transitive deps 점검 가이드
- [ ] 첫 부트스트랩 1세션 내에 **사용자 요구 검증** — 못 주면 즉시 decommission

## 관련 스킬

- `python-oss-bootstrap` (references/external-tool-wrapping.md) — 일반 외부 도구 wrapping 패턴
- `python-oss-bootstrap` (references/case-studies.md 사례 4) — kakao-summary 시퀀스
- `python-oss-bootstrap` (Phase 2 Decommission) — 5단계 제거 절차
