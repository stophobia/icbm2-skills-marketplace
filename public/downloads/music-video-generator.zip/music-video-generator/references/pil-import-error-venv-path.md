# PIL ImportError — python3 vs venv 경로 충돌

## 증상

```
ModuleNotFoundError: No module named 'PIL'
```

스크립트 실행 시 PIL( Pillow ) 모듈을 찾지 못하는 오류.

## 원인

`source secrets/minimax.env`로 환경변수 설정 후 `python3` 명령만 호출하면:

- `python3` → `/usr/bin/python3` (시스템 Python, PIL 없음)
- venv `python3` → `~/.hermes/hermes-agent/venv/bin/python3` (PIL 설치됨)

bash 스크립트에서 `source`로 환경변수를 설정해도, `python3`는 PATH 우선순위로 시스템 Python을 실행함.

## 해결 방법

**Python 실행 시 venv 경로 직접 지정:**

```bash
# ❌ 시스템 python3 — PIL 없음
source ~/.hermes/secrets/minimax.env
python3 script.py

# ✅ venv python3 — PIL 설치됨
source ~/.hermes/secrets/minimax.env
/Users/hjshin/.hermes/hermes-agent/venv/bin/python3 script.py
```

## 검증

```python
import sys
print(sys.executable)  # /Users/hjshin/.hermes/hermes-agent/venv/bin/python3 인지 확인
from PIL import Image
print("PIL OK")
```

## 관련 파일

- Venv 경로: `~/.hermes/hermes-agent/venv/bin/python3`
- 시스템 python3: `/usr/bin/python3` (3.9.6)
- PIL 설치 위치: venv 내 `lib/python3.x/site-packages/PIL/`

## 발생 이력

- 2026-05-25: quick_mv_2topics.py 실행 시 PIL ImportError → venv python3 경로 지정으로 해결