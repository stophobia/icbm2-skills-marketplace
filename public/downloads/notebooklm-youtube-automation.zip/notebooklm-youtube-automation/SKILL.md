---
name: notebooklm-youtube-automation
description: NotebookLM에서 생성한 비디오 오버뷰를 YouTube에 업로드하는 워크플로우 — 사용자가 직접 선택 후 수동 요청
trigger: "notebooklm, youtube upload, video overview, automation"
---

# NotebookLM YouTube 자동화 워크플로우

## ⚠️ 핵심 수정 이력

| 날짜 | 수정 내용 |
|------|----------|
| 2026-05-11 | 번호 불일치 해결, topics 원본 보존, YouTube 제목 변환 제거 |
| 2026-05-12 | selection.py가侯選 전송 시 topics 저장, delete CLI 옵션 수정, upload_pipeline 경로 오류 수정 |

---

## 파일 구분 — 절대 혼동하지 말 것

| 파일 | 위치 | 용도 |
|------|------|------|
| `notebooklm_selection.json` | `~/.hermes/memory/` | **侯選 topics 목록** (date, topics[], selection_numbers) — 번호 매핑용 |
| `notebook_ids.json` | `/tmp/icbm_notebooklm/` | **생성된 노트북 ID 목록** (prepare.py 결과물) — 노트북 ID 확인용 |
| `notebook_info.json` | `/tmp/icbm_notebooklm/` | **업로드 파이프라인용 메타데이터** — pipeline 실행 전 필요 |

> ⚠️ **侯選 topic 번호 매핑 시 절대 `notebook_ids.json`를 읽지 마라.**
> 이 파일은 이미 생성된 노트북만 담고 있어侯選 번호(1~11)가 "없다"고 잘못 응답하게 된다.

**올바른 번호→topic 매핑:**
```python
with open(os.path.expanduser("~/.hermes/memory/notebooklm_selection.json")) as f:
    selection = json.load(f)
topics = selection["topics"]  #侯選 전송 시 저장된 원본
nums = [2, 3, 4, 10]         # 1-indexed 번호
selected = [topics[n - 1] for n in nums]
```

---

## 워크플로우 3단계

### 1단계:侯選 전송 (매일 16:00 크론)
**스크립트:** `notebooklm_selection.py`

Notion DB에서 최신侯選 주제를 로드하여 텔레그램으로 전송.
Telegram 전송 직후 topics를 `~/.hermes/memory/notebooklm_selection.json`에 저장.

### 2단계: 노트북 생성 (사용자 번호 선택 후)
**스크립트:** `notebooklm_prepare.py`

사용자가 선택한 번호(예: `2,3,4,10`)를 읽고:
1. 각 주제에 맞는 소스를 동적으로 수집
2. NotebookLM 노트북 생성
3. 노트북에 소스 추가

**소스 수집 규칙:**
| 카테고리 | 소스 |
|---------|------|
| AI/ML | GitHub API + HackerNews |
| 개발도구 | GitHub API + ProductHunt |
| 개발팁 | HackerNews + Reddit |

### 3단계: 업로드 (사용자가 "업로드"라고 요청)
**스크립트:** `notebooklm_upload.py`

주인님이 NotebookLM에서 비디오 오버뷰를 **모두 생성한 후** "업로드"라고 알려주시면:
1. 각 노트북에서 비디오 오버뷰 다운로드
2. 주제 키워드로 출처 재수집 → 설명에 출처 URL 포함
3. 일반 영상 + 숏츠 동시 업로드 (N:N)
4. 노트북 자동 정리

**⚠️ 일부 topic 영상 생성 실패 시:**
```
사용자가 "2번은 영상생성이 안 되네, 나머지만 업로드해줘"라고 알려줌
  → /tmp/icbm_notebooklm/에는 오늘 생성된 영상이 없을 수 있음
  → 사용자에게 파일 위치를 먼저 물어야 함
  → 성공한 topic만 notebook_info.json에 수동 등록 후 upload pipeline 실행
  → 실패 topic은 절대 upload 시도하지 말 것
```

---

## Notion侯選 DB ID (두 개 있음 — 절대 혼동)

| 용도 | DB ID |
|------|-------|
|侯選 전송 크론 (`notebooklm_selection.py`) | `41d83ee7-6925-4f77-a26d-40a3a10bf852` |
| prepare.py 내부 DB 조회 | `34276f2e-9097-811e-ab69-f8759ecf0be7` |

---

## YouTube 업로드 — `yt_upload.py`는 positional argument만

**재발방지:** `yt_upload.py`는 `sys.argv[1]`, `sys.argv[2]`, `sys.argv[3]` positional 인자만 해석.
절대 `--title`, `--description` 같은 키워드 인자로 호출하지 말 것.

```python
# ✅ 올바른 호출
subprocess.run(["python3", script, file_path, title, description], timeout=300)

# ❌ 잘못된 호출 (인자 무시됨)
subprocess.run(["python3", script, file_path, "--title", title, ...], ...)
```

**사용하는 스크립트:** `~/.hermes/scripts/yt_upload.py`
(`~/.hermes/skills/creative/youtube-uploader/scripts/upload.py`는 존재하지 않음)

---

## OAuth 토큰 만료 시 복구

**증상:** `upload.py` timed out after 120s / `yt_upload.py` 호출 시 `EXPIRED - needs reauth`

```python
import os, pickle
from google.auth.transport.requests import Request

TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")
with open(TOKEN_FILE, "rb") as f:
    creds = pickle.load(f)

if not creds.valid:
    creds.refresh(Request())
    with open(TOKEN_FILE, "wb") as f:
        pickle.dump(creds, f)
    print("Token refreshed! valid:", creds.valid)
```

토큰이 만료되면 `yt_upload.py`가 OAuth refresh loop에 빠져 hanging 상태가 됨.
수동 refresh 후 정상 업로드 가능. 자주 사용하면 자연스럽게 갱신됨.

---

## notebooklm CLI 옵션

**delete:**
```bash
# ❌ 오답
notebooklm delete <id> -y

# ✅ 정답
notebooklm delete -n <id> -y
```

**확인:** `notebooklm delete --help`

---

## Shorts 세트 업로드 — 필수 규칙

일반 영상 업로드 시 반드시 Shorts도 함께 제작 + 업로드. (N:N 정책)

**Shorts 규격:** 9:16 세로형 (1080x1920), 59초 이하, SAR=1:1, DAR=9:16

**FFmpeg 변환 (Blur Letterbox):**
```bash
ffmpeg -y -i input.mp4 -t 59 \
  -filter_complex "
    [0:v]split=2[bg][fg];
    [bg]scale=1080:1920,boxblur=20,setsar=1:1,setdar=9/16[bg2];
    [fg]scale=1080:-1,setsar=1:1,setdar=9/16[fg2];
    [bg2][fg2]overlay=(W-w)/2:(H-h)/2[vout];
    [0:a]atrim=0:59,afade=t=out:st=56:d=3[aout]
  " \
  -map "[vout]" -map "[aout]" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  -pix_fmt yuv420p -movflags +faststart \
  output.mp4
```

**FFmpeg boxblur 구문:** `boxblur=lr:lp` 형태만 지원. `cr=`, `cs=`, `cp=` 옵션 없음.

---

## 단일 영상 다운로드

```bash
# 1. 노트북 선택
source ~/.hermes/venv-notebooklm/bin/activate
notebooklm use <notebook_id>

# 2. 비디오 다운로드 — --force만으로 가장 최근 비디오 자동 선택
notebooklm download video /tmp/video.mp4 --force
# 출력: "Video saved to: /tmp/video.mp4" / "Artifact: <제목> (only artifact)"

# 3. ffprobe로 정보 확인
ffprobe -v error -select_streams v:0 -show_entries stream=width,height,duration -of csv=p=0 /tmp/video.mp4
```

---

## notebooklm_upload_pipeline.py 사용 시

이 스크립트는 `notebooklm_prepare.py`가 만든 `notebook_info.json`을 전제함.
우회로 노트북을 생성했다면 수동으로 만들어야 함:

```bash
cat > /tmp/icbm_notebooklm/notebook_info.json << 'EOF'
[
  {
    "notebook_id": "<노트북-ID>",
    "title": "<주제명>",
    "content_type": "ai_deep_review"
  }
]
EOF
python3 ~/.hermes/scripts/notebooklm_upload_pipeline.py
```

**content_type 옵션:** `github_trending`, `daily_tech`, `ai_deep_review`

---

## 절대 규칙

1. **侯選 topic 번호 매핑** → `~/.hermes/memory/notebooklm_selection.json`의 `topics` 배열만 사용
2. **`notebook_ids.json` 읽지 마라** — 이미 생성된 노트북용
3. **`yt_upload.py`는 positional argument만** — `--key value` 형태 금지
4. **영상 생성 실패 topic** → upload 시도하지 말 것
5. **노트북 수동 삭제 금지** — ID 유실 → 출처 누락 + 파이프라인 꼬임
6. **자동 영상 생성 금지** — 사용자가 직접 NotebookLM에서 생성 후 "업로드"라고 알려줘야 실행

---

## 스크립트 구조

```
~/.hermes/scripts/
├── notebooklm_selection.py        #侯選 전송 (16:00 크론)
├── notebooklm_prepare.py        #노트북+소스 생성 (선택 후)
├── notebooklm_upload.py         #On-Demand 업로드
└── yt_upload.py                 #YouTube OAuth 업로드 (직접 호출)
```

---

## 参考文件

- `references/verify-fix-2026-05-11.md` — 2026-05-11 수정 내역
- `references/verify-fix-2026-05-12.md` — 2026-05-12 수정 내역 (3버그 수정, OAuth 토큰 만료)
- `references/verify-fix-2026-05-12-files.md` — 파일 혼동 버그 상세 분석