# 2026-05-13 —侯選 번호 불일치 근본 원인 분석

## 증상
사용자가 "2, 6, 7 선택"이라고 하면 내가 엉뚱한 topic을 생성함.
-侯選에 없는 번호를 고른다거나
-번호는 있지만 제목이 다르다
-아예侯選 목록이 안 보인다

## 근본 원인 3가지

### 원인 1:侯選 표시 시 전체 대신 일부만 표시
**실제 흐름:**
1. 16:00 크론 → `selection.json`에 12개 topics 저장 ✅
2. 사용자가侯選 요청 → 내가 `/tmp/icbm_notebooklm/notebook_ids.json`를 읽음 ❌
   → 이 파일은 이미 생성된 4개 노트북만 담고 있음
3. 사용자에게 4개만 보여줌 (1~4번)
4. 사용자가 2,6,7 선택 → 12개 중 2,6,7이 아니라 4개 중 2번, 6번(없음), 7번(없음)

**수정:**侯選 표시 시 항상 `~/.hermes/memory/notebooklm_selection.json`의 `topics` 배열 사용.

### 원인 2: 크론 재실행 시 덮어쓰기
1. 16:00 크론 정상 실행 → 12개 topics 저장
2. 사용자가 "16:00 크론 다시 실행" 요청
3. `notebooklm_selection.py` 재실행 → 같은 파일에 **새 12개 topics 덮어씀**
4.侯選 목록이 아예 바뀜

**수정 (2026-05-13):** `selection.json`에 이미 오늘 topics가 있으면 덮어쓰지 않고 백업만 수행.

### 원인 3: `strip_cjk()` 한자 제거 버그
`notebooklm_prepare.py`의 `load_active_topics_with_urls()`에서:
```python
name = strip_cjk(name)   # ← 이것 때문에 topic name 깨짐
cat = strip_cjk(cat)
```
Notion에 저장된 원본 topic 이름에서 한자/한문을 제거하여 제목이 변경됨.

**수정 (2026-05-13):** `strip_cjk()` 호출 제거 — topics.name 원본 그대로 보존.

## 추가 발견된 버그 (동일 세션)

### 버그 4: `strip_cjk()`가 한국어까지 제거
`notebooklm_upload.py`의 `strip_cjk()` 함수 regex에 한국어 범위(`\uac00-\ud7af`)가 포함되어 있었음.
```python
# BEFORE (버그)
return re.sub(r'[\u4e00-\u9fff\u3400-\u4dbf\u3000-\u303f\uac00-\ud7af]', '', text)
# 한국어 "안녕하세요" → "" (전체 제거)

# AFTER (수정)
return re.sub(r'[\u4e00-\u9fff\u3400-\u4dbf\u3000-\u303f\uff00-\uffef]', '', text)
# 한국어 보존, 한자/한문/全角만 제거
```
`build_description()`에 `topic_name` 원본을 전달하고, `strip_cjk()`는 한자 제거용으로만 사용.

### 버그 5: 출처 URL이 GeekNews 대신 원본 기사 URL로 바뀜
`collect_sources_for_description()`의 0순위에서 `resolve_geeknews_topic_url()`을 호출해서 GeekNews URL이 원본 기사로 변경됨.
주인님 요청: 출처는 항상 GeekNews 토픽 URL 유지.

### 버그 6: 검토 메시지가 코드블록으로 전송됨
Telegram에서 길고 읽기 어려운 포맷. 일반 Markdown + 항목별 이모지 구분으로 개선.

## 수정된 파일
- `~/.hermes/scripts/notebooklm_selection.py` — 덮어쓰기 방지 로직 추가
- `~/.hermes/scripts/notebooklm_prepare.py` — strip_cjk() 제거
- `~/.hermes/scripts/notebooklm_upload.py` — strip_cjk() regex 수정, GeekNews URL 유지, 검토 포맷 개선

## 반복 발생 방지 규칙
1.侯選를 사용자에게 보여줄 때: `selection.json`의 `topics` 배열만 사용
2.크론 재실행해도侯選 목록 보존
3.topic name은 원본 그대로 가공 없이 사용
