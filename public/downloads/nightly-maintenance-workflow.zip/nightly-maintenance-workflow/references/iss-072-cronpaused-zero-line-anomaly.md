# ISS-072 — CronPaused 0-line 자기 매칭 이상 (2026-06-16 발견) 🆕

## 요약

**발견일:** 2026-06-16 03:30 KST
**상태:** 🟡 관찰 중 (1회 관찰, 정식 등록은 3회 반복 시점까지 보류)
**심각도:** 🟢 낮음 (FP 확정, 자동 fix 불필요)
**관련:** ISS-062/063/065/066/067/068/069/071 — Self-Healer FP 메타 트랩 시리즈
**등록 임계:** 1회 관찰 (3회 반복 시 ISS-072 정식 등록)

## 사례

`dc9a2e6aaaaa` (NotebookLM 후보 전송) 잡에서 self-healer가 `CronPaused` 패턴 `(?:paused|disabled|stopped)` 매칭을 1건 보고.

### (a) self_heal 리포트 매칭 잡 확인

`memory/self_heal_2026-06-16.md`에서:
```json
{
  "type": "output_error",
  "message": "출력에서 CronPaused 감지 — 패턴 매치: (?:paused|disabled|stopped)",
  "job": "📝 NotebookLM후보 전송 (사용자 선택 후 생성)",
  "path": null
}
```

`path: null` 주목 — 일반적인 FP 경로(`/path/to/file.md:L123`)와 달리 **매칭 파일 경로가 없음**.

### (b) jobs.json 상태

`dc9a2e6aaaaa` jobs.json:
- `status: ok`
- `last_status_error: ""` (길이 0)
- `last_ok_time: 2026-06-16T03:30:47` (최근)
- `consecutive_failures: 0`

→ 실제 에러 아님.

### (c) cron output grep 검증 (06-16 03:31)

`/Users/hjshin/.hermes/cron/output/dc9a2e6aaaaa/*.md` 72시간 내 모든 파일을 regex `(?:paused|disabled|stopped)`로 grep:

```python
import re
from pathlib import Path
from datetime import datetime, timedelta
root = Path('/Users/hjshin/.hermes/cron/output')
cutoff = datetime.now() - timedelta(hours=72)
pat = re.compile(r'(?:paused|disabled|stopped)', re.I)
for p in root.glob('dc9a2e6aaaaa/*.md'):
    if datetime.fromtimestamp(p.stat().st_mtime) < cutoff: continue
    t = p.read_text(encoding='utf-8', errors='ignore')
    hits = [(i+1, line[:120]) for i, line in enumerate(t.splitlines()) if pat.search(line)]
    print(f'{p.name}: {len(hits)} hits')
```

**결과: 0 hits** — 잡의 모든 cron output 파일에 `paused|disabled|stopped` 단어가 **실제로 등장하지 않음**.

## 분석 — 왜 매칭이 발생했나

`path: null` + 0 hits의 조합은 self-healer의 검사 경로가 다음 중 하나임을 시사:

### 가설 A: 잡 메타데이터 / cron job 정의 파일 검사
- `~/.hermes/cron/jobs/dc9a2e6aaaaa.yaml` 같은 정의 파일에 `disabled: true` 또는 `paused at ...` 같은 시스템 상태가 자동 기록되는 경우
- self-healer가 content 외에 메타 필드도 scan

### 가설 B: jobs.json의 `last_status_error` 또는 다른 필드에 시스템 메시지 기록
- 1단계 monitor가 1회 빈 출력(empty_output)을 감지하면서 `last_status_error: "Cron job stopped due to..."` 같은 시스템 메시지를 자동 삽입했을 가능성
- 단, (b)에서 본 `last_status_error: ""` (빈 문자열)이면 가설 B는 약함

### 가설 C: 출력 파일 mtime/경로 메타 검사
- self-healer의 CronPaused 패턴이 다른 패턴들과 별도 경로 (예: 파일 삭제/이동/만료 검사)에서 발생
- 06-15 22:00 daily 리뷰 시점에 b1bca63a117a 12개 파일이 `cleanup_fix`로 삭제되면서, dc9a2e6aaaaa 잡도 영향 받은 파일 시스템 이벤트 추적

### 가설 D: 알려지지 않은 검사 경로 (bug 또는 의도된 동작)
- self-healer 코드 미확인 상태. cron_self_healer.py에서 `CronPaused` 키워드 검색하여 정확히 어떤 조건에서 `path: null`로 report되는지 확인 필요

## 판별 결과

→ **FP 확정**, 자동 fix 불필요 ✅

- jobs.json: ok
- cron output: 매칭 단어 0건
- `path: null` — 일반적인 FP 경로(`/path/to/file.md:L123`)와 다른 메타 검사 경로

## 기존 패턴과의 차이

| 패턴 | 매칭 위치 | path | 빈도 |
|------|----------|------|------|
| ISS-063 (일일리뷰 자기 진단) | cron output content, 라인 매칭 | `/.../5d0f14aef84c/2026-06-XX_HH-MM-SS.md:L123` | 매일 |
| ISS-067 #2 (Tistory SKILL.md leak) | cron output content, 라인 매칭 | `/.../b1bca63a117a/2026-06-XX_HH-MM-SS.md:L123` | 자주 |
| ISS-068 (심야통합 자기 리포트 leak) | cron output content, 라인 매칭 | `/.../81f1c81f8664/2026-06-XX_HH-MM-SS.md:L123` | 자주 |
| **ISS-072 (CronPaused 0-line) 🆕** | **메타 필드/정의 파일 (추정)** | **`null`** | **1회 관찰** |

**차이점**: 기존 패턴은 모두 cron output content의 라인 매칭 — `path: <file>:L<line>` 형태로 매칭 위치가 명시됨. ISS-072는 `path: null`이라 매칭 경로가 불분명.

## 누적 임계 추적

| 날짜 | FP 에러 수 | 누적 | 임계 | 매칭 잡 |
|------|----------|------|------|---------|
| 06-16 03:30 | 1 (CronPaused 0-line) | 1회 | 1/3 | dc9a2e6aaaaa |

- 06-17 03:30: 2회 관찰 시 → 2/3 임계, 06-22 22:00 일일 리뷰에서 후속 조사
- 06-18 03:30: 3회 관찰 시 → **3/3 임계 → ISS-072 정식 등록**
- 06-19+: 0건 유지 시 → 일회성 버그, ISS-072 등록 안 함

## 권장 후속 작업

1. **cron_self_healer.py 소스 분석**: `CronPaused` 패턴 검사 시 어떤 데이터 소스(content vs metadata vs jobs.json field)를 사용하는지 확인. 06-17 22:00 일일 리뷰에서 권장.
2. **`path: null` 케이스 카운트**: self-healer가 `path: null`로 report하는 빈도가 다른 ISS 패턴(매칭 위치 명시)과 어떻게 다른지 추적. 4주 모니터링 후 pattern 별 cron report 통계.
3. **현재 조치 불필요**: 단발성 관찰, 자동 fix 시도 안 함. ISS-072 정식 등록은 3회 반복 시점까지 보류.

## (a)+(b)+(c) 절차 보강 — `path: null` 케이스

기존 (a)+(b)+(c) 절차에 추가 분기:

| 단계 | 결과 | 다음 단계 |
|------|------|----------|
| (a) 매칭 잡 식별 | `path: <file>:L<line>` | 기존 grep 절차 (c)로 진행 |
| (a) 매칭 잡 식별 | **`path: null`** | **(c2) cron output grep 0건 → self-healer 소스 분석 (가설 A/B/C/D 분기)** |
| (b) jobs.json 상태 | status=ok, last_err="" | FP 의심 |
| (c) grep 매칭 | 0건 | FP 확정 |

`path: null` + (b) ok + (c) 0건 = **메타 검사 경로 FP** (ISS-072 후보) — 자동 fix 불필요.

## 06-17 03:30 KST 업데이트 (NEW, ISS-068 계열 1일 lag + ISS-072 0-line 동시 발현) 🆕

**관찰:** `81f1c81f8664` (심야 통합 점검) 잡이 self-healer에서 `CronPaused` 패턴 매칭 1건 보고. **`path: null`** (06-16 03:30 dc9a2e6aaaaa 케이스와 동일).

```json
{
  "type": "output_error",
  "message": "출력에서 CronPaused 감지 — 패턴 매치: (?:paused|disabled|stopped)",
  "job": "🛡️ 심야 통합 점검 (정비+에러)",
  "path": null
}
```

**검증 (a)+(b)+(c) 절차 + `path: null` 분기 (이 reference의 보강 절차):**
- (a) 매칭 잡 식별: `81f1c81f8664` (심야 통합 점검) — 어제(06-16) 03:30 자기 자신의 self_heal 리포트가 cron output으로 작성되어 매칭된 경로
- (b) jobs.json: status=ok, consecutive_failures=0, last_ok_time=2026-06-17T03:31:21 (최근)
- (c) `cron/output/81f1c81f8664/*.md` 72시간 내 grep `(?:paused|disabled|stopped)`:
  - `2026-06-15_03-33-26.md` (어제 심야 통합 리포트) — `ISS-068/069` 진단 표 안에 "stopped" / "paused" 단어가 informational 텍스트로 등장
  - **매칭 1건** → 어제 자기 자신의 diagnostic 본문이 본 단어 포함 → 1일 lag 구조 한계
- (c2) `path: null` 분기: 매칭 잡의 어제 output이 본 단어 보유 → ISS-068 계열 FP로 통합 분류 가능 (별도 ISS-072 분기 트리거 아님)

**판별:** ISS-068 계열 (1일 lag 자기 진단 leak) + ISS-072 패턴 (CronPaused regex) **동시 발현** — 동일 현상의 두 관점. 5d0f14aef84c (일일리뷰) FP + 81f1c81f8664 (심야통합) FP 합쳐서 ISS-068/069 시리즈로 카운트.

**누적 임계 (ISS-072 단독, 자기 진단 leak 제외):**
| 날짜 | CronPaused 0-line 매칭 | path | 매칭 잡 | 비고 |
|------|---------------------|------|---------|------|
| 06-16 03:30 | 1 | null | dc9a2e6aaaaa (NotebookLM후보) | 1회째 관찰 |
| 06-17 03:30 | 0 (CronPaused 단독) | — | — | ISS-068 계열 1일 lag와 합쳐져서 카운트 분리 안 됨 |

→ **ISS-072 단독 매칭은 1회 (06-16)** + **ISS-068/069 1일 lag 합쳐진 케이스 1회 (06-17)** = 총 2회 관찰, 정식 등록까지 보류 (3회 반복 시점).

**조치:**
- 자동 fix 불필요 (FP 확정) ✅
- 06-17 22:00 일일 리뷰 권장: `mask_self_healer_terms.py`에 `(?:paused|disabled|stopped)` 라인 마커 추가 (Tistory known-issues의 "paused" 워딩 + 일일 리뷰 표의 "stopped due to ..." 인용 마스킹)
- cron_self_healer.py의 `CronPaused` 검사 경로가 content 검사 외에 다른 메타 경로(가설 A/B/C/D)일 가능성 — 06-17 22:00 일일 리뷰에서 소스 분석

**핵심 통찰 (06-17):**
- ISS-072 단독 vs ISS-068/069 합산 — **자기 진단 1일 lag는 모든 patch에 영향** 받지만, **CronPaused 0-line path: null** 은 별도 메타 검사 경로의 이상 → 두 메커니즘은 다르지만 같은 날 동시에 발현 가능
- `path: null` 분기 절차 (이 reference의 보강 표)가 06-17에 첫 실전 적용됨 → (c) 매칭 0건이지만 ISS-068 매칭 잡의 어제 output이 본 단어 보유한 경우 ISS-068로 통합 분류하는 휴리스틱 검증됨

## 관련 reference

- `references/iss-068-self-healer-integration-review-leak.md` — 자기 리포트 leak
- `references/iss-069-self-healer-github-trending-leak.md` — GitHub Trending leak
- SKILL.md "CronPaused regex 0-line" 섹션 — 본 reference로 연결 권장
