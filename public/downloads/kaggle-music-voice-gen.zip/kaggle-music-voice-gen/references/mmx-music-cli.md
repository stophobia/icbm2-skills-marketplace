# mmx music generate 상세 레퍼런스

> 출처: 2026-06-03 실세션 (왕치치 → IU 풍 창작 발라드 작업)

## 버전 이력
- 1.0.15 (2026-06-03 갱신 직전)
- 1.0.16 (현재 권장)

## 인증 흐름
```bash
mmx auth status
# {
#   "method": "api-key",
#   "source": "config.json",
#   "key": "sk-c...kEIs"
# }
```
`config.json`에 API key가 등록돼 있으면 즉시 사용 가능. 없으면 `mmx auth login`으로 발급.

## 갱신 명령
```bash
mmx update
# Current version: 1.0.15
# Run: npm update -g mmx-cli

npm update -g mmx-cli
# changed 1 package in 35s
```

## 핵심 제약
- `--prompt` + 구조화 플래그 합쳐서 **최대 2000자**
- `--lyrics` 또는 `--lyrics-file`은 **최대 3500자**
- 가사 태그 `[Intro]`, `[Verse]`, `[Pre Chorus]`, `[Chorus]`, `[Interlude]`, `[Bridge]`, `[Outro]`, `[Post Chorus]`, `[Transition]`, `[Break]`, `[Hook]`, `[Build Up]`, `[Inst]`, `[Solo]` 사용 가능
- ⚠️ 태그 안에 설명 쓰면 **그대로 노래됨** — 태그는 깨끗하게
- `--lyrics-optimizer`로 가사 자동 생성 가능 (`--lyrics`와 동시 사용 불가)

## 실전 명령 (검증된 보컬 발라드)
```bash
mmx music generate \
  --prompt "korean female vocal, emotional k-pop ballad, piano ballad, soft pop, singer-songwriter, warm and gentle, late night, soft strings, brushed drums, healing, comforting" \
  --vocals "bright female soprano, IU-inspired, breathy, whispery" \
  --genre "pop ballad" \
  --mood "warm, comforting, healing" \
  --instruments "piano, soft strings, brushed drums, acoustic guitar" \
  --bpm 70 \
  --key "D major" \
  --references "IU 밤편지, Paul Kim" \
  --lyrics-file /Users/hjshin/Music/ai-ballad-workspace/lyrics/song.txt \
  --out /Users/hjshin/Music/ai-ballad-workspace/output/song_v1.mp3
```

## 모델 선택 (`--model`)
- `music-2.6` (기본) — 최신, 한국어 자연스러움 우수
- `music-2.5+` — 안정적, instrumental native flag
- `music-2.5` — 구버전

## 출력 옵션
- `--output-format hex` (기본) — 파일 저장
- `--output-format url` — 24시간 만료 URL, 빨리 다운로드
- `--format mp3|wav|pcm` (기본 mp3)
- `--sample-rate 44100` (기본)
- `--bitrate 256000` (기본)
- `--stream` — stdout으로 raw audio 스트리밍

## 워터마크 / AIGC
- `--aigc-watermark` — 오디오에 AI 생성 마크 임베드 (콘텐츠 provenance)
- YouTube 업로드 시 정책상 권장 — 단, 청취 경험엔 영향 없음

## 트러블슈팅

### `mmx update` 후에도 같은 버전
- `npm update -g mmx-cli` 명시 실행 (자동 갱신 안 되는 경우 있음)
- 1.0.15 → 1.0.16 같은 minor patch는 자동 갱신되는 케이스 확인

### 한국어 발음 이상할 때
- 가사에 한자/영어 섞지 말 것 (음절 단위 끊김 발생)
- 영문 가수명/제목은 가사 안에 직접 넣지 말고 `--references`로 분리
- 구조태그 위치가 부자연스러우면 멜로디가 어색해짐 → 가사 단락 조정

### 생성 시간
- 30초~1분 (음악 길이 대비 빠른 편)
- 5분 곡은 5분 안팎

## Suno ↔ mmx 프롬프트 호환
mmx의 `--prompt`/`--vocals`/`--instruments` 등 구조화 플래그를 그대로 Suno의 "Style of Music" 자유 텍스트 칸에 붙여넣으면 대부분 동작함. 단어 순서는 Suno가 자유 텍스트에 더 민감하므로 의미 단위로 끊어쓰기 권장.
