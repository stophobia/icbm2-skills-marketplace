---
name: desktop-companion-sim
description: Build LLM-powered desktop companion simulators on Mac/Linux — animated character face (pygame/Tk), emotion-tag-driven expressions, eye blinking, mouth sync, Korean/English TTS, and structured brainstorming before build. Use for "키위 동반자 만들어줘", "stackchan simulator for Intel Mac", "animated AI avatar on my desktop", "M5Stack-style companion but in software", "LLM 캐릭터 시뮬레이터", "감정 표현하는 데스크탑 봇" requests. Class-level umbrella covers the full stack (LLM client + emotion tag parsing + face rendering + TTS + main loop), with platform-specific quirks (Intel Mac no Apple Silicon-only apps, Python 3.8 compat, pyttsx3 voice selection, headless validation, 3-class pygame crash triage).
version: 0.2.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [companion, simulator, llm, avatar, face, pygame, tts, korean, minimax, stackchan, pyttsx3, emotion]
---

# Desktop Companion Simulator

LLM-based animated desktop companion (text → emotion-tagged response → face animation + TTS). The umbrella covers the full class: brainstorming the right tool stack, picking the LLM client, building a face renderer with blinking and mouth sync, wiring up TTS with voice selection, integrating everything in a main loop, and validating it in a headless environment.

**When to use this skill:**
- User wants a StackChan/M5Stack-style companion but on a regular Mac/PC
- User asks for an animated AI avatar that reacts emotionally to conversation
- User wants to prototype a "desktop pet" with modern LLM brains
- User asks about `stackchan simulator Intel Mac` (Apple Silicon-only StackChan World won't work)
- User wants a class of work that combines LLM API + GUI face + TTS audio

**Sections:**
1. [Brainstorm-first decision tree](#1-brainstorm-first-decision-tree)
2. [Intel Mac / Apple Silicon constraint](#2-intel-mac--apple-silicon-constraint)
3. [Architecture: 4 modules + 1 main loop](#3-architecture-4-modules--1-main-loop)
4. [LLM module with emotion tags](#4-llm-module-with-emotion-tags)
5. [Face renderer (pygame + emotions + blink + mouth)](#5-face-renderer-pygame--emotions--blink--mouth)
5b. [macOS NSWindow main-thread constraint](#5b-macos-nswindow-main-thread-constraint-critical-pitfall)
5c. [Non-blocking stdin from main thread](#5c-non-blocking-stdin-from-main-thread)
5d. [pygame.time.Clock() + SDLTimer crash](#5d-pygametimeclock--sdltimer-crash-critical-pitfall)
6. [Main loop integration](#6-main-loop-integration)
7. [StackChan-style face design (emotion → eye/mouth mapping)](#7-stackchan-style-face-design-emotion--eyemouth-mapping)
7b. [pygame.arc direction trap (0~π vs π~2π)](#7b-pygamearc-direction-trap-0π-vs-π2π-critical-pitfall)
8. [Headless validation pattern](#8-headless-validation-pattern)
9. [Pitfalls (encountered)](#9-pitfalls-encountered)
10. [Extension ideas](#10-extension-ideas)

**References** (under `references/`):
- `kiwi-stackchan-session.md` — full 2026-06-23 v1 session trace (first working version)
- `kiwi-v2-face-and-crashes.md` — full 2026-06-23 v2 session trace (face redesign + 3rd crash fix + arc trap)
- `python38-compatibility.md` — Python 3.8 vs 3.10+ syntax cheatsheet for `Optional[X]`, `X | None`, `list[dict]`
- `minimax-api-emotion-tags.md` — MiniMax Anthropic-compatible API + emotion tag prompt engineering
- `macos-tts-voice-selection.md` — pyttsx3 voice priority, Yuna vs Eddy tradeoffs, `say` fallback
- `intel-mac-constraints.md` — why StackChan World won't run + alternative software simulators

**Templates** (under `templates/`):
- `kiwi-companion-minimal/` — copy-and-modify starter: llm.py / tts.py / face.py / kiwi.py

**Scripts** (under `scripts/`):
- `headless-gui-probe.sh` — `SDL_VIDEODRIVER=dummy` validation harness for any pygame GUI
- `save-face-previews.py` — save 5 emotion PNGs to `~/projects/.../preview/` for user visual verification

---

## 1. Brainstorm-first decision tree

**Always brainstorm 4 decision points before building.** User explicitly prefers "옵션 2~3 + 추천" presentations over silently picking defaults. The 4 standard points:

1. **Face rendering** — emoji + system font (5min) vs PNG assets vs real-time PIL drawing
2. **LLM call** — direct cloud API (low latency) vs local Ollama (free, slow on Intel Mac) vs fallback chain
3. **Speech input** — text-only (v1) vs macOS Speech Framework vs Whisper local
4. **Windowing** — pygame (full control) vs Tkinter (no deps) vs menu-bar only (lightweight)

Default recommendation bundle for **Intel Mac, no hardware budget, want it working in 30min**:
- **①A emoji + font** (5min, swap to PNG later)
- **②A direct API** (MiniMax, already authenticated on Hermes)
- **③A text-only** (skip Whisper; ~500MB overhead unjustified for v1)
- **④A pygame** (best for animated face + mouth sync)

This combination hits 4-5 working emotions in one session.

When the user comes back and says "the face looks bad / I want it to look like StackChan," use the **②-Brainstorm-2** decision points (4 questions on body/eyes/emotion-style/seeds), and skip ahead to the **PNG-preview workflow** (section 7). Don't redo the whole stack.

---

## 2. Intel Mac / Apple Silicon constraint

**Critical user-environment gotcha:** StackChan World (M5Stack's official macOS app from App Store) is **Apple Silicon only** (requires M1+). On Intel Mac, the App Store option doesn't even let you download. Always check this first when the user mentions stackchan on a Mac.

**Detection command:**

```bash
uname -m
# arm64 → Apple Silicon (StackChan World OK)
# x86_64 → Intel (need alternative path)
```

**Intel Mac alternatives:**

| Option | Pros | Cons |
|---|---|---|
| **Build your own (this skill)** | Full control, no install, free | 30min work |
| **M5Stack official simulator** (GitHub) | Authentic firmware testing | PlatformIO + ESP32 toolchain install |
| **Unity 3D simulator** | Visual fidelity | 1-2hr build time |
| **Boot Camp / Parallels** (for Windows-only sims) | Runs Windows sims | Heavy |

When the user just wants "see and talk to a stackchan-like character on my Mac," **build-your-own (option A from this skill) is the right answer** 95% of the time.

---

## 3. Architecture: 4 modules + 1 main loop

```
┌─────────────────────────────────────────────┐
│  Main loop (kiwi.py)                        │
│  - argparse + env check                     │
│  - spawn face window thread                 │
│  - initialize TTS                           │
│  - readline loop → call_llm → say + face   │
└──────┬─────────────┬──────────────┬─────────┘
       │             │              │
       ▼             ▼              ▼
  ┌─────────┐  ┌──────────┐  ┌──────────┐
  │ llm.py  │  │ face.py  │  │ tts.py   │
  │ API call│  │ pygame   │  │ pyttsx3  │
  │ + parse │  │ thread   │  │ + fallback│
  │ emotion │  │ 60fps    │  │   to say  │
  │   tag   │  │          │  │          │
  └─────────┘  └──────────┘  └──────────┘
       │
       ▼
  ┌──────────────────────┐
  │ MiniMax Anthropic API│
  │ + secrets.env loaded │
  │ + emotion-tag system │
  │   prompt             │
  └──────────────────────┘
```

**Why separate modules:**
- Test each in isolation (`python3 llm.py "test"`, `python3 tts.py "test"`, `python3 face.py`)
- Swap implementations (e.g., pyttsx3 → say) without touching main loop
- Headless tests don't need the GUI thread

**Conversation history pattern:** main loop holds a list of `{"role": "user|assistant", "content": "..."}` and passes a windowed slice (`conversation[-max_history:]`) to `call_llm`. Cap at ~20 turns to avoid token bloat.

---

## 4. LLM module with emotion tags

The trick: get the LLM to **emit a structured emotion tag** at the end of every response, then strip it for TTS/display and use it to drive face rendering.

**System prompt pattern:**

```text
너의 이름은 '키위'야. ... (personality)

[감정 표현]
모든 답변 끝에 반드시 다음 중 하나의 감정 태그를 붙여줘 (대괄호로):
[emotion:happy]    — 기쁨, 즐거움, 신남
[emotion:sad]      — 슬픔, 위로가 필요할 때
[emotion:thinking] — 생각 중, 의문
[emotion:surprised]— 놀라움, 반전
[emotion:neutral]  — 일반 대화
```

**Parser pattern:**

```python
EMOTION_RE = re.compile(r"\[emotion:\s*(happy|sad|thinking|surprised|neutral)\s*\]", re.IGNORECASE)
VALID_EMOTIONS = {"happy", "sad", "thinking", "surprised", "neutral"}

def parse_response(raw):
    match = EMOTION_RE.search(raw)
    emotion = match.group(1).lower() if match else "neutral"
    if emotion not in VALID_EMOTIONS:
        emotion = "neutral"
    text = EMOTION_RE.sub("", raw).strip()
    return {"text": text, "emotion": emotion, "raw": raw}
```

**Why this works:** LLM is good at "tag this utterance with a category" tasks. MiniMax-M3 hit 5/5 emotion accuracy in testing (sad/happy/surprised all clean; thinking occasionally defaults to happy for joyful-with-confusion). 100% is impossible; ~85-95% is achievable and good enough.

**API call pattern (MiniMax Anthropic-compatible):**

```python
import os, json, urllib.request

BASE_URL = os.environ["MINIMAX_API_HOST"] + "/anthropic/v1/messages"

req = urllib.request.Request(
    BASE_URL,
    data=json.dumps({
        "model": "MiniMax-M3",
        "max_tokens": 512,
        "system": SYSTEM_PROMPT,
        "messages": messages,
    }).encode("utf-8"),
    headers={
        "Content-Type": "application/json",
        "x-api-key": os.environ["MINIMAX_API_KEY"],
        "anthropic-version": "2023-06-01",
    },
    method="POST",
)
```

Note: do **not** use the `requests` library here — `urllib` ships with stdlib, no extra dep, no proxy/auth surprises. `requests` works too but adds nothing.

**Source the API key before running:**

```bash
source ~/.hermes/secrets/minimax.env
python3 kiwi.py
```

This is a critical UX step — without the `source`, `MINIMAX_API_KEY` is undefined and the program exits with a clear error. Document this prominently in README and as the first thing the main script checks.

---

## 5. Face renderer (pygame + emotions + blink + mouth)

**Threading pattern:** pygame's event loop blocks. Run it on the main thread (see 5b). Worker thread reads from shared state and pushes to main via queue.

```python
class KiwiFace:
    def __init__(self):
        self.emotion = "neutral"
        self.speaking = False
        self.mouth_open = 0.0
        self._ready = False
        self._quit_requested = False

    def set_emotion(self, e): self.emotion = e
    def set_speaking(self, s, amplitude=0.5): ...
    def request_quit(self): self._quit_requested = True

    # Called on MAIN thread
    def init_pygame(self):
        pygame.display.init()  # NOT pygame.init() — see 5b/5d
        pygame.font.init()
        self._window = pygame.display.set_mode((W, W))
        # DO NOT: self._clock = pygame.time.Clock() — see 5d
        self._ready = True

    def tick(self) -> bool:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: return False
        if self._quit_requested: return False
        self._update(time.time()); self._draw()
        pygame.display.flip()
        # NO clock.tick(60) — main loop's time.sleep throttles
        return True
```

**5-emotion face rendering cheatsheet (visual signature, not just color):**

| Emotion | Eyes | Mouth | BG tint |
|---|---|---|---|
| happy | closed arcs `^ ^` | big upward arc (smile), wider when speaking | warm yellow |
| sad | line + tear drops `; ;` | downward arc | cool blue |
| thinking | flat lines `-- --` | small `o` (closed) | lavender |
| surprised | wide white circles `O O` | O-shape, bigger when speaking | peach |
| neutral | normal white + dark pupil + 2 highlights | small smile | soft green |

For the v2 redesign (per-emotion eye_style + mouth_style + brown body + seeds), see [section 7](#7-stackchan-style-face-design-emotion--eyemouth-mapping).

**Eye blink pattern (natural, not metronomic):**

```python
BLINK_INTERVAL = (3.0, 5.5)  # seconds, randomized per blink
self._is_blinking = False
self._next_blink = time.time() + random.uniform(*BLINK_INTERVAL)

# in update loop
if not self._is_blinking and time.time() >= self._next_blink:
    self._is_blinking = True
    self._blink_start = time.time()
elif self._is_blinking and time.time() - self._blink_start > 0.15:
    self._is_blinking = False
    self._next_blink = time.time() + random.uniform(*BLINK_INTERVAL)

# in draw
if self._is_blinking:
    pygame.draw.line(window, eye_color, (x-20, y), (x+20, y), 3)
```

**Mouth sync pattern:** main loop sets `face.set_speaking(True, amplitude=0.7)` before TTS, `False` after. The face interpolates `mouth_open` toward `target_mouth` at ~0.18 per frame for smoothness.

```python
self.mouth_open += (self.target_mouth - self.mouth_open) * 0.18
```

For per-phoneme accuracy you'd want to analyze audio amplitude, but for a v1 companion the simple on/off amplitude interpolation is enough to feel alive.

---

## 5b. macOS NSWindow main-thread constraint (CRITICAL pitfall)

**Symptom you MUST recognize:** GUI code looks correct, TTS works, LLM responds, but **the pygame window never appears**. Terminal shows:

```
pygame.error: NSWindow should only be instantiated on the main thread!
```

(Chat still works because the LLM/TTS side has nothing to do with the GUI.)

**Root cause:** macOS Cocoa backend requires all `NSWindow` and related AppKit UI objects to be created on the main thread. This applies to pygame when it uses the `cocoa` driver — which is the default on macOS.

**Why the "run face in a daemon thread" pattern fails on macOS:**

```python
# ❌ Works on Linux/Windows, fails on macOS with NSWindow error
face = KiwiFace()
threading.Thread(target=face.run, daemon=True).start()  # worker thread
# face.run() calls pygame.display.set_mode() → NSWindow ctor → CRASH
```

**The fix — main-thread event loop + worker thread for LLM/TTS:**

```python
import queue

event_queue = queue.Queue()  # worker → main

def llm_worker(user_text, history):
    try:
        event_queue.put({"type": "thinking_start"})
        result = llm.call_llm(user_text, conversation=history)
        event_queue.put({"type": "emotion", "emotion": result["emotion"], "text": result["text"]})
        speaker.say(result["text"], blocking=False)
        event_queue.put({"type": "speaking_end"})
    except Exception as e:
        event_queue.put({"type": "error", "message": str(e)})

# Main thread:
face.init_pygame()  # NSWindow created on main thread ✓
while not face.is_quit_requested():
    try:  # 1) Drain worker events (non-blocking)
        while True:
            ev = event_queue.get_nowait()
            if ev["type"] == "thinking_start": face.set_emotion("thinking")
            elif ev["type"] == "emotion": face.set_emotion(ev["emotion"])
            elif ev["type"] == "speaking_start": face.set_speaking(True, 0.7)
            elif ev["type"] == "speaking_end": face.set_speaking(False)
    except queue.Empty: pass
    # 2) Spawn worker if input available
    # 3) One pygame frame
    face.tick()
```

**Refactor face.py into init / tick / shutdown:**

```python
class KiwiFace:
    def init_pygame(self):
        """Call ONCE on main thread."""
        pygame.display.init()
        pygame.font.init()
        # NO pygame.init() — see 5b/5d
        # NO pygame.time.Clock() — see 5d
        self._window = pygame.display.set_mode((W, W))
        self._ready = True

    def tick(self) -> bool:
        """Call every frame on main thread. Returns False if quit."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT: return False
        if self._quit_requested: return False
        self._update(time.time()); self._draw()
        pygame.display.flip()
        return True

    def shutdown(self):
        pygame.quit()
```

Setter methods (`set_emotion`, `set_speaking`) just modify plain instance attributes — safe from any thread. **Only pygame operations (init, draw, flip, event poll) need main thread.**

**Diagnostic when "window doesn't appear":**
1. If you see `NSWindow should only be instantiated on the main thread!` → thread pattern is wrong, refactor as above.
2. If no error but window missing → `print(pygame.display.get_driver())` should be `cocoa` on Mac. If it shows `dummy`, `SDL_VIDEODRIVER` env var is leaking from a test harness.
3. Window may be off-screen on a different Space: `F3` (Mission Control) or `Cmd+Space → "Kiwi"`.
4. If `pgEvent_New` / `PyDict_SetItemString` is in the crash trace → SDLTimer issue, see 5d.

## 5c. Non-blocking stdin from main thread

Main thread is busy with `face.tick()` (60 FPS) — can't call `input()` directly without blocking the GUI. Use `select`:

```python
import select

def read_stdin_nonblocking():
    if select.select([sys.stdin], [], [], 0.0)[0]:
        return sys.stdin.readline().rstrip("\n")
    return None
```

## 5d. pygame.time.Clock() + SDLTimer crash (CRITICAL pitfall)

**The third crash class** (the one that survives the NSWindow fix and the mixer init fix). Symptom:

```text
Thread 0 Crashed::  Dispatch queue: com.apple.main-thread
0   ???                              0xf ???
1   python                           PyDict_SetItem + 3388
2   python                           PyDict_SetItemString + 77
3   event.cpython-311-darwin.so      pgEvent_New + 4596
4   event.cpython-311-darwin.so      pg_event_get + 696
...
Thread 10: SDLTimer  ← still alive
```

**Why mixer init: False was NOT enough.** `pygame.init()` activates SDL_INIT_AUDIO → spawns AudioQueue/IOThread. `pygame.mixer.init()` is the explicit audio init → same spawn. We thought `display.init() + font.init()` only would be enough. **It wasn't.** The remaining crash was caused by `pygame.time.Clock()`:

```python
self._clock = pygame.time.Clock()  # ← creates SDLTimer thread
self._clock.tick(60)               # ← per-frame call
```

`pygame.time.Clock()` activates SDL's timer subsystem → spawns the `SDLTimer` thread → that thread posts events back to the main thread via a Python dict (`pgEvent_New` → `PyDict_SetItemString` path) → race with whatever else is touching Python state → NULL deref at offset 0xf.

**The fix — remove `pygame.time.Clock()` entirely.** Frame timing is just "don't burn CPU":

```python
# In init_pygame:
# DO NOT do: self._clock = pygame.time.Clock()
self._clock = None  # explicitly unused

# In tick:
pygame.display.flip()
# DO NOT do: self._clock.tick(60)
# The main loop's time.sleep(0.005) is enough to throttle.
```

**Verification — what threads should look like after the fix:**

```python
# Expected: only NSEventThread (AppKit). No SDLTimer, no AudioQueue.
import sys; sys.path.insert(0, '.')
import face
f = face.KiwiFace()
f.init_pygame()
import pygame
print(f'mixer init: {pygame.mixer.get_init()}')  # must be False
print(f'time init: {pygame.time.get_init()}')    # must be False
f.shutdown()
```

**Why this is a pygame 2.6.1 + Python 3.11 + macOS 15.5 specific bug:** Pygame's timer subsystem calls back into the Python interpreter to construct `pygame.event.Event` objects, which goes through `PyDict_SetItemString`. The SDLTimer thread does this on its own thread. If main thread is mid-`PyDict_SetItem` (also possible from your own event-loop code) when SDLTimer fires, both touch the same dict internals without a lock → classic use-after-free → NULL deref.

**Workaround that's known safe on Intel Mac:** never call `pygame.time.Clock()` and never call `pygame.init()`. Use `display.init() + font.init()` only.

Full session trace: see `references/kiwi-v2-face-and-crashes.md` section 1.

---

## 6. Main loop integration

**Threading structure:**

```python
face = KiwiFace()
face.init_pygame()  # main thread
speaker = KiwiSpeaker()  # main thread
# Worker threads spawn per LLM call
```

**Order matters:** init pygame BEFORE pyttsx3, or you get `OSError: CoreAudio device not available` on the TTS init.

**Per-turn flow:**

```python
face.set_emotion("thinking")  # show user we're working
result = llm.call_llm(user_input, conversation=history)
face.set_emotion(result["emotion"])
print(f"[키위:{emotion}] {text}")
face.set_speaking(True, amplitude=0.7)
speaker.say(text, blocking=True)  # blocking so we don't overlap with next turn
face.set_speaking(False, amplitude=0.0)
# append to history (text only, no emotion tag)
history.append({"role": "user", "content": user_input})
history.append({"role": "assistant", "content": text})
```

**Why blocking TTS:** if you start a new LLM call while TTS is still running, the user sees the face go to "thinking" mid-sentence. Blocking keeps the experience clean.

**Cleanup:**

```python
finally:
    face.request_quit()  # set flag, main loop exits in next frame
    speaker.stop()       # kill any pending pyttsx3 utterances
    time.sleep(0.3)      # let main loop finish shutdown
```

Without the `time.sleep(0.3)`, the main process exits before the pygame loop finishes cleanup, which on macOS sometimes leaves a zombie pygame process.

---

## 7. StackChan-style face design (emotion → eye/mouth mapping)

When the user says "the face looks bad / I want it to look like StackChan," don't redo the whole stack. Brainstorm 2 questions on **body** and **eye style**, then jump to the PNG preview workflow (section 8).

### 4 design decisions

| # | Decision | Options |
|---|---|---|
| ① Body | (a) Brown + highlight + seeds / (b) Green / (c) Other color |
| ② Eyes | (a) White sclera + dark pupil + 2 highlights (StackChan signature) / (b) Solid black dot / (c) OLED-style rectangle |
| ③ Eye style per emotion | (a) Same shape, color changes / (b) Different shape per emotion (`^ ^` vs `O O` vs `; ;`) |
| ④ Mouth style per emotion | (a) Same arc, color changes / (b) Different shape per emotion (big ∪ vs O vs ∩) |

User confirmed preference (v2): **brown body + white-sclera eyes + per-emotion eye/mouth styles**. The visual signature of a stackchan is the **white-sclera + dark-pupil + 2 highlights** eye combo, not the color palette.

### Centralize all emotion visuals in `EMOTION_PALETTE` (data over code)

```python
EMOTION_PALETTE = {
    "happy": {
        "bg": (255, 248, 220),
        "body": (139, 111, 71),        # warm brown
        "cheek": (255, 156, 174),
        "eye_style": "closed_happy",   # ^ ^
        "mouth_style": "open_smile",   # big ∪
        "eye_color": (40, 30, 20),
        "mouth_color": (180, 60, 80),
    },
    "sad": { "body": (110, 95, 70), "eye_style": "sad", "mouth_style": "frown", ... },
    "thinking": { "body": (130, 115, 85), "eye_style": "line", "mouth_style": "small", ... },
    "surprised": { "body": (160, 130, 85), "eye_style": "big", "mouth_style": "o", ... },
    "neutral": { "body": (143, 115, 75), "eye_style": "circle", "mouth_style": "smile", ... },
}
```

Adding a new emotion is a dict entry, not a function branch.

### Dispatch by style name in `_draw_eye` / `_draw_mouth`

```python
def _draw_eye(self, x, y, color, style):
    if self._is_blinking:
        pygame.draw.line(...); return
    if style == "closed_happy":  # ^ ^
        pygame.draw.arc(window, color, (x-24, y-14, 48, 28), 0.25*math.pi, 0.75*math.pi, 5)
    elif style == "sad":         # ; ;
        pygame.draw.line(window, color, (x-18, y), (x+18, y), 4)
        pygame.draw.circle(window, color, (x-20, y+12), 3)   # tear
        pygame.draw.circle(window, color, (x-20, y+22), 2)   # tear drop
    elif style == "line":        # --
        pygame.draw.line(...)
    elif style == "big":         # O O
        pygame.draw.circle(window, (255,255,255), (x,y), 28)
        pygame.draw.circle(window, color, (x,y), 22)
        pygame.draw.circle(window, (255,255,255), (x-8, y-8), 7)  # big highlight
    # ... etc
```

### "Data ≠ display" — don't put seeds on the face

If you add decorative elements (seeds, freckles, scale texture) that are placed randomly on the body, **skip placements that overlap with the face features**. Otherwise the face looks broken.

```python
# Draw body
pygame.draw.circle(window, body_color, (cx, cy), FACE_RADIUS)

# Draw seeds, but skip ones that would land in the eye/mouth region
for _ in range(12):
    angle = rng.uniform(0, 2*math.pi)
    dist = rng.uniform(70, FACE_RADIUS - 25)
    sx, sy = int(cx + math.cos(angle)*dist), int(cy + math.sin(angle)*dist)
    if abs(sy - cy) < 60 and abs(sx - cx) < 90:  # face center has eyes/mouth
        continue
    pygame.draw.circle(window, (50, 40, 25), (sx, sy), 2)
```

Generalizes to: "just because data exists doesn't mean you render it." Same rule for Notion DB columns you don't display, B-roll footage you don't use, README sections you don't write.

## 7b. pygame.arc direction trap (0~π vs π~2π) (CRITICAL pitfall)

**Symptom:** You want a smile (∪, upward-opening curve). You write what looks like the right math:

```python
# "0 = 3 o'clock, 0.5π = 6 o'clock, π = 9 o'clock, 1.5π = 12 o'clock"
# "Clockwise sweep = 0 → 0.5π → π → 1.5π → 2π"
# "For ∪, sweep through 12 o'clock: 0.5π → 1.5π"
pygame.draw.arc(window, color, rect, 0.5*math.pi, 1.5*math.pi, 5)
```

**This draws a full circle (180° sweep), not ∪.** When the bbox is small enough that the arc gets clipped, it looks like S-curve, not a smile.

**What actually happens (vision-verified on rendered test PNGs):**

pygame.arc with rect `R` and angles `a1 < a2` draws the segment of the ellipse inscribed in `R` going counter-clockwise from `a1` to `a2`. Verified table:

| Angle range | Where the arc lands in the rect |
|---|---|
| `0 ~ π` | TOP of rect (above center, like ∩) |
| `π ~ 2π` | BOTTOM of rect (below center, like ∪) |
| `0.5π → 1.5π` | Full half-circle (180° sweep) |
| `0.25π → 0.75π` | BOTTOM half (∪ shape, smile) |
| `0.15π → 0.85π` | Mostly bottom half (wider ∪) |
| `0 → 2π` | Full circle |

So to draw a **smile (∪)** — the part of the ellipse below the center — use **`0.25π → 0.75π`** (or `0.15π → 0.85π` for a wider smile). The naive "0.5π → 1.5π" is wrong.

### The reliable recipe

| Want | Use |
|---|---|
| Smile ∪ (mouth turns up) | `0.25π → 0.75π` (or `0.15π → 0.85π` for wider) |
| Frown ∩ (mouth turns down) | `0 → π` (or `0.15π → 0.85π` and flip y...) |
| Half-circle (left/right side) | `0.5π → 1.5π` |
| Full circle | `0 → 2π` |

### Vision-debug the arc

```python
import os
os.environ['SDL_VIDEODRIVER'] = 'dummy'
import pygame, math
pygame.init()
screen = pygame.display.set_mode((600, 400))
screen.fill((255, 255, 255))

for i, (start, end, label) in enumerate([
    (0, math.pi, "0→π"),
    (0.5*math.pi, 1.5*math.pi, "0.5π→1.5π"),
    (0.25*math.pi, 0.75*math.pi, "0.25π→0.75π"),
    (0, 0.5*math.pi, "0→0.5π"),
    (math.pi, 2*math.pi, "π→2π"),
    (0.15*math.pi, 0.85*math.pi, "0.15π→0.85π"),
]):
    x, y = 50 + (i % 3) * 200, 50 + (i // 3) * 200
    pygame.draw.rect(screen, (200, 200, 200), (x, y, 150, 150), 1)
    pygame.draw.arc(screen, (255, 0, 0), (x, y, 150, 150), start, end, 3)
    font = pygame.font.Font(None, 20)
    screen.blit(font.render(label, True, (0,0,0)), (x, y + 155))

pygame.image.save(screen, "arc_test.png")
# Read arc_test.png with vision and label each as "∪" or "∩"
```

Then ask vision: "for each red arc, is the curve convex-up (∪) or convex-down (∩)?" The map is what you actually want, not what pygame's docs suggest.

**Trust issues with vision:** in the same session, vision may call `0.15π → 0.85π` first "∪" then "∩" then "∪" depending on surrounding context. The human user is the only consistent oracle. **For visual deliverables, save previews and let the user click through** (see section 8).

---

## 8. Headless validation pattern

Critical for CI/SSH sessions where you can't actually open a window:

```bash
SDL_VIDEODRIVER=dummy python3 your_gui_module.py
```

This runs pygame with a fake video driver — no window appears, but all `pygame.draw.*` calls execute and any `pygame.event.get()` polling works. Lets you catch:
- Import errors
- Syntax errors
- `pygame.draw.circle` parameter mismatches
- Threading deadlocks (the `is_ready()` flag never flips)
- Crashes (NSWindow, SDLTimer, etc.) — dummy driver simulates the same crash paths

**Combined test pattern (verify LLM + TTS + face without GUI):**

```python
# 1. LLM only — fastest
result = llm.call_llm("test")
assert result["emotion"] in VALID_EMOTIONS

# 2. TTS only — no GUI needed
speaker = KiwiSpeaker()
speaker.say("test", blocking=False)

# 3. Face with dummy SDL
import os
os.environ["SDL_VIDEODRIVER"] = "dummy"
face = KiwiFace()
face.init_pygame()
# cycle emotions
for e in EMOTIONS: face.set_emotion(e); time.sleep(0.2)
face.request_quit()
```

The `scripts/headless-gui-probe.sh` script in this skill automates this pattern.

### Save PNG previews for visual verification

When the deliverable is a visual change (face redesign, layout tweak, color shift), the user is the only ground truth. Save 5 emotion PNGs and let the user click through:

```python
# save-face-previews.py
import os, sys
os.environ['SDL_VIDEODRIVER'] = 'dummy'
sys.path.insert(0, '/Users/hjshin/projects/your-companion')

import pygame
import face

OUT = os.path.expanduser('~/projects/your-companion/preview')
os.makedirs(OUT, exist_ok=True)

f = face.KiwiFace()
f.init_pygame()

for emotion in ['happy', 'sad', 'thinking', 'surprised', 'neutral']:
    f.set_emotion(emotion)
    f.set_speaking(False)
    f._update(0)
    f._draw()
    pygame.display.flip()
    pygame.image.save(f._window, f'{OUT}/face_{emotion}.png')
    print(f'✓ {emotion}')

f.shutdown()
```

Then: `open ~/projects/your-companion/preview` — user clicks each PNG and tells you what's wrong.

Iterate on the worst offenders only — don't try to perfect all 5 at once; ask the user which one is most wrong.

---

## 9. Pitfalls (encountered)

1. **`Optional[X]` vs `X | None` syntax** — Python 3.8 (still on some Hermes host machines) rejects `X | None`. Always use `from typing import Optional, List, Dict, Union`. See `references/python38-compatibility.md`.

2. **Naive voice substring match picks wrong voice** — `if "yuna" in v.id` may match Eddy or other voices first if they appear earlier in `getProperty("voices")` list. Use exact-name match or `endswith(".yuna")`.

3. **pyttsx3 not thread-safe** — concurrent `say()` calls from multiple threads corrupt the audio queue. Use a `threading.Lock` or run TTS sequentially.

4. **pygame grabs audio device on macOS** — initialize pygame BEFORE pyttsx3, or you get `OSError: CoreAudio device not available` on the TTS init.

5. **Apple Silicon-only app on Intel Mac** — `StackChan World` from App Store requires M1+. Always check `uname -m` first when user mentions stackchan on Mac.

6. **MINIMAX_API_KEY not in `printenv`** — Hermes stores it in `~/.hermes/secrets/minimax.env` as `export MINIMAX_API_KEY=...`. You must `source` it explicitly; the shell doesn't inherit from the agent sandbox.

7. **Executing `execute_code` is blocked in cron contexts** — even in interactive sessions, `execute_code` may be denied. Use terminal + `python3 -c "..."` pattern for one-off inspection.

8. **Blocking TTS during LLM call overlaps** — if you don't `speaker.say(text, blocking=True)`, the next `set_emotion("thinking")` happens mid-utterance, breaking the visual coherence.

9. **Conversation history grows unbounded** — pass `conversation[-max_history:]` (e.g., last 20 turns) to `call_llm` to keep token usage bounded.

10. **Pygame main loop blocks on macOS but should run on main thread** — On Linux/Windows you can run pygame on a daemon thread; on macOS Cocoa this fails with NSWindow main-thread error. Run pygame init/event/draw on main thread; LLM/TTS work on worker thread; communicate via `queue.Queue`.

11. **`NSWindow should only be instantiated on the main thread!` (macOS only)** — the "run pygame on a daemon thread" pattern fails on macOS Cocoa. Refactor so pygame init/event/draw all run on main thread; LLM/TTS work happens in worker thread. See section 5b.

12. **`pygame.time.Clock()` + SDLTimer crash** — even after fixing the NSWindow and mixer issues, `pygame.time.Clock()` creates the `SDLTimer` thread which posts Python `dict` updates asynchronously, racing with the main thread's `pygame.event.get()` path. Symptom: `pgEvent_New → PyDict_SetItemString → NULL deref at offset 0xf`. **Fix: never call `pygame.time.Clock()`; throttle via `time.sleep()` in the main loop instead.** See section 5d.

13. **`pygame.draw.arc` direction trap** — naive math "0.5π → 1.5π = ∪ (sweep through 12 o'clock)" is **wrong**; that draws a full half-circle. To draw a smile ∪ use `0.25π → 0.75π` (bottom half of ellipse). To draw a frown ∩ use `0 → π` (top half). Verify with `SDL_VIDEODRIVER=dummy` + vision on rendered test PNGs. See section 7b.

14. **Vision tool is unreliable for arc direction** — in the same session, vision may call the same arc "∪" then "∩" then "∪" depending on context. For visual deliverables, **save previews to PNG and let the human user verify**, not the vision tool.

15. **The "face looks bad" feedback means redesign the visual, not redo the stack** — when user comes back saying the face doesn't look like StackChan, don't brainstorm all 4 sections again. Brainstorm 2 questions (body + eye style) and jump to the PNG preview workflow. The crash triage (5b/5d) is settled; the LLM/TTS/main loop don't need changes.

---

## 10. Extension ideas

- [x] **PNG face assets (partial)** — the per-emotion eye_style/mouth_style pattern via `EMOTION_PALETTE` is in place; loading actual PNG images would be a drop-in `set_emotion` change.
- [ ] **STT (speech input)** — add `openai-whisper` or use `Speech.framework` via `objc`. Increments v1 → v2.
- [ ] **Smooth emotion transitions** — interpolate the palette colors over 0.3s when emotion changes (face morphs instead of snapping).
- [ ] **Conversation log** — append to SQLite with timestamps for memory recall.
- [ ] **Context-aware emotions** — time of day, weather, recent user activity → bias the emotion system prompt.
- [ ] **M5Stack hardware bridge** — pair a real M5Stack device over WiFi (TCP/UDP) and forward face emotion + TTS audio to it.
- [ ] **MCP integration** — expose `kiwi.say(text, emotion)` as an MCP tool so any agent (Hermes, Claude Code) can dispatch to the desktop companion.
- [ ] **Multi-character** — render multiple faces in a window, switch active speaker by name.

---

## Related Skills

- `ai-music` — sister skill for audio generation, similar brainstorming + verification flow
- `mcp-builder` — for exposing companion as MCP tool
- `text-game-builder` — also uses LLM-as-character pattern, deeper game-state architecture
- `automation` — for cron-based companion greetings ("키위야 아침 브리핑 해줘")
- `media` — broader audio/video output patterns
- `notion` — for saving conversation logs to Notion DB
