# Korean Corruption Patterns Dict

`markdown_to_tistory_html.py` 변환 중 또는 CJK cleaning 과정에서 손상된 Korean 텍스트를 복구하는 패턴 사전.

## korean_corruption_patterns (Python dict)

```python
korean_corruption_patterns = {
    '각단대이': '각 팀이',           # 62차 — CJK cleaning이 "각 팀이"를 Chinese로 오해
    'AI가주류로': 'AI가 주류로',     # 65차 — HTML 변환 후 Korean 단어 합쳐짐
    '마진，要求': '마진, 요구',       # 65차 — CJK comma → 한국어 comma
    '소사나혁명': '작은 혁명이',     # 58차 — markdown_to_tistory_html.py 변환 중 손상
    '起码': '최소한',                # 58차
    '正经한': '정확한',              # 58차
    'キャプチャ': '캡처',            # 58차 — Japanese katakana 혼입
    'ситуаций': '상황',             # 58차 — Russian/Cyrillic
    # 80차 (2026-06-01) — CJK cleaning으로 困/扰 개별 제거 후 Korean 단어 끊어짐
    '차 계산에될 필요 없이': '시차 계산에 불편함 없이',
    # 기타 발견 시 추가
}
```

## 사용 방법

CJK cleaning 루프 후 Korean corruption check 실행:
```python
for bad, good in korean_corruption_patterns.items():
    if bad in html:
        print(f"⚠️ Korean text corruption: {bad} → {good}")
        html = html.replace(bad, good)
```
