# Music Video — Multi-Image + Ken Burns + Wave Bar (2026-05-23)

## 테스트 결과 요약

| 요소 | 시도 | 결과 |
|------|------|------|
| 3개 이미지 전환 | ✅ FFmpeg concat | 성공 (212초 영상) |
| Ken Burns (zoompan) | ❌ 4K 입력에서 Invalid argument | 실패 |
| Ken Burns (Python PIL) | ⏱ 프레임 생성 120초+超时 | 시간 문제 |
| Wave bar overlay | ✅ 2160 프레임 생성 | 성공 (참고용) |

## 권장 파이프라인 (검증됨)

### 1. 이미지 3개 생성 (변이 프롬프트)
```bash
for i in 1 2 3; do
  mmx image generate \
    --prompt "...base prompt..., variation $i" \
    --out ~/images/img_$i.png
done
```

### 2. Ken Burns 효과 적용 (Python PIL → FFmpeg)
```python
from PIL import Image
import os, subprocess

def ken_burns_frames(src_path, output_dir, fps=25, dur=72, scale_start=1.0, scale_end=1.15):
    src = Image.open(src_path)
    w, h = src.size
    total = fps * dur
    os.makedirs(output_dir, exist_ok=True)
    
    for frame in range(total):
        t = frame / fps
        s = scale_start + (scale_end - scale_start) * (t / dur)
        cw, ch = int(1280*s), int(720*s)
        l = (w - cw) // 2
        t = (h - ch) // 2
        cropped = src.crop((l, t, l+cw, t+ch)).resize((1280, 720), Image.LANCZOS)
        cropped.save(f"{output_dir}/frame_{frame:05d}.png")
        cropped.close()
    
    src.close()

# 사용
ken_burns_frames("img1.png", "/tmp/frames1", scale_end=1.15)
ken_burns_frames("img2.png", "/tmp/frames2", scale_end=1.0)
ken_burns_frames("img3.png", "/tmp/frames3", scale_end=1.12)
```

### 3. 세그먼트별 영상 생성 + 연결
```bash
# 세그먼트별 오디오 추출
for i in 1 2 3; do
  ffmpeg -y -i music.mp3 -ss $(( (i-1)*72 )) -t 72 -acodec copy audio_$i.mp3
done

# 프레임 → 영상 (각 25fps)
ffmpeg -y -framerate 25 -i /tmp/frames1/frame_%05d.png -i audio_1.mp3 \
  -c:v libx264 -preset ultrafast -crf 28 -c:a aac -b:a 192k \
  -movflags +faststart seg_1.mp4

# (seg_2, seg_3 반복)

# concat
cat > concat.txt << EOF
file 'seg_1.mp4'
file 'seg_2.mp4'
file 'seg_3.mp4'
EOF
ffmpeg -y -f concat -safe 0 -i concat.txt \
  -c:v libx264 -preset ultrafast -crf 23 \
  -c:a aac -b:a 192k \
  -movflags +faststart final.mp4
```

## Wave Bar Overlay (참고)

Wave bar는 Ken Burns보다 복잡해서 오늘 테스트에서는 생략.
필요 시 PIL로 2160 프레임 생성 → FFmpeg overlay.

```python
# 40개 바 × 30fps × 72초 = 2160 프레임
# FFmpeg로 영상 위에 overlay: ffmpeg -i video.mp4 -i wave_%05d.png -filter_complex overlay=... output.mp4
```

## YouTube OAuth 토큰 — 매업로드 전 리프레시 (중요)

```python
import pickle, os
from google.auth.transport.requests import Request

TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")

with open(TOKEN_FILE, "rb") as f:
    creds = pickle.load(f)
if not creds.valid:
    creds.refresh(Request())
    with open(TOKEN_FILE, "wb") as f:
        pickle.dump(creds, f)
```

## 실제 업로드 결과 (2026-05-23)

- **일반 영상 (3장, 212초):** https://www.youtube.com/watch?v=Co2e-aAIK_g
- **Shorts (60초):** https://www.youtube.com/watch?v=WXMyziXxf4Y
- **단일 이미지 영상 (3분 32초, 212초):** https://www.youtube.com/watch?v=dgCVpvUCTSU
- **Shorts (60초, 212초):** https://www.youtube.com/watch?v=duHYrEs5_JM

## 기억할 점

1. **YouTube 토큰 만료**: 2일마다 만료 → 매업로드 전 리프레시 필수
2. **FFmpeg zoompan 4K**: macOS FFmpeg 4.3.2에서 4K 입력 시 `Invalid argument`
3. **Python 프레임 생성은 느림**: 1800프레임 생성에 120초+ → 백그라운드 처리 필요
4. **가사 필터링**: 한자/일본어 제거 후 한국어만 남김