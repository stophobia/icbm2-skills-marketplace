# 외부 도구 Wrapping — 심화 노트 (2026-06-16 kakao-summary)

`python-oss-bootstrap` SKILL.md 본문의 **"외부 도구 wrapping 패턴 — MCP/CLI stdio 통합"** 섹션에 없는 비-자명한 함정 4가지를 정리한 보조 문서. **macOS GUI 자동화 도구 (kmsg, Karabiner, skhd, hammerspoon 등)를 subprocess로 호출하는 모든 Python OSS에 적용 가능**.

---

## 함정 1: **PTY 할당 필수** (가장 중요)

**증상**: `subprocess.run([kmsg, "read", ...])` 또는 `subprocess.Popen(...)` (no PTY) → **30초 타임아웃 또는 hang**. `kmsg` CLI를 터미널에서 직접 실행하면 5초 안에 응답하는데, Python에서 호출하면 무한 대기.

**원인**: macOS의 Accessibility API (AX) 기반 도구들 (`kmsg`, AppleScript로 GUI 제어하는 모든 도구)은 **TTY가 할당된 foreground 프로세스**에서만 정상 동작. Python `subprocess.run`은 default로 no-TTY (pipe) → macOS가 "백그라운드 프로세스"로 분류 → AX 트리 접근 거부.

**해결**: `pty.openpty()`로 의사 터미널 할당:

```python
import pty, os, subprocess

def call_with_pty(cmd: list[str], timeout: int = 30) -> str:
    master_fd, slave_fd = pty.openpty()
    try:
        proc = subprocess.Popen(
            cmd,
            stdin=slave_fd, stdout=slave_fd, stderr=slave_fd,
            close_fds=True,
        )
        os.close(slave_fd)
        slave_fd = -1  # 이중 close 방지
        output = b""
        while True:
            try:
                chunk = os.read(master_fd, 4096)
            except OSError:
                break
            if not chunk:
                break
            output += chunk
        proc.wait(timeout=timeout)
        return output.decode("utf-8", errors="replace")
    finally:
        try: os.close(master_fd)
        except OSError: pass
        if slave_fd != -1:
            try: os.close(slave_fd)
            except OSError: pass
```

**재사용**: 다음 macOS 도구들 모두 동일 패턴:
- `kmsg` (카카오톡 CLI)
- `Karabiner` 키매핑 도구
- `skhd` 핫키 데몬
- `hammerspoon` 자동화
- AppleScript `osascript` 호출 시
- `cliclick` 마우스/키보드 시뮬레이션

**대안**: `pty=True` (Hermes terminal tool 옵션)에서 직접 호출 — Hermes terminal이 이미 TTY 할당하므로 wrapping 코드 불필요. **단, Python 라이브러리 내부에서 호출해야 할 때는 위 PTY 패턴 필수**.

---

## 함정 2: **MCP initialize 핸드셰이크 순서** (kmsg-mcp 통합 시)

**증상**: kmsg-mcp 서버에 첫 `tools/call` 요청 → `error: -32002 Server not initialized`. mcp-mcp 본가의 README에는 언급 없음.

**원인**: [MCP Protocol 2024-11-05](https://modelcontextprotocol.io) 명세는 클라이언트가 다음 순서를 **반드시** 따라야 함:

1. `initialize` 요청 → 서버 응답 (capabilities 교환)
2. `notifications/initialized` notification → 서버에 "준비 완료" 알림
3. 그 후 `tools/call`, `resources/read` 등 실제 호출

우리 코드가 (3)부터 시작해서 `Server not initialized` 에러.

**해결** (`start()` 메서드에 추가):

```python
def start(self):
    # subprocess 시작
    self._proc = subprocess.Popen(...)

    # 1. initialize 요청 (응답 받음)
    init_response = self._send_request("initialize", {
        "protocolVersion": "2024-11-05",
        "capabilities": {},
        "clientInfo": {"name": "kakao-summary", "version": __version__},
    })
    if "error" in init_response:
        raise KmsgUnavailableError(f"MCP initialize failed: {init_response['error']}")

    # 2. initialized 알림 (응답 없음 — notification)
    self._send_notification("notifications/initialized", {})

def _send_notification(self, method, params):
    notification = {"jsonrpc": "2.0", "method": method, "params": params}
    self._proc.stdin.write(json.dumps(notification) + "\n")
    self._proc.stdin.flush()
```

**핵심 차이**: `request` 는 `id` 필드 있어서 응답을 읽음. `notification`은 `id` 없음 → 서버도 응답 안 함. JSON-RPC 2.0 스펙 그대로.

**대안** — `mcp` Python 라이브러리 사용: `from mcp.client.session import ClientSession` + `stdio_client` 컨텍스트 매니저. **단점**: 외부 의존성 (zero-deps 정책 깨짐). 그래서 위 raw 구현 선호.

---

## 함정 3: **kmsg-mcp `PROCESS_TIMEOUT` → kmsg CLI 우회**

**증상**: kmsg-mcp `kmsg_read` 호출은 20초 타임아웃 빈번 (특히 Accessibility 권한 부여 직후, 또는 카톡 창이 백그라운드). 같은 PC에서 `kmsg read` CLI는 5초 안에 정상.

**원인**: kmsg-mcp는 subprocess로 `kmsg`를 띄운 뒤 **AX 트리 결과 파싱 + JSON 직렬화** 추가 단계. macOS 환경에서 이 추가 단계가 hang. `kmsg` CLI 단독은 안정적.

**해결**: `KmsgCliClient` (직접 subprocess)를 기본으로, `KmsgClient` (kmsg-mcp)는 옵션. `core.py`에서:

```python
# v0.1.0: kmsg-mcp 우회 — kmsg CLI 직접 호출이 안정적
from .kmsg_cli_client import KmsgCliClient as KmsgClient
```

**kmsg CLI JSON 출력 포맷 (v1.260606.1 기준)**:
```json
{
  "chat": "[코드팩토리] 바이브코딩 x 클로드 코드",
  "count": 20,
  "fetched_at": "2026-06-16T02:36:26.433Z",
  "messages": [
    {
      "author": "거지열무김치/클코 코덱스",
      "body": "그렇겟죠아무래도",
      "date": "2026-06-16",
      "time_raw": "오전 9:28"
    },
    ...
  ]
}
```

**핵심 필드**:
- `date` + `time_raw` 분리 (kmsg-mcp의 `time` 통합 필드와 다름)
- `time_raw` 형식: `"오전 9:28"` / `"오후 3:45"` / `"9:28"` — 한국어 AM/PM + 12시간제
- 파싱: `re.search(r"(오전|오후)?\s*(\d{1,2}):(\d{2})", time_raw)` + 24시간 변환

**재사용**: 어떤 macOS GUI 도구의 MCP 래퍼가 불안정할 때 → 해당 도구 CLI 직접 호출 + JSON/Regex 파싱으로 우회. 검증된 도구: `kmsg`, 추정: 다른 AX 기반 도구들도 동일 패턴 적용 가능.

---

## 함정 4: **argparse subparser + nargs="?" 위치 인자 충돌**

**증상**: `kakao-summary sync "[코드팩토리] 바이브코딩 x 클로드 코드" --target 100` → `error: argument COMMAND: invalid choice: '[코드팩토리]...'` (sync 서브 명령이 무시되고 첫 번째 위치 인자가 COMMAND로 잘못 매칭).

**원인**:
```python
parser.add_argument("chat", nargs="?", default=None)  # 위치 인자
subparsers = parser.add_subparsers(dest="command")  # subparser
sync_p = subparsers.add_parser("sync")
sync_p.add_argument("chat")  # sync의 위치 인자
```

argparse는 `nargs="?"` 위치 인자가 있으면 subparser를 **두 번째로 강등** — 첫 번째 non-option 인자를 `chat`으로 매칭, 그 다음에 오는 게 subparser. **단톡방 이름이 multi-word (공백, 특수문자 포함)면 subparser 이름(`sync`)보다 먼저 매칭됨**.

**해결 옵션 A** (kakao-summary 채택, 가장 간단): subparser 안에 `--chat` 플래그로 변경
```python
sync_p.add_argument("--chat", required=True)
sum_p.add_argument("--chat", required=True)
# positional "chat" 제거
```
**장점**: subparser 우선순위 충돌 원천 차단, multi-word 인자 안전
**단점**: 단축 사용 (`kakao-summary <chat>`) 불가, 항상 `kakao-summary summarize --chat "..."` 형식

**해결 옵션 B**: nargs="*" (가변 위치 인자)
```python
parser.add_argument("chat", nargs="*", default=[])
```
**장점**: 단축 사용 복원
**단점**: argparse가 subparser 위치까지 가변 인자로 흡수할 위험, 예측 어려운 동작

**해결 옵션 C**: 단축 사용 + 서브 명령 모두 positional, `--chat` 옵션은 안 씀
```python
parser.add_argument("chat", nargs="*")  # 가변
# 사용자가 "kakao-summary chat1 chat2 sync ..." 형태로 호출 시 복잡
```
**비추천**: 사용자 경험 최악

**판단 기준**:
- multi-word 인자 (채팅방, 파일 경로, 사용자 이름) → **옵션 A** (안전)
- 단일 단어 인자 (ID, number) → 옵션 B도 OK
- 단축 사용이 중요 → 옵션 B + 첫 단어를 command로 분리하는 추가 로직

**재사용**: kmsg-doctor/cron-doctor 같은 multi-word 인자를 받는 모든 CLI 도구.

---

## 보너스: kmsg 카톡 접근 가능 상태 만들기 (전제 조건)

Python 코드 작성 전, 사용자 PC에서 다음 3단계가 **반드시** 끝나 있어야 함:

1. **kmsg 설치**: `brew install channprj/tap/kmsg` (Intel Mac은 `/usr/local/bin/kmsg`, Apple Silicon은 `/opt/homebrew/bin/kmsg`)
2. **Accessibility 권한 부여** (수동, 사용자 직접):
   - 시스템 설정 → 개인정보 보호 및 보안 → 손쉬운 사용 → 자물쇠 풀기 → `+` → `Cmd+Shift+G` → `/usr/local/bin/kmsg` 입력 → 추가 → 토글 켜기
   - **kmsg 바이너리 자체**를 추가 (터미널이 아님) — 이게 README에 명시 안 돼 있어 헤맬 수 있음
3. **카카오톡 데스크톱 실행 + 로그인 + 활성화** (포커스 상태 유지, 백그라운드/최소화 시 read 실패)

**진단 명령어**:
```bash
kmsg         # "Accessibility Permission: ✓ Granted" 확인
kmsg chats   # 채팅방 20개 이상 인식 → AX 트리 접근 OK
kmsg read "<chat>" --limit 5  # 5초 안에 응답 → 정상
```

세 가지 다 통과해야 Python 코드 실행 가능. 하나라도 안 되면 hang 또는 `PROCESS_TIMEOUT`.

---

## 환경변수 `KMSG_BIN` Intel/Apple Silicon 호환

`kakao-summary` 코드 기본값은 `/opt/homebrew/bin/kmsg` (Apple Silicon). Intel Mac은 `/usr/local/bin/kmsg`. **두 가지 해결**:

1. **코드에서 분기** (가장 안전):
   ```python
   import platform
   DEFAULT_KMSG_BIN = (
       "/opt/homebrew/bin/kmsg" if platform.machine() == "arm64"
       else "/usr/local/bin/kmsg"
   )
   ```
2. **사용자 환경변수** (`~/.zshrc`에 영구):
   ```bash
   export KMSG_BIN=/usr/local/bin/kmsg  # Intel
   # 또는
   export KMSG_BIN=/opt/homebrew/bin/kmsg  # Apple Silicon
   ```

kakao-summary v0.1.0은 옵션 2 (환경변수) 채택. macOS 업그레이드/이전 시 brew 경로 바뀌면 환경변수만 업데이트.
