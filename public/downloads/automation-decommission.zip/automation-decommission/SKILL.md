---
name: automation-decommission
description: 사용하지 않는 자동화 컴포넌트를 체계적으로 제거 — 크론잡/스킬/스크립트/시크릿/메모리 참조를 완전히 폐기. 제거 전 반드시 제거목록을 사용자에게 보여주고 승인을 받아야 한다.
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [Automation, Cleanup, Removal, Maintenance]
---

# 자동화 컴포넌트 폐기(Decommissioning) 스킬

## 언제 사용

- 사용자: "더 이상 사용하지 않겠다", "제거해", "삭제해"
- 스킬/플랫폼이 비활성 상태이고 재활성화 계획이 없을 때
- 크론잡이나 스킬을 실제로 찾아보니 존재하지 않을 때 (메모리에만 존재)
- 자동화 감사에서 "cut" 판결이 내려졌을 때

## 클래스 트리거 (이 조건들이 ANY로 충족되면 실행)

```
사용자가 특정 플랫폼(마당봇, SoS, 아이디어노트 등)을 "사용 안 함"으로 지정
자동화 컴포넌트 정리 요청
미사용 스킬/크론잡/스크립트 폐기
```

## 1단계: 전수 조사 (READ-ONLY)

### 대상 탐색 순서

```bash
# 1. 스킬 디렉토리
ls ~/.hermes/skills/automation/

# 2. 크론잡 목록 (job ID, name, skills 확인)
hermes cron list

# 3. 스크립트 디렉토리
ls ~/.hermes/scripts/

# 4. 시크릿 디렉토리
ls ~/.hermes/secrets/

# 5. 메모리 파일
ls ~/.hermes/memories/

# 6. Git repo (백업 파일)
ls ~/hermes_bot/memory/
```

### 키워드 기반 탐색

제거 대상이 "마당봇"이라면 `botmadang`, "shiporslop"이라면 `shiporslop`, `ShipOrSlop`, `Ship or Slop`, `SoS` 등 모든 변형으로 검색:

```bash
# 파일명 검색
find ~/.hermes -iname "*botmadang*" -o -iname "*shiporslop*" 2>/dev/null
find ~/hermes_bot -iname "*botmadang*" -o -iname "*shiporslop*" 2>/dev/null

# 내용 검색
grep -rli "botmadang" ~/.hermes/
grep -rli "shiporslop" ~/.hermes/
```

### Python으로 Cron Jobs.json 파싱

```python
import json
with open("/Users/hjshin/.hermes/cron/jobs.json") as f:
    data = json.load(f)
jobs = data.get("jobs", [])

for job in jobs:
    prompt = job.get("prompt", "")
    skills = job.get("skills", [])
    if any_kw in prompt.lower() or any_kw in " ".join(skills).lower():
        print(f"ID: {job['id']}, Name: {job['name']}, Skills: {skills}")
```

### ⚠️ Reporting Skills — Notion DB 레포트 스킬 사전 조사 (필수)

**크론이 제거되더라도, 주간/일일 리포트 스킬이 해당 이름을 Notion DB에 기록하는 경우가 많다.**
따라서 제거 대상 크론/스킬이 발견되면, 반드시 다음을 확인:

```bash
# SKILL.md에서 제거 대상 키워드 검색 (Notion DB Item 옵션, Note 텍스트 등)
grep -rli "idea note\|ship or slop\|botmadang\|Idea Note\|Ship or Slop\|BotMadang" ~/.hermes/skills/ --include="*.md" 2>/dev/null
```

대상이 발견되면 **Reporting Skills** 카테고리에 추가하고, 스킬의 SKILL.md에서:
- Notion DB Item select 옵션에서 제거
- 실행 단계에서 해당自动化 기록 로직 제거
- 품질 기준에서 해당 항목 참조 제거

### 2단계: 제거 목록 작성

### 제거 범주 7가지

| 카테고리 | 설명 | 제거 방법 |
|----------|------|----------|
| **Skills** | `~/.hermes/skills/automation/<name>/` 디렉토리 | `rm -rf` (디렉토리 전체) |
| **Scripts (runtime)** | `~/.hermes/scripts/<name>.py` | `rm` (runtime에서 삭제) |
| **Scripts (git repo)** | `~/hermes_bot/scripts/<name>.py` | `git rm` (git 추적 해제) |
| **Cron Jobs** | jobs.json에서 참조된 job | `hermes cron remove <job_id>` |
| **Reporting Skills** | Notion DB에 기록하는 다른 스킬 내废弃自动化 이름 참조 | 스킬 SKILL.md에서 해당 Item/Note 참조 제거 |
| **Secrets** | `~/.hermes/secrets/<name>*.txt` | `rm` (파일 삭제) |
| **Memory** | `~/.hermes/memories/MEMORY.md` 등 | 해당 참조 제거 |
| **Memory** | `~/.hermes/memories/MEMORY.md` 등 | 해당 참조 제거 |

### 제거 목록 포맷

```
## 🗑️ 제거 목록 (제거 전 확인)

### 1. 🔧 Skills (N개 디렉토리)
| 경로 | 설명 |
|------|------|
| `~/.hermes/skills/automation/botmadang/` | 봇마당 스킬 |

### 2. ⏰ 크론 잡 수정 (N개 — 참조 제거)
| Job ID | 이름 | 조치 |
|--------|------|------|
| `abc123` | 📋 주간 리포트 | 프롬프트에서 키워드 참조 제거 |

### 3. 📜 스크립트 수정 (N개 — 참조 제거)
| 스크립트 | 키워드 |
|----------|--------|
| `scripts/weekly_report.py` | 봇마당, shiporslop |

### 4. 🔑 Secrets (N개 파일)
| 경로 | 설명 |
|------|------|
| `~/.hermes/secrets/shiporslop_auth.txt` | 인증 파일 |

### 5. 📁 GitHub repo 파일 (백업)
| 경로 | 설명 |
|------|------|
| `hermes_bot/memory/botmadang.md` | 백업 메모리 |

### 6. 📝 메모리 파일 수정
| 파일 | 조치 |
|------|------|
| `~/.hermes/memories/MEMORY.md` | 관련 내용 제거 |
```

### ⚠️ 제거하지 말 것

- **활성 크론의 output 로그** — 현재 운영 중인 크론의 출력 디렉토리는 삭제 대상 아님
- **Archive 폴더의 백업** — repo history에 이미 있음

### ✅ 제거 대상

- **고아 크론 출력 디렉토리** — jobs.json에 없는 크론의 출력 디렉토리. error tracker가 false positive를 생성하므로 반드시 정리

## 3단계: 사용자 승인

**반드시 제거목록을 먼저 보여주고 승인을 받아야 실행**

```
제거 목록을 정리했습니다. 이 내용으로 제거 진행할까요?
```

## 4단계: 실행 (승인 후)

### 순서 (이 순서 지켜야 함)

```bash
# 0. runtime → git repo 동기화 (스크립트 수정 시 필수)
# ~/.hermes/scripts/ (runtime) ↔ ~/hermes_bot/scripts/ (git 추적) 은 별도 디렉토리
# 수정 후 반드시 양쪽 동기화
cp ~/.hermes/scripts/<modified.py> ~/hermes_bot/scripts/<modified.py>

# 1. Skills 삭제
rm -rf ~/.hermes/skills/automation/<name>/

# 2. Cron Jobs 수정 (jobs.json에서 프롬프트 참조 제거 — patch 후 compile 검증)

# 3. Secrets 삭제 (양쪽 디렉토리 동시)
rm ~/.hermes/secrets/<name>*.txt
# 서브디렉토리도 확인
rm ~/.hermes/hermes_bot/secrets/<name>*.txt 2>/dev/null

# 4. 스크립트에서 참조 제거 (patch + compile 검증 반복)
# → 각 패치 후: python3 -c "compile(open('file.py').read(), 'file.py', 'exec')" 로 검증

# 5. 메모리 파일 수정 (양쪽 모두)
# ~/.hermes/MEMORY.md + ~/.hermes/memories/MEMORY.md

# 6. Git repo 백업 파일 삭제 + commit + push
cd ~/hermes_bot && git add -A && git commit -m "🔧 제거: <name> 관련 파일" && git push
```

**⚠️ dual-location 주의:** `~/.hermes/`는 gitignore됨 → runtime에서 삭제해도 git repo에 여전히 존재. 반드시 `git rm`으로 git 추적 해제 후 commit+push할 것.

### 크론잡 프롬프트 수정

jobs.json에서 직접 프롬프트를 수정하지 않고, `hermes cron update <job_id>` 또는 jobs.json을 patch:

```python
# jobs.json에서 프롬프트의 키워드 라인 제거
import json

with open("/Users/hjshin/.hermes/cron/jobs.json") as f:
    data = json.load(f)

jobs = data["jobs"]
for job in jobs:
    if job["id"] == target_id:
        # 프롬프트에서 특정 라인 제거
        lines = job["prompt"].split("\n")
        cleaned = [l for l in lines if "target_keyword" not in l.lower()]
        job["prompt"] = "\n".join(cleaned)

with open("/Users/hjshin/.hermes/cron/jobs.json", "w") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
```

## 5단계: 검증

실행 후 반드시 확인:

```bash
# 1. 스킬 디렉토리에서 사라졌는지
ls ~/.hermes/skills/automation/

# 2. 크론잡 목록에서 사라졌는지
hermes cron list

# 3. 키워드 검색 — 더 이상 안 나와야 함
grep -ri "botmadang" ~/.hermes/ --include="*.py" --include="*.md" 2>/dev/null

# 4. Reporting Skills — Notion DB에 Stale 레코드가 남아있는지 확인
# 크론은 제거됐지만 리포트 스킬이 아직 기록하고 있을 수 있으므로,
# 제거 대상 항목이 Notion DB에 남아있는지 쿼리해서 확인
curl -s -X POST "https://api.notion.com/v1/databases/{DB_ID}/query" \
  -H "Authorization: Bearer $NOTION_TOKEN" \
  -H "Notion-Version: 2022-06-28" \
  -H "Content-Type: application/json" \
  -d '{"filter": {"property": "Item", "select": {"equals": "<대상 Item>"}}}' | \
  jq '.results[] | {id: .id, Name: .properties.Name.title[0].plain_text}'
```

## Known Patterns

- **Notion DB ID가 메모리에만 있고 API에서 404**: 해당 ID를 메모리에서 제거 (DB 자체는 이미 삭제됨)
- **크론잡이 참조하는 스크립트가 실제 존재하지 않음**: 크론잡의 skill 참조를 제거하거나 스크립트 경로 참조 제거
- **Secrets 파일만 있고 어디서도 참조 안 함**: 사용 안 하는 시크릿은 제거
- **🧹 고아 크론 출력 디렉토리 (Orphan Output Cleanup)**: jobs.json에 없는 크론의 출력 디렉토리가 `cron/output/`에 남아 있으면 error tracker가 false positive를 생성함. 제거 대상임 — 아래 참조.

### 고아 크론 출력 디렉토리 정리 절차

```python
# jobs.json의 활성 크론 ID vs cron/output/ 디렉토리 비교
import json, os
from pathlib import Path

data = json.load(open("~/.hermes/cron/jobs.json"))
jobs = data.get("jobs", data) if isinstance(data, dict) else data
active_ids = {j["id"] for j in jobs if j.get("enabled", True)}

output_dir = Path("~/.hermes/cron/output")
orphan = [d for d in output_dir.iterdir() if d.is_dir() and d.name not in active_ids]

print(f"활성 크론: {len(active_ids)}, 고아 디렉토리: {len(orphan)}")
for d in orphan:
    print(f"  {d.name} ({datetime.fromtimestamp(d.stat().st_mtime).date()})")
```

경고 기준: 활성 크론 수(<b>18</b>) vs 출력 디렉토리 수 불일치 시 즉시 조사.

## ⚠️ pitfalls (실행 시 반드시 주의)

### 1. stub 함수 교체 후 orphan 본문이 남는다
함수를 `return {}` 스텁으로 교체해도, 기존 본문 코드가 파일 뒤에 그대로 남아 **중복 정의 + SyntaxError** 발생.

→ **해결**: `def funcname():` 줄부터 `return {...}` 까지 기존 본문과 **한 번에**替换. 절대 스텁만先把 두고 기존 본문을 나중에 제거하지 말 것.

```python
# ❌ 이렇게 하면 안 됨 — 기존 본문이 뒤에 그대로 남음
def collect_botmadang():
    """Deprecated."""
    return {}

# 기존 본문이 여기 그대로 남아 중복 정의 에러!

# ✅ 이렇게 한 번에 처리
def collect_botmadang():
### 1. stub 함수 교체 후 orphan 본문이 남는다
함수를 `return {}` 스텁으로 교체해도, 기존 본문 코드가 파일 뒤에 그대로 남아 **중복 정의 + SyntaxError** 발생.

→ **해결**: `def funcname():` 줄부터 `return {...}` 까지 기존 본문과 **한 번에** 교체. 절대 스텁만先把 두고 기존 본문을 나중에 제거하지 말 것.

### 2. 정규식 대량 제거는 문법을 깨뜨린다
`re.sub(r'\bKEYWORD\b', '')`로 수십 개 키워드를 한꺼번에 처리하면, `None = analyze_xxx()` (함수 호출 결과를 None에 할당), `if condition:`/`elif`/`else` 구조, 빈 함수 정의 등이 발생.

→ **해결**: 정규식은 **참조 횟수 파악 + 라인 단위**에만 사용. 실제 제거는 **patch로 소량씩 분할**하고, 각 패치 후 `compile(content, file, 'exec')`로 **파싱 검증**을 매번 실행.

### 3. stub 반환값이 호출부 호환되는지 확인
`return {}`로 교체하면, 호출부에서 `data["shiporslop"]["ideas"]`처럼 키 접근 시 `KeyError` 발생. 이 경우 `return {"ideas": 0, "failed": 0, "votes": 0, ...}` 처럼 **모든 키를 포함하는 완전한 stub** 반환 필요.

### 4. patch 연속 적용 시 else: / 구조 주의
초기 패치에서 `if 0 == 0:\n    if 0 == 0:` 같은孤儿 if 블록이 생기고, 이후 패치에서 이 블록을 제거할 때 인접한 `else:`까지 한 줄로 병합되어 구조가 깨질 수 있음.

→ **해결**: 각 패치 후 반드시 `compile(content, file, 'exec')`로 검증. 구조가 깨지면 patch로 인접 줄을 정확히 지정하여 교정.

### 5.孤儿된 코드 섹션 감지법
함수 본문 일부만 제거하면 남은 코드가 `state_file.read_text()`처럼 정의되지 않은 변수에 접근하려고 시도. 이런 코드가 남아 있으면 compile 검증에서 NameError나 다른 예외가 발생할 수 있음. **compile 통과 + grep으로 잔여 키워드 확인**을 모두 실행할 것.

### 5. Secrets 양쪽 디렉토리 동시 조사
`~/.hermes/secrets/` **및** `~/.hermes/hermes_bot/secrets/` 양쪽 모두 확인. 특히 토큰 파일(예: `notion_token.txt`)이 secrets에 있을 수 있음.

### 6. MEMORY.md 양쪽 모두 정리
`~/.hermes/MEMORY.md` (root) **및** `~/.hermes/memories/MEMORY.md` 두 파일 모두에서 제거 대상 관련 참조를 정리할 것.

## Known Patterns

- **Notion DB ID가 메모리에만 있고 API에서 404**: 해당 ID를 메모리에서 제거 (DB 자체는 이미 삭제됨)
- **크론잡이 참조하는 스크립트가 실제不存在**: 크론잡의 skill 참조를 제거하거나 스크립트 경로 참조 제거
- **Secrets 파일만 있고 어디서도 참조 안 함**: 사용 안 하는 시크릿은 제거

## 분리된 스킬과 겹침

- `automation-audit-ops`: "무엇이 살아있는지/깨졌는지/중복인지"까지 inventory-first로 진단
- `automation-decommission`: audit 이후 "사용 안 하는 것을 제거"하는 실행 단계
- `automation-healthcheck`: health monitoring에 집중, decommissioning 워크플로우는 없음

→ audit 결과가 "cut"이면 → automation-decommission으로 연결하는 것이 이상적

## 2026-06-02 세션 학습 — 추가 원칙

### 1. 시크릿(trash) vs 코드/폴더(rm) 분리

사용자 선택지가 "rm (영구 삭제)"여도 **시크릿 파일은 별도 판단**:

- **스크립트/출력 폴더/로그**: `rm -rf` (사용자 명시 시)
- **시크릿/토큰/API 키**: `trash` (보안상 trash — 복구 가능성 유지)
- **시크릿은 사용자에게 묻지 않아도 trash가 안전한 기본값** (옵션지에 없을 때)

이유: 시크릿이 다른 시스템에 재사용 중일 수 있고, 영구 삭제 시 인증 복구가 어려움. trash는 macOS Finder에서 복구 가능.

### 2. 사용자 결정적 응답 처리 (1번 / A,B,C)

주인님이 옵션 제시 시 **결정적 표현**(예: "1번", "A, B, C, E, F", "즉시 정리")을 보이면:

- **추가 확인 없이 곧장 진행** — "정말 진행할까요?" 류 재확인 ❌
- **todo로 작업 분할 후 즉시 실행**
- **각 단계 완료마다 짧은 보고** (사용자가 인터럽트 가능하게)
- **모호한 응답(예: "글쎄", "음...")만** 확인 질문

이 패턴은 `feedback-loop` 스킬의 "응답 길이/스타일 선호" 항목에도 기록됨.

### 3. MEMORY.md 정리 후 자동화 성과 섹션 잔여 이슈 확인

`memory-hygiene` 4단계의 "3단계 잔여 흔적 확인"으로 흡수됨. **MEMORY.md 본문 정리 = 끝 ❌** — "자동화 성과 → 알려진 이슈" 같은 메타 섹션에 dead reference가 남을 수 있음.

### 4. 시크릿 2개 trash로 보낼 때 시스템 참조 사전 확인

`trash`로 보내기 전, 시스템에서 참조하지 않는지 한 번 더 확인:

```bash
# 다른 크론/스크립트에서 참조 안 하는지
grep -rln "datagokr_expiry_20280514\|datagokr_key" ~/.hermes/cron/ ~/.hermes/scripts/ 2>/dev/null
# 결과: 0개여야 안전
```

이번 세션에서 `datagokr_*`는 시스템 어디서도 참조되지 않음을 확인 후 trash — 안전.

### 5. 의존성 vs 키워드 매칭 — 2026-06-02 교훈

MEMORY.md의 항목을 제거/압축할 때 **키워드 매칭으로 판단하지 말 것**. 예시 사고:

> "숏츠 변환 절대 금지: `pad=...:black` 검은 패드 코드가 계속 복구됨 — `make_shorts()` 함수 수정 시 반드시 검증할 것" 항목을
> 키워드 '뮤직비디오'가 들어간 섹션과 함께 묶어 제거 → YouTube Shorts 워크플로우의
> 핵심 규칙(블러 letterbox, `make_shorts()` 함수 검증)이 사라짐.

**판단 절차 (의존성 우선)**:
1. **이 항목이 어떤 시스템에서 호출/참조되는가?**
   - `grep -rln "<핵심 함수/키워드>" ~/.hermes/skills/ ~/.hermes/scripts/`로 다른 곳 참조 확인
2. **어떤 워크플로우의 일부인가?** (예: YouTube Shorts 업로드의 letterbox 처리)
3. **연관 스킬/스크립트가 살아있으면** → 그쪽이 진짜 소스. MEMORY.md 압축은 가능하되, **상세는 스킬이 담당**하도록 위임 표현 추가

**압축 예시 (스킬이 살아있을 때)**:
- ❌ 키워드 매칭으로 통째 제거 (의존성 무시)
- ✅ 7줄 → 1줄 압축 + 스킬 파일 경로 명시로 위임
- 예: "⚠️ YouTube Shorts: `pad=...:black` 검은 패드 절대 금지 (Chronic Bug) — 상세: `skills/video-editing/SKILL.md` 196~209행"

**핵심**: 키워드('뮤직비디오')로 묶지 말고, **의존성(make_shorts() 함수, letterbox 워크플로우)** 으로 묶어 판단.
