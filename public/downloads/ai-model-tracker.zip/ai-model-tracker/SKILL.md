---
name: ai-model-tracker
description: 미니맥스/ NVIDIA NIM 등 AI 모델 API 사용량을 체크하고 Notion에 기록합니다. 그룹 멤버십 잔여량, 모델별 사용량 추적, 임계치 경고가 필요할 때 사용합니다.
version: 1.1.0
author: icbm2
---

# AI Model Usage Tracker

미니맥스/ NVIDIA NIM API 사용량을 체크하고 Notion에 기록합니다.

## 사용량 조회 API

### 미니맥스 코딩 플랜 잔여량

```bash
curl -s "https://api.minimax.io/v1/api/openplatform/coding_plan/remains" \
  -H "Authorization: Bearer $MINIMAX_API_KEY"
```

**실제 응답 구조 (snake_case):**
```json
{
  "model_remains": [
    {
      "start_time": 1777284000000,
      "end_time": 1777302000000,
      "remains_time": 12660048,
      "current_interval_total_count": 4500,
      "current_interval_usage_count": 4222,
      "model_name": "MiniMax-M*",
      "current_weekly_total_count": 45000,
      "current_weekly_usage_count": 43786,
      "weekly_start_time": 1777248000000,
      "weekly_end_time": 1777852800000,
      "weekly_remains_time": 563460048
    }
  ],
  "base_resp": { "status_code": 0, "status_msg": "success" }
}
```

**⚠️ 중요: usage_count = 잔여량! (실제 사용 아님)**

**필드 설명 (실제 API 기준):**
- `model_name`: 모델명 (MiniMax-M*, speech-hd, coding-plan-vlm 등)
- `start_time`/`end_time`: Interval 윈도우 기간 (Unix ms)
- `remains_time`: Interval 잔여 시간 (ms)
- `current_interval_total_count`: Interval 할당량
- `current_interval_usage_count`: **Interval 잔여량** (실제 사용 아님)
- `current_weekly_total_count`: 주간 할당량
- `current_weekly_usage_count`: **주간 잔여량** (실제 사용 아님)
- `weekly_start_time`/`weekly_end_time`: 주간 윈도우 (Unix ms)
- `weekly_remains_time`: 주간 잔여 시간 (ms, 전체 모델 통합)

**신규 필드 (2026-06 관측):** `current_interval_remaining_percent`, `current_weekly_remaining_percent`, `current_interval_status`, `current_weekly_status` — 카테고리형 모델 응답에서 잔여량을 직접 제공.

**실제 사용량 = total_count - usage_count**

## 사용량 계산 (Python)

```python
import json
from datetime import datetime

data = json.load(open("response.json"))

for m in data["model_remains"]:
    name = m["model_name"]
    start = m["start_time"]
    end = m["end_time"]
    remains_time = m["remains_time"]
    interval_total = m["current_interval_total_count"]
    interval_usage = m["current_interval_usage_count"]
    weekly_total = m["current_weekly_total_count"]
    weekly_usage = m["current_weekly_usage_count"]

    # === 시간 기반 (Interval Window 기준) ===
    window_ms = end - start
    window_h = window_ms / 3600000
    used_time_ms = window_ms - remains_time
    time_usage_pct = used_time_ms / window_ms * 100 if window_ms > 0 else 0

    # === 요청 수 기반 (usage_count = 잔여량!) ===
    interval_remaining = interval_usage  # interval_usage가 실제로는 잔여량
    weekly_remaining = weekly_usage     # weekly_usage가 실제로는 잔여량
    interval_used = interval_total - interval_usage    # 실제 사용량
    weekly_used = weekly_total - weekly_usage          # 실제 사용량

    print(f"=== {name} ===")
    print(f"  Interval: 할당={interval_total}, 잔여={interval_remaining}, 사용={interval_used}")
    print(f"  Weekly: 할당={weekly_total}, 잔여={weekly_remaining}, 사용={weekly_used}")
    print(f"  Interval Window: {window_h:.1f}h ({datetime.fromtimestamp(start/1000)} ~ {datetime.fromtimestamp(end/1000)})")
    print(f"  시간 사용률: {time_usage_pct:.1f}%")
```

### ⚠️ 주의: total_count = 0 인 모델 있음

일부 모델(예: `MiniMax-Hailuo-2.3-Fast-6s-768p`, 그리고 2026-06부터 `general`/`video` 카테고리형 응답)은 `current_interval_total_count=0`으로 응답합니다. 이 경우 **나누기 연산 시 ZeroDivisionError**가 발생.

**반드시 0 체크를 추가:**

```python
interval_total = m.get("current_interval_total_count") or 0
weekly_total = m.get("current_weekly_total_count") or 0

# 0으로 나누기 방지
interval_used = interval_total - interval_usage if interval_total > 0 else 0
weekly_used = weekly_total - weekly_usage if weekly_total > 0 else 0
```

**total=0 응답 시 새 필드 fallback**: `current_interval_remaining_percent` / `current_weekly_remaining_percent`를 직접 사용.

**스크립트에서 직접 수정이 필요한 경우:**
```bash
# 확인
grep -n "interval_total - interval_usage" ~/.hermes/scripts/model_tracker.py
# 또는
grep -n "/ interval_total" ~/.hermes/scripts/model_tracker.py
```

## ⚠️ 중요: Interval vs Weekly 구분

**Interval quota**: 짧은 윈도우 (5시간 또는 24시간) 내 요청 수 제한
**Weekly quota**: 주간 총 요청 수 제한

예시:
- `MiniMax-M*`: Interval 4,500회 (5시간), Weekly 45,000회
- `speech-hd`: Interval 4,000회 (24시간), Weekly 28,000회

**잔여량 = min(interval_remaining, weekly_remaining)** 가 아닌, **각각 독립적으로 해석**

## Notion에 사용량 기록

**⚠️ 이 스킬은 두 개의 Notion DB를 사용합니다. 크론_job 호출 시 반드시 두 DB 모두 확인하세요.**

### AI Model Tracker DB
- **DB ID:** `33c76f2e-9097-8132-9033-e434f4055b56`
- **DB명:** AI Model Tracker
- **실제 스키마 (반드시 확인):**
  - `Name`: title
  - `Provider`: rich_text
  - `Model`: rich_text
  - `Type`: select
  - `Date`: date
  - `URL`: url

### 성과 대시보드 DB (ai-model-tracker 용이 아님, 다른 스킬용)
- **DB ID:** `33f76f2e-9097-8116-a225-c0c23f1a8a9d`

**AI Model Tracker 기록 속성 (실제 DB 스키마):**
```python
payload = {
    "parent": {"database_id": "33c76f2e-9097-8132-9033-e434f4055b56"},
    "properties": {
        "Date": {"date": {"start": today}},
        "Name": {"title": [{"text": {"content": f"MiniMax {name}"}}]},
        "Provider": {"rich_text": [{"text": {"content": "MiniMax"}}]},
        "Model": {"rich_text": [{"text": {"content": name}}]},
        "Type": {"select": {"name": "Weekly Remaining"}},
        "URL": {"url": "https://api.minimax.io/v1/api/openplatform/coding_plan/remains"},
    }
}
```

### ⚠️ API 신뢰성: 재시도 로직 필수
MiniMax `coding_plan/remains` API는 간헐적으로 `system error, QueryCodePlanRemains failed` (status_code 1033)를 반환합니다.
**반드시 최대 3회 재시도 로직을 구현하세요:**

```python
for attempt in range(1, 4):
    response = json.loads(curl_output)
    if "model_remains" in response:
        break
    time.sleep(3)
```

## 사용량 체크 & 경고 로직

```bash
# 임계치 경고 (잔여 15% 이하)
WARN_THRESHOLD=0.15
CRITICAL_THRESHOLD=0.05

usage_pct=$(echo "scale=3; ($endTime - $startTime - $remainsTime) / ($endTime - $startTime)" | bc)

if [ "$(echo "$usage_pct >= 0.95" | bc)" -eq 1 ]; then
  echo "🚨 [$MODEL_NAME] 사용량 $usage_pct% - 위험!"
elif [ "$(echo "$usage_pct >= 0.85" | bc)" -eq 1 ]; then
  echo "⚠️ [$MODEL_NAME] 사용량 $usage_pct% - 주의"
fi
```

**2026-06 신규 패턴:** 카테고리형 모델(`general`, `video`)은 `weekly_remaining_percent` 필드를 직접 사용:

```python
wk_pct = m.get("current_weekly_remaining_percent")
if wk_pct is not None and wk_pct <= 5:
    warn = "🚨"
elif wk_pct is not None and wk_pct <= 15:
    warn = "⚠️"
```

## 주요 모델 목록 (API 응답 기준)

**코딩 플랜 모델:**
- `MiniMax-M*` — 주간 45,000회, Interval 4,500회 (5시간)
- `coding-plan-vlm` — 주간 45,000회, Interval 4,500회 (5시간)
- `coding-plan-search` — 주간 45,000회, Interval 4,500회 (5시간)

**음성/음악 모델:**
- `speech-hd` — 주간 28,000회, Interval 4,000회 (24시간)
- `music-2.5`, `music-2.6`, `music-cover`
- `lyrics_generation`

**기타:**
- `MiniMax-Hailuo-2.3-Fast-6s-768p`, `MiniMax-Hailuo-2.3-6s-768p`
- `image-01`

### ⚠️ API 응답 drift 경고 (2026-06 검증)

2026-06-02~03 실측 결과, API가 `general`, `video` 같은 **문서에 없는 카테고리형 모델명**을 반환하고 두 항목 모두 `interval_total=0`, `weekly_total=0`으로 응답. 즉:

- 위 "주요 모델 목록"이 **더 이상 정확하지 않을 수 있음** — API가 플랜/카테고리 단위로 응답하도록 변경된 것으로 보임
- 문서 모델명(`MiniMax-M*`, `speech-hd` 등)도 여전히 응답할 수 있으나 **사전 가정 금지** — 매 실행 시 `response["model_remains"][*]["model_name"]`을 그대로 읽고 동적으로 처리
- 0/0 응답 시 **잔여량 표시 형식**: `Name: "<model> W:94%/I:95%"`, `Provider: "MiniMax"`, `Model: "<model>"`, `Type: "Weekly Remaining"`. Notion 기록 자체는 성공 처리 (호출 자체가 정상)
- 잔여량 표시는 `current_weekly_remaining_percent` / `current_interval_remaining_percent` 신규 필드에서 직접 가져옴
- **모델명 정규화/매핑이 필요할 때** 별도 `references/known-models.md` 표를 만들어 갱신 추적

## 실행 환경 주의사항 (크론 모드)

- `execute_code`는 **크론 모드에서 차단**된다. 패턴:
  1. `write_file`로 스크립트 작성 → 2. `terminal`로 실행
- **`write_file`의 Bearer 토큰 마스킹 함정 (2026-06 발견)**: `write_file`에 `Bearer <token>` 같은 평문 토큰이 포함되면 **마스킹되면서 인접 문자열이 깨져 SyntaxError**. `terminal` heredoc도 동일하게 마스킹. **반드시 런타임에 토큰을 조합**:
  ```python
  # ❌ 동작 안 함 (마스킹됨)
  prefix = "Authorization: Bearer *** 
  # ✅ 동작함 (런타임 조합)
  BEARER = "Bearer " + ""
  prefix = "Authorization: " + BEARER
  cmd = '-H "' + prefix + api_key + '"'
  ```
- 시크릿 env 파일은 `export MINIMAX_API_KEY=...` 한 줄. `line.split("=", 1)[1].strip().strip('"').strip("'")` 패턴으로 안전 파싱

자세한 코드 예시는 `references/cron-execution-pattern.md` 참조.

## 시크릿 파일

- 미니맥스 API Key: `~/.hermes/secrets/minimax.env` (export MINIMAX_API_KEY=...)
- Notion Token: `~/.hermes/secrets/notion_token.txt`

## 이미지 생성 API (image-01)

MiniMax `image-01`은 **Text-to-Image 생성 모델**입니다. 잔여량이 100% 남아 있어 사용 가능:

**Endpoint:** `POST https://api.minimax.io/v1/image_generation`

```bash
curl -s -X POST "https://api.minimax.io/v1/image_generation" \
  -H "Authorization: Bearer $MINIMAX_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "image-01",
    "prompt": "이미지 설명 (최대 1500자)",
    "aspect_ratio": "1:1",
    "response_format": "url",
    "n": 1
  }'
```

**주요 파라미터:**
- `model`: `image-01` 고정
- `prompt`: 텍스트 프롬프트 (최대 1500자)
- `aspect_ratio`: `1:1`, `16:9`, `4:3`, `3:2`, `2:3`, `3:4`, `9:16`, `21:9`
- `response_format`: `url` (24시간 만료) 또는 `base64`
- `n`: 생성할 이미지 수 (1~9)
- `prompt_optimizer`: `true`로 설정하면 프롬프트 자동 최적화

**MCP 도구와의 차이점:**
- `mcp_minimax_understand_image` → 이미지 **이해/분석**만 가능
- MiniMax REST API `/v1/image_generation` → 이미지 **생성** 가능

자세한 API 스펙은 `references/image-generation.md`를 참조하세요.

## 참고 자료

자세한 API 응답 필드와 에러 코드는 `references/usage-api.md`를 참조하세요. Bearer 토큰 마스킹 회피 등 크론 실행 패턴은 `references/cron-execution-pattern.md` 참조.
