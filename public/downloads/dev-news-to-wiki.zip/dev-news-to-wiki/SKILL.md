---
name: dev-news-to-wiki
description: Notion Dev News Archive 뉴스 클리핑을 분석하여 LLM Wiki에 자동 등록
---

# Dev News → Wiki Sync

## Overview
Notion Dev News Archive의 뉴스 클리핑 DB를 매일 분석하여 LLM Wiki에 등록하는 자동화.
> Support files: `references/category-registration-guide.md` (category→type mapping + skip patterns), `references/2026-06-04-sync-lessons.md` (latest session decisions, backlink gaps, platform-war pattern tracking)

## Notion Page
- URL: `https://www.notion.so/Dev-<DB_ID>` (본인 DB URL로 설정)
- Integration: ICBM2 Notion Integration (연결 완료)
- DB 이름: 뉴스 클리핑
- DB 속성: 이름, 분류(뉴스/인사이트/TIP/오픈소스/iOS), 발견일, 부연설명, 원문 URL, 즐겨찾기

## Schedule
- 크론: 평일(월~금) 20:00
- 스크립트: `~/.hermes/scripts/notion_news_to_wiki.py`

## Wiki Location
**`~/wiki`** (absolute: `/Users/hjshin/wiki`). This is NOT under `~/.hermes/`. Use this path directly — do not search for it.

### 1단계: 스크립트 실행
```bash
python3 ~/.hermes/scripts/notion_news_to_wiki.py
```
출력의 지시사항을 읽고 Autonomous하게 실행합니다. 크론 컨텍스트에서 실행되므로 Clarify 요청이 불가능합니다.

### 2단계: Wiki 방향 확인 (Orientation)
Wiki 조작 전 반드시 실행 (매번):
1. `~/wiki/SCHEMA.md` 읽기 — conventions, tag taxonomy, page thresholds 파악
2. `~/wiki/index.md` 읽기 — 현재 페이지 목록과 중복 체크
3. `~/wiki/log.md` 마지막 20~30줄 — 최근 활동 확인

### 3단계: Content Fetch (병렬)
여러 항목을 동시에 fetch하면 속도가大幅 향상됩니다. **2~3개씩 병렬 호출**합니다.
- GeekNews (hada.io): 제목+URL로 핵심 파악 가능 → fetch 불필요, raw source에 제목+카테고리만 저장
- 기술 기사 (AI Times 등): `mcp_ddg_search_fetch_content`로 본문 fetch 후 핵심 정리
- 유튜브만 제공: `mcp_ddg_search_search`로 GitHub/프로젝트 페이지를 먼저 검색
- 각 호출은 `max_length=6000` 설정

### 4단계: Raw Source 파일 작성
각 뉴스 항목의 핵심 내용을 요약하여 `raw/articles/`에 저장.
파일명: `{주제-2026}.md`, 형식: 타이틀, URL, Date, Category, 요약

**Content fetch 전략:**
- **hada.io/GeekNews TIP급**: 제목+URL로 핵심 파악 가능 → fetch 불필요, 제목+카테고리+간단 요약만 raw source로 저장
- **AI Times 기술 기사** (깊은 분석, 벤치마크 수치 포함): `mcp_ddg_search_fetch_content`로 본문 fetch 후 핵심 정리
- **유튜브 인사이트**: 제목+카테고리로 판단 → 로컬 GPU 비교, 페르소나 등 기술적 깊이 있는 것은 fetch, 단순 TIP은 skip
- 판단 기준: 항목명에 벤치마크/비교/프레임워크/아키텍처 관련어가 있으면 → fetch

**병렬 fetch 패턴 (중요):** 여러 항목을 동시에 fetch할 때는 2~3개씩 **동시에** 호출한다. `mcp_ddg_search_fetch_content`를 한 번에 여러 개 호출하면 병렬 처리되어 속도가大幅 향상된다. 8개 항목이면 3+3+2 또는 3+3+2로 분할해서 호출. 각 호출은 `max_length=6000`으로 설정 (긴 기술 기사는 6000, GeekNews 급은 4000).

**Content Fetch Fallback Strategy (YouTube / Minimal Content):**
- 유튜브만 제공되는 경우: `mcp_ddg_search_search`로 실제 GitHub 또는 프로젝트 페이지를 먼저 검색. 본문 fetch는 GitHub/프로젝트 페이지에서 수행
  - 예: "OpenSwarm" YouTube → DuckDuckG 검색 → `github.com/openswarm-ai/openswarm` repo 요약으로 Wiki 정보 충당
- GeekNews (hada.io) 요약만 있는 경우: 제목+URL로 판단, deep fetch 불필요
- 403 Forbidden 우회: `mcp_ddg_search_search`로 동일 기사를 dev.to, medium, pasqualepillitteri.it 등 대체 출처에서 검색

**YouTube 영상 처리 강화 (2026-06-04 학습):**
- 제목만 보고 "흥미로워 보이는" YouTube 영상(예: "클로드 코드 Dynamic Workflow 기능 비교", "랄프모드 딥인터뷰")은 **무조건 skip하지 말 것**
- 먼저 `mcp_ddg_search_search`로 영상/채널/주제를 검색해서 본문 텍스트/스크립트/transcript 추출 시도
  - 예: "ralph mode deep interview" → 관련 GitHub repo나 블로그 글 발견되면 fetch
- 추출 불가능하면 skip하되 log에 **"콘텐츠 미확보"** 사유 명시
- 키워드/도구 이름(Ralph mode, Dynamic Workflow)이 주제 자체로 가치가 있으면 **개념 페이지 1개 생성도 고려** — 향후 동기화에서 확장 가능한 시드 페이지
- 이 패턴이 누적되면 `references/workflow-pattern-tracker.md` 같은 **워크플로우 패턴 진화 추적 파일**로 활용 가능

**이미지 기반 콘텐츠 (유머/게임 등):**
- 루리웹 게임 매출 순위, 밈/유머 게시글 등 → **즉시 skip** (주인님 핵심 관심사 AI/ML/iOS/개발자 도구 범위 밖)
- 판단이困难的 경우: "이것이 에이전트, 코딩, iOS, AI 모델, 개발 도구와 직접 관련 있는가?"로 테스트

### 4단계: 분류
Notion DB에 이미 주인님 관심사만 스크랩되어 있으므로, **모든 항목을 Wiki에 등록**합니다.

**분류 규칙:**
- products, models, frameworks, companies, tools → **entities/**
- techniques, formats, theories, paradigms → **concepts/**

### 5단계: 기존 페이지 처리 — "이미 등록" 판단 기준

**3가지 경우가 있음. 각각 다르게 처리해야 함:**

| 상황 | 판단 기준 | 처리 |
|------|-----------|------|
| A. Wiki page 존재 + 내용 충실 | index.md에 있고 page가 있음, updated 날짜가 recent | **Skip** (완전한 previous sync) |
| B. Wiki page 존재 + 내용 陈旧 | page는 있으나 최신 뉴스의 세부사항이 빠져있음 | **Update** — read_file 후 patch로 내용 보강 |
| C. index.md에 wikilink만 있음 + page 없음 | 이전 sync에서 index에만 추가되고 page 파일이 생성 안 됨 | **Create** — page 파일 생성 |

**실전 판단:**
- `ruflo.md`: 기존 page가 v3 Claude Flow 수준 → 오늘 v3 (Rust 엔진, 32개 플러그인) 새로운 정보 없음 → **Skip**
- `ssh-tunnel-services.md`: 기존 page에 NatNest 상세 내용 포함 → **Update** (상세 분리하여 natnest.md 생성, ssh-tunnel-services.md는 참조 요약으로 변경)
- `siri-ai-agent.md`: 기존 page는 개요 수준 → 오늘 iOS 27 Siri 상세 디자인 (Dynamic Island, 카드 UI, Search or Ask 등) 추가로움 → **Update**

> **핵심 기준:** "이미 등록"은 page 파일의 **내용 충실도**로 판단. 단순히 index.md에 있并不能不代表 Skip. 반드시 page 파일을 read_file해서 최신 뉴스 대비 누락이 있는지 확인할 것.

### 6단계: Wiki 페이지 작성
Batch로 처리하면 효율적. **모든 write_file을 한 번에 호출한 뒤 한 번에 patch하는 순서**가 context 절약에 유리.

> ⚠️ **index.md patch 주의사항 (중요)**: `patch`의 `old_string`이 파일에서 **2곳 이상** 매치되면 모든 지점이 한 번에 수정됩니다. 이 session에서 중복이 2배로 늘어난 사례가 있습니다. 방지 방법:
> 1. **미리 `read_file`으로 전체 파일을 읽고** 매치 범위 확인
> 2. **unique한 context** (예: surrounding 3줄 이상)를 포함시켜서 매치를 제한
> 3. 2곳 이상 매치되면 `write_file`로 통째 재작성
> 4. **수정 후 `read_file`으로 중복이 사라졌는지 반드시 확인**

**index.md 정렬 표준:**
- 모든 항목은 `- ` 접두어 (빼기/공백) 사용 — `|- ` 절대 사용하지 말 것
- 중복 항목이 생기기 쉬운 위치: tokenmon, vo``x``cpm2, whichllm 등 기존 항목 근처에 새 항목을 insert할 때
- **반드시 read_file으로 삽입 위치 전후 3줄을 확인**한 뒤 unique context로 patch

**"이미 등록" 판단 기준 — script 출력과 Wiki 현황의 괴리:**
스크립트 출력의 "신규 항목: N건"은 **Notion DB에 새로 추가된 항목**이지, Wiki에まだ登録されていない 항목을 의미하지 않습니다. 동일 항목이昨天 Wiki에 등록된 경우도 "신규"로 표기됩니다.

**따라서 모든 항목에 대해 Wiki existing page check가 필수입니다:**
1. 스크립트 출력의 각 항목을 `search_files`로 Wiki에서 검색
2. page가 이미 존재하면 → **Skip** (昨天的 동기화에서 처리됨)
3. page가 없으면 → **Create**

실전 판단 (2026-05-19 기준):
- `apple-on-device-openai`, `whichllm`, `sherlock-ai-notes`, `google-skills`, `ai-subscription-timebomb` → 모두昨天的 동기화에서 이미 Wiki 등록됨 → **Skip**
- `Emergence World`, `Datatype`, `Tokenova` → Wiki에 없음 → **Create**

### 7단계: Raw Source 파일 작성

각 뉴스 항목의 핵심 내용을 요약하여 `raw/articles/`에 저장.
파일명: `{주제-2026-MM-DD}.md`, 형식: 타이틀, URL, Date, Category, 요약

> Note: Raw source 저장은 Wiki page 생성 후에 해도 무방. `/tmp/notion_news_digest.json`에 원본 데이터가 이미 존재하므로 raw source는 "참조용"이며 Wiki page가 주요 산출물이다.

### 8단계: Orphan 검증 (생성 직후 필수)

Orphan = 다른 페이지에서 `[[wikilink]]`로 한 번도 참조되지 않는 페이지. 모든 새 페이지는 반드시 2개 이상의 아웃바운드 wikilink를 포함해야 합니다.

```bash
# 아웃바운드 wikilink가 없는 페이지 찾기
grep -r "\[\[" ~/wiki/entities/ ~/wiki/concepts/ ~/wiki/comparisons/ 2>/dev/null \
  | grep -oE '\[\[[^]]+\]\]' | sort | uniq -c | sort -rn \
  | awk '$1==1 {print $2}' | sed 's/\[\[//g; s/\]\]//g'
```

Orphan이 발견되면 해당 페이지에 [[hermes-agent]], [[ai-agents-trends-2026]] 등 범용 백링크라도 추가합니다.

## 9단계: 도메인 패턴 인식 (2026-06-04 학습)

새로운 entity/concept가 등장할 때 **단일 페이지 등록을 넘어 도메인 차원의 패턴으로 승격**할지 검토:

- **"프로덕션 하네스 정렬 학습" 패턴** (MAI-Code-1-Flash): 벤치마크 최적화가 아닌 실제 워크플로 하네스에서 직접 학습하는 새 학습 패러다임 → `concepts/coding-agent-benchmark.md`에 "벤치마크 한계 + harness-aligned training" 섹션 추가
- **"코딩 도구 → 범용 업무 플랫폼" 카테고리 이동** (Codex Plugins/Sites): AI 코딩 에이전트가 비개발자 영역으로 확장하는 트렌드 → `concepts/ai-agents-trends-2026.md`에 "에이전트형 업무 자동화 메인스트림 진입" 섹션 추가
- **"주주 플랫폼 전쟁"** (Anthropic Skills/Cowork vs OpenAI Plugins/Sites vs Microsoft MAI): 3사가 같은 도메인(팀 업무 에이전트)에 진입 → 별도 `concepts/agent-platform-war-2026.md` 페이지 검토 (현재는 트렌드 페이지에 섹션으로 흡수)
- **인식된 도메인 패턴이 3건 이상 누적되면 별도 concept 페이지 분리** — 그렇지 않으면 ai-agents-trends-2026 같은 트렌드 페이지가 비대해짐 (200줄 임계점 주의)

이런 패턴 인식은 **다음 동기화에서 cross-reference 작업 부하를 大幅 줄임** + 사용자(희정님)에게 "기술 트렌드의 큰 그림" 인사이트 제공.

## Pitfalls

### frontmatter 필수: title, created, updated, type, tags (taxonomy만), sources
- 최소 2개 이상의 outbound `[[wikilinks]]` 포함
- 기존 페이지 있으면 새 정보만 추가, updated 날짜 갱신
- 같은 entity/concept에 여러 뉴스가 있으면 **한 페이지에 병합** (중복 방지)

### Skip decision trees (주인님 관심사 프로필)
> See `references/category-registration-guide.md` for detailed category→type mapping and correct skip patterns.
- **Tutorials/How-to**: 단일 튜토리얼은 항상 skip (Git 커밋 로그 자동화 등)
- **인사이트 (insight)**: 새 엔티티/개념 있으면 등록, 없으면 skip
- **TIP (tool)**: 도구/플랫폼이면 entities/, 개념적 추상화면 concepts/
- **오픈소스**: entities/에 등록하는 것이 기본

### index.md patch 주의사항 (중요)
> ⚠️ `patch`의 `old_string`이 파일에서 **2곳 이상** 매치되면 모든 지점이 한 번에 수정됩니다.
> 1. `read_file`으로 전체 파일 읽고 매치 범위 확인
> 2. unique context 3줄 이상 포함시켜서 매치 제한
> 3. 2곳 이상 매치되면 `write_file`으로 통째 재작성
> 4. 수정 후 `read_file`으로 중복 확인

> Note: Raw source 저장은 Wiki page 생성 후에 해도 무방. `/tmp/notion_news_digest.json`에 원본 데이터가 이미 존재하므로 raw source는 "참조용"이며 Wiki page가 주요 산출물이다.
