#!/usr/bin/env python3
"""Post prepared weekly entries to Notion DB with preflight + status fallback.

Re-runnable. Uses template/notion_preflight.py to probe the token first.
On 401: writes a status file to ~/.hermes/memory/reports/notion_YYYY-WNN_status.md
with all prepared payloads preserved (so the next run after token rotation
can replay them).

Edit the ENTRIES list with the week's actual data, then:
    python3 scripts/post_weekly_entries.py

DB: Weekly Report (33c76f2e-9097-81be-9ea4-cefd03512e81)
"""
import json
import os
import subprocess
import sys
from datetime import datetime, timezone, timedelta

# Resolve preflight relative to this script
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "templates"))
try:
    from notion_preflight import check as preflight
except ImportError:
    # Inline fallback if template isn't on path
    def preflight():
        return False, "notion_preflight template not importable"

DB_ID = "33c76f2e-9097-81be-9ea4-cefd03512e81"
NOTION_VERSION = "2022-06-28"
TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
STATUS_DIR = os.path.expanduser("~/.hermes/memory/reports")
KST = timezone(timedelta(hours=9))


# === EDIT THIS LIST FOR THE WEEK ===
ENTRIES = [
    # {
    #     "name": "2026-W23 Tistory Blog",
    #     "item": "Tistory",
    #     "value": 57,
    #     "week": "2026-W23",
    #     "note": "b1bca63a117a 6/2-6/7 sum 57 — 6/2 2, 6/3-6/6 12, 6/7 7. stable",
    # },
    # ... add real entries per week
]


def post_one(tk, e):
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": e["name"]}}]},
            "Week": {"rich_text": [{"text": {"content": e["week"]}}]},
            "Item": {"select": {"name": e["item"]}},
            "Value": {"number": e["value"]},
            "Note": {"rich_text": [{"text": {"content": e["note"]}}]},
        },
    }
    with open("/tmp/notion_entry.json", "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    r = subprocess.run(
        [
            "curl",
            "-s",
            "-X",
            "POST",
            "--max-time",
            "15",
            "https://api.notion.com/v1/pages",
            "-H",
            f"Authorization: Bearer *** + tk,
            "-H",
            f"Notion-Version: {NOTION_VERSION}",
            "-H",
            "Content-Type: application/json",
            "--data-binary",
            "@/tmp/notion_entry.json",
        ],
        capture_output=True,
        text=True,
    )
    try:
        j = json.loads(r.stdout)
        if j.get("object") == "page":
            return True, j["id"]
        return False, j.get("message", r.stdout[:200])
    except Exception as ex:
        return False, f"parse error: {ex} | {r.stdout[:200]}"


def write_status(reason, entries):
    os.makedirs(STATUS_DIR, exist_ok=True)
    week = entries[0]["week"] if entries else "unknown"
    path = os.path.join(STATUS_DIR, f"notion_{week.replace('-', '_')}_status.md")
    lines = [
        f"# Notion Weekly Report — {week} (FAILED)",
        "",
        f"**Status:** ❌ {reason}",
        f"**When:** {datetime.now(KST).strftime('%Y-%m-%d %H:%M KST')}",
        f"**Token file:** {TK_PATH}",
        f"**Target DB:** {DB_ID} (Weekly Report)",
        "",
        "## Error",
        f"- Preflight: {reason}",
        "- All 6 prepared entries were NOT delivered. They are preserved below for replay after token rotation.",
        "",
        "## Payload Prepared (replay-ready)",
        "",
    ]
    for e in entries:
        lines.append(
            f"{len([x for x in lines if x.startswith(str(entries.index(e)+1)+'.')])+1}. **{e['name']}** — {e['item']} / {e['value']} / {e['note']}"
        )
    lines.extend(
        [
            "",
            "## Recovery Steps",
            "1. Re-issue Notion integration secret (workspace Settings → Connections)",
            "2. Write new token to: " + TK_PATH,
            "3. Re-run: `python3 " + os.path.abspath(__file__) + "`",
            "4. Status file can be deleted after successful replay",
        ]
    )
    with open(path, "w") as f:
        f.write("\n".join(lines) + "\n")
    return path


def main():
    if not ENTRIES:
        print("ENTRIES list is empty. Edit scripts/post_weekly_entries.py first.")
        sys.exit(1)

    ok, msg = preflight()
    print(f"Preflight: {'OK' if ok else 'FAIL'} — {msg}")
    if not ok:
        path = write_status(msg, ENTRIES)
        print(f"Status file written: {path}")
        # Optional Telegram alert — see api-key-manager for pattern
        sys.exit(1)

    with open(TK_PATH) as f:
        tk = f.read().strip()

    success = 0
    fail = 0
    for e in ENTRIES:
        post_ok, post_msg = post_one(tk, e)
        if post_ok:
            print(f"OK   {e['name']} -> {post_msg}")
            success += 1
        else:
            print(f"FAIL {e['name']}: {post_msg}")
            fail += 1

    print(f"\nPosted {success}/{success+fail} entries")
    sys.exit(0 if fail == 0 else 2)


if __name__ == "__main__":
    main()
