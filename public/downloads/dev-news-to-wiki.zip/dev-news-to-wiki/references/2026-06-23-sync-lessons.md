# 2026-06-23 Sync Session Lessons

Session-specific detail captured for the dev-news-to-wiki skill. See SKILL.md for active rules.

## What Got Processed

| Notion Item | Category | Decision | Page Action |
|-------------|----------|----------|-------------|
| agent-connector (MCP 서버/훅 42개 CLI 일괄 배포) | TIP | CREATE | `entities/agent-connector.md` |
| agent-blackbox (Claude Code/OpenCode 세션 단위 토큰 낭비 분석) | 오픈소스 | CREATE | `entities/agent-blackbox.md` |
| bigset (자연어 한 문장으로 라이브 데이터셋 생성) | 오픈소스 | CREATE | `entities/bigset.md` |
| mydoo (클로드 코드 기본 LLM VS Code 포크 한국 IDE) | TIP | CREATE | `entities/mydoo.md` |
| open-code-review (Alibaba AI 코드 리뷰 도구, Apache-2.0) | 오픈소스 | CREATE | `entities/open-code-review.md` |
| repolis (GitHub 레포 3D 도시 시각화) | 오픈소스 | CREATE | `entities/repolis.md` |
| 비드래프트 GPQA Diamond 90.9% | 뉴스 | **SKIP (mixed-batch 중복)** | `entities/bedraft.md` 2026-06-22 동기화에서 이미 반영 |

6 신규 + 1 mixed-batch 중복 (Total 134 → 140).

## Mixed-Batch (Partial-Overlap) Handling — 7건 중 6건만 신규

이번 세션의 핵심 패턴: **Notion digest가 7건을 줬지만, 1건은 직전 동기화(2026-06-22)에 이미 Wiki에 반영**. llm-wiki 스킬의 "Partial-overlap (mixed) batch handling" pitfall이 정확히 작동.

**Detection recipe** (이번 세션에서 실행):
```bash
# 1. Notion digest의 제목/URL을 log.md의 최신 sync entry와 비교
# 2. "비드래프트, GPQA Diamond 90.9% 기록" → bedraft.md가 이미 존재 + index/log 등록 완료
# 3. → log entry에 "⏭️ 이미 처리됨 (2026-06-22)" 명시
```

**Log entry 템플릿 (이번 세션에서 사용)**:
```
## [2026-06-23] ingest | Notion Dev News → LLM Wiki 동기화
- Source: Notion 뉴스 클리핑 DB (7건, 2026-06-22~23)
- **처리**: 7건 중 **6건 신규**, 1건은 2026-06-22 동기화에서 이미 처리됨
  - ✅ **신규**: `agent-connector`, `agent-blackbox`, `bigset`, `mydoo`, `open-code-review`, `repolis`
  - ⏭️ **이미 처리됨 (2026-06-22)**: `비드래프트 GPQA Diamond 90.9%` → [[bedraft]] 동기화에서 이미 반영
```

**User-facing report**도 동일한 구조로 `✅ 신규` / `⏭️ 이미 처리됨` 분리 — silent skipping 안티패턴 회피.

## Domain Pattern Recognition — 이번 세션에서 추가된 패턴

### Pattern 8: 에이전트 표준화 3단계 (Protocol + Distribution + UI)

오늘 6개 항목 중 가장 큰 시사점 — **"표준화는 한 단계로 끝나지 않는다"**:

| 계층 | 표준/도구 | 역할 |
|------|-----------|------|
| **통신 표준** | [[agent-client-protocol]] (Anthropic 2026) / [[mcp-vs-skills]] | 에이전트 ↔ 클라이언트 인터페이스 |
| **배포 표준** | **[[agent-connector]]** (이번 세션) | 42개 호스트에 MCP/훅 일괄 배포 |
| **UI 표준** | [[acp-ui]] | reference 클라이언트 |

- 한 단계만 있는 표준은 **종속을 만든다** (예: ACP만 있고 agent-connector 없으면 호스트별 설정 지옥)
- `mcp-vs-skills` 의 "배포 표준화" 섹션으로 흡수 (이번 세션 patch)
- → 향후 OpenAPI/LSP 등 다른 표준 생태계에도 적용 가능한 메타-패턴

### Pattern 9: 결정론적 보강의 도메인 확산 (4·5번째 사례 추가)

`local-llm-agentic-coding` 의 "결정론적 보강" 메타 패턴에 2026-06-16 의 perfectpixel-studio(이미지) 에 이어:

- **[[open-code-review]]** (2026-06-23) — 코드 리뷰 영역. **결정론적 엔지니어링 × 에이전트 하이브리드**:
  - 정밀 파일 선택 / 스마트 파일 번들링 → 엔지니어링 로직
  - 동적 판단 (코드 이해) → 에이전트
  - 결과: 동일 모델 대비 토큰 **~1/9**, Precision/F1 우위
- **[[agent-blackbox]]** (2026-06-23) — 세션 분석 영역. **결정론적 패턴 매칭 × 에이전트 이벤트 로깅**:
  - 낭비 패턴(같은 파일 반복 읽기 / 실패 명령 반복 / prompt cache 미활용) → 결정론적 탐지
  - 컨텍스트 흐름 → 에이전트
  - 결과: 발견한 낭비를 AGENTS.md / CLAUDE.md 에 자동 반영 (self-improving 루프)

→ "결정론적 보강"은 이제 5개 도메인에 확산: 코딩 / 이미지 / 리뷰 / 세션 분석 / (그리고 [[oh-my-harness]] 의 hook도 같은 계열). `local-llm-agentic-coding` 페이지의 "관련" 섹션에 2개 신규 추가.

### Pattern 10: 한국 AI 도구의 실무화 (mydoo)

- **[[mydoo]]** — Anthropic의 [[claude-cowork]] 비전 (법률/금융/팀 도메인 자율 에이전트) 을 **한국 SMB/SOHO 시장**에 풀어냄
- 차별점: 클로드 코드 기본 LLM 고정 + Recall(RAG 기억 공유) + DooDesk(팀 채팅) + Doopyrus(문서 발행) = IDE를 업무 플랫폼으로 확장
- `multi-model-orchestration` 의 **Cascade/Router 단순화** 버전으로 분류 가능 ("시종장 = Claude Code + 멀티 LLM 보조")
- → 향후 한국 개발자 IDE 생태계 모니터링 필요 (cursor/kiro/zed 등 글로벌 vs mydoo 비교)

### Pattern 11: 자연어 → 데이터셋 자급자족 파이프라인

`bigset` 의 등장으로 **AI가 자체 데이터를 만들고/저장하고/소비하는** 파이프라인이 명확해짐:

| 단계 | 도구 | 역할 |
|------|------|------|
| **자연어 → 라이브 데이터** | **[[bigset]]** (이번 세션) | 웹 자동 조사 + 스키마 추론 + 주기 갱신 |
| **데이터 저장** | [[gitdb]] | GitHub을 backend로 (인프라 0) |
| **정적 코퍼스** | [[ai-readable-gazette-kr]] | PDF → AI-readable markdown (정적) |
| **소비** | [[hermes-agent]] / 다양한 에이전트 | 자동화 파이프라인 입력 |

→ `bigset` 은 [[hermes-agent]] 의 자동화 파이프라인에 데이터 수집 백엔드로 통합 검토 가능 (현재 뉴스 클리핑 / 시장 모니터링 단계에서 활용).

## 한국 사용자 친화 패턴 (mydoo 추가 분석)

`mydoo` 페이지의 구조에서 한국 SMB 사용자에게 특히 중요한 패턴:
- **모바일 승인 요청** — PC에서 작업 중 모바일로 승인 알림 (핸즈프리 워크플로우)
- **팀 기억 공유** — 팀원의 기억을 회사가 소유 (온보딩 비용 0)
- **프리랜서 과정 기억** — 협업 과정도 영구 보존 (의존도 감소)
- → Anthropic의 [[claude-cowork]] 가 영어권 법률/금융에 특화되어 있다면, mydoo는 한국 SMB 일반 업무에 특화된 로컬라이제이션

## index.md 정렬 검증 패턴 (bigset 케이스)

이번 세션에서 한 번 잘못된 알파벳 순으로 삽입했다가 즉시 재정렬한 사건:

1. 1차 patch: `bedraft` 다음에 `bigset` 삽입 → `ai-readable-gazette-kr` 다음
2. 검증: `ai-*` 가 `bedraft/bigset` 다음에 와야 알파벳 순
3. 2차 patch로 즉시 재정렬

**교훈**: llm-wiki 스킬의 "Alphabetical insertion" pitfall이 정확히 작동했지만, **`patch → read_file 검증 → 잘못되면 즉시 재정렬`** 의 루프가 필요. 이번에는 2번째 patch가 정상이었지만, 만약 2번째 patch도 잘못되면 3번째로 가야 함 (최대 3회까지, 그 이후는 write_file로 통째 재작성 검토).

## Backlink 작업 — 7개 페이지

이번 세션에서 **6개 신규 엔티티** + **7개 기존 페이지 백링크 갱신**:

| 백링크 타깃 | 추가된 신규 wikilinks | 의의 |
|------------|----------------------|------|
| `ai-agents-trends-2026.md` | 6개 항목 종합 (섹션 23) | 트렌드 페이지의 종합 분석 |
| `mcp-vs-skills.md` | agent-connector | "배포 표준화" 카테고리 추가 |
| `local-llm-agentic-coding.md` | open-code-review, agent-blackbox | 결정론적 보강 4·5번째 사례 |
| `china-ai-lab-culture.md` | open-code-review | 알리바바의 분산된 AI 깊이 |
| `vibe-coding.md` | repolis, mydoo | 바이브 코딩 사례 누적 |
| `oh-my-harness.md` | open-code-review, agent-connector, agent-blackbox | 이중 방어선 + 다중 호스트 + 세션 분석 |
| `agent-client-protocol.md` | agent-connector | 통신 표준 + 배포 표준 직교 관계 |

총 **13개 outbound 추가 backlinks**. 이번 세션의 핵심 작업량 중 하나였으며, 모든 patch가 frontmatter 갱신과 동시에 atomic하게 처리됨 (patch-disaster-case-studies.md Case 9 회피).

## frontmatter 갱신 — 7개 페이지 단일 patch 원칙 준수

이번 세션에서 7개 페이지의 `updated` 날짜 + `title` 을 단일 patch로 atomic하게 갱신:
- `ai-agents-trends-2026.md`: 2026-06-19 → 2026-06-23
- `mcp-vs-skills.md`: 2026-06-15 → 2026-06-23 (title 도 단축)
- `local-llm-agentic-coding.md`: 2026-06-15 → 2026-06-23 (title 도 단축)
- `china-ai-lab-culture.md`: 2026-06-19 → 2026-06-23
- `vibe-coding.md`: 2026-06-02 → 2026-06-23 (title 도 변경)
- `oh-my-harness.md`: 2026-06-15 → 2026-06-23
- `agent-client-protocol.md`: 2026-06-12 → 2026-06-23 (title 도 단축)

**모든 patch가 단일 old_string/new_string으로 전체 frontmatter 블록을 한 번에 교체** — Case 9 (split-patch frontmatter 갱신) 안티패턴 회피.

## 권고 사항 (다음 동기화에서 검토)

1. **[[hermes-agent]] 의 자동화 파이프라인에 [[bigset]] (라이브 데이터 수집) + [[agent-blackbox]] (세션 분석) + [[agent-connector]] (MCP 일괄 배포) 통합 검토**
2. **[[oh-my-harness]] 의 pre-commit hook + [[open-code-review]] 의 CI 리뷰 = 이중 방어선 구성**
3. **[[vibethinker-3b]] + [[open-code-review]] 결정론적 보강을 결합한 로컬 코딩 워크플로우 검토** (3B 모델 + 결정론적 하니스 = 효율 극대화)
4. **[[mydoo]] 모니터링 — 한국 SMB/SOHO AI 도구 시장 동향 분기별 점검**
5. **Notion DB `Wiki-synced` 마킹** — upstream 스크립트 패치 (2026-06-19 부터 filed, 여전히 미해결)