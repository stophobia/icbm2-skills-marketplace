---
name: canvas-static-site-pipeline
description: 단일 페이지 정적 웹 프로젝트 End-to-End 파이프라인 — 컨셉 → GitHub 저장소 생성 → HTML/CSS/JS 구현 → Vercel 배포. Canvas API, D3.js, Three.js, p5.js 등 브라우저 기반 시각화/시뮬레이터에 최적화.
category: devops
tags:
  - static-site
  - canvas
  - vercel
  - github
  - simulation
  - visualization
  - educational
when to use: >
  사용자가 새로운 웹 앱/시뮬레이터/시각화 프로젝트 요청 시.
  "저장소 생성하고 Vercel로 배포해줘" 계열의 요청.
  Canvas API, 순수 JavaScript 기반 인터랙티브 앱 제작.
---

# canvas-static-site-pipeline

## steps

### 0. 컨셉/스코프 정리 (구현 전 필수)

**반드시 구현 전에 한다.** 사용자가 처음에 LLM/agent/AI benchmark를 언급해도 실제 deliverable이 **(a) 정적 시각화, (b) LLM 평가/벤치마크, (c) 그 외** 중 어디에 속하는지 먼저 분류한다 — 다른 워크플로로 빠지는 함정. (2026-06-11 세션: "Artemis Mission Control Challenge"가 LLM 에이전트 평가로 보였지만 실제 목표는 GPT-5.5 키노트 스타일 정적 궤적 시각화였음.)

확정 후 **brainstorming-first** 패턴으로 3~4개 결정 포인트를 A/B/C 옵션으로 제시하고 **추천 1개를 굵게** 표시한다. 사용자는 "그대로 진행" 또는 옵션 교체만 답하면 됨. 예시는 `references/decision-points-checklist.md` 참조.

핵심 결정 포인트 4가지:
- **데이터 소스** (live API vs precomputed JSON vs runtime fetch — 아래 섹션)
- **렌더링 라이브러리** (Three.js vs regl vs r3f vs raw WebGL — 아래 섹션)
- **비주얼 컨셉 범위** (2D / 3D / 토글 / 텔레메트리 오버레이)
- **작업 흐름 분할** (이 PC에서 끝 / 다른 PC 위주 / 협업)

### 1. 저장소 생성
```bash
gh repo create {project-name} --public --clone
mkdir -p ~/Desktop/project/work/ai/{project-name}
```

### 2. 프로젝트 구현
파일 구성:
```
/index.html    - 메인 HTML
/styles.css    - 스타일시트
/app.js        - Canvas/애니메이션 로직
/vercel.json   - Vercel 설정 (정적 사이트)
/README.md     - 한국어 프로젝트 설명
```

`vercel.json` 템플릿:
```json
{
  "buildCommand": null,
  "outputDirectory": ".",
  "installCommand": null,
  "framework": null,
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
}
```

### 3. GitHub 푸시
```bash
cd ~/Desktop/project/work/ai/{project-name}
git init
git remote add origin https://github.com/sigco3111/{project-name}.git
git add -A
git commit -m "{이모지} {프로젝트명} - {한 줄 설명}"
git branch -M main
git push -u origin main
```

### 4. Vercel 배포
```bash
vercel --yes --prod --token $(cat ~/.hermes/secrets/vercel_token.txt)
```

### 5. 결과 보고
- GitHub 저장소 URL
- 라이브 Vercel URL
- 구현된 기능 목록

### 5.5 Self-check (보고 전, "실망" 방지)

**사용자 보고 전 한 번 더 점검.** 결과물이 "발표 데모"급이려면:

- [ ] **브라우저에서 직접 확인** — Vercel URL 열어서 (a) 첫 프레임에 모든 body 보임, (b) trail이 끊김 없이 부드럽게 그려짐, (c) timeline/play 정상 작동, (d) 콘솔 에러 없음. curl HEAD 200 + grep 데이터 본문만으로는 부족.
- [ ] **시각적 임팩트** — 단순 Three.js sphere + line은 "키노트 데모"가 아님. 발광(emissive), halo, particle star field, 단일 액센트 색, 텔레메트리 HUD 같은 요소가 최소 1~2개.
- [ ] **인터랙션** — 자동 orbit만으로는 부족. OrbitControls 또는 hover/click 인터랙션 1개 이상.
- [ ] **README의 "구현된 기능"** — phase table / screenshot 등이 **실제 결과물과 일치**. 부풀려 쓰지 않기. 사용자가 phase table 보고 Vercel 열면 "이게 그거?" 안 되게.

자체 평가 통과 못 하면 **추가 polish 1라운드** 후 보고. (2026-06-11: phase table의 "GPT-5.5 데모 스타일" 카피와 실제 Three.js 결과물 사이 간극이 사용자 실망 신호. "있어 보이게 쓰지 말 것" lesson.)

### 6. 철거 / Cleanup (사용자가 요청 시)

Vercel + GitHub repo 한 번에 정리. **로컬 디렉토리, /tmp 산출물, ~/.hermes/skills/ 심볼릭 링크**는 별도 — 사용자에게 확인 후 `trash`로.

```bash
# 1) GitHub repo 삭제
gh repo delete sigco3111/{project-name} --yes

# 2) Vercel 프로젝트 + 모든 배포 + alias 제거
# ⚠️ `vercel project rm --yes` 옵션 없음. `yes y | ...` 무한 stdin은 hang.
# → `printf "y\n"` + `--non-interactive` 조합이 정답.
printf "y\n" | vercel project rm {project-name} --non-interactive --token $(cat ~/.hermes/secrets/vercel_token.txt)

# 3) 남은 alias 개별 제거 (production + preview URL들)
for alias in $(vercel alias ls --token $(cat ~/.hermes/secrets/vercel_token.txt) 2>&1 | grep -i {project-name} | awk '{print $1}'); do
  vercel alias rm "$alias" --yes --token $(cat ~/.hermes/secrets/vercel_token.txt)
done

# 4) 검증 — project/alias 모두 0건
vercel project ls --token $(cat ~/.hermes/secrets/vercel_token.txt) 2>&1 | grep -i {project-name}
vercel alias ls --token $(cat ~/.hermes/secrets/vercel_token.txt) 2>&1 | grep -i {project-name}

# 5) 로컬 디렉토리 + /tmp 산출물
trash ~/Desktop/project/work/ai/{project-name}
trash /tmp/{h_*,*.json}  # 데이터 수집 단계 임시 파일
```

**정리 대상 체크리스트**:
- [ ] GitHub repo (소유자 확인: `gh repo view sigco3111/{name}` → 404)
- [ ] Vercel project + 모든 deployment
- [ ] Vercel alias (production + preview URL 모두)
- [ ] 로컬 디렉토리 (사용자 확인 후 `trash`, 절대 `rm -rf` 금지)
- [ ] /tmp 임시 파일 (ephemeris raw, JSON 변환본 등)
- [ ] `~/.hermes/skills/` 심볼릭 링크 (다른 프로젝트에서 쓰는 스킬이면 보존)

### 7. 다른 PC 핸드오프 (선택)

사용자가 "다른 PC에서 작업 예정"을 시사하면 step 5 직후 `HANDOFF.md` 자동 작성. 다른 PC에서 `git clone`만으로 이어서 작업 가능하도록:

```markdown
# Handoff — 다른 PC에서 이어서 작업하기

## 🌐 라이브 URL
- Vercel: https://{project-name}.vercel.app
- GitHub: https://github.com/sigco3111/{project-name}

## 📦 클론 & 실행
git clone https://github.com/sigco3111/{project-name}.git
cd {project-name}
npm install
npm run dev   # http://localhost:5173

## 🧱 핵심 파일
- app.js — Three.js main scene (line XX~YY = scene setup)
- trajectory.json — JPL Horizons data
- index.html — HUD layout

## 🎯 다음 단계 후보
1. OrbitControls (마우스 인터랙션)
2. Phase labels (TLI / MCC / flyby / re-entry)
3. Mobile touch

## 🔑 토큰 (다른 PC)
- Vercel: `vercel login` 필요
- GitHub: gh auth login
```

핸드오프는 GitHub repo에 같이 커밋 (`HANDOFF.md`) — `git clone` 한 번이면 다 따라옴.

## implementation notes

**GitHub Pages 배포 후 검증:**
- 롤백 감지: `curl -sI "https://{user}.github.io/{repo}/" | grep last-modified` — 날짜가 예상과 다르면 롤백 의심
- 컨텐츠 검증: `curl -s "URL" | grep -c "unique-string"` — 핵심 문자열 존재 확인
- 실패 시: `git log --oneline -5` → 최종 커밋 확인 → 강제 푸시로 복구

**OpenCode 위임 시:**
- `delegate_task` 사용 시 `toolsets: ["terminal", "file"]` 필수
- OpenCode 404/연결 오류 시 직접 구현으로 폴백

**Canvas 구현:**
- DPI 대응: `canvas.width = rect.width * 2; ctx.scale(2, 2)`
- 애니메이션: `requestAnimationFrame` + deltaTime
- 반응형: `window.addEventListener('resize', resizeCanvas)`

**데이터 소스 결정 (정적 시각화 핵심):**
실세계 데이터 시각화 프로젝트(궤적, 날씨, 주가, 지진 등)는 거의 항상 이 결정이 먼저다. 세 가지 패턴:

| 패턴 | 장점 | 단점 | 적합 시점 |
|---|---|---|---|
| **A. 빌드 시 precompute** — Python/Node로 API 호출 → JSON 커밋 | 정적 호스팅 OK, 클라이언트 부담 0, 결정적 | 데이터 갱신 시 재빌드 필요 | 임의 시점 스냅샷 (NASA JPL Horizons, 과거 주가) |
| **B. 런타임 fetch** — 클라이언트가 공개 API 직접 호출 | 항상 최신, 빌드 단순 | CORS·API 키·rate limit 이슈 | 날씨, 라이브 주가 (API 키 클라이언트 노출 시 B는 부적합) |
| **C. 사전 임베드 + 시뮬레이션** — 임의 시점 데이터 + 클라이언트 보간 | 1개 데이터셋으로 임의 시점 표시 | 계산량·정확도 트레이드오프 | "Artemis II 발사 10일 trajectory" 같이 고정 임무 표시 |

2026-06-11 Artemis 시각화 세션에서는 **A 패턴 채택** — Horizons API에서 발사±10일 ephemeris를 시간 스텝으로 sampling해 `data/trajectory.json` 커밋, Vite 정적 호스팅. 가장 안전·가볍고 결정적.

**WebGL 라이브러리 선택:**
사용자가 "WebGL + Vite"를 지정하면 후보:
- **Three.js** — 가장 보편적. 광원·카메라 컨트롤·로드러 즉시 사용. AI 키노트 데모 느낌에 가장 가까움. (추천 기본값)
- **regl** — functional WebGL, 더 가벼움, 코드 명시적. 단순 도형·궤적선에 적합.
- **react-three-fiber + drei** — React 선호 시. 컴포넌트 구조.
- **raw WebGL2** — 가장 가볍지만 작업량 多. 특수한 셰이더 효과 필요 시.

Vite + Three.js 보일러플레이트는 `templates/threejs-vite-data-viz.md` 참조 (전체 프로젝트 구조 + 코드 스니펫 + 배포 워크플로 + JSON inline 검증법).

NASA JPL Horizons(실측 천체역학) API로 우주선/행성 ephemeris를 가져오는 절차는 `references/jpl-horizons-api-guide.md` 참조 — `curl -k` SSL 우회, spacecraft ID 검색, 발사/임무 cutoff 시간 처리, km→scene unit 스케일링.

**AI 키노트 데모 미학 (GPT-5.5/Gemini/Claude 발표 페이지 스타일):**
- **배경**: 완전 검정 `#000` 또는 매우 어두운 그라데이션 (`#0a0a14` → `#000`). 별 입자(particle field) 추가하면 "우주적" 인상 ↑.
- **색상 팔레트**: 단일 액센트 (시안 `#00d4ff` 또는 오렌지 `#ff6b35`) + 흰색 텍스트. 무지개 그라데이션 금지.
- **타이포그래피**: 모노스페이스 또는 Inter/Geist Sans. 텍스트는 화면 모서리에 floating, 중앙은 시각화 전용.
- **텔레메트리 오버레이**: 좌상단 = 미션명·시작 시각, 우상단 = 현재 속도/거리/단계. 폰트 작게(12~14px), 반투명.
- **카메라**: 자동 회전 (0.1 rad/s) + 마우스 드래그로 manual override. 너무 빠르지 않게.
- **궤적선**: TubeGeometry 또는 Line2 (fat line), 발광(`emissive` + `emissiveIntensity`)로 빛나는 느낌.
- **포인트 라이트**: 궤적 따라가는 광원 1~2개, 거리 따라 intensity 변동.
상세 노트는 `references/ai-keynote-demo-aesthetics.md`.

**Pitfalls:**
- **정적 시각화 vs LLM 평가 혼동**: "Artemis Challenge", "GPT-X benchmark" 같은 키워드가 나와도 deliverable이 agent 평가 환경이 아닐 수 있음. `clarify`로 1차 분류 후 진행.
- **Vercel 스킬 이름 충돌**: `skill_view(name='vercel')`은 **ambiguous 에러**를 던진다 (devops 본 스킬 + archive 템플릿이 충돌). `skill_view(name='devops/vercel')` 처럼 카테고리 경로 명시. 이 skill 본문에서 `vercel`을 related-skill로 언급할 때도 `'devops/vercel'`로 표기.
- **빌드 명령 누락**: Vite 프로젝트는 `vercel.json`에 `buildCommand: "npm run build"`, `outputDirectory: "dist"` 필수. `canvas-static-site-pipeline` 기본 템플릿(plain HTML)은 빌드 명령 없음 — Vite로 가면 템플릿을 덮어쓴다.
- **CORS 우회 안 됨**: 런타임 fetch 패턴(B)에서 API가 CORS 막으면 백엔드 프록시 필요 → 정적 호스팅 불가. 가능하면 A 패턴 권장.
- **Vite prod JSON import는 minify된 채 inline됨** (2026-06-11 학습): `grep "mission" dist/assets/*.js` 같은 키 검색은 0. 대신 **데이터 패턴**(날짜, 숫자)으로 검증: `grep -c "2026-04-" dist/*.js` → inline 됐다면 644+ 같은 큰 숫자. 0이면 JSON이 external URL fetch로 빠진 것 → 코드에서 `fetch()`로 변경 필요.
- **Vercel 토큰 export 형태** (2026-06-11 학습): `vercel --token $(cat ~/.hermes/secrets/vercel_token.txt)` 한 줄이 가장 짧지만 subshell 안에선 변수 export가 필요. `export VERCEL_TOKEN=...; vercel --token $VERCEL_TOKEN` 패턴. 첫 배포 시 `vercel link --yes`로 프로젝트 연결 후 `vercel deploy --prod`가 안전.
- **`vercel project rm` 옵션 함정** (2026-06-11 학습): `--yes`, `--force`, `-f` 전부 **unknown option** 에러. 정답: `--non-interactive` + `printf "y\n" |` (single stdin). `yes y |`는 무한 stdin으로 60초+ hang. 옵션 확인은 `vercel project rm --help`로 (Global Options: `--non-interactive` 명시). cleanup script는 항상 timeout 또는 single-y stdin으로.
- **Vercel cleanup 후 alias 잔존**: project 삭제해도 alias (production 도메인)는 **자동 삭제되지 않음**. `vercel alias ls`로 잔존 확인 후 `vercel alias rm` 개별 처리. preview alias (UUID 포함된 `xxx-username.vercel.app`)는 보통 deploy와 함께 사라지지만 production alias는 명시적 제거 필요.
- **shell 명령에 `$()` + secret 환경변수 섞으면 break** (2026-06-11 학습): `export VERCEL_TOKEN=$(cat ~/.hermes/secrets/vercel_token.txt)` 같은 한 줄을 `terminal`/`patch`로 직접 실행하면 `(...)` 부분이 tool output 마스킹 단계에서 깨져서 `syntax error near unexpected token ')'` 에러. 해결: `write_file`로 `.sh` 스크립트 본문 전체를 먼저 쓰고 `chmod +x` → 실행. heredoc 안에서도 동일 문제 발생 — `.sh` 파일이 정답. `HOM...` 같은 환경변수는 write_file 결과도 마스킹되니 주의.

**갤러리 카드 구현 패턴 (정적 HTML):**
- 이미지 3개 고정 너비: `width: 33.33%` flex 레이아웃, 카드마다 이미지 수 동적 대응 필요 시 class based (`one/two/three`)
- **모달 이미지 뷰어**: 클릭 → `openModal(img)` → 카드 내 `.card-img-wrap`에서 전체 이미지 배열 추출 → 좌우 화살표(`navModal`), ESC 키 지원. `data-search` 속성에 검색 키워드 저장
- **접기/펼침 기능**: preview 텍스트만 HTML에 있으면 의미 없음 → 전체 텍스트를 `data-fulllyrics` 속성에 분리 저장 → 클릭 시 모달(`showLyrics`)로 표시. `data-fulllyrics` 없는 카드(가사 없음)는 토글 의미 없음

## related skills
- `devops/vercel` — Vercel 특화 작업 (환경변수, 로그, 프로젝트 관리). **반드시 카테고리 경로 명시** — bare name `'vercel'`은 ambiguous 에러 발생.
- `github/github-cli` — GitHub 저장소 관리
- `autonomous-ai-agents/opencode` — 코딩 에이전트 위임 (실패 시 이 파이프라인으로 폴백)
