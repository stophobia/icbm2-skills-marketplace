# CJK 한자 잔존 정리 + 호칭 통일 (2026-06-02)

## 배경

2026-06-02 세션에서 주인님께서 두 가지 교정을 내리셨다:

1. **호칭 통일**: "主人님" 같은 한자 혼용 → "**주인님**" (한글)
2. **Cron 산출물의 한자 정리**: "侯選", "전前" 같은 한자 잔존 → "후보", "전" (한글)

이전 세션에서 다른 에이전트가 생성한 SKILL.md와 cron 프롬프트에 한자가 잔존해 있었음. 본 레퍼런스는 정리 작업의 **정확한 매핑표**와 **재발 방지 규칙**을 기록한다.

## 한자 → 한글 매핑표

| 한자 | 위치 | 한글 |
|------|------|------|
| `侯選` (候補) | `侯選 전송`, `侯選 topic`, `侯選 목록` | `후보` |
| `前` (앞) | `전前`, `실행前` | `전` |
| `昨天` (어제) | `어제의 topics` 주석 | `어제` |
| `的` (의) | `主的人的`, `主人的 절대` | `의` |
| `禁止` (금지) | `수정禁止` | `금지` |
| `的` (격 조사) | `成功` 의 `的` | `의` |
| `侯選 END` 마커 | 스크립트 stdout | `후보 END` |
| `NOTEBOOKLM侯選` 마커 | 스크립트 stdout | `NOTEBOOKLM 후보` |

## 호칭 통일 규칙 (영구)

| 잘못된 표기 | 올바른 표기 |
|------------|------------|
| `主人님` | **`주인님`** |
| `主人` | `주인` |
| `主` 단독 사용 | 사용 금지 |

이 규칙은 **모든 산출물** (cron 출력, Telegram 메시지, 메모리, 스킬 본문, 로그)에 적용된다.
`USER.md` / `MEMORY.md`에 영구 저장되어 있음.

## Cron prompt에서 한자 제거 패턴

UTF-8 escape 형식으로 저장된 cron job (`~/.hermes/cron/jobs.json`)은
다음과 같이 직접 patch 한다:

```python
# \u4faf (侯) + \u9078 (選) → \ud6c4 (후) + \ubcf4 (보)
old_prompt_part = "NotebookLM\u4faf\u9078"
new_prompt_part = "NotebookLM\ud6c4\ubcf4"
```

`\u306b\u3088\u308b` 같은 일본어 한자 (`に よ る`, `由于`) 도
가끔 섞여 들어온다. 한국어 산출물에서는 무조건 한글로 치환.

## 재발 방지 (verify checklist)

cron prompt 또는 스크립트 stdout에 한자가 들어가지 않았는지 확인할 때:

```bash
python3 -c "
import json
with open('/Users/hjshin/.hermes/cron/jobs.json') as f:
    jobs = json.load(f)
for j in jobs['jobs']:
    text = json.dumps(j, ensure_ascii=False)
    cjk = [c for c in text if '\u4e00' <= c <= '\u9fff']
    if cjk:
        print(f'{j[\"name\"]}: {len(cjk)} 한자 잔존')
        from collections import Counter
        print('  ', Counter(cjk))
"
```

`counter == 0` 이 아니면 본 레퍼런스의 매핑표를 보고 patch.

## 일자별 정리 이력

| 날짜 | 정리한 파일 | 한자 → 한글 |
|------|------------|------------|
| 2026-06-02 | `cron/jobs.json` (dc9a2e6aaaaa) | `侯選`→`후보`, `前`→`전` |
| 2026-06-02 | `scripts/notebooklm_selection.py` | 마커 `NOTEBOOKLM侯選`→`NOTEBOOKLM 후보` |
| 2026-06-02 | `scripts/notebooklm_selection.py` 주석 | `昨天`→`어제`, `的`→`의`, `禁止`→`금지` |
| 2026-06-02 | `skills/automation/notebooklm-youtube-automation/references/source-correction-2026-05-21.md` | `主人的`→`주인님의` |
| 2026-06-02 | `skills/automation/music-video-generator/SKILL.md` | `不是选项`→`옵션이 아닙니다`, `主人的`→`주인님의` |
| 2026-06-02 | `skills/automation/dev-news-to-wiki/references/category-registration-guide.md` | `主人的`→`주인님의` |
| 2026-06-02 | `cron/output/81f1c81f8664/2026-05-31_*.md`, `dc9a2e6aaaaa/2026-05-27_*.md` | 과거 출력, 텔레그램 재방문 대비 정리 |
| 2026-06-02 | 본 SKILL.md | `侯選`, `时机`, `机`, `的`, `导致`, `成的`, `己`, `天`, `前`, `昨`, `禁`, `止`, `等`, `전`, `上`, `下`, `实`, `际`, `拍`, `错`, `误`, `时`, `关`, `联`, `解`, `决`, `输`, `入`, `入`, `续`, `多`, `波`, `语`, `步`, `处`, `理` (일본어/중국어 잔존) 전부 한글로 정리 |
