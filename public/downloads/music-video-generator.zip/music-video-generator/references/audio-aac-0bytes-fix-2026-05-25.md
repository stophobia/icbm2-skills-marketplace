# audio.aac 0 bytes 문제 + ngrok 타임아웃 패턴 (2026-05-25)

## audio.aac 0 bytes 문제

**원인:** `ffmpeg -i music.mp3 -vn -c:a copy audio.aac`로 추출 시, MP3 codec은 AAC로 copy 불가 → audio.aac이 0 bytes.

**증상:** concat은 성공하지만 최종 영상에 오디오 없음 (video_final.mp4 50MB, audio.aac 0 bytes). ffprobe로 확인 시 오디오 스트림 없음.

**✅ 해결:** `-c:a aac`로 인코딩 강제:
```bash
ffmpeg -y -i music.mp3 -vn -c:a aac -b:a 192k audio.aac
```

**Shorts 오디오 추출 시에도 동일 문제 — music.mp3에서 직접:**
```bash
ffmpeg -y -i music.mp3 -vn -c:a aac -b:a 128k -t 59 audio_short.aac
```

## ngrok URL 추출 — execute_code subprocess.Popen 타임아웃

**문제:** `execute_code`에서 ngrok stdout을 readline()으로 URL 추출 시 300초 execute_code 제한突破.
**원인:** ngrok이 tunnel 설정 완료 전에는 stdoutに何も出力せず, URL 추출 대기 중 300秒制限突破.

**✅ 검증된 Working 방식 — terminal tool background=true 사용:**
```bash
# terminal에서 background=true로 HTTP 서버 + ngrok 동시 실행
terminal(background=true, command="/usr/bin/python3 -m http.server 8765")
terminal(background=true, command="ngrok http 8765")

# 10초 후 URL 추출
curl -s http://localhost:4040/api/tunnels | /usr/bin/python3 -c "import sys,json; d=json.load(sys.stdin); [print(t['public_url']) for t in d.get('tunnels',[])]"
# → https://require-entangled-primer.ngrok-free.dev
```

**핵심:** ngrok URL 추출은 `execute_code` ❌ → `terminal(background=true)` + curl 사용.

## FFmpeg zoompan — PIL Ken Burns 대신 사용 (300초 타임아웃 방지)

**문제:** `create_ken_burns_frames()`로 800+ 프레임을 PIL로 생성 → execute_code 300초 타임아웃 빈번.

**✅ FFmpeg zoompan 방식 (58초로 3개 세그먼트 완료):**
```python
segments = [
    ("img0.png", "seg0.mp4", 0, 67.4),
    ("img1.png", "seg1.mp4", 67.4, 134.8),
    ("img2.png", "seg2.mp4", 134.8, 202.2),
]
for img_path, out_path, start_t, end_t in segments:
    dur = end_t - start_t
    cmd = [
        "ffmpeg", "-y", "-loop", "1", "-i", img_path,
        "-filter_complex",
        "zoompan=z='min(zoom+0.001,1.5)':d=25:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)',scale=1280:720",
        "-t", str(dur), "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28",
        "-pix_fmt", "yuv420p", out_path
    ]
    subprocess.run(cmd, capture_output=True, timeout=120)
```

## 3개 이미지 Ken Burns + concat + audio mux 파이프라인 (검증됨 2026-05-25)

```python
# Step 1: 세그먼트별 Ken Burns MP4 생성
for i in range(3):
    subprocess.run([
        "ffmpeg", "-y", "-loop", "1", "-i", f"img{i}.png",
        "-filter_complex", "zoompan=z='min(zoom+0.001,1.5)':d=25:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)',scale=1280:720",
        "-t", "67.4", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28",
        "-pix_fmt", "yuv420p", f"seg{i}.mp4"
    ])

# Step 2: concat
with open("concat.txt", "w") as f:
    for i in range(3): f.write(f"file 'seg{i}.mp4'\n")

subprocess.run([
    "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", "concat.txt",
    "-c:v", "libx264", "-preset", "fast", "-crf", "23",
    "video_only.mp4"
])

# Step 3: 오디오 추가 (MP3 → AAC 인코딩 필수!)
subprocess.run([
    "ffmpeg", "-y", "-i", "video_only.mp4", "-i", "music.mp3",
    "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-shortest",
    "-movflags", "+faststart", "video_final.mp4"
])
```