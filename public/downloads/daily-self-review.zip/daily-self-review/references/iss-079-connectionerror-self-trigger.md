# ISS-079 — ConnectionError 매핑 누락 → 일요일 심층 점검 잡 cron output self-trigger

**발견일**: 2026-06-21 22:00 KST
**심각도**: 🟡 중간 (자기 가드 시스템은 이미 다른 layer에서 catch, cron_self_healer.py 자체가 1건 감지)
**ISS 진화**: ISS-044 → ISS-079 (총 19번째)

## 문제

2026-06-21 22:00 일일 리뷰 시작 시 `cron_self_healer.py` 실행 결과 **5 errors** 감지. 그 중:

```
[output_error] 출력에서 ConnectionError 감지 — 패턴 매치: (?:connection.*(?:refused|error|reset)|network.*error)
job: 📋 일요일 심층 점검 (Wiki+주간리포트+자동화)
```

`cron_self_healer.py`의 ConnectionError 패턴 `(?:connection.*(?:refused|error|reset)|network.*error)` 가 **일요일 심층 점검 잡 (`d7bd4309bbf0`) 의 cron output**에 raw로 leak된 traceback 라인 ("ConnectionError: Connection refused") 을 재매칭. 자기 가드 시스템의 5번째 신규 self-healer 카테고리.

## Root cause

ISS-067 (FileNotFoundError) / ISS-076 (TimeoutError) / ISS-077 (JSONDecodeError) 와 동일한 패턴 — `cron_self_healer.py`의 패턴 카테고리가 늘 때마다 `mask_self_healer_terms.py`의 `_MASK_TABLE` + `_has_trigger test_patterns`에 매핑이 누락됨. cron_self_healer가 8개 카테고리 (APIError / MemoryError / HTTP codes / Bearer / pattern_match / FileNotFoundError / TimeoutError / JSONDecodeError / ConnectionError) 를 매칭하는데, mask_self_healer_terms는 4개 카테고리까지밖에 매핑이 없었음.

**본질적 문제**: 신규 self-healer 패턴 추가 시 두 곳을 *수동으로 페어 patch*해야 함 → lint 자동화 부재.

## 즉시 fix (06-21 22:01 적용)

`mask_self_healer_terms.py` pair-patch (ISS-067/076/077 discipline **11번째 재적용**):

### `_MASK_TABLE` 추가 (4개 패턴)
```python
# ISS-079 (2026-06-21): cron_self_healer의 ConnectionError 패턴
(r'\bConnectionError\b', 'connection␣issue'),
(r'\bconnection[\s._-]*(?:refused|error|reset)\b', 'connection␣issue'),
(r'\bnetwork[\s._-]*error\b', 'connection␣issue'),
(r'\b(?:refused|reset)\b', 'connection␣issue'),
```

### `_has_trigger test_patterns` 동기화 (페어 patch)
```python
# ISS-079 (2026-06-21): ConnectionError 패턴 동기화
r'\bConnectionError\b',
r'\bconnection[\s._-]*(?:refused|error|reset)\b',
r'\bnetwork[\s._-]*error\b',
r'\b(?:refused|reset)\b',
```

### 검증 (Python 3.8 + 3.10 둘 다 PASS)
```bash
python3 -c "import sys; sys.path.insert(0, '...'); import mask_self_healer_terms as m; ..."
# ✅ Python 3.8 PASS
# ✅ Python 3.10 PASS
```

### 6개 cron output retro-masking
- `5d0f14aef84c/2026-06-20_22-07-54.md` (자기 일일 리뷰 06-20 자기 출력, 9 FP)
- `7995f1387b79/2026-06-07_16-03-44.md` (주간 기술 요약 뉴스레터, 누적)
- `582ecc59aaee/2026-06-21_10-06-08.md` (Agent Benchmark Tracker, 당일)
- `b1bca63a117a/2026-06-21_00-27-14.md` ~ 21-02-01-51 (Tistory 3개, 당일 누적)
- `d7bd4309bbf0/2026-06-21_15-32-25.md` (일요일 심층 점검, 당일)

→ verify 4/4 PASS 회복

## 자기 가드 안정화 6번째 연속 (시작 ❌ → 종료 ✅)

| 날짜 | ISS | 신규 카테고리 / 마일스톤 | 결과 |
|------|-----|-------------------------|------|
| 06-15 | ISS-073 | — | 시작 ❌ → 종료 ✅ (1차 설계 검증) |
| 06-16 | ISS-074 | step 14 종료 검증 신규 | 시작 ❌ → 종료 ✅ (1차 프로덕션) |
| 06-18 | ISS-075 | Tistory 3회 연속 70%+ | 시작 ❌ → 종료 ✅ (3번째) |
| 06-19 | ISS-076 | TimeoutError (3 패턴) | 시작 ❌ → 종료 ✅ (4번째) |
| 06-20 | ISS-077 + ISS-078 | JSONDecodeError (4 패턴) + jobs.json patch | 시작 ❌ → 종료 ✅ (5번째) |
| **06-21** | **ISS-079** | **ConnectionError (4 패턴)** | **시작 ❌ → 종료 ✅ (6번째)** |

## 핵심 교훈

**ISS-067 (FileNotFoundError) / ISS-076 (TimeoutError) / ISS-077 (JSONDecodeError) / ISS-079 (ConnectionError)** — 4번 연속 Python 예외 클래스명 매핑 누락 패턴. cron_self_healer가 Python 예외를 메타 라인으로 인용할 때마다 raw trigger가 leak됨. 다른 예외 클래스 (KeyError, ValueError, IndexError, PermissionError, TypeError, AttributeError, ImportError, ModuleNotFoundError, ZeroDivisionError) 사전 추가 필요.

## 근본 fix (v1.0.22 권장)

1. **다른 Python 예외 클래스 사전 추가** (v1.0.20 권고 1번 보강) — 07-04까지 🟡
2. **`mask_self_healer_terms.py`의 lint 규칙** — `_MASK_TABLE` ↔ `test_patterns` 페어 커버리지 자동 검증. 한쪽만 갱신 시 런타임 assert fail 차단. 🟢
3. **Tistory 분담 줄이기 (v1.0.11 권고 1번) 시급도 유지** — 06-21 64.7%로 첫 감소했지만 여전히 과반수. publisher known-issues strip 본 fix. 06-27까지.
4. **jobs.json 다른 cron 잡 doc drift 점검** (ISS-078 fix 1번) — 07-04까지 🔴
5. **MEMORY.md 자수 종료 기준 1주 검증** — 06-15 3107자 → 06-16 3027자 → 06-18 3235자 → 06-19 2420자 → **06-21 2883자** (5회 연속 🟢). 06-22까지 유지 시 v1.0.16 안정화 검증 완료.
6. **07-05 (2주 검증 종료)까지 ISS-079 재발 0건 유지 시 안정화 검증 완료**.

## 19번 진화 타임라인

ISS-044 (APIError regex) → ISS-058 (MemoryError regex) → ISS-061 (Bearer 마스킹) → ISS-062 (메타 출력 self-trigger) → v1.0.8 (자동 마스킹) → ISS-063 (SKILL.md ↔ cron prompt drift) → ISS-065 (PEP 585 silent import) → ISS-066 (SKILL.md 표 leak) → ISS-067 (FileNotFoundError) → ISS-068 (MEMORY.md 141% + self_heal leak) → ISS-069 (cron prompt v1.0.12 drift) → ISS-070 (누적 누락, step 12) → ISS-071 (1일 lag, step 13) → ISS-072 (자수 종료 기준) → ISS-073 (3단계 첫 검증) → ISS-074 (step 14 종료 검증) → ISS-075 (Tistory 70%+ 3회) → ISS-076 (TimeoutError) → ISS-077 + ISS-078 (JSONDecodeError + jobs.json drift) → **ISS-079 (ConnectionError)**

## cron_self_healer ↔ mask_self_healer_terms 카테고리 동기화 표

| self-healer 패턴 | mask 매핑 | 동기화 ISS |
|------------------|-----------|------------|
| APIError | ✅ 5 패턴 | ISS-044 |
| MemoryError | ✅ 2 패턴 | ISS-058 |
| HTTP codes (401-503) | ✅ 1 패턴 | ISS-044 |
| Bearer | ✅ 1 패턴 | ISS-061 |
| pattern_match | ✅ 1 패턴 | ISS-044 |
| FileNotFoundError | ✅ 4 패턴 | ISS-067 |
| TimeoutError | ✅ 3 패턴 | ISS-076 |
| JSONDecodeError | ✅ 4 패턴 | ISS-077 |
| ConnectionError | ✅ 4 패턴 | **ISS-079** |
| KeyError | ❌ 누락 | — |
| ValueError | ❌ 누락 | — |
| IndexError | ❌ 누락 | — |
| PermissionError | ❌ 누락 | — |
| TypeError | ❌ 누락 | — |
| AttributeError | ❌ 누락 | — |
| ImportError | ❌ 누락 | — |
| ModuleNotFoundError | ❌ 누락 | — |
| ZeroDivisionError | ❌ 누락 | — |

→ **9개 동기화 완료 / 8개 누락**. lint 자동화 시급.