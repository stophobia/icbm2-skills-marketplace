"""
Kiwi Companion - TTS Module (template)
"""
import os
import shutil
import subprocess
import threading
from typing import Optional

try:
    import pyttsx3
    PYTTSX3_AVAILABLE = True
except ImportError:
    PYTTSX3_AVAILABLE = False


# 한국어 보이스 우선순위: Yuna > Kyung > 기타 ko-KR
_KOREAN_PREFERENCE_KEYS = ("yuna", "kyung", "ko-kr.yuna", "ko_kr.yuna", "korean")


def _find_korean_voice(engine) -> Optional[object]:
    for keyword in _KOREAN_PREFERENCE_KEYS:
        for v in engine.getProperty("voices"):
            name = (getattr(v, "name", "") or "").lower()
            vid = (getattr(v, "id", "") or "").lower()
            if keyword == "yuna":
                if name == "yuna" or vid.endswith(".yuna") or "ko-kr.yuna" in vid:
                    return v
            elif keyword in name or keyword in vid:
                return v
    for v in engine.getProperty("voices"):
        for lang in getattr(v, "languages", []) or []:
            if "ko" in str(lang).lower():
                return v
    return None


class KiwiSpeaker:
    def __init__(self, rate: int = 180, volume: float = 1.0):
        self.rate = rate
        self.volume = volume
        self.engine = None
        self.voice_id = None
        self.backend = "none"
        self._lock = threading.Lock()

        if PYTTSX3_AVAILABLE:
            try:
                self.engine = pyttsx3.init()
                self.engine.setProperty("rate", rate)
                self.engine.setProperty("volume", volume)
                voice = _find_korean_voice(self.engine)
                if voice:
                    self.voice_id = voice.id
                    self.engine.setProperty("voice", voice.id)
                    self.backend = "pyttsx3+nsspeech-ko"
                else:
                    self.backend = "pyttsx3+nsspeech-default"
            except Exception as e:
                print(f"[TTS] pyttsx3 초기화 실패: {e}")
                self.engine = None

    def say(self, text: str, blocking: bool = False):
        if not text:
            return
        if self.engine is None:
            self._say_fallback(text, blocking)
            return
        with self._lock:
            try:
                self.engine.say(text)
                if blocking:
                    self.engine.runAndWait()
                else:
                    threading.Thread(target=self._run_and_wait_safe, daemon=True).start()
            except Exception as e:
                print(f"[TTS] 발화 실패, 폴백: {e}")
                self._say_fallback(text, blocking)

    def _run_and_wait_safe(self):
        with self._lock:
            try:
                self.engine.runAndWait()
            except Exception:
                pass

    def _say_fallback(self, text: str, blocking: bool):
        say_bin = shutil.which("say")
        if not say_bin:
            print(f"[키위(텍스트만)] {text}")
            return
        for voice in ["Yuna", "Kyung", ""]:
            cmd = [say_bin]
            if voice:
                cmd += ["-v", voice]
            cmd.append(text)
            try:
                if blocking:
                    subprocess.run(cmd, check=True, timeout=60)
                else:
                    subprocess.Popen(cmd)
                return
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                continue
        print(f"[키위(폴백 실패)] {text}")

    def stop(self):
        with self._lock:
            if self.engine:
                try:
                    self.engine.stop()
                except Exception:
                    pass

    def describe(self) -> str:
        return f"backend={self.backend}, voice_id={self.voice_id or 'default'}, rate={self.rate}"


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("사용법: python3 tts.py '안녕하세요'")
        sys.exit(1)
    text = " ".join(sys.argv[1:])
    speaker = KiwiSpeaker()
    print(f"[TTS] {speaker.describe()}")
    print(f"[발화] {text}")
    speaker.say(text, blocking=True)
    print("[완료]")
