---
name: tistory-publisher
description: Tistory 블로그 자동 발행 — 쿠키 기반 내부 API를 사용하여 글 작성/발행
version: "1.8.16"
last_updated: "2026-06-08-85th-cron"
references:
  - known-issues.md
  - cjk-dictionary-75.md
  - korean-text-corruption-patterns.md
  - cjk-loop-residuals-1-75.md
  - quality-gate-false-positives.md
  - session-20260524.md
  - session-20260525.md
  - cjk-70th-batch.md
  - cjk-71st-batch.md
  - cjk-72nd-batch.md
  - cjk-74th-batch.md
  - session-20260529.md
  - session-20260529-75th.md
  - cjk-prevention-checklist.md
  - session-20260530.md
  - cjk-77th-batch.md
  - cjk-78th-batch.md
  - execute_code-cron-blocked.md
  - session-20260601.md
  - cjk-79th-batch.md
  - session-20260602.md
  - cjk-80th-batch.md
  - cjk-81st-batch.md
  - cron-mode-constraints.md
  - zero-cjk-pattern.md
  - session-20260603.md
  - session-20260604.md
  - image-auto-insert-policy-conflict.md
  - session-20260607.md
  - session-20260608.md
  - session-20260608-84th.md
---

# Tistory 자동 발행 스킬

## ⚠️ Known Issues

### 🔴 이미지 + 개행 누락 문제 (2개월 이상 미해결)
**Symptom:** 발행된 블로그 글에 이미지가 표시되지 않고, 개행(line break)이 완전히 사라짐.
**First reported:** 2026-04-20 21시 발행 글
**Status:** 미해결 (learning-gap-tracker 등록됨, 우선순위 high)
**Root cause:** 未特定 — `tistory_publisher.py`의 HTML 생성 로직 분석 필요

### 🟡 Korean word boundary corruption (2026-05-23, 70차 및 2026-05-26, 72차)
CJK 정제 시 Chinese 복합어가 포함된 Korean 문장이 점진적으로 파괴됨. `references/korean-text-corruption-patterns.md` 및 `references/cjk-72nd-batch.md` 참조.

**72차 신규 패턴:** "很有意思하다" → "有意思하다" → "하다." (순차 문자 제거). Chinese 복합어 "很有意思"의 개별 문자(很/有/意/思)가 CJK cleaning dict로 순차 제거되어 문장이 파괴됨. 예방: CJK cleaning 전 preemptive Chinese → Korean 교체 실행.

### 🟡 markdown_to_tistory_html.py 제목 인식 문제 (2026-05-22)
`blog_quality_gate.py --file`가 H1을 제목으로 오인. `--title` CLI로 별도 전달. **2026-06-08 84차 확인:** `--file`만 단독 사용 시 `{"error": "title_and_content_required"}` 에러 반환. 반드시 `--title` 명시.

### 🟡 blog_pipeline.py --record 시그니처 분쟁 (2026-06-08 84차 발견)
세션 메모 일부가 4인자(`--record TOPIC TITLE URL TOPIC_URL`)로 적혀 있으나, 84차 실전 검증에서 **3인자(`--record TOPIC TITLE URL`)**가 정상 동작함. `python3 ~/.hermes/scripts/blog_pipeline.py --help`로 현재 시그니처 재확인 후 사용할 것. `published_urls.txt` 갱신 여부는 3인자로도 정상 처리됨.

### 🟡 rm -rf 후 cwd 소실로 git 명령 실패 (2026-06-08 84차 발견)
**Symptom:** Step 7에서 `rm -rf /tmp/blog-images-repo && git clone ...`를 cron 모드(작업 디렉터리 = `~/.hermes/hermes-agent` 등)에서 실행하면, `rm -rf`가 현재 작업 디렉터리를 지워서 `fatal: Unable to read current working directory: getcwd: cannot access parent directories: No such file or directory` 에러 발생. 후속 `cd /tmp/blog-images-repo`도 실패.
**원인:** heredoc/파이프 없이 한 줄에 `rm -rf` + 다른 명령 결합 시 bash가 첫 명령의 부작용으로 cwd를 잃음.
**해결:** 각 git/rm 명령을 `workdir=/tmp` 또는 `workdir=/tmp/blog-images-repo`로 분리 호출 (terminal 도구 `workdir` 파라미터 사용). `cd /tmp && rm -rf ... && git clone ...`도 cwd 변경에 의존하므로 신뢰도 낮음. **terminal 도구에서는 `workdir`을 명시적으로 지정하는 것이 가장 안전.**

---

## 개요

Tistory 공식 Open API가 종료된 후, 브라우저 내부 API를 사용하여 Python으로 블로그 글을 자동 발행합니다.

## cron 모드 표준 워크플로우 (84차 검증, 14단계)

`execute_code`는 cron 모드에서 차단됨 (`references/cron-mode-constraints.md` 참조). 아래 14단계는 **모두 `terminal` 도구 + `python3 -c "..."` heredoc**으로만 실행해야 한다.

1. `python3 ~/.hermes/scripts/blog_pipeline.py` (terminal) → JSON에서 `selected_topic` 확인
2. `mcp_ddg_search_fetch_content URL` → 긱뉴스 본문 수집 (DDG 검색 0 results 시 즉시 폴백, 본문만으로 진행)
3. `write_file /tmp/blog_post.md` → 한국어 Markdown 초안 (CJK 사전 삽입 금지)
4. `python3 -c "import re... [\u4e00-\u9fff] 검사"` (terminal) → Markdown CJK 1차 검사
5. `python3 ~/.hermes/scripts/markdown_to_tistory_html.py /tmp/blog_post.md /tmp/blog_tistory.html` (terminal)
6. `python3 -c "...clean_cjk 루프..."` (terminal) → HTML CJK cleaning
7. `rm -rf /tmp/blog-images-repo && git clone https://github.com/sigco3111/blog-images.git /tmp/blog-images-repo` (terminal, `workdir=/tmp` 명시)
8. `curl -sL "https://picsum.photos/seed/{키워드}/800/400" -o /tmp/blog-images-repo/2026MMDD-{키워드}-{해시}.jpg` (terminal, `workdir=/tmp/blog-images-repo`)
9. `cd /tmp/blog-images-repo && git add && git commit && git push origin main` (terminal, `workdir=/tmp/blog-images-repo`)
10. `python3 -c "...figure 커버 삽입..."` (terminal) → HTML `<h1` 앞에 cover figure 삽입
11. `python3 ~/.hermes/scripts/blog_quality_gate.py --title "제목" --file /tmp/blog_tistory.html --tags "..." --category "개발도구"` (terminal) → A 등급 확인
12. `python3 ~/.hermes/scripts/tistory_publisher.py --title "제목" --content "$(cat /tmp/blog_tistory.html)" --tags "..." --visibility public --category 1219748` (terminal) → 발행
13. `python3 ~/.hermes/scripts/blog_pipeline.py --record "주제" "발행된 제목" "발행 URL"` (terminal) → 중복 방지 기록
14. `rm -f /tmp/blog_post.md /tmp/blog_tistory.html` (terminal) → 임시 파일 정리

## 사전 요구사항

- Tistory 블로그 계정
- 쿠키 파일: `$TISTORY_COOKIE_PATH` (예: `secrets/tistory.env`)
- Python requests 라이브러리

## 쿠키 획득 방법

1. Chrome에서 https://www.tistory.com 로그인
2. 브라우저에서 글쓰기 후 [발행] 클릭
3. F12 → Network 탭 → "로그 유지" 체크
4. `post.json` 요청 우클릭 → Copy → Copy as cURL
5. 쿠키 값 추출 후 `$TISTORY_COOKIE_PATH`에 저장

### 쿠키 필드

| 쿠키 | 환경변수명 | 설명 |
|------|-----------|------|
| REACTION_GUEST | TISTORY_REACTION_GUEST | 게스트 토큰 |
| \_\_T\_ | TISTORY\_\_\_T\_ | 로그인 플래그 |
| \_\_T\_SECURE | TISTORY\_\_\_T\_SECURE | 보안 플래그 |
| TSSESSION | TISTORY_TSSESSION | 세션 ID |
| \_T\_ANO | TISTORY\_\_T\_ANO | 인증 토큰 (주기적 갱신 필요) |

⚠️ **\_T\_ANO 쿠키는 시간이 지나면 만료됩니다.** 발행 실패 시 다시 쿠키를 갱신하세요.

## API 명세

### 글 발행

```
POST https://{blog}.tistory.com/manage/post.json
Content-Type: application/json
Cookie: REACTION_GUEST=...; __T_=1; __T_SECURE=1; TSSESSION=...; _T_ANO=...
```

### 요청 본문 (JSON)

```json
{
  "id": "0",
  "title": "글 제목",
  "content": "<p data-ke-size=\"size16\">HTML 본문</p>",
  "slogan": "",
  "visibility": 0,
  "category": 0,
  "tag": "태그1,태그2",
  "published": 1,
  "password": "8자리문자",
  "uselessMarginForEntry": 1,
  "cclCommercial": 0,
  "cclDerive": 0,
  "type": "post",
  "attachments": [],
  "recaptchaValue": "",
  "draftSequence": null
}
```

### 응답

성공:
```json
{"entryUrl": "https://blog.tistory.com/123"}
```

실패:
```json
{"data": null, "message": "에러 메시지"}
```

### 파라미터 설명

| 파라미터 | 설명 | 값 |
|----------|------|-----|
| id | "0"=신규, 기존 ID=수정 | string |
| visibility | 공개 범위 | 20=공개, 0=비공개 (2026-04-08 검증) |
| category | 카테고리 ID | 0=카테고리 없음 |
| published | 발행 여부 | 1=발행, 0=임시저장 |
| type | 글 타입 | "post" 또는 "page" |
| password | 랜덤 8자리 | md5 해시 일부 |
| uselessMarginForEntry | 여백 설정 | 1 (고정) |

### 이미지 업로드

```
POST https://{blog}.tistory.com/manage/post/attach.json
Content-Type: multipart/form-data
Cookie: (same as post endpoint)
```

요청: `file` 필드에 이미지 파일 전송

응답:
```json
{"name":"image.jpg", "url":"https://blog.kakaocdn.net/dna/...", "key":"...", "filename":"img.jpg", "size":12345}
```

### 이미지 삽입 (GitHub 호스팅)

Tistory CDN 업로드(`attach.json`)는 불안정하므로 사용하지 마라. **GitHub 저장소를 이미지 호스팅**으로 사용한다.

**이미지 저장소:** `sigco3111/blog-images` (public)
**로컬 클론:** `/tmp/blog-images-repo/`

**이미지 추가 방법:**
```bash
cd /tmp/blog-images-repo && git pull
cp /path/to/image.jpg /tmp/blog-images-repo/{이름}.jpg
cd /tmp/blog-images-repo && git add {이름}.jpg && git commit -m "Add {이름}" && git push origin main
```

**GitHub raw URL 형식:**
```
https://raw.githubusercontent.com/sigco3111/blog-images/main/{filename}
```

**HTML 삽입:**
```html
<figure data-ke-type="image" data-ke-style="alignCenter">
  <img src="https://raw.githubusercontent.com/sigco3111/blog-images/main/{filename}"/>
  <figcaption>캡션 텍스트</figcaption>
</figure>
```

### 기타 API

| 엔드포인트 | 설명 |
|-----------|------|
| GET /manage/posts.json?category=-3&page=1 | 글 목록 |
| GET /manage/category.json | 카테고리 목록 |
| GET /manage/post/{id}.json | 글 상세 (수정 시) |
