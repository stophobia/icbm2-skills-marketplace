# 2026-06-02 Decommission 실행 — 뮤직비디오 + 공개데이터포탈

## 배경

주인님이 "뮤직비디오는 이제 안할 거니까 제거", "공개데이터포탈도 안할 거니까 메모리와 스킬 등 모든 것을 제거"로 명시적 폐기 지시.

## 자산 식별

### 1. 뮤직비디오 자동화
- 스크립트 2개: `music_video_producer.py` (851줄), `music_video_review.py`
- 출력 폴더: `~/.hermes/music_videos/` (112개 파일, 909KB)
- 크론 잡: 이미 5/25 ngrok 전환 시 cron 자동 업로드 중단 — 등록된 전용 크론 없음
- 시크릿: 없음
- 스킬 폴더: `music-video-generator` 폴더가 `skills/automation/music-video-generator/`에 존재했음 (이전 정리에서 못 봤던 자산)

### 2. 공개데이터포탈
- 스크립트: `apikey_holiday_monitor.py`
- 시크릿 2개: `datagokr_expiry_20280514.txt`, `datagokr_key.txt`
- 크론 잡 1개: `8b859449c91d` (API Key 만료 감시, 09:00)

## 실행 흐름

### 사용자 선택지
clarify 도구로 "음악/영상 파일을 어떻게 할지" 물음 → "영구 삭제 (rm)" 선택

### 실행 순서 (시크릿 trash vs 코드 rm 분리)
1. **MEMORY.md** — 두 섹션("뮤직비디오 자동화", "공개데이터포탈") + "숏츠 변환 절대 금지" 항목 제거
2. **자동화 성과 섹션의 뮤직비디오 이슈 1줄** 별도 제거
3. **크론 잡 1개** remove (`8b859449c91d`)
4. **스크립트 3개** `rm -f` (영구 삭제)
5. **시크릿 2개** `trash` (복구 가능성 유지)
6. **출력 폴더** `rm -rf` (영구 삭제)

## 교훈 (스킬에 반영됨)

### 1. 의존성 vs 키워드 매칭
- "숏츠 변환 절대 금지" 항목을 키워드 '뮤직비디오'로 묶어 제거 → YouTube Shorts 워크플로우의 핵심 규칙이 사라짐
- 주인님이 정확히 짚어줘서 복구
- → `memory-hygiene`, `automation-decommission` SKILL.md에 "의존성 우선 판단" 절차 추가

### 2. 진짜 MEMORY.md 식별 실패
- 시스템 프롬프트의 "MEMORY (98% 가득)" 메모를 보고 `memories/MEMORY.md`를 정리 → 정작 사용 중인 건 `~/.hermes/MEMORY.md` (root)
- 3건 잘못 적용 후 사용자가 "1번"으로 진짜 소스 지정
- → `memory-hygiene` SKILL.md 1단계에 "두 개 이상 MEMORY.md가 있으면 진짜 소스 식별" 절차가 이미 있음 (이번 사고로 더 강화됨)

### 3. 시크릿 trash vs 코드 rm 분리
- `automation-decommission` SKILL.md에 이미 반영되어 있던 원칙을 실제로 적용
- 사용자 옵션에 "영구 삭제"가 있어도 시크릿은 trash로 안전하게

## MEMORY.md 변화

| 단계 | 크기 |
|------|------|
| 시작 | 8,964B |
| 1차 정리 (G/J/K) | 7,668B |
| 뮤직비디오+데이터포탈 제거 | 4,259B |
| 숏츠 항목 복구 | 4,606B |
| 2차 정리 (Q/R/S/T/U) | 3,854B |

**총 변화: 8,964B → 3,854B (−57%)**
