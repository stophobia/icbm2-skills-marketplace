---
name: remote-file-delivery
description: "PC 없는 사용자에게 로컬 파일(음악, 영상, PDF 등)을 외부에서 접근 가능한 임시 URL로 전달. MEDIA 태그가 동작 안 하거나 모바일/원격에서 파일을 들어야 할 때 발동. ngrok 기반."
version: 1.0.0
metadata:
  hermes:
    tags: [ngrok, file-sharing, http-server, telegram, remote-access, url]
    related_skills: [ai-music-generation, video-editing]
---

# Remote File Delivery via ngrok

## Overview

로컬 macOS에서 생성한 파일을 **외부에서 임시로 다운로드/스트리밍**할 수 있게 만드는 워크플로우.

**사용 시점:**
- `MEDIA:/path/to/file` 태그가 텔레그램에서 텍스트로만 출력될 때
- 사용자가 PC 앞에 없을 때 (모바일, 외부, 다른 기기)
- 파일이 너무 커서 텔레그램 첨부 한도(50MB) 근처일 때
- 빠른 미리듣기/미리보기가 필요할 때

**주의**: ngrok 무료 플랜은 트래픽 inspect 경고를 한 번 거쳐야 함 (브라우저 "Visit Site" 클릭).

## Workflow (3단계)

### Step 1: 로컬 HTTP 서버 시작

```bash
cd <파일이 있는 디렉토리>
python3 -m http.server 8080 &
```

`8080` 포트가 비어있지 않으면 다른 포트 (`8081`, `8888` 등).

### Step 2: ngrok 터널 시작

```bash
ngrok http 8080 &
```

ngrok은 백그라운드 데몬으로 작동. API로 터널 URL 확인:
```bash
curl -s http://127.0.0.1:4040/api/tunnels
```

응답에서 `public_url` 필드 = 외부 접근 URL. 예: `https://xxx-yyy-zzz.ngrok-free.dev`

### Step 3: URL 전달 + 정리

**전달할 때 메시지 형태:**
```
🎧 외부에서 들을 수 있는 임시 링크입니다:
- 30초 미리듣기: https://xxx-yyy-zzz.ngrok-free.dev/preview.mp3
- 전체 파일: https://xxx-yyy-zzz.ngrok-free.dev/full.mp3

⚠️ 첫 접속 시 "Visit Site" 클릭 (ngrok 경고 페이지)
```

**세션 종료 전 정리 (반드시!):**
```bash
# ngrok 프로세스 종료
pkill -f "ngrok http"

# HTTP 서버 종료
pkill -f "http.server 8080"
```

## Pitfalls

### 1. 한글 파일명 URL 인코딩 404

HTTP 서버가 한글 파일명에 대해 404 응답하는 경우 많음. **ASCII 심볼릭 링크로 우회**:

```bash
# 원본
/Users/hjshin/Music/ai-ballad-workspace/audio/오늘도_잘했어_v2.mp3

# ASCII 별칭 만들기
ln -sf "오늘도_잘했어_v2.mp3" "preview_v2_full.mp3"
```

심볼릭 링크는 같은 디렉토리에 두고, ASCII 이름으로 접근.

### 2. 큰 파일은 미리듣기 30초 클립 권장

```bash
# mp3 미리듣기 (Telegram 음성 메시지 호환)
ffmpeg -y -i original.mp3 -ss 0 -t 30 -c:a libmp3lame -b:a 96k -ac 1 -ar 22050 preview.mp3

# mp4 영상 미리듣기 (원본 16:9 → 720p, 30초)
ffmpeg -y -i original.mp4 -ss 0 -t 30 -vf scale=1280:720 -c:v libx264 -preset fast -crf 23 -c:a aac -b:a 128k preview.mp4
```

30초면 사용자가 분위기 파악 가능. 마음에 들면 전체 파일로 다시 접속.

### 3. MEDIA 태그가 텍스트로만 출력될 때

텔레그램 채널에서 `MEDIA:/path/to/file`이 그냥 텍스트로 보이는 경우:
- 프롬프트 컨텍스트에 따라 자동 인식 안 될 수 있음
- **ngrok URL로 항상 우회 가능** — 이게 가장 확실

### 4. ngrok 무료 플랜 트래픽

- 1GB/월 무료
- 동시 접속 1개로 제한 (free)
- 트래픽 inspect 경고 (사용자가 "Visit Site" 클릭해야 함)
- 영구 URL은 유료 ($8/월)

**단발성 전달** 용도로는 무료로 충분.

### 5. ngrok 인증 토큰

최초 1회 등록:
```bash
ngrok config add-authtoken <TOKEN>
```

미등록 시 8시간짜리 임시 도메인만 발급. 정식 도메인 받으려면 무료 가입 후 토큰 등록.

### 6. 동시에 여러 파일 전달

같은 HTTP 서버 + ngrok 터널에서 여러 파일 동시 제공:
```bash
ln -sf file1.mp3 alias1.mp3
ln -sf file2.mp3 alias2.mp3
ln -sf "원본 한글.mp3" alias3.mp3
```

URL에 `alias1.mp3`, `alias2.mp3`, `alias3.mp3` 으로 각각 접근 가능.

## Verification

```bash
# 로컬에서 정상 응답 확인
curl -s -o /dev/null -w "HTTP %{http_code} (size=%{size_download})\n" http://127.0.0.1:8080/preview.mp3

# 200 OK, size가 파일 크기와 일치 → 정상
# 404 → 파일 경로 오류 또는 한글 URL 인코딩 문제
```

## 정리 명령 (세션 종료 시)

```bash
pkill -f "ngrok http"
pkill -f "http.server 8080"
# 또는 PID 직접 종료
# kill <ngrok_pid>
# kill <python_pid>
```

확인: `lsof -i :8080` 으로 점유 프로세스 확인 가능.

## Related Skills

- `ai-music-generation` — 음악 생성 후 외부 전달 시 함께 사용
- `video-editing` — 영상 편집 후 외부 전달 시 함께 사용
