---
name: api-key-manager
description: API Key的生命주기 관리 — 발급, 파일 저장, 만료 감시, Telegram 알림까지 Entire 파이프라인. 공공데이터포털(data.go.kr) 키 관리에 특화.
version: 1.1.0
author: ICBM2
metadata:
  hermes:
    tags: [Automation, API, Secret, Expiry, Monitoring]
  created: 2026-05-14
---

# API Key Manager 스킬

## 개요

외부 API Key를 체계적으로 관리하고, 만료일을 추적하며 자동 알림을 주는 파이프라인.

**주 사용처:**
- 공공데이터포털 (data.go.kr) API 키
- 다른 외부 API 키들도 동일한 패턴 적용 가능

## 파일 명명 규약 (Naming Convention)

```
~/.hermes/secrets/
  {platform}_expiry_YYYYMMDD.txt    ← 만료일 관리 대상 키 (7일 전 알림)
  {platform}_key.txt               ← 만료일 없는 일반 키 (감시 안 함)
  {platform}_token.txt             ← 통합 토큰 (Notion, Slack, GitHub 등) — liveness probe 필요
```

**`{platform}_expiry_YYYYMMDD.txt` 파일 규칙:**
- 파일명: `{플랫폼명}_expiry_{만료일(YYYYMMDD)}.txt`
- 내용: API Key 원본 (첫 줄만 또는 `KEY=값` 형태)
- 예: `datagokr_expiry_20280514.txt` → 만료일 2028-05-14

**`{platform}_key.txt` 파일 규칙:**
- 만료일 없는 일반 키 파일
- 스크립트가 자동 감지하지만 만료 알림은 보내지 않음

**`{platform}_token.txt` 파일 규칙 (통합 토큰):**
- Notion Integration, Slack Bot, GitHub PAT, OpenAI/Anthropic API key 등
- **발급 시점에 만료일을 알 수 없는 토큰** — workspace 측에서 silent revoke 가능
- 만료일 추적 대신 **liveness probe** (e.g. `/v1/users/me` for Notion)로 방어
- probe 실패 시 status file fallback + Telegram 알림 패턴: `weekly-automation-report/templates/notion_preflight.py` 참조

## 모니터링 스크립트

**스크립트:** `~/.hermes/scripts/apikey_holiday_monitor.py`

```bash
# Key 만료 체크 (7일 전부터 매일 알림)
python3 ~/.hermes/scripts/apikey_holiday_monitor.py --check-expiry

# 공휴일/연휴 조회 (14일 내)
python3 ~/.hermes/scripts/apikey_holiday_monitor.py --holidays current
python3 ~/.hermes/scripts/apikey_holiday_monitor.py --holidays 2026 12
```

**liveness probe는 별도 패턴** — 위 스크립트는 날짜 기반 만료 감시만 수행. 통합 토큰
(특히 Notion)의 silent revoke는 probe-based 모니터링이 필수. 예시: 매주 weekly
report cron이 `weekly-automation-report/templates/notion_preflight.py`로 검증.

## 크론 잡 설정

| 시간 | 작업 | 설명 |
|------|------|------|
| 09:00 | `--check-expiry` | Key 만료 7일 전부터 매일 알림 |
| 10:00 | `--holidays current` | 14일 내 공휴일/연휴 알림 |
| 매주 일요일 | weekly cron → `notion_preflight.py` | Notion 통합 토큰 liveness probe (weekly-automation-report 연동) |

## 새 키 추가 절차

1. **발급 받기** → 공공데이터포털에서 API Key 발급
2. **파일 저장** → 만료일 포함 파일명 사용
   ```bash
   echo "API_KEY_값" > ~/.hermes/secrets/{platform}_expiry_YYYYMMDD.txt
   ```
3. **즉시 검증** → 만료일 포함되었는지 확인
   ```bash
   python3 ~/.hermes/scripts/apikey_holiday_monitor.py --check-expiry
   ```

## 통합 토큰 추가 절차 (만료일 미고지, e.g. Notion)

1. **발급 받기** → Notion workspace Settings → Connections → Create integration
2. **파일 저장** → `_token.txt` 접미사
   ```bash
   echo "ntn_..." > ~/.hermes/secrets/notion_token.txt
   ```
3. **즉시 liveness probe** → 인증 거부되면 의미 없는 키
   ```bash
   TK=$(cat ~/.hermes/secrets/notion_token.txt)
   curl -s https://api.notion.com/v1/users/me -H "Authorization: Bearer *** -H "Notion-Version: 2022-06-28" | grep -q '"object": "user"'
   ```
4. **probe 결과 false → 즉시 rotation** (workspace 측 revoke 가능성)
5. **liveness probe 스케줄 등록** — `weekly-automation-report` 같은 정기 워크플로우에 probe 단계 추가

## ⚠️ data.go.kr API Quirks

[data.go.kr API 특징과 한계](references/datagokr-api-quirks.md)를 반드시 참조할 것.

## Telegram 알림 설정

환경 변수 `TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID` 설정 시 텔레그램으로 직접 전송.
미설정 시 stdout만 출력 (크론 로그에서 확인).

```bash
# Telegram 설정 확인
echo "TOKEN: ${TELEGRAM_BOT_TOKEN:-(not set)}"
echo "CHAT: ${TELEGRAM_CHAT_ID:-(not set)}"
```

## Pitfalls

- **Python global 변수 문제:** `DATAGOKR_KEY` 같은 모듈 전역 변수는 함수 안에서 `global` 선언 필수. 안 하면 `UnboundLocalError` 발생 (2026-05-14 버그 history)
- **http vs https:** 공공데이터포털 API는 `https://` 필수. `http://`는 타임아웃
- **만료일 형식:** YYYYMMDD 8자리. YYYY-MM-DD 형식 불가
- **파일 존재 ≠ 토큰 유효:** Notion Integration Token이 silent revoke되면 파일은 존재하지만 401 반환. 매 probe 필수. 2026-06-07 incident: weekly cron이 6주 연속 silent failure했다가 우연히 발견됨.
- **integration revoke는 user에게 통보되지 않음** — Notion은 workspace owner가 integration을 삭제해도 consumer에게는 알림 없음. liveness probe가 유일한 defense.
- **weekly-automation-report 스킬과 강하게 결합** — probe 패턴이 그쪽에 있음 (`templates/notion_preflight.py`). 이 스킬은 메타데이터/추적만, 실제 probe 구현은 weekly-automation-report 참조.
