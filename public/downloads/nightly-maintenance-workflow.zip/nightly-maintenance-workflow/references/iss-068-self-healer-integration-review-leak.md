_content># ISS-068 — Self-Healer FP 5번째 메타 트랩: 심야통합점검 자기 리포트 leak (2026-06-13 등록)

## 요약

**발견일:** 2026-06-13 03:30 KST
**상태:** 🟡 진행중
**심각도:** 🟡 경고
**등록 근거:** SKILL.md "메모리 업데이트 규칙" 3회 반복 임계 도달
**관련:** ISS-062/063/065/066/067 — Self-Healer FP 메타 트랩 시리즈 5번째

## 누적 카운트

| 날짜 | FP 에러 수 | 누적 | 임계 | 매칭 잡 |
|------|----------|------|------|---------|
| 06-10 03:30 | 2 | 1회 | 1/3 | b1bca63a117a Tistory |
| 06-12 03:30 | 2 | 2회 | 2/3 | 5d0f14aef84c + b1bca63a117a |
| 06-13 03:30 | 2 | 3회 | **3/3 → 등록** ✅ | 5d0f14aef84c + 81f1c81f8664 |

## 06-13 03:31 매칭 디테일

### 잡 1: `5d0f14aef84c` (일일 자기 개선 리뷰) — TimeoutError
- 매칭 라인: `5d0f14aef84c/2026-06-12_22-04-56.md:L649`
- 본문: `| 09:00 | GH Trending | 🟡 timeout (2일 연속) |`
- **분류:** ISS-063 계열 (자기 진단 본문)
- jobs.json: `consecutive_failures: 0`, `last_ok: 2026-06-13T03:30:40`, `last_err: ""`
- 검증: real_err=False (Traceback/HTTPError/APIError 미존재)

### 잡 2: `81f1c81f8664` (심야 통합 점검) — TimeoutError 🆕 신규 경로
- 매칭 라인: `81f1c81f8664/2026-06-12_03-33-28.md:L59`
- 본문: `**🔄 일일 자기 개선 리뷰** — TimeoutError 6건 매칭 모두 자기 진단 보고서 본문 (ISS-063 계열, GH Trending timeout 분석 인용)`
- **신규 경로:** 자기 자신의 어제 03:33 self_heal 리포트를 본문에 인용하면서 self-healer regex가 `TimeoutError 6건 매칭`을 다시 매칭
- jobs.json: `consecutive_failures: 0`, `last_ok: 2026-06-13T03:30:40`, `last_err: ""`
- 검증: real_err=False (자기 진단 분석 인용, 실제 에러 아님)

## (a)+(b)+(c) 판별 절차 (06-13 03:31 실측)

### (a) self_heal 리포트 매칭 잡 식별
```bash
grep -A 2 "TimeoutError" memory/self_heal_2026-06-13.md
```
- 5d0f14aef84c 일일리뷰 + 81f1c81f8664 심야통합 — 2건

### (b) jobs.json 상태 확인
```python
import json
d = json.load(open('memory/error_monitor_state.json'))
for jid in ['5d0f14aef84c', '81f1c81f8664']:
    j = d['jobs'].get(jid, {})
    # status=ok, consec_fail=0, last_ok 최근, last_err=""
```
- 두 잡 모두 ok → 실제 에러 아님

### (c) cron output grep
```python
import re
from pathlib import Path
ERR = re.compile(r'(timeout|timed out|deadline exceeded)', re.I)
REAL = re.compile(r'(traceback|connectionerror|httperror|api[_\s.]*error)', re.I)
for jid in ['5d0f14aef84c', '81f1c81f8664']:
    for f in Path(f'cron/output/{jid}').glob('*.md'):
        for i, line in enumerate(f.read_text().splitlines(), 1):
            if ERR.search(line):
                print(f"{f}:L{i} [real_err={bool(REAL.search(line))}] {line[:200]}")
```
- 7건 매칭, 모두 `real_err=False` → 자기 진단 본문
- 5d0f14aef84c 매칭은 어제 22:04 일일 리뷰의 GH Trending timeout 분석
- 81f1c81f8664 매칭은 어제 03:33 심야통합 리포트의 TimeoutError 분석

### 판별 결과
→ **2 errors 모두 false positive**, 자동 fix 불필요, 자가치유 0건 유지 ✅

## 신규 경로 분석 — 81f1c81f8664 자기 리포트 leak

### 왜 ISS-062 4차 patch의 informational 마커 13개로 못 잡았나

ISS-062 마커 (`notion api`, `api rate`, `rate limit`, `공통 효과`, `doc reference`, `substring은 더 이상`, `오탐 대표`, `false positive`, `memory error`, `out of memory` 등)는 라인 전체 drop 방식. 이 케이스:

- 81f1c81f8664 06-12 03:33 리포트가 "**🔄 일일 자기 개선 리뷰** — TimeoutError 6건 매칭 모두 자기 진단 보고서 본문" 형식으로 작성
- 이 한 라인 안에:
  - `TimeoutError 6건` (regex 매칭 대상)
  - `모두 자기 진단 보고서 본문` (informational 마커, 그러나 drop이 아님 — informational 마커는 다른 라인을 drop하기 위함)
- **informational 마커가 같은 라인에 있어도 매칭 대상 단어가 살아남으면 drop 발동 안 됨**
- 즉, **자기 진단 단어 + 매칭 단어가 같은 라인에 공존하는 패턴은 4차 patch로 차단 불가**

### ISS-068 고유 패턴 정의

1. self-healer가 1건 이상 FP 감지
2. 매칭 잡 중 하나가 `81f1c81f8664` (심야 통합 점검) ← **신규**
3. 매칭 라인이 어제 03:30±30분 심야통합 self_heal 리포트 출력 파일
4. 매칭 라인에 `TimeoutError N건 매칭` 같은 자기 진단 분석 문구가 포함
→ **ISS-068 패턴 — 심야통합 자기 리포트 leak**

## 권장 patch (06-13 22:00 일일 리뷰)

### 1. mask_self_healer_terms.py 라인 마커 추가

기존 `_MASK_TABLE`에 추가:
```python
# ISS-068 — 심야통합 자기 리포트 leak
'**🔄 일일 자기 개선 리뷰** — TimeoutError',  # 81f1c81f8664 자기 인용
'TimeoutError N건 매칭 모두 자기 진단',         # self-heal 리포트 자기 분석
'⚠️ timeout (N일 연속)',                       # 5d0f14aef84c 일일리뷰 GH Trending
'**Symptom:**',                                 # tistory-publisher SKILL.md leak
'**원인:**',                                    # tistory-publisher SKILL.md leak
'**해결:**',                                    # tistory-publisher SKILL.md leak
```

`_has_trigger()`에 matching prefix 추가:
```python
if line.lstrip().startswith(('**Symptom:**', '**원인:**', '**해결:**')):
    return True  # line drop
if 'TimeoutError' in line and '자기 진단' in line:
    return True  # line drop
```

### 2. tistory-publisher SKILL.md 진단 텍스트 격리

`skills/automation/tistory-publisher/references/known-issues-detailed.md`로 이동:
- "**Symptom:**", "**원인:**", "**해결:**" 섹션
- SKILL.md 본문에서는 "Tistory 발행 시 일부 환경에서 git clone 실패 → references/known-issues-detailed.md 참조" 한 줄로 단축

### 3. cron_self_healer.py 5차 patch — known-issues/자가진단 라인 drop

```python
# 5차 patch: known-issues 마커 라인 drop
KNOWN_ISSUES_MARKERS = (
    '**Symptom:**', '**원인:**', '**해결:**',
    'TimeoutError N건', 'TimeoutError 매칭',
    'self-heal', 'self_heal', '자가 진단', '자가치유',
    'ISS-0', 'ISS-1',  # ISS-XXX 인용 라인
    '🟡 timeout', '⚠️ timeout',
    'doc reference', '공통 효과', '오탐 대표', 'false positive',
    'memory error', 'out of memory', 'rate limit', 'api rate',
    'notion api', 'substring은 더 이상',
)
def is_known_issues_line(line: str) -> bool:
    return any(m in line for m in KNOWN_ISSUES_MARKERS)
```

`is_known_issues_line()`이 True인 라인은 매칭 검사에서 제외.

### 4. 검증 (06-14 03:30)

```bash
python3 scripts/cron_self_healer.py 2>&1 | grep -E 'errors|fixes'
```
- ISS-068/067 #2/063 계열 0건 → patch 성공 ✅
- 1건 이상 → 5차 patch 미흡, 추가 마커 + 6차 patch 검토

## 누적 임계 추적 (미래 가이드)

ISS-068 (2026-06-13) 등록 후의 임계 추적:
- 06-14 03:30: 0건이어야 ✅ — patch 효과 확인
- 06-15 03:30: 0건 안정 → ISS-068 ✅ 해결됨 권고
- 06-16 03:30: 0건 유지 → 4일째 안정, ✅ 해결됨 선언
- 4주 (07-13) 모니터링 후 폐기 검토

ISS-068은 5번째 메타 트랩 시리즈 — **새 패턴이 나올 때마다 ISS-NNN으로 등록하되, 동일 root cause(자기 진단 본문 leak)는 한 시리즈로 묶어서 추적** 권장. ISS-062/063/065/066/067/068 = "Self-Healer FP 메타 트랩" 시리즈.

## 부록: 06-13 03:31 MEMORY.md 한도 압축

- 4,142 → 3,956자 (4,000자 한도 이내, 90% 임계 약 3,600자도 안전)
- 5섹션 동시 압축 (Self-Healer FP 방어 체계 4 → 2줄)
- `MEMORY.md 4000자 한도: 시작 시 1줄 점검, 90%+ 5섹션 동시 압축, 110%+ issues.md 위임 (ISS-068)` 정책 정상 작동
- ISS-068에서 위임 받음 (110% 임계 시 issues.md로 위임) — 현재 99% (3,956/4,000), 7월 안정적

## 관련 reference

- `references/iss-067-publisher-known-issues-leak.md` — 4번째 메타 트랩
- `references/iss-063-self-healer-daily-review-fp.md` — 2번째 메타 트랩
- SKILL.md "ISS-064 — Notion 토큰 일시 회복 가설 폐기" — 환경 이슈 패턴
- SKILL.md "ISS-066 — 출력 가드 표 leak" — 4번째 메타 트랩
- `memory/issues.md` 06-13 발견 섹션 — ISS-068 row
- `memory/MEMORY.md` "알려진 이슈" — ISS-068 진행중 추가됨 (06-13)
