# CJK Cleaning Loop History

68차 (2026-05-21 저녁 cron — OpenAI SynthID 워터마크 블로그 글):
- Markdown CJK 선검사 1차: 27자 (`が`, `ら`, `与`, `乱`, `作`, `化`, `协`, `参`, `可`, `囲`, `型`, `弱`, `態`, `成`, `扩`, `採`, `散`, `数`, `极`, `構`, `生`, `用`, `秒`, `积`, `範`, `築`, `自`, `视`)
- 종합 사전 1차 정제로 대부분 제거
- 잔여 9자 (`与`, `乱`, `参`, `態`, `採`, `秒`, `範`, `築`, `视`) → targeted final-pass로 제거 완료
- HTML 변환 0회차 통과 (CJK 루프 미작동)
- 발견된 new CJK characters:
  - `与`(여), `乱`(난), `参`(참), `態`(태), `採`(채), `秒`(초), `範`(범), `築`(축), `视`(시)
- These were likely introduced from the GeekNews article's Chinese text ("参与", "扩展", "采用", "范围", "建构", etc.) being mixed into the Korean draft