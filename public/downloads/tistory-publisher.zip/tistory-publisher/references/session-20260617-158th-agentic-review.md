# 158차 세션 노트 (2026-06-17)

## 주제: 에이전틱 코드 리뷰
- source_url: https://news.hada.io/topic?id=30571
- tistory_url: https://sigco.tistory.com/779
- 긱뉴스 본문: 5,000자+ 풍족 (Faros/CodeRabbit/GitClear/GitHub 다중 데이터셋 + 위치별 가이드 + Loop engineering + 실무 지침)

## 적용된 정석 패턴

### 1. --record 사전 호출 시퀀스 (158차 신규 정형화)
```
# Step 1: publisher 호출 전 source_url 선기록
python3 ~/.hermes/scripts/blog_pipeline.py --record "에이전틱 코드 리뷰" "TBD" "https://news.hada.io/topic?id=30571"

# Step 2: publisher 호출 → 성공
python3 ~/.hermes/scripts/tistory_publisher.py --title "..." --category 1219746 --tags "..." --image-query "..." --file /tmp/agentic_review_post.md --visibility public

# Step 3: publisher 성공 후 Tistory URL 갱신
python3 ~/.hermes/scripts/blog_pipeline.py --record "에이전틱 코드 리뷰" "에이전틱 코드 리뷰 — AI 시대, 검증 단계가 진짜 병목이 된 이유" "https://sigco.tistory.com/779"
```

### 2. 한자 표현 1회 patch 치환 (158차 신규 정형화)
- 1차 본문: "저(低)AI 도입에서 고(高)AI 도입으로 전환할 때"
- patch 후: "저(낮은) AI 도입에서 고(높은) AI 도입으로 전환할 때"
- patch 명령: `patch /tmp/<post>.md --mode replace --old_string "저(低)AI 도입에서 고(高)AI 도입으로" --new_string "저(낮은) AI 도입에서 고(높은) AI 도입으로"`
- 3번째 섹션 "고(高)blast-radius"도 동일 패턴으로 patch 예정이었으나 grep 재확인 결과 매치 0건 (실제 본문엔 등장 안 함) — 따라서 patch 1회로 종료

### 3. 본문 1,800자+ 분기 (158차 실전 검증)
- 긱뉴스 본문 풍족 (5,000자+) → 5-H2 구조 + 데이터 다수 인용으로 1차 작성 시 자연스럽게 4,000자+ 도달
- patch 0회 → 1회 컷 4,596자 (목표 2,500자 초과 84%)
- 분기표 그대로 유효: 1,800자+ → patch 0~1회 (결론 보강만) → 2,000자+ / 실제 결과는 4,596자

### 4. freshness 3중 앵커링 적용
- 도입 첫 문장: "2026년 6월 현재, 코딩 에이전트의 성능이 급격히 끌어올려지면서..."
- 결론 마지막 문장: "2026년 6월 기준으로 코드를 더 빨리 쓰는 팀이 이기는 게 아니라..."
- 본문 H2 다수: H1(2026년 데이터), H3(2026년 6월 현재 입장, 2026년 6월 기준)
- 2025년 직접 인용 (CodeRabbit 2025년 12월, GitClear 2025년까지): 긱뉴스 원문에 명시된 사실 정보로 일반화하면 안 됨 (생성 작업)

### 5. 제목 38자 (30~60자 가이드라인 통과)
- "에이전틱 코드 리뷰 — AI 시대, 검증 단계가 진짜 병목이 된 이유"
- 부제 붙이되 38자로 절제

## 최종 발행 결과

| 항목 | 값 |
|---|---|
| 카테고리 | 1219746 (AI/ML) |
| 제목 길이 | 38자 |
| 본문 길이 | 4,596자 |
| 태그 | AI에이전트, 코드리뷰, LLM, DevTools, 엔지니어링 (5개) |
| 이미지 | 본문 Picsum 2장 + OG 자동 1장 = 3장 |
| CJK | 0건 (저(低)/고(高) patch 후) |
| 1회 컷 | 38회째 (1,800자+ 분기 patch 0회) |

## 학습 신호 (158차)

1. **`--record` 사전 호출**: publisher 호출 전 source_url 선기록 → publisher 실패 시 추적 가능
2. **한자 괄호 주석 1회 patch**: 긱뉴스 원문 한자 표현이 본문 어휘로 들어가면 1회 patch로 한글로 치환
3. **1,800자+ 분기 검증**: 긱뉴스 본문 풍족 → 1차 5-H2 + 데이터 인용으로 1회 컷 4,500자+ 가능
4. **CJK 47회 연속 / 1회 컷 38회째 / OG 3장 63회째**: 안정화 패턴 누적
