# Post-conversion Cleanup — tags 라인 + 출처 중복 제거 (2026-06-04 추가)

Markdown → HTML 변환 직후, CJK 정제 **전에** 다음 두 가지를 처리하라. SKILL.md에는 각각에 대한 경고가 이미 있지만 cron 환경에서 매번 위반되기 쉬우므로 변환 직후 cleanup 스크립트로 안전망을 둔다.

## 1. `<p>tags: ...</p>` 라인 제거

Markdown 본문 첫 줄에 `tags: 태그1,태그2`가 있으면 변환 후 HTML 첫 줄에
`<p data-ke-size="size16">tags: 태그1,태그2</p>`로 그대로 노출된다.

- `blog_quality_gate`는 이 라인을 본문 일부로 인식해서 길이 계산이 꼬임
- 발행된 글 첫 줄에 "tags: ..." 문구가 그대로 보임
- **Markdown 작성 시 `tags:` 라인은 본문에 절대 넣지 마라** — 태그는 항상 `--tags` CLI 인자로만 전달

## 2. 출처 섹션 중복 제거

Markdown 하단에 `---` + `📚 출처` 섹션이 있고 `--source-url`도 함께 전달하면 출처가 두 번 추가된다. 둘 중 하나만 사용:
- Markdown에 출처 직접 작성 → `--source-url` 없이 변환
- Markdown에 출처 작성 안 함 → `--source-url`로 출처 자동 추가

## 통합 cleanup 스크립트

방지 실패 시 변환 후 아래 Python으로 후처리 (CJK cleaning **전에** 실행):

```python
import re
with open('/tmp/blog_tistory.html', 'r') as f:
    html = f.read()

# 1) 첫 줄 'tags: ...' 제거 (있을 때만)
html = re.sub(r'<p data-ke-size="size16">tags:.*?</p>\n?', '', html, count=1)

# 2) 중복 출처 섹션 제거 — 마크다운 형식 출처('[제목](URL)<hr/>')가 발견되면 제거
html = re.sub(
    r'<p data-ke-size="size16">• \[[^\]]+\]\([^)]+\)</p><hr/>\n',
    '',
    html
)
# '📚 출처' 인접 중복 라벨 제거 (3번 이상 등장 시 중간 라벨 제거)
parts = html.split('<p data-ke-size="size16"><strong>📚 출처</strong></p>')
if len(parts) > 2:
    html = parts[0] + '<p data-ke-size="size16"><strong>📚 출처</strong></p>' + ''.join(parts[1:-1]) + parts[-1]

with open('/tmp/blog_tistory.html', 'w') as f:
    f.write(html)
```

## 위험성

이 두 가지를 변환 직후 적용하지 않으면 발행된 글 첫 줄에 `tags: ...` 라인이 그대로 보이고, 출처 섹션이 두 번 노출된다.

`tistory_publisher.py`의 content validation(300자 이상)은 두 가지 모두 통과시키기 때문에 **조용히 발행되는 게 가장 위험**하다 — 발행 후 브라우저로 직접 확인하지 않는 한 발견이 어렵다.

## 2026-06-04 발행 사례

`markdown_to_tistory_html.py /tmp/blog_post_20260604.md /tmp/blog_tistory.html --source-url "https://news.hada.io/topic?id=30133"` 실행 시 발생한 증상:
- HTML 첫 줄에 `<p>tags: Gmail, Fastmail, ...</p>` 노출
- HTML 말미에 `<p>📚 출처</p><p>• [Gmail은 ...](https://news.hada.io/topic?id=30133)</p><hr/><p>📚 출처</p><p>• <a href="...">...</a></p>` — 출처 2개

cleanup 스크립트 적용 후:
- 첫 줄 `tags:` 라인 제거 확인
- 출처 1개로 통합 확인 (`text.count("출처") == 1`)

## 발원

Markdown 변환 직후 + CJK cleaning 전에 `python3 /tmp/fix_post_conversion.py` (또는 동등한 inline 스크립트) 실행으로 해결. 향후 SKILL.md의 자동 발행 파이프라인 §6 "HTML 변환" 단계에서 cleanup → CJK 정제 순서로 명시할 것.
