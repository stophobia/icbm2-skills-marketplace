---
name: notebooklm-youtube-automation
description: NotebookLM侯選 → 노트북 생성 → YouTube 업로드 (일반 영상 + Shorts 세트) 자동화 워크플로우
trigger: "notebooklm youtube upload video overview shorts automation"
---

# NotebookLM YouTube 자동화 워크플로우

## 4단계 개요

| 단계 | 발생时机 | 스크립트 | 출력 |
|------|----------|----------|------|
| 1.侯選 전송 | 매일 16:00 크론 | `notebooklm_selection.py` | Telegram → `selection.json` 저장 |
| 2. 노트북 생성 | 사용자 번호 선택 후 | `notebooklm_prepare.py` | 노트북 + 소스 추가 |
| 3. 검토 | 사용자 "업로드" → | `notebooklm_upload.py --review` | Telegram 제목/설명 미리보기 |
| 4. 업로드 | 사용자 '확인' 후 | `notebooklm_upload.py --approved` | YouTube 일반 영상 + Shorts |

> ⚠️ **절대 바로 `--approved` 실행 금지** — 반드시 `--review`로 검토를 먼저 거칠 것

---

## 파일 인벤토리

| 용도 | 경로 |
|------|------|
|侯選 topics (번호 매핑용) | `~/.hermes/memory/notebooklm_selection.json` |
| 업로드 검토 내용 | `~/.hermes/memory/upload_review.json` |
| YouTube OAuth 토큰 | `~/.hermes/secrets/youtube_token.pickle` |
| YouTube 클라이언트 시크릿 | `~/.hermes/secrets/client_secret_*.json` |

---

## 1단계:侯選 전송 (크론 — 매일 16:00)

**스크립트:** `~/.hermes/scripts/notebooklm_selection.py`

- Notion DB에서 URL 있는 활성侯選 로드 → Telegram 전송 시도
- 전송 직후 `selection.json`에 `topics` + `selection_numbers=[]` 저장
- 사용자가 번호 선택 → `selection_numbers`에 직접 기입

### Telegram 전송 메커니즘 (2026-06-01)

**⚠️ `telegram_bot_token.txt`는 Placeholder — curl 전송은 항상 실패:**

`~/.hermes/secrets/telegram_bot_token.txt`의 내용은 `PLACEHOLDER_TOKEN_REPLACE_WITH_REAL`이며, 실제 Telegram Bot Token이 **아닙니다**. 따라서 `notebooklm_selection.py`의 curl 기반 Telegram 전송은 항상 `exit_code=3` (빈 응답)으로 실패합니다.

**실제侯選 전달 경로 — stdout 마커 fallback:**

```
notebooklm_selection.py 실행
  → curl Telegram API → 실패 (placeholder token)
  → stdout에 "===== NOTEBOOKLM侯選 =====" 마커 출력
  → 크론 에이전트가 마커 사이 내용물을 읽어 주인님께 전달
```

**즉:**侯選 목록이 텔레그램으로 도착하는 것은 **curl 전송 성공이 아니라 stdout 마커 fallback** 때문입니다. 이 mechanism은 정상 동작 중이며, 텔레그램 봇 토큰 설정과 무관하게侯選가 전달됩니다.

> **디버깅 시 참고:** `curl: (3) URL using bad/illegal format or missing URL` 또는 빈 응답은 placeholder token导致的 expected failure입니다.侯選가 마커와 함께 출력되면 전달은成功的입니다.

**크론 재실행 시 덮어쓰기 방지 (2026-05-13):**
- 이미 오늘(`date=YYYY-MM-DD`) topics가 존재하면 덮어쓰지 않고 백업만 수행
- 이를 통해 cron 재실행해도侯選 목록이 변하지 않음

**선택 번호 지정:**
```bash
# ~/.hermes/memory/notebooklm_selection.json 열기
# selection_numbers만 수정 (selected는 빈칸으로 유지 — 스크립트가 자동 복원)
"selection_numbers": [2, 3, 6, 7],
```

### ⚠️ selection.json topics 배열을 수동 생성하지 마세요 (2026-06-01)

**절대 topics 배열을 처음부터 재작성하지 마십시오.**

크론 job의 `notebooklm_selection.py`가 생성한 `selection.json`의 `topics` 배열에는 **이미 올바른 Notion URL**이 저장되어 있습니다. 이 배열을 지우고 다시 쓰면:
- 크론 출력 메시지의 카테고리 정렬 순서 ≠ Notion DB 반환 순서 → **번호-주제 매핑 완전히 틀어짐**
- URL이 전부 `null`이 되어 `TypeError: 'NoneType' object is not subscriptable` 발생

**올바른 수정 방법 — `selection_numbers`만 변경:**
```bash
# selection_numbers만 수정, topics 배열은 그대로 유지
python3 - << 'EOF'
import json
path = "/Users/hjshin/.hermes/memory/notebooklm_selection.json"
with open(path) as f:
    d = json.load(f)
d["selection_numbers"] = [1, 3, 12]   # 사용자가 선택한 번호
# d["topics"]는 절대 건드리지 말 것 — 이미 올바른 URL이 저장됨
with open(path, "w") as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
print("OK — selection_numbers만 수정됨")
EOF
```

**올바른 JSON 구조:**
```json
{
  "date": "2026-06-01",
  "topics": [
    {"name": "AI 이후의 소프트웨어...", "url": "https://news.hada.io/topic?id=30061", ...},
    ...
  ],
  "selected": [],
  "selection_numbers": [1, 3, 12]
}
```

**topics 배열을 지우거나 재작성하면 안 되는 이유:**
- 크론 출력의 #1 = Notion의 #1이 **아님** (카테고리 정렬 vs DB 순서)
- 수동 재작성 시 URL이 null이 되어 prepare.py 실행 시 `TypeError` 발생
- 항상 크론 job이 생성한 topics 배열을 그대로 사용할 것

---

## 2단계: 노트북 생성 (사용자 번호 선택 후)

**스크립트:** `~/.hermes/scripts/notebooklm_prepare.py`

> ⚠️ **`--topics` 인자 없음** — 선택 번호는 반드시 `selection.json`에 먼저 써야 함

**실행 전 인증 확인 (권장):**
```bash
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json 2>&1 | head -3
```
→ `{"error"` 있으면 `login` 먼저 실행. auth 오류 상태에서 `prepare.py`를 실행하면 모든 노트북이 "생성 실패"로 기록됨.

**실행:**
```bash
source ~/.hermes/venv-notebooklm/bin/activate
python3 ~/.hermes/scripts/notebooklm_prepare.py --skip-telegram
```

**원리:**
- `selection_numbers`를 `topics` 배열 인덱스로 변환 (`topics[n-1]`)
- topics는侯選 전송 시 저장된 원본 — Notion 재�라우지 않도록 그대로 사용
- `selected` 키가 비어있으면 자동 복원

### ⚠️ 디버깅 패턴: CLI 오류 메시지가 stdout/stderr哪儿에 있는지 확인
`run_notebooklm()`의 `subprocess.run(capture_output=True)`는 stderr를 캡처하지만, 인증 오류(`Error: Authentication expired`)는 **stdout**에 출력되고 `returncode=1`로退出. `result.stderr.strip()[:200]`가 비어보이면 stdout도 확인:
```bash
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm create "ICBM | Test" 2>&1; echo "EXIT:$?"
```
→ `EXIT:0` + 에러 텍스트 = stdout에 에러 (CLI 자체 처리)
→ `EXIT:1` + 에러 텍스트 = auth 문제 (notebooklm 내부)

---

## 3단계: 업로드 (사용자 "업로드" 요청)

**⚠️ 필수 확인: 사용자가 NotebookLM에서 모든 영상을 생성했는가?**

**⚠️ 중요: 업로드 전 검토 단계 (2026-05-13 추가)**

```
업로드 요청 → --review (검토) → '확인' 입력 → --approved (실제 업로드)
```

절대 바로 `--approved`를 실행하지 않는다. 반드시 `--review`로 미리보기를 보내고 사용자의 확인을 받아야 한다.

### 3-a: 검토 요청 (`--review`)
```bash
python3 ~/.hermes/scripts/notebooklm_upload.py --review
```
- 제목/설명/소스를 Telegram으로 전송 (업로드 없음)
- ⚠️ **NotebookLM 실제 소스도 함께 표시** — 노트북에 추가된 URL을 원본 기사 단위로 보여주어 검증 가능
- ⚠️ **설명 전체를 보내야 함** — 일부만 자르면 엉뚱한 내용이 포함되는 문제가 있음
- 검토 내용: `~/.hermes/memory/upload_review.json`에 저장
- 사용자가 내용을 확인하고 '확인' 이라고 입력할 때까지 대기

**검토 메시지 구조:**
```
◆ {번호}. {주제명}
🎬 일반 영상: {제목}
🔥 숏츠: {제목}
📝 설명: {설명 전체}

🔗 출처 (NotebookLM):        ← 실제 노트북 소스 (추가된 URL들)
  • {소스 제목}
    {소스 URL}
📰 주제: {GeekNews URL}      ←侯選 Topic URL
---
```

**⚠️ 소스 불일치 검출 (2026-05-21):**
4. **소스 불일치 검출 (2026-05-21 추가):** `--review`에서 NotebookLM 실제 소스와 GeekNews 주제 URL을 반드시 함께 표시. 주인이 "엉뚱한 소스"라고 교정하면 → `references/source-correction-2026-05-21.md` 참조하여 소스 교체.

## YouTube 업로드: 두 가지 경로

### 경로 A — 검토 후 업로드 (표준 파이프라인)
```
사용자: "업로드"
→ --review (검토) → '확인' 입력 → --approved (실제 업로드)
```
이 경로는 `upload_review.json`이 비어있거나 오늘 날짜가 아니면 동작 안 함.

### 경로 B — 검수 링크 단계에서 바로 업로드 (2026-05-24)
사용자가 이미 검수 링크에서 영상을 직접 확인하고 "업로드"라고 회신한 경우.
`upload_review.json`에 데이터가 있으면 `--review`를 건너뛸 수 있음.

**판단 기준:**
- `upload_review.json`에 오늘 날짜의 검토 데이터가 존재하는가?
- 사용자가 "검토" 없이 바로 "업로드"라고 했는가?

**경로 B 실행:**
```bash
cd ~/.hermes && ./venv-notebooklm/bin/python3 scripts/notebooklm_upload.py --approved
```
→ `upload_review.json`의 내용으로 바로 업로드

> ⚠️ `upload_review.json`에昨天的 데이터가 남아 있으면 **잘못된 주제가 업로드됨**. 반드시 오늘 데이터인지 확인 후 실행.

### YouTube 쿼타 초과 에러 처리 (2026-05-24)
`yt_upload.py`에 429 재시도 + 토큰 선제 리프레시 로직이 이미 구현됨.
사용자가 "쿼타 부족"이라고 하면 → **스크립트 오류가 아니라 YouTube API 일시적 트래픽 문제**이므로 재시도하면 결국 성공함.
최대 5회 재시도 (10s→20s→40s→80s→160s 지수 백오프).

### YouTube 설명 템플릿

MEMORY의 블로그 업로드 설명과 동일한 구조를 사용한다:

```
{ description }

📚 출처
• {topic_name}
  {topic_url}

#ICBM #AI #테크 #개발자 #인공지능
```

### Shorts 제작 규격

- 9:16 세로형 (1080×1920)
- 59초 이하
- **Letterbox** 배경 (원본 영상 위아래 검은 패딩 — 원본 전체 보존, 좌우 크롭 없음)
- SAR=1:1, DAR=9:16

**FFmpeg 4.3.2 레터박스 방식:**
```ffmpeg
-vf "scale=1080:-1,pad=0:1920:(ow-iw)/2:(oh-ih)/2:black,setsar=1,setdar=9/16"
```
→ 16:9 입력(1280x720) → 1080x607 스케일 →上下 656.5px 검은 패딩 → 1080x1920 완성
→ 좌우 크롭 없음, 원본 비율 100% 보존

---

## 파일 구조

```
~/.hermes/scripts/
├── notebooklm_selection.py       #侯選 전송 (16:00 크론)
├── notebooklm_prepare.py        #노트북+소스 생성
├── notebooklm_upload.py          #YouTube 업로드 파이프라인 (--review / --approved)
└── yt_upload.py                 #YouTube OAuth 업로드 (직접 호출용)
```

---

## NotebookLM CLI 실행 원칙

**⚠️ 절대 system anaconda의 notebooklm를 직접 실행하지 마라**

system Python (`/Users/hjshin/opt/anaconda3/bin/notebooklm`)은 문법 오류로 깨져 있습니다:
```
File ".../notebooklm/cli/session.py", line 11
    from typing import Optionalimport os
                                      ^
SyntaxError: invalid syntax
```

**⚠️ 계정 요구사항: consumer Gmail만 지원**

NotebookLM CLI는 **consumer Gmail.com 계정만** 지원합니다. Google Workspace 계정(ubob.com 등)은 어떤 방법으로도 인증 불가. 쿠키가 유효해도(만료 2027) 요청 시 Google 로그인 리다이렉트 발생.

| 명령 | 올바른 방식 |
|------|------------|
| login | `~/.hermes/venv-notebooklm/bin/python3 -m notebooklm login` |
| list | `~/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json` |
| create | `~/.hermes/venv-notebooklm/bin/python3 -m notebooklm create "제목"` |
| source add | `~/.hermes/venv-notebooklm/bin/python3 -m notebooklm source add "URL"` |
| download | `~/.hermes/venv-notebooklm/bin/python3 -m notebooklm download video -n {nb_id} {output_path}` |

> `notebooklm_prepare.py` 등의 스크립트는 이미 내부에서 venv 경로를 사용하므로 직접 호출하면 안 됩니다.

## 인증 실패 디버깅 (v0.14.0+)

**⚠️ 가장 흔한 원인: Google Workspace 계정 사용 (ubob.com)**

NotebookLM CLI는 **consumer Gmail 계정만** 지원합니다. Google Workspace/업무용 계정(ubob.com 등)은 어떤 방법으로도 인증이 되지 않습니다.

증상: `storage_state.json`에 유효한 쿠키가 있어 보여도(만료일 2027년), 모든 요청이 Google 로그인 페이지로 리다이렉트됨. 쿠키 도메인이 `.google.co.kr`로 표시됨.

**확인 방법:**
```bash
~/.hermes/venv-notebooklm/bin/python3 -c "
from notebooklm.auth import _load_storage_state
data = _load_storage_state()
for c in data.get('cookies', []):
    if c['name'] == 'SID':
        print('SID domain:', c['domain'])
"
```
→ `.google.com`이 나와야 정상. `.google.co.kr`이면 Workspace 계정 쿠키.

**해결:** 브라우저 프로필 초기화 + Gmail.com 개인 계정으로 재로그인:
```bash
rm -rf ~/.notebooklm/browser_profile
rm ~/.notebooklm/storage_state.json
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm login
```
→ Gmail.com 계정으로 로그인, NotebookLM 홈이 뜨면 ENTER.

→详见 `references/auth-debug-2026-05-18.md`

## YouTube API 인증

**토큰 스코프 중요:** `youtube.upload`만 있으면 업로드는 되지만 **search/delete 불가**.
삭제 작업이 필요하면 전체 `youtube` 스코프로 재인증:

```python
from google_auth_oauthlib.flow import InstalledAppFlow
SCOPES = ['https://www.googleapis.com/auth/youtube']
flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET, SCOPES)
creds = flow.run_local_server(port=0)
with open(TOKEN_FILE, 'wb') as f:
    pickle.dump(creds, f)
```

---

## 핵심 금기 (절대 어기지 말 것)

1. **노트북 수동 삭제 금지** — ID 유실 → 출처 누락 + 파이프라인 꼬임
2. **`yt_upload.py` 인자 형식** — positional 인자 사용 (수정 후 argparse `--title`, `--description` 등)
3. **영상 생성 안 된 topic** — upload 시도하지 말 것
4. **侯選 번호 매핑** — `notebook_ids.json` 절대 사용 금지
5. **侯選 목록 표시 시 `selection.json`만 사용** — `notebook_ids.json`은 생성된 노트북만 담고 있어 12개 중 일부만 표시됨.侯選를 사용자에게 보여줄 때는 반드시 `~/.hermes/memory/notebooklm_selection.json`의 `topics` 배열을 사용한다.
6. **한자/한문 제거 금지 (`strip_cjk`)**: `notebooklm_prepare.py`의 `load_active_topics_with_urls()`에서 `strip_cjk()` 호출 시 topic name이 깨짐. topics.name은 원본 그대로 보존한다.
7. **`strip_cjk()` Korean character bug (2026-05-13) fix**:
   - regex에 한국어 범위(`\uac00-\ud7af`)가 포함되어 있었음 → 한국어 텍스트가 통째로 제거됨
   - 수정: regex에서 `\uac00-\ud7af` 제거. ff00-ffef(全角 영문/숫자/구두점)만 남김
   - `build_description()`에는 원본 `topic_name`을 전달
   - `strip_cjk()`는 description 내 한자 제거용으로만 사용
8. **출처 URL은 GeekNews 토픽 URL 그대로 (2026-05-13)**:
   - `collect_sources_for_description()`의 0순위에서 `resolve_geeknews_topic_url()` 호출 금지
   - 항상 `topic['url']` (GeekNews URL)을 그대로 출처로 사용
   - 주인님이 GeekNews 출처를 선호するため
9. **검토 메시지 포맷 (2026-05-13)**:
   - 코드블록(```) 사용 금지 — 일반 Markdown으로 전송
   - 각 항목별 구분: ◆ 번호, 🎬 일반 영상, 🔥 숏츠, 📝 설명, 🔗 출처
   - 구분선(---)으로 항목 분리
   - 설명은 전체를 잘리지 않고 보내야 함

---

## On-Demand 업로드: 완전한 절차 (2026-05-19)

사용자가 "노트북 비디오 오버뷰 생성 완료. 업로드"라고 말하면, 일반 4단계 파이프라인을 생략하고 **이미 생성된 영상만** 업로드하는 경우.侯選 전송 → 노트북 생성 → 영상 생성까지 전부 이미 완료된 상태에서 업로드만 하면 된다.

### Step 0: 대상 확인
```bash
notebooklm list
# → 05-18/05-19 날짜의 노트북 ID와 제목 기록
```

### Step 1: 영상 아티팩트 상태 확인
```bash
notebooklm use <nb_id_1>
notebooklm artifact list
# → Video 아티팩트 ID + status (completed/pending) 확인
# 필요시 nb_id_2, nb_id_3... 반복
```

### Step 2: 영상 다운로드
```bash
mkdir -p /tmp/icbm_notebooklm/videos
notebooklm use <nb_id>
notebooklm download video --all /tmp/icbm_notebooklm/videos/ --force
```
**⚠️ positional 인자 사용 — `-o` 옵션 없음!** (`-o` 전달 시 "No such option: -o" 오류 발생)

### Step 3: selection.json 수동 생성
`--review`는 `~/.hermes/memory/notebooklm_selection.json`의 `date`가 오늘(KST)이어야 동작한다.
4단계 파이프라인을 안 거쳤으므로 이 파일이 없거나 날짜가 틀릴 수 있다.

**required JSON 구조:**
```json
{
  "date": "YYYY-MM-DD",
  "topics": [
    { "number": 1, "name": "주제명", "category": "AI/ML",
      "url": "https://news.hada.io/topic?id=xxxxx",
      "file": "/tmp/icbm_notebooklm/videos/영상파일.mp4" }
  ],
  "selection_numbers": [1, 2, 3],
  "selected": [ /* topics와 동일 내용 */ ]
}
```

### ⚠️ python3 버전 문제 (2026-05-19 추가)

`notebooklm_upload.py` 내부에서 `yt_upload.py`를 호출할 때 `googleapiclient` 모듈을 사용합니다. 시스템 기본 python3(`/Library/Frameworks/Python.framework/Versions/3.8/bin/python3`)에는 이 모듈이 없으므로 **모든 업로드가 `No module named 'googleapiclient'`로 실패**합니다.

**해결:** 스크립트를 실행할 때 **venv-notebooklm의 python3**을 사용합니다:

```bash
cd ~/.hermes && ./venv-notebooklm/bin/python3 scripts/notebooklm_upload.py --approved
```

> ⚠️ `--review`는 API 호출 없이 로컬 처리만 하므로 정상 동작합니다. 따라서 `--approved`에서만 이 문제가 발생합니다.

### Step 4: 검토 → 업로드
```bash
cd ~/.hermes && ./venv-notebooklm/bin/python3 scripts/notebooklm_upload.py --review
# → 검토 내용 확인 후 '확인' 입력
./venv-notebooklm/bin/python3 scripts/notebooklm_upload.py --approved
```

## ⚠️ `googleapiclient` Python 版本問題 (2026-05-19)

`--approved` 실행 시 `No module named 'googleapiclient'` 오류가 발생하는 경우가 있음.

**원인:** 시스템 기본 Python(`/Library/Frameworks/Python.framework/Versions/3.8/bin/python3`)에는 `googleapiclient`가 설치되어 있지 않음.

**증상:** `ModuleNotFoundError: No module named 'googleapiclient'`

**해결:** **venv-notebooklm의 python3**으로 스크립트 실행:
```bash
cd ~/.hermes && ./venv-notebooklm/bin/python3 scripts/notebooklm_upload.py --approved
```

> `--review`는 API 호출 없이 로컬 처리만 하므로 이 문제가 발생하지 않음. `--approved`에서만 발생.

---

## ⚠️ 16:00 크론 silent-skip 엣지 케이스 (2026-05-19)

`notebooklm_selection.py`의 "이미 오늘 처리됨" 로직(line 198: `existing.get("date") == today`)으로 인해 특정 순서에서候選가 전송되지 않음.

**실패 순서:**
1. **오전 세션** (예: 06:07):候選 생성 → `selection.json`에 오늘 날짜 저장
2. **16:00 크론**: 같은 날再次 실행 → `date == today` 확인 → 덮어쓰기 방지 → `[SILENT]`
3. **결과**: 사용자가候選를받지 못함

**해결 방법:**
- 방법 A (권장):侯選 generation과 Telegram 전송을 분리
- 방법 B (대안): `selection_numbers`가 비어있으면 강제 생성
- 방법 C (현재): 수동으로 `notebooklm_selection.py` 재실행

**증상:** 크론 로그에 `[SILENT]`만 있고 Telegram에候選 미전송

**이슈 추적:** ISS-035

---

## On-Demand 업로드: 완전한 절차 (2026-05-19)

## notebooklm CLI 참고

```bash
notebooklm list --json
notebooklm source list -n <nb_id> --json
notebooklm download video --all <output_dir> --force   # positional, -o 없음
notebooklm download video --dry-run
notebooklm artifact list
```

| 날짜 | 내용 |
|------|------|
| 2026-05-11 | 번호 불일치 해결, topics 원본 보존, YouTube 제목 변환 제거 |
| 2026-05-12 | delete CLI 옵션 `-n`, OAuth 토큰 만료 자동 refresh |
| 2026-05-13 | `ct` NameError fix, description 템플릿 MEMORY 통일, topic_name/url 전파, yt_upload.py argparse 수정, YouTube 스코프 인증 |
| 2026-05-18 | 브라우저 프로필 초기화 + Gmail.com 계정 필요 clarified; auth-debug reference updated |
| 2026-05-13 |侯選 표시 시 전체 목록 누락 문제 해결, cron 재실행 덮어쓰기 방지, strip_cjk() 한자 제거 버그 수정 |
| 2026-05-19 | On-Demand 업로드 완전한 4단계 절차 추가 (이미 생성된 영상의 업로드 경로) |
| 2026-06-01 | selection.json topics 배열 수동 생성 금지 — 크론 출력 번호 ≠ Notion DB 순서, 수동 재작성 시 URL=null로 TypeError 발생. `selection_numbers`만 수정할 것 |