# bunx → npx -y 자동 감지 패턴 검증 (2026-06-18)

## 배경

Tokscale `tokscale-setup.zip` 빌드 중 이 PC가 Bun 미설치임을 발견:

```
$ command -v bunx
bunx not found
$ command -v npx
/usr/local/bin/npx
```

`bunx hardcode`로 작성된 `install.sh` / `daily-submit.sh` / `SETUP_GUIDE.md`가
모두 cron 호환 실패 위험. **3파일이 동일 패턴으로 자동 감지하도록 일괄 patch**.

## 발견된 함정 — 부분 갱신

처음에는 install.sh만 `bunx` → `npx -y`로 일괄 교체. 하지만 daily-submit.sh와
SETUP_GUIDE.md의 코드 예제에 `bunx` 하드코드가 남아있어서:

1. 사용자가 SETUP_GUIDE.md quickstart 예제를 따라하다 `bunx tokscale@latest login`
   → `bunx: command not found` 에러
2. daily-submit.sh의 `bunx tokscale@latest submit` → 동일 에러 → cron 실패
3. install.sh만 고쳤다고 생각한 LLM이 다른 두 파일을 빠뜨리는 패턴

**결론**: Node 프로젝트 셋업 3종 (install.sh + daily-submit.sh + SETUP_GUIDE.md)은
**하나의 변경이라도 항상 같이 patch**해야 한다.

## 최종 패턴 — 3파일 공통 헤더

```bash
# 모든 셋업 스크립트 공통 시작 부분
if command -v bunx >/dev/null 2>&1; then
  RUNNER="bunx"
elif command -v npx >/dev/null 2>&1; then
  RUNNER="npx -y"
else
  echo "❌ bunx도 npx도 없습니다. Node 18+ 또는 Bun 설치 필요." >&2
  exit 1
fi
```

이후 모든 호출은 `$RUNNER tokscale@latest ...`로 통일.

## 실제 commit 메시지

```
[main 8b60d67] fix: bunx → npx -y (cron 호환)
 4 files changed, 60 insertions(+), 52 deletions(-)
```

4 files = install.sh + daily-submit.sh + SETUP_GUIDE.md + README.md (commit message).

## cron 호환성 검증

| 환경 | 동작 |
|---|---|
| Bun 설치된 PC | `RUNNER=bunx` → `bunx tokscale@latest` |
| Node만 있는 PC (이 PC) | `RUNNER="npx -y"` → `npx -y tokscale@latest` |
| 둘 다 없음 | 에러 메시지 + exit 1 → cron 알림 자동 발송 |
| cron 환경 (PATH 최소) | `command -v bunx` 실패해도 `npx`는 Node 설치 시 PATH에 포함 |

## 일반화 가능성

`npx -y`는 npm registry의 모든 패키지를 *설치 단계 없이 즉시 실행*한다.
따라서 **Node CLI를 cron으로 배포하는 모든 프로젝트**에 동일 패턴 적용 가능:

- AI 코딩 어시스턴트 wrapper (Claude Code, OpenCode, Codex 등)
- npm 배포 CLI 도구 (lint, format, build, deploy)
- 정기 실행 스크립트 (cleanup, sync, monitoring)
- 내부 npm private registry 패키지

**권장 사항**: 프로젝트 셋업 시 *runner 감지 로직을 단일 함수로 추출*하고
3개 셋업 파일이 같은 함수를 source하도록 만들 것. 부분 갱신 위험 원천 차단.

## 다음 작업 권장

- [ ] `references/two-pc-setup-recipe.md`에 bunx/npx 자동 감지 섹션 추가
- [ ] 다른 npm 기반 프로젝트 (auto-researcher, blog-pipeline 등) audit
- [ ] cron 등록 시 runner 감지 누락 → silent fail 가능성 점검
