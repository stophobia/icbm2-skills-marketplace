# Case Study: 시드 교체 + 4개 장르 repo 일괄 생성 (2026-06-12, 3부)

> 1부(`case-study-2026-06-12.md`) = 브레인스토밍 → 아키텍처, 2부(`case-study-2026-06-12-pt2.md`) = README 한글화 + 시드 시스템. 이 3부는 **시드 교체 + 다중 장르 repo 일괄 생성** 기록.

## 입력 (사용자 의도)

두 차례 사용자 결정:

### 결정 1: 샘플 시드 교체
> "샘플시드를 알도리아가 아닌 중세 고구려로 수정해줘."

**시드 선택 신호 (sigco3111님)**:
- 한국 역사 (위키/문헌 풍부, 사실주의)
- 시드 디렉토리명 컨벤션: `goguryeo-391` (kebab-case + 연도)
- 시드 디렉토리 안에 들어갈 콘텐츠: `seed.json` + `factions/` + `characters/` + `regions/` + `overview.md`

**선택지 제시 — 브레인스토밍 원칙**:
1. **미니멀**: 시드 메타데이터만 갈아끼우기, 구체 lore는 Phase 1
2. **적당히 (추천)**: 시드 메타 + 개요 2~3문장 + 시작 조건
3. **자세히**: 시드 메타 + 각국 1~2줄 + 5~6개 인물
4. **최대**: 시드 메타 + lore/seeds/goguryeo-391/ 디렉토리 구조 + 파일 이름

sigco3111님은 **"적당히"** 선택 — 선호 신호: "기능 나열 ❌, 적당한 깊이로 콘텐츠 보여주기 ✅". **퀄리티 기준이 높아서 "엉망"이면 처음부터 다시 시작**이라는 사용자 성향과 일치 (2026-06-11 메모리).

**고구려 391 선택 이유 (제가 제안)**:
| 이유 | 설명 |
|------|------|
| 풍부한 사건 | 4세기 후반 = 영토 확장 정점, 백제/신라/왜/후燕 5개국 외교 |
| 역사적 명장 | 광개토대왕 등 실존 인물 — 전략적 깊이 |
| 다자 관계 | 고구려 vs 백제 vs 신라 vs 왜 vs 동부여 — 그랜드 전략 시드 최적 |
| 명확한 위협 | 전연 침공 직후, 후燕 남하 압력, 한반도 통일 경쟁 |
| 룸 가능성 | 실제 역사 따라가도 플레이 가능, 분기도 풍부 |

### 결정 2: 4개 장르 repo 일괄 생성
> "sigco3111/ai-gm-fantasy-rpg, sigco3111/ai-gm-sci-fi-explore, sigco3111/ai-gm-mystery-detective 이 3개의 저장소와 리드미 파일도 진행해줘"

→ **기존 strategy-war 패턴 그대로 3개 복제** + 각 장르별 차별점.

## 시드 교체 워크플로우 — README 흔적 5군데

알도리아 → 고구려 교체 시 README에 흔적이 남는 위치 5~6군데를 **search_files로 한 번에 검색** 후 모두 갱신:

```bash
# 1. 한국어 흔적 검색
search_files pattern="알도리아|aldoria|Aldoria|1487|엘리사벳|elisabet|Elisabet" path=ai-gm-strategy-war

# 2. 영문 흔적 검색 (시드별 콘텐츠)
search_files pattern="kingdom-of-aldoria|queen-elisabet|capital-aldoria|constitutional_monarchy" path=ai-gm-strategy-war
```

**갱신 필요 6군데** (실제 검증):
1. 도입부 한국어 ("샘플 시드 (예: 알도리아 1487)" → "고구려 391")
2. 도입부 영문 ("Sample seeds (e.g. Aldoria 1487)" → "Goguryeo 391")
3. 4가지 결정 사항 표의 시드 행
4. "🌰 샘플 시드 미리보기" 섹션 통째 교체
5. 저장소 구조 트리의 `lore/seeds/aldoria-1487/` → `goguryeo-391/`
6. 로드맵 Phase 1의 시드 디렉토리명

**판단 포인트**: 장르 엔티티 JSON 예시 블록은 이미 `<nation_id>`, `<character_id>` 플레이스홀더로 추상화돼 있어서 시드 교체와 무관. **추상화 유지 = 장르 비종속 메시지 강화**. 굳이 시드별 스키마로 채우지 말 것.

## 4개 장르 repo 일괄 생성 — 일관성 규칙

각 장르마다 6개 파일 (장르별 차이는 README + 샘플 시드 + 엔티티 스키마):

| 파일 | 장르별 차이? | 비고 |
|------|-----------|------|
| `README.md` | ✅ 다름 | 한/영 병기, 4가지 결정, 샘플 시드, 엔티티 스키마 |
| `LICENSE` | ❌ 동일 | Apache 2.0 |
| `.gitignore` | ❌ 동일 | Python + games/ |
| `games/.gitkeep` | ❌ 동일 | placeholder |

### README 양식 (모든 장르에 공통)

```
# 타이틀 (장르 + 장르 플러그인 명시)
# 한/영 소개 → 의존성 → 🎮 새 게임을 시작하세요 → 4가지 결정 → 샘플 시드 미리보기
# → 장르 엔티티 → 저장소 구조 → 빠른 시작 → 게임플레이 루프 → 로드맵 → 톤 & 영감 → See Also
```

### 한/영 병기 규칙

- 본문: 항상 한/영 병기
- 시드명: 영문 유지 (예: Goguryeo 391)
- 엔티티 ID/스키마 키: 영문 유지
- 게임 용어 (Quest, Party, War): 영문 1회 + 한글 번역
- 4가지 결정 사항 표: 옵션은 한/영 혼합 (예: "사실주의 / 저마법 / 신화·전설")

→ **한글 README ≠ 순수 한글**. 영어 토큰을 적절히 섞는 게 sigco3111님 톤.

### 4가지 결정 사항 — 장르별 차별화

| 장르 | 1번 결정 | 2번 | 3번 | 4번 |
|------|---------|-----|-----|-----|
| 전략/전쟁 | 시대 | 톤 | 맵 규모 | 국가 |
| 판타지 RPG | 서브장르 (D&D풍/다크/무마법/동양/모더니즘) | 톤 | 스케일 | 캐릭터 빌드 (종족 + 직업) |
| SF 탐험 | 하드/소프트 SF | 톤 | 스케일 | 함선 |
| 미스터리 | 시대/배경 | 톤 | 사건 규모 | 탐정 |

→ 4가지 결정 사항이 장르마다 다름. **장르별 README에서 4가지 결정 표를 새로 작성** (그냥 복사 ❌).

### 샘플 시드 — 한국 역사 / SF / 미스터리 톤

| 장르 | 샘플 시드 | 선택 이유 |
|------|----------|---------|
| 전략/전쟁 | 고구려 391 | 한국 역사 (sigco3111님 선호) |
| 판타지 RPG | Age of Dragons 1024 (Shallowstone 마을, Red Wyrm Kargad) | 클래식 D&D 모티브 |
| SF 탐험 | Expansion Era 2247 (EAS Eurasia, Sedna-9) | Mass Effect 모티브 |
| 미스터리 | Death at Haberton Manor 1923 (잉글랜드 폭설, 1총살) | Agatha Christie 모티브 |

→ 전략/전쟁만 한국 역사, 나머지는 영문 시드. **장르별로 톤이 다름** — 일관성보다 장르 특성 우선.

## About description 작성 규칙 (한글화)

**패턴**: `[장르 설명] — [코어 의존]. [톤 한 줄]. 샘플 시드: [시드명]. [정책].`

**검증된 4개 예시**:
- `ai-gm`: *"장르 비종속 AI 게임 마스터 공통 엔진. 게임 시작 시 GM이 사용자에게 설정을 묻고 시작 — 미리정해진 세계 없음. 장르 플러그인이 위에 얹힘."*
- `ai-gm-strategy-war`: *"전략/전쟁 장르 플러그인 — ai-gm 코어 기반. 턴제 그랜드 전략. 샘플 시드: 고구려 391. 게임 시작 시 GM이 시대·톤·규모·국가를 사용자에게 묻고 시작. 미리지정 시드 없음."*
- `ai-gm-fantasy-rpg`: *"판타지 RPG 장르 플러그인 — ai-gm 코어 기반. AI GM이 던전·도시·NPC 운영. 샘플 시드: 드래곤 시대 1024. 미리지정 시드 없음."*
- `ai-gm-sci-fi-explore`: *"SF 탐험 장르 플러그인 — ai-gm 코어 기반. 함장 시점 성간 탐험. 샘플 시드: 인류 진출기 2247. 미리지정 시드 없음."*
- `ai-gm-mystery-detective`: *"미스터리/탐정 장르 플러그인 — ai-gm 코어 기반. 추리 + 심문 + 단서 추적. 샘플 시드: 하버튼 저택의 죽음 1923. 미리지정 시드 없음."*

**구성 요소**:
1. 장르 한 줄 설명
2. 코어 의존성 명시 ("ai-gm 코어 기반")
3. 톤/특징 한 줄
4. 샘플 시드 명시
5. **"미리지정 시드 없음"** 정책 (모든 장르 공통)

→ 한글 description + 4요소 모두 포함. About description은 sigco3111님이 한/영 병기 선호 (Pitfall #9와 연결).

## Topics (장르별 10개)

```bash
gh repo edit sigco3111/ai-gm-fantasy-rpg \
  --add-topic "fantasy-rpg,rpg,adventure,ai-game-master,llm,mcp,genre-plugin,korean,text-game,tabletop,open-source"

gh repo edit sigco3111/ai-gm-sci-fi-explore \
  --add-topic "sci-fi,space-exploration,ai-game-master,llm,mcp,genre-plugin,korean,text-game,starship,ftl"

gh repo edit sigco3111/ai-gm-mystery-detective \
  --add-topic "mystery,detective,noir,ai-game-master,llm,mcp,genre-plugin,korean,text-game,investigation,clue"
```

**공통 토픽 6개** (모든 장르): `ai-game-master, llm, mcp, genre-plugin, korean, text-game`
**장르별 차별 토큰 4~5개**.

## gh CLI 일괄 실행 패턴

```bash
# 3개 repo + push (병렬)
gh repo create sigco3111/ai-gm-fantasy-rpg --public \
  --description "..." \
  --source .../ai-gm-fantasy-rpg --remote=origin --push

gh repo create sigco3111/ai-gm-sci-fi-explore --public ... 
gh repo create sigco3111/ai-gm-mystery-detective --public ...

# 3개 repo topics (병렬)
gh repo edit sigco3111/ai-gm-fantasy-rpg --add-topic "..."
gh repo edit sigco3111/ai-gm-sci-fi-explore --add-topic "..."
gh repo edit sigco3111/ai-gm-mystery-detective --add-topic "..."

# 메타 repo도 카탈로그 갱신 후 푸시
cd ai-gm
git commit -am "장르 카탈로그 갱신: 4개 장르 repo 모두 공개 링크"
git push origin main
```

**전체 작업 흐름** (4개 repo):
- 로컬 디렉토리 3개 생성 + 파일 작성 (10분)
- git init × 3 + commit × 3 (1분)
- gh repo create × 3 (2분, 병렬)
- gh repo edit (topics) × 3 (1분, 병렬)
- 메타 repo 카탈로그 갱신 + 푸시 (2분)
- **총 16분**

→ 한 세션에 4개 repo 셋업 가능. **Phase 0 = "방향 정해지면 README만" 변형**의 확장판.

## 산출물 (3부)

| repo | 변경 | 커밋/액션 |
|------|------|----------|
| `ai-gm-strategy-war` | 샘플 시드 알도리아 → 고구려 교체 (6군데) | `b5ce636` |
| `ai-gm-fantasy-rpg` | 신규 생성 (README + LICENSE + .gitignore + games/) | initial commit |
| `ai-gm-sci-fi-explore` | 신규 생성 | initial commit |
| `ai-gm-mystery-detective` | 신규 생성 | initial commit |
| `ai-gm` (메타) | 장르 카탈로그 갱신 (한/영 양쪽) | `b296101` |
| About × 4 | 한글 description + 토픽 10개씩 | gh repo edit |

## 잘 작동한 것

- **시드 교체 시 search_files로 흔적 6군데 한 번에 검색** — 빠짐없이 갱신
- **4개 README 양식 일관성** — 한/영 병기 + 4가지 결정 + 큐레이션 톤 — 다른 PC에서 작업할 때 혼동 없음
- **장르별 4가지 결정 차별화** — 표를 그대로 복사 ❌, 장르 특성에 맞게 새로 작성
- **About description 4요소 패턴** — 모든 장르에 일관 적용
- **gh repo create 병렬 실행** — 토픽 추가까지 1세션 완결

## 다음 세션이 가져갈 것

- 다른 PC에서 Phase 1+ 작업
- 첫 작업: `lore/seeds/goguryeo-391/seed.json` + factions/characters/regions/overview.md
- **시드 작성 트랩**: 절대 README에 "기본 시드" 표현 만들지 말 것. 시드는 옵션.
- **시드 디렉토리 컨벤션**: `lore/seeds/<seed-name>/{factions,characters,regions,etc.}/` (시드별 격리)

## 이 case study가 검증한 스킬 함정

1. (Pitfall #8) 코어 repo 이름에 "core" 붙이지 말 것 — `ai-gm-core`는 장르 종속처럼 들림
2. (Pitfall #9) README에 "기본 시드: X" 섹션 금지 — 시드 시스템 재설계 트리거
3. (Pitfall #10 신규) 시드 교체 시 README 흔적 6군데 — search_files로 한 번에 검색
4. (Pitfall #11 신규) 시드 = 사용자가 선택, 절대 사전 지정 X — "미리지정 시드 없음" 이중 안전장치
5. (Pitfall #12 신규) 시드 콘텐츠 격리 — `lore/seeds/<seed-name>/` 하위에 위치, 전역 디렉토리 ❌
6. (신규 패턴) 4개 장르 repo 일괄 생성 — README 양식 + 4가지 결정 차별화 + About description 4요소
7. (신규 패턴) 시드 컨셉 신호 — 한국 역사, 실존 인물, 명확한 위협+기회 동시 존재
