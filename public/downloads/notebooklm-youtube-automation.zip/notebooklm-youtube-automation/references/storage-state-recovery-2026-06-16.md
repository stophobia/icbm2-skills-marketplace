# NotebookLM storage_state.json 0바이트 복구 (2026-06-16)

> 작성: 2026-06-16 (5개 노트북 업로드 세션 — CrankGPT, hera-agent-unity, AI/ML 논문, 리우데자네이루, tradingcodex)

## 현상

venv-notebooklm 복구 후 list 작동 확인했음에도 `~/.notebooklm/profiles/default/storage_state.json`이 **0바이트로 텅 빔**.

### 진단 순서

```bash
# 1. storage_state.json 크기 확인
ls -la /Users/hjshin/.notebooklm/profiles/default/storage_state.json
# → 0 bytes 또는 0B 표시

# 2. SID 쿠키 도메인 확인
/Users/hjshin/.hermes/venv-notebooklm/bin/python3 -c "
from notebooklm.auth import _load_storage_state
data = _load_storage_state()
for c in data.get('cookies', []):
    if c['name'] == 'SID':
        print('SID domain:', c['domain'])
        break
"
# → 빈 결과 또는 'NoneType' 오류

# 3. list 시도
/Users/hjshin/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json
# → {"error": true, "code": "UNEXPECTED_ERROR",
#    "message": "Unexpected error: Authentication expired or invalid. Redirected to: https://accounts.google.com/<redacted>\nRun 'notebooklm login' to re-authenticate."}
```

### 백업 복구 시도 (실패)

```bash
# 둘 다 만료된 쿠키라 복구 효과 없음
cp /Users/hjshin/.notebooklm/storage_state.json.bak.personal \
   /Users/hjshin/.notebooklm/profiles/default/storage_state.json
/Users/hjshin/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json
# → 여전히 "Authentication expired"
```

## 해결 — 풀 OAuth 재로그인

### 1단계: Playwright 설치 (필수)

```bash
/Users/hjshin/.hermes/venv-notebooklm/bin/pip install --quiet "notebooklm-py[browser]"
/Users/hjshin/.hermes/venv-notebooklm/bin/playwright install chromium
# → Chrome Headless Shell ~97.5 MiB 다운로드
```

### 2단계: notebooklm login 백그라운드 실행

```bash
/Users/hjshin/.hermes/venv-notebooklm/bin/python3 -u -m notebooklm login 2>&1
```

PTY 모드 + background + notify_on_complete=true 필수 (60초 timeout 회피). Chromium 창이 자동으로 뜨고 5분 대기.

### 3단계: 사용자가 브라우저에서 로그인

- consumer Gmail 계정 (Google Workspace 계정은 정책상 자제, 다만 list/download는 작동)
- 5분 이내 로그인 감지되면 자동 저장

### 4단계: 검증

```bash
ls -la /Users/hjshin/.notebooklm/profiles/default/storage_state.json
# → ~12KB (정상)

/Users/hjshin/.hermes/venv-notebooklm/bin/python3 -c "
from notebooklm.auth import _load_storage_state
data = _load_storage_state()
for c in data.get('cookies', []):
    if c['name'] == 'SID':
        print('SID domain:', c['domain'])
        break
"
# → .google.com (정상)
```

## 의존성 함정 — venv 재설치 시 4개 패키지 추가 (금기 #24)

OAuth 로그인만으로는 부족. `--review`/`--approved` 실행 시 또 import 오류:

```bash
# 증상 1
/Users/hjshin/.hermes/venv-notebooklm/bin/python3 /Users/hjshin/.hermes/scripts/notebooklm_upload.py --review
# → ModuleNotFoundError: No module named 'requests'

# 증상 2
... --approved
# → No module named 'google'

# 해결 (4개 한 번에)
/Users/hjshin/.hermes/venv-notebooklm/bin/pip install --quiet \
    requests \
    google-api-python-client \
    google-auth-oauthlib \
    google-auth-httplib2
```

## YouTube 토큰 refresh (금기 #25)

```bash
# venv-notebooklm엔 google.auth 없음 → 시스템 /usr/bin/python3 사용
/usr/bin/python3 -c "
import os, pickle
from google.auth.transport.requests import Request
p = os.path.expanduser('~/.hermes/secrets/youtube_token.pickle')
c = pickle.load(open(p,'rb'))
if not c.valid:
    c.refresh(Request())
    pickle.dump(c, open(p,'wb'))
    print('✅ refresh 성공')
"
# → FutureWarning(EOL Python 3.9)/NotOpenSSLWarning(LibreSSL 2.8.3) 무시
```

## 5개 업로드 결과 (실측 검증)

| # | 주제 | 일반 영상 | Shorts | 소요 |
|---|------|-----------|--------|------|
| 1 | CrankGPT | mViQdhyerqI | JP8AAdkGaqI | 17:47:54 ~ 17:48:09 |
| 2 | hera-agent-unity | lkGESX8MX2I | 83YbAhzgWK0 | 17:48:24 ~ 17:48:40 |
| 3 | AI/ML 논문 | CYdE_rGrt0c | PmIAh8hGNTo | 17:48:58 ~ 17:49:16 |
| 4 | 리우데자네이루 | p-_NXVXnsgI | wL-EarGMYS4 | 17:49:34 ~ 17:49:49 |
| 5 | tradingcodex | _adyLWYjvps | y6g1f0EZii8 | 17:50:06 ~ 17:50:20 |

**총 5분 30초**, 10/10 성공, 5개 노트북 cleanup 정상.

## 예방 — venv 셋업 표준화

```bash
# ~/.hermes/scripts/setup_venv_notebooklm.sh 패턴 권장
/usr/local/opt/python@3.12/bin/python3.12 -m venv --clear venv-notebooklm
./bin/pip install --quiet --upgrade pip
./bin/pip install --quiet \
    notebooklm-py[browser] \
    requests \
    google-api-python-client \
    google-auth-oauthlib \
    google-auth-httplib2
./bin/playwright install chromium
./bin/python3 -m notebooklm list --json | head -3   # 인증 검증
# → 인증 살아있으면 list 정상, 0바이트면 풀 OAuth 필요
```

## 디버깅 체크리스트

| 증상 | 원인 | 해결 |
|------|------|------|
| `Playwright not installed` | browser extra 미설치 | `pip install "notebooklm-py[browser]"` + `playwright install chromium` |
| `Authentication expired` | storage_state.json 0바이트 | 풀 OAuth 재로그인 (위 1~4단계) |
| `ModuleNotFoundError: No module named 'requests'` | venv 의존성 누락 | `pip install requests` |
| `No module named 'google'` | google-api-python-client 누락 | 4개 패키지 한 번에 설치 |
| OAuth URL은 떴는데 5분 지나도 반응 없음 | 브라우저 창이 백그라운드 | Dock에서 Chromium 아이콘 클릭, 창이 안 보이면 `ps aux \| grep -E "playwright|notebooklm"` |
| 로그인 후 storage_state.json 여전히 0바이트 | OAuth race condition | 한 번 더 `notebooklm login` 실행, 백업에서 복구 후 재시도 |
| Workspace 계정(ubob.com) 쿠키 (.google.co.kr) | 정책 위반 | Gmail.com 개인 계정으로 재로그인 (브라우저 프로필 초기화) |
