# fireToken — 컨텍스트 자동 관리 + Windows native 부트스트랩

> 2026-06-19 fireToken v0.1.0 부트스트랩 세션에서 검증된 컨텍스트 운영 매뉴얼 +
> Windows native 부트스트랩 절차 + "묵묵히 + 최종 보고" 워크플로.

## 🪟 Windows native 부트스트랩 8단계

fireToken (sigco3111/fireToken v0.1.0, 2026-06-19) 사례 기반. Python 대신
PowerShell 5.1+ + Batch (.bat) 듀얼 스택으로 OSS를 부트스트랩할 때 적용.

### 1단계: 브레인스토밍 (결정 포인트별 옵션)

사용자 요청을 받으면 **먼저 결정 포인트 옵션 2~3개 + 추천** 제시:

| 결정 포인트 | 옵션 A | 옵션 B | 옵션 C |
|---|---|---|---|
| **이름** | ... | ... | ... (추천) |
| **타겟 OS** | Windows native | WSL2 | 크로스플랫폼 |
| **LLM** | NIM gpt-oss-120b | HF Inference | OpenRouter |
| **부스트 전략** | A+B+C+D (풀옵션) | A만 | B+C |
| **범위** | α 미니멀 | β 표준 | γ 풀세트 |
| **공개** | private | public | internal |

사용자 확정 시 즉시 실행 모드 진입.

### 2단계: 워크스페이스 + 파일 작성 (한 세션)

```bash
mkdir -p ~/workspace/<name>/scripts ~/workspace/<name>/docs
cd ~/workspace/<name>
git init -b main
```

작성 파일 12개:
1. `README.md` — 한/영 병기 + 다층 옵션 + 시스템 요구사항 + 옵션 + 안전장치 + 면책
2. `AGENTS.md` — 다른 PC 작업자용 (환경 체크 + 함정 + Git 워크플로)
3. `LICENSE` — MIT + 면책 조항
4. `.gitignore` — Windows + PowerShell + secret 보호
5. `scripts/<name>.bat` — 더블클릭/Task Scheduler 진입점
6. `scripts/<name>.ps1` — 메인 오케스트레이터 (파라미터 + 환경 체크 + 메인 루프)
7. `scripts/context_manager.ps1` — 컨텍스트 자동 슬라이딩/리셋
8. `scripts/inject_input.ps1` — 입력 부풀리기 (junk text 생성)
9. `scripts/setup-task.bat` — Task Scheduler 등록
10. `docs/STRATEGY.md` — 핵심 알고리즘 상세
11. `docs/CONTEXT_MANAGEMENT.md` — 한도 운영 매뉴얼
12. `docs/ARCHITECTURE.md` — 시스템 구조 + 데이터 흐름

### 3단계: git commit (한 줄)

```bash
git add . && git -c user.name="sigco3111" \
  -c user.email="sigco3111@users.noreply.github.com" \
  commit -m "feat: <name> v0.1.0 - <한 줄 요약>

- <주요 기능 1>
- <주요 기능 2>
- ...
"
```

### 4단계: gh repo create + push (private 가능, 한 줄)

```bash
gh repo create sigco3111/<name> --private --source=. \
  --description "<한글 한 줄>" --push
```

⚠️ `--license MIT` 옵션 일부 gh 버전에서 도움말만 출력 → **파일로 직접 push** (License 함정 회피).

### 5단계: GitHub API 검증 (트리 확인)

```bash
gh api repos/sigco3111/<name>/git/trees/main?recursive=1 \
  --jq '.tree | map({path, type, sha: .sha[0:7]})'
```

→ 12개 파일 모두 blob으로 존재해야 OK.

### 6단계: raw URL 검증 (private repo 함정 회피)

```bash
# ❌ 비공개 repo는 raw URL 404 (raw는 public 전용)
curl -s -o /dev/null -w "%{http_code}" \
  "https://raw.githubusercontent.com/sigco3111/<name>/main/README.md"
# → 404

# ✅ 인증 토큰 필요
curl -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: token $GH_TOKEN" \
  "https://raw.githubusercontent.com/sigco3111/<name>/main/README.md"
# → 200
```

### 7단계: GitHub tree + size 확인

```bash
gh api repos/sigco3111/<name>/git/trees/main?recursive=1 \
  --jq '.tree | .[] | "\(.type[0:4]) \(.sha) \(.path)"'
```

각 파일의 SHA + size가 표시되면 푸시 검증 완료.

### 8단계: 사용자 가이드 안내 (최종 보고)

✅ 결과 요약 표 + 📦 산출물 트리 + 🚀 즉시 사용법 + 🔄 다음 단계

---

## 🔄 컨텍스트 자동 관리 (120K 한도)

### 임계치 맵

```
0K ─────────── 80K ─────────── 100K ────────── 120K (CAP)
│              │                │                │
│   safe       │   warning      │   critical     │
│   (신규 세션) │   (슬라이딩)   │   (강제 초기화) │
```

### 정책 4종

| 정책 | 80K | 100K | 120K |
|---|---|---|---|
| `slide` (기본) | history 30% drop | history 30% drop | history 30% drop |
| `reset` | history clear | history clear | history clear |
| `warn` | 로그만 | `slide` | `slide` |
| `hard` | history clear | history clear | **새 세션 ID** |

### 구현 (PowerShell)

```powershell
$script:ContextCap = 120000
$script:SlideThreshold = 80000
$script:ResetThreshold = 100000

function Test-ContextOverflow {
    param([int]$CurrentTokens, [string]$Policy)

    if ($CurrentTokens -ge $script:ContextCap) {
        Write-Host "[HARD] 120K cap 도달 (현재: $CurrentTokens)" -ForegroundColor Red
        return "hard"
    } elseif ($CurrentTokens -ge $script:ResetThreshold) {
        Write-Host "[$Policy] 100K 도달 (현재: $CurrentTokens)" -ForegroundColor Yellow
        return $Policy
    } elseif ($CurrentTokens -ge $script:SlideThreshold) {
        Write-Host "[slide] 80K 도달 (현재: $CurrentTokens)" -ForegroundColor Cyan
        return "slide"
    } else {
        return $null
    }
}

function Invoke-ContextSlide {
    param([array]$Messages, [int]$KeepRatio = 70)

    if ($Messages.Count -le 2) { return $Messages }

    $system = $Messages[0]
    $history = $Messages[1..($Messages.Count - 1)]
    $keepCount = [Math]::Floor($history.Count * $KeepRatio / 100)
    if ($keepCount -lt 1) { $keepCount = 1 }
    $trimmed = $history[($history.Count - $keepCount)..($history.Count - 1)]
    return @($system) + $trimmed
}
```

### 안전장치 통합

- **NIM 40 rpm 자동 throttle** — 5세션 × 8 rpm = 7.5초/요청 sleep
- **3회 연속 실패 → 세션 종료** — exponential backoff (5s, 10s, 15s)
- **CPU 80% → 세션 자동 종료** — `Get-Counter`로 모니터링
- **API key 마스킹** — 로그에 평문 노출 방지 (`Substring(0, 7) + "***" + Substring(-4)`)

---

## 🤫 "묵묵히 + 최종 보고" 워크플로

### 트리거 (사용자 "B" 옵션 선택)

부트스트랩 5단계 이상 + 사전 결정 완료 + 검증 가능한 산출물.

### 워크플로

1. **todo 리스트 생성** (전체 단계 한 번에)
2. **중간 작업** — 상태만 짧게 표시 (예: "📄 README.md 작성 중...")
3. **모든 작업 완료 후** — 한 번에 최종 보고
4. **보고 포맷** — ✅ 결과 요약 표 + 📦 산출물 트리 + 🚀 사용법 + 🔄 다음 단계

### 반대로 "단계별 보고"가 필요한 경우

- 디버깅/트러블슈팅 (사용자 결정介入)
- 다중 PC 협업 (다음 단계 지시)
- 위험한 작업 (rm, 외부 API POST 승인)

### 검증된 사례

- **fireToken v0.1.0** (2026-06-19) — "묵묵히" 모드로 12개 파일 작성 + 비공개 repo 푸시 + GitHub API 검증. 사용자는 todo 15개 중 1개만 보고 후 "진행상황은?" 한 번 물어봄.

---

## ⚠️ 함정 6가지 (Windows native + NIM 신규)

1. **`raw.githubusercontent.com` 비공개 repo 404** — 비공개 repo raw URL은 인증 없이 404. `Authorization: token $GH_TOKEN` 헤더 필수.

2. **`--license MIT` 일부 gh 버전 버그** — 도움말만 출력되는 현상. LICENSE는 파일로 직접 push.

3. **PowerShell `ExecutionPolicy` Restricted** — 기본값이 Restricted. `-ExecutionPolicy Bypass` 필수.

4. **PowerShell `Start-Job` 출력 캡처** — `Wait-Job` 단독은 출력 손실. `Receive-Job -Keep` 폴링 패턴.

5. **NIM `reasoning_effort` 응답 필드 안전 접근** — `getattr(choice.message, "reasoning_content", None)` 패턴. JSON 직접 파싱 시 `dict.get()`.

6. **Bearer 토큰 마스킹** — 로그 노출 방지 (`Substring(0, 7) + "***" + Substring(-4)`).

---

## 📜 검증된 사례

- **fireToken v0.1.0** (2026-06-19, sigco3111/fireToken 비공개)
  - 12개 파일, ~57KB
  - NIM `openai/gpt-oss-120b` 무료 tier + reasoning 모델 + 5세션 병렬 + 컨텍스트 자동 관리
  - 부트스트랩 절차 검증 (이 문서의 8단계 그대로)