---
name: agent-benchmark-tracker
description: AI 에이전트/모델 벤치마크 결과를 추적하여 Notion에 기록 — SWE-bench, HumanEval, GAIA, WebArena, LiveCodeBench 등
version: 1.0.0
author: icbm2
metadata:
  hermes:
    tags: [AI, Benchmark, Agent, Notion, Weekly]
prerequisites:
  secret_files: [notion_token.txt]
---

# AI 에이전트 벤치마크 트래커

AI 모델/에이전트의 벤치마크 성능 결과를 주간으로 추적하여 Notion DB에 기록합니다. 코딩, 추론, 에이전트 능력 등 다양한 벤치마크를 종합 관리합니다.

## Notion DB

- **DB ID:** `34076f2e-9097-81a0-9314-c781e2742b83`
- **DB명:** Agent Benchmark Tracker
- **속성:**
  - Name(title): "모델명 — 벤치마크명" (예: "Claude 4 Opus — SWE-bench Verified")
  - Date(date): 결과 발표/업데이트 날짜
  - Model(rich_text): 모델명 (예: Claude 4 Opus, GPT-5, Gemini 2.5 Pro)
  - Provider(rich_text): 제공사 (OpenAI, Anthropic, Google, Meta, Mistral, DeepSeek 등)
  - Benchmark(select): 벤치마크 이름
  - Score(number): 점수 (퍼센트 또는 점수)
  - Tier(url): 성능 등급 — ⚠️ 실제 DB에서 url 타입으로 설정되어 있어 Notion 속성으로 기록 불가. 페이지 본문 상단에 `[S]`, `[A]`等形式으로 표기할 것
  - URL(url): 출처 링크
- **Benchmark 옵션:** SWE-bench Verified, SWE-bench Lite, HumanEval+, LiveCodeBench, GAIA, WebArena, Aider Polyglot, CodeForces, MMLU-Pro, GPQA, ARC-AGI, MATH, **AIME**, Other
- **Tier 등급 기준:** S(90%+), A(80-89%), B(70-79%), C(60-69%), D(<60%)

## 추적 벤치마크 목록

### 코딩 (Coding)
| 벤치마크 | 설명 | 측정 항목 |
|----------|------|----------|
| SWE-bench Verified | 실제 GitHub 이슈 해결 | resolve % |
| SWE-bench Lite | SWE-bench 축약版 | resolve % |
| LiveCodeBench | 라이브 코딩 경진대회 | pass@1 % |
| HumanEval+ | 함수 생성 | pass@1 % |
| Aider Polyglot | 다국어 코드 편집 | % completed |
| CodeForces | 경쟁 프로그래밍 | rating/점수 |

### 추론 (Reasoning)
| 벤치마크 | 설명 | 측정 항목 |
|----------|------|----------|
| GPQA | 대학원 수준 Q&A | 정확도 % |
| MMLU-Pro | 다분야 지식 | 정확도 % |
| ARC-AGI | 추론 능력 | 점수 |
| MATH | 수학 문제 해결 | 정확도 % |
| AIME 2024/2025 | 수학 경시대회 | 점수 |

### 에이전트 (Agent)
| 벤치마크 | 설명 | 측정 항목 |
|----------|------|----------|
| GAIA | 일반 AI 어시스턴트 | 정확도 % |
| WebArena | 웹 자동화 | 성공률 % |
| TAU-bench | 항공/소매 에이전트 | 성공률 % |
| OSWorld | OS 자동화 | 성공률 % |
| RULER | 긴 컨텍스트 이해 | 정확도 % |

## 실행 단계

### 1. 데이터 수집

> ⚠️ **중요:** 공식 리더보드 페이지(swebench.com, livecodebench.github.io)는 JavaScript 기반 렌더링으로 HTML 페치 시 데이터가 비어 있습니다. 반드시 아래 **검증된 소스**를 사용하세요.

#### 검증된 소스 (실제 데이터 확보 가능)

| 벤치마크 | 가장 신뢰할 수 있는 소스 | 백업 소스 |
|----------|------------------------|-----------|
| SWE-bench Verified | `https://llm-stats.com/benchmarks/swe-bench-verified` | `https://aiflashreport.com/benchmarks/swe-bench-verified/` |
| LiveCodeBench v6 | `https://llm-stats.com/benchmarks/livecodebench-v6` | `https://aiflashreport.com/benchmarks/livecodebench/` (v5, 99개 모델) |
| LiveCodeBench (일반) | `https://artificialanalysis.ai/evaluations/livecodebench` | — |
| 기타 벤치마크 | `https://llm-stats.com/benchmarks` ( 종합) | — |

#### 데이터 수집 파이프라인

```bash
# 1. llm-stats.com에서 SWE-bench Verified + LiveCodeBench v6 데이터를 먼저 확보
# fetch_content로 leaderboard 테이블 전체 확보 가능

# 2. aiflashreport.com은 모델 수가 더 많음 (LiveCodeBench v5 = 99개 모델)
# llm-stats.com은 최신 v6 데이터 (45개 모델)

# 3. official 리더보드는 JavaScript 렌더링 — fetch_content로 데이터 획득 불가
# swebench.com/verified.html → 텍스트 설명만, 테이블 없음
# livecodebench.github.io → "Loading..."만 반환

# 4. search 도구로 HN/Reddit 검색은 site: 한정자 사용 시 대부분 실패
# 대신 웹 검색 + fetch_content 조합으로 데이터 수집
```

#### 파이썬 기반 수집 예시

```python
import subprocess

def fetch_leaderboard(url):
    r = subprocess.run(
        ['curl', '-s', url],
        capture_output=True, text=True
    )
    return r.stdout  # HTML에서 테이블 파싱 필요

# llm-stats.com은 테이블 구조로 데이터 제공 → fetch_content로 충분
# aiflashreport.com도 유사한 테이블 구조
```

### 2. Notion에 기록

```python
import os, json, subprocess
from datetime import datetime, timezone, timedelta

TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
DB_ID = "34076f2e-9097-81a0-9314-c781e2742b83"
today = datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")

with open(TK_PATH) as f:
    tk = f.read().strip()

def calc_tier(score):
    if score >= 90: return "S"
    elif score >= 80: return "A"
    elif score >= 70: return "B"
    elif score >= 60: return "C"
    else: return "D"

def add_entry(title, model, provider, benchmark, score, url, summary, tier):
    # ⚠️ Tier 필드는 DB에서 url 타입으로 설정되어 있어 속성 기록 불가 — tier를 본문 앞에 표기
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": title}}]},
            "Date": {"date": {"start": today}},
            "Model": {"rich_text": [{"text": {"content": model}}]},
            "Provider": {"rich_text": [{"text": {"content": provider}}]},
            "Benchmark": {"select": {"name": benchmark}},
            "Score": {"number": score},
            "URL": {"url": url}
        },
        "children": [
            {
                "object": "block",
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"text": {"content": f"[{tier}] {summary}"}}]
                }
            }
        ]
    }
    with open("/tmp/notion_entry.json", "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    env = dict(os.environ)
    env["NTK"] = tk
    r = subprocess.run(
        f'curl -s -X POST --max-time 15 https://api.notion.com/v1/pages -H "Authorization: Bearer $NTK" -H "Notion-Version: 2022-06-28" -H "Content-Type: application/json" -d @/tmp/notion_entry.json',
        shell=True, capture_output=True, text=True, env=env
    )
    return r.stdout

# 사용 예시
add_entry(
    title="Claude 4 Opus — SWE-bench Verified",
    model="Claude 4 Opus",
    provider="Anthropic",
    benchmark="SWE-bench Verified",
    score=72.5,
    url="https://www.swe-bench.com/",
    summary="Anthropic Claude 4 Opus가 SWE-bench Verified에서 72.5%를 기록했다.",
    tier="B"
)
```

### 3. 품질 기준

- **최소 5개, 최대 15개** 항목 기록 (주간)
- 최근 1주일간 발표/업데이트된 결과만 포함
- 반드시 Score와 Tier를 계산하여 기입
- 각 항목에 1-2문장 요약을 페이지 본문에 추가:
  - 어떤 변화가 있었는지 (새 기록, 개선폭, 이전 모델 대비 등)
  - 의미 있는 인사이트
- **URL 속성은 항상 기록** (공식 리더보드, 논문, 발표 페이지)
- 한국어로 작성
- 이미 기록된 모델+벤치마크 조합은 갱신하지 않음 (신규 결과만)

### 4. 주간 요약 (페이지 본문)

모든 항목 기록 후, 주간 트렌드 요약을 작성:
- 이번 주 가장 큰 성과를 낸 모델
- 가장 큰 점프를 기록한 벤치마크
- 새로 등장한 벤치마크나 평가 방식
- 코딩/추론/에이전트 분야별 순위 변동

## 스케줄

- **크론:** 매주 일요일 09:00 KST
- **delivery:** origin (Telegram)

## 참고

- ai-model-tracker 스킬과 보완 관계 (모델 트래커는 출시/업데이트, 벤치마크 트래커는 성능 결과)
- 점수 비교 시 동일 조건(pass@1, few-shot 수 등) 확인 필수

## ⚠️ 흔한 함정

**Tier 필드 에러:** DB의 Tier 필드는 `url` 타입으로 설정되어 있어 `{"select": {"name": tier}}`를 사용하면 `validation_error`가 발생합니다. Tier 값은 항상 페이지 본문 상단에 `[S]` / `[A]`等形式으로 표기하고, Tier 속성은 payload에서 생략하세요.

**토큰 경로:** `os.environ["NOTION_TOKEN_PATH"]`가 아닌 `os.path.expanduser("~/.hermes/secrets/notion_token.txt")`을 사용하세요.

**신규 삽입 전 검증:** 동일한 모델+벤치마크 조합이 이미 존재하는지 DB를 먼저 쿼리(`POST /databases/{id}/query`)하여 중복을 방지하세요. 기록된 조합은 갱신하지 않고 신규 결과만 추가합니다.

**LiveCodeBench 버전 주의:** llm-stats.com은 LiveCodeBench **v6** (45개 모델), aiflashreport.com은 v5 (99개 모델)를 제공합니다. 둘 다 참조하되, DB 기록 시 어떤 버전인지 URL로 구분하세요.

**검색 도구 제한:** DuckDuckGo MCP (`mcp_ddg_search_search`)는 `site:news.ycombinator.com`, `site:reddit.com` 등 사이트 한정 검색 시 대부분의 경우 빈 결과를 반환합니다. 벤치마크 데이터는 항상 fetch_content로 리더보드 페이지를 직접 가져오는 방식으로 수집하세요.
