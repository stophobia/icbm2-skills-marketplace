#!/usr/bin/env python3
"""
이퀄라이저 웨이브 바 애니메이션 생성기
RGBA PNG 시퀀스 → GIF (투명 배경 보존)
"""
from PIL import Image, ImageDraw
import math, os, sys, subprocess

def generate_wave_animation(output_dir=".", num_frames=30, fps=30):
    """
    투명 배경 이퀄라이저 바 애니메이션 생성
    
    Args:
        output_dir: 출력 디렉토리
        num_frames: 프레임 수 (기본 30 = 1초 @30fps)
        fps: 프레임레이트
    """
    os.makedirs(output_dir, exist_ok=True)
    
    w, h = 360, 120  # 이퀄라이저 전체 크기
    num_bars = 20
    bar_w = 12
    bar_spacing = 6
    margin_bottom = 15
    
    # 네온 핑크 → 보라 → 블루 그라데이션
    colors = [
        (255, 80, 120),
        (200, 80, 180),
        (120, 80, 255),
        (80, 150, 255),
    ]
    
    import random
    random.seed(42)
    base_heights = [random.randint(30, 80) for _ in range(num_bars)]
    
    # PNG 프레임 생성
    for frame in range(num_frames):
        img = Image.new('RGBA', (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        phase = frame * 0.3
        
        for i in range(num_bars):
            wave = math.sin(phase + i * 0.4) * 0.4 + 0.6
            bar_h = int(base_heights[i] * wave)
            bar_h = max(10, min(bar_h, h - margin_bottom - 10))
            
            x = i * (bar_w + bar_spacing)
            y = h - margin_bottom - bar_h
            
            color_idx = int((i / num_bars) * (len(colors) - 1))
            color = colors[min(color_idx, len(colors) - 1)]
            
            draw.rounded_rectangle(
                [x, y, x + bar_w, h - margin_bottom],
                radius=4,
                fill=color + (220,)
            )
        
        img.save(f'{output_dir}/wave_{frame:03d}.png')
        img.close()
    
    print(f"Generated {num_frames} frames → {output_dir}/")
    return output_dir

def make_gif(png_dir, output_gif, fps=30):
    """PNG 시퀀스 → GIF (palettegen으로 투명도 보존)"""
    palette_path = os.path.join(png_dir, "palette.png")
    
    # palette 생성
    subprocess.run([
        "ffmpeg", "-y",
        "-framerate", str(fps),
        "-i", f"{png_dir}/wave_%03d.png",
        "-vf", "palettegen=stats_mode=diff",
        palette_path
    ], capture_output=True)
    
    # GIF 인코딩
    subprocess.run([
        "ffmpeg", "-y",
        "-framerate", str(fps),
        "-i", f"{png_dir}/wave_%03d.png",
        "-i", palette_path,
        "-lavfi", "paletteuse=dither=bayer:bayer_scale=3:diff_mode=rectangle",
        "-loop", "0",
        output_gif
    ], capture_output=True)
    
    print(f"GIF created: {output_gif}")

if __name__ == "__main__":
    # 사용법: python3 wave_animator.py [output_dir]
    out_dir = sys.argv[1] if len(sys.argv) > 1 else "."
    frames_dir = os.path.join(out_dir, "wave_frames")
    
    generate_wave_animation(frames_dir, num_frames=30, fps=30)
    make_gif(frames_dir, os.path.join(out_dir, "wave_loop.gif"), fps=30)
    print("Done!")