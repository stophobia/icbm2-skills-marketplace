# Patch-Disaster Case Studies

Real examples of structural patches going wrong in the LLM Wiki, with the
exact `old_string` / `new_string` that caused the failure and the recovery
pattern. Read this once after encountering the "Patching a file to insert
section N+1" pitfall.

## Case 1: Inserting a new numbered section wipes the next section's header (2026-06-05)

**File**: `concepts/ai-agents-trends-2026.md` (had sections ### 1 through ### 15)

**Intent**: Add a new `### 16. 구글 드림빈즈 (Dreambeans)` section after section 15.

**Disaster patch**:

```python
# WRONG — collapsed structure
patch(
    old_string = "### 15. OpenAI Codex 비개발자 확장 + Microsoft 자체 MAI 모델 (2026-06-04)",
    new_string = """### 16. 구글 드림빈즈 (Dreambeans) — Personal Intelligence 공개 (2026-06-05)
- [[dreambeans]] — 구글 랩스 일일 AI 브리핑 앱 ...
- ...
- [[codex]] — 500만 사용자, 비개발자 20%·3배 빠른 성장 ...
- [[mai-code-1-flash]] — Microsoft 첫 자체 코딩 모델 ...
- 의미: Anthropic Skills/Cowork vs OpenAI Codex Plugins/Sites ...
- [[claude-cowork]]와 직접 경쟁 ...
- [[context-mode]]와 맞물림 ...
"""
)
```

The patch tool did the string replacement cleanly — but section 15's body
content (5 bullet lines, including the `### 15.` header line) was inside
the matched `old_string` neighborhood, and the `new_string` only had the
new `### 16.` section + the original section 15 body. Result: section 15
header disappeared, section 16 was created, and section 15's bullets
became part of section 16's body. Structurally broken.

**Recovery**: Second patch that re-introduced the `### 15. ...` header
between section 14 and section 16, restoring the original structure.

**Safe pattern for "insert section N+1 before existing section N"**:

```python
patch(
    old_string = """### 15. OpenAI Codex 비개발자 확장 + Microsoft 자체 MAI 모델 (2026-06-04)
- [[codex]] — 500만 사용자, 비개발자 20%·3배 빠른 성장 ...
""",
    new_string = """### 16. 구글 드림빈즈 (Dreambeans) — Personal Intelligence 공개 (2026-06-05)
- [[dreambeans]] — 구글 랩스 일일 AI 브리핑 앱 ...
- 의미: ...
- [[openai-smartphone-2028]]·[[gemini-intelligence]] ...

### 15. OpenAI Codex 비개발자 확장 + Microsoft 자체 MAI 모델 (2026-06-04)
- [[codex]] — 500만 사용자, 비개발자 20%·3배 빠른 성장 ...
"""
)
```

The `old_string` ends at section 15's first line, and `new_string` puts
section 16 ABOVE the verbatim section 15 header. Both sections survive.

**Alternative safe pattern — append at end of file**:

```python
# Read the file, find the last bullet of section 15. Patch by
# replacing the last bullet with "last bullet + blank + section 16".
patch(
    old_string = "- [[context-mode]]와 맞물림 — 적응형 응답 길이 = 토큰 효율 트렌드 공통 화두\n",
    new_string = "- [[context-mode]]와 맞물림 — 적응형 응답 길이 = 토큰 효율 트렌드 공주 화두\n\n### 16. 구글 드림빈즈 ...\n- ...\n"
)
```

This works because the last line of section 15 is a unique anchor
(appears exactly once in the file) and we append the new section AFTER
it. No section header is at risk.

**Always**: re-read the patched file end-to-end to confirm section count
and headers survived before moving on.

## Case 2: Wikilink to non-existent page written into a new entity (2026-06-05)

**File**: `entities/dreambeans.md`

**Drafted wikilinks**:
- `[[google-labs]]` — no page exists (it's the developer org name, never got its own entity)
- `[[nano-banana-2]]` — no page exists (the model is only mentioned in `[[vision-banana]]`)

**Detection**: ran `ls ~/wiki/entities/ | grep -iE "vision|nano|google"` after
drafting the page, before writing. Saw neither slug existed.

**Fix**: patched the file to convert those wikilinks to plain text:

```diff
-- [[google-labs]] — 드림빈즈 개발 조직
+- **구글 랩스(Google Labs)** — 드림빈즈 개발 조직. 별도 페이지 미존재
-- [[nano-banana-2]] / [[vision-banana]] — 드림빈즈의 일러스트 생성 기반
+- [[vision-banana]] — 드림빈즈의 일러스트 생성 기반(추정)
```

If undetected, both links would have been broken wikilinks in the index
and Obsidian graph view until the next lint caught them.

**Lesson**: the `ls`-based pre-write verification is cheap (one command
listing the relevant directory) and prevents the entire class of broken
wikilinks. Do it before `write_file`, not after.

## Case 3: No-op detection correctly skipped a re-run item (2026-06-05)

**Context**: The Notion collector script returned 2 items:
1. Dreambeans — new, processed normally
2. Codex 역할별 플러그인 — already processed in 2026-06-04 sync

**Detection**: searched `log.md` for the most recent sync entry
(`## [2026-06-04] ingest | Notion Dev News → LLM Wiki 동기화`) and
confirmed both items appeared in that single entry. The Codex article
was registered, the raw source file existed, the entity page existed,
the concept section existed.

**Action**: did not re-fetch content, did not re-create pages. Logged
the no-op note in this session's log entry under "Already registered"
and "Idempotency note" sections. The Codex article's continued
re-appearance in the Notion digest is a known script bug — the script
doesn't mark processed items in Notion. This is the third occurrence
of this issue (logged on 2026-04-12 and 2026-06-02 as well).

**Lesson**: the no-op detection pattern works. The recurring underlying
bug is the collector script's lack of marking. File this as a follow-up
recommendation each time it occurs, so the eventual fix to
`notion_news_to_wiki.py` accumulates enough signal to be prioritized.
