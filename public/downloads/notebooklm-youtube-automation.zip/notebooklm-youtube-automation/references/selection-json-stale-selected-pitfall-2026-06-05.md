# selection.json `selected` 배열 stale 함정 (2026-06-05)

## 증상

사후에 새 토픽을 추가한 뒤 `prepare.py`를 재실행하면, **선택하지 않은 이전 토픽까지 다시 처리**되어 불필요한 노트북이 재생성됨. 이미 업로드된 영상이 다시 업로드되지는 않지만 (selection_numbers 기준이 아니므로) NotebookLM 측에 노트북이 새로 만들어지고 source add까지 실행됨.

## 발생 경로 (2026-06-05 실측)

### 타임라인

| 시각 | 액션 | 결과 |
|------|------|------|
| 16:00 | 크론 `notebooklm_selection.py` 실행 | `selection.json`에 topics 12개 생성, selection_numbers=[] |
| 16:15 | `selection_numbers = [1, 4, 5]` 설정 후 prepare.py 실행 | 노트북 3개 생성 (ID: `90353606`, `09c3ac62`, `b38517cd`) |
| 16:43 | `notebooklm_upload.py --approved` | 6개 영상 업로드 + **cleanup 단계에서 3개 노트북 모두 삭제** |
| 16:51 | OpenAI Memory Dreaming 주제 사후 추가 | `selection_numbers = [13]` 설정, **selected는 [topic1, topic4, topic5, topic13]으로 잘못 append** |
| 16:52 | prepare.py 재실행 | 4/4 처리 → 노트북 4개 모두 재생성 (1, 4, 5번이 새 ID로 만들어짐) |

### 잘못된 Python (내가 실행)

```python
d["topics"].append(new_topic)
d["selected"].append(new_topic)        # ❌ append — 이전 토픽이 남음
new_num = len(d["topics"])
d["selection_numbers"] = [new_num]     # 이것만 [13]인데 selected는 4개
```

`prepare.py`는 `selected` 배열 길이만큼 처리하므로, 4개 모두 다시 만들어짐.

## 원인

`prepare.py`의 `selected` 처리 로직:
- `selected`가 비어있으면 `selection_numbers → topics` 매핑으로 자동 복원 (정상)
- `selected`에 항목이 있으면 **그대로 사용** (이전 항목 무시 안 함)

사후 추가 시 `selected`가 이전 실행의 항목(1, 4, 5)을 그대로 갖고 있으면, 새 토픽(13)뿐 아니라 그것까지 같이 처리됨.

## 올바른 Python

```python
d["topics"].append(new_topic)
d["selected"] = [d["topics"][-1]]      # ✅ REPLACE — 새 토픽 하나만
d["selection_numbers"] = [len(d["topics"])]
```

## 멱등성 (#10)과의 상호작용

`prepare.py`는 같은 제목의 노트북이 존재하면 skip하는 멱등성이 있다 (금기 #10). 그러나:

1. 업로드 후 cleanup이 노트북을 삭제함 (금기 #11)
2. 다음 prepare.py 실행 시 같은 제목의 노트북이 **존재하지 않음**
3. 멱등성 체크가 안 걸리므로 **새 노트북이 재생성됨**

즉, 멱등성은 "한 라이프사이클 (생성 → 사용 → 삭제)" 내에서만 유효. 라이프사이클이 끝난 노트북은 재생성됨.

## 영향

- **NotebookLM 측 자원 낭비**: 불필요한 노트북 3개 + source add 3회
- **사용자 경험**: NotebookLM 목록에 이전에 다뤘던 노트북이 다시 나타남
- **YouTube 업로드**: 영향 없음 (selection.json의 date/topic_url 기반이라)

이미 업로드된 영상은 그대로 유지되므로 "치명적"은 아니지만, 멱등성 보장과 자원 효율 측면에서 명확히 개선할 부분.

## 재발 방지

| 체크 | 방법 |
|------|------|
| `selected` 길이 == `selection_numbers` 길이 | `assert len(d["selected"]) == len(d["selection_numbers"])` |
| `selected` 내용이 `selection_numbers` 매핑과 일치 | `assert all(d["selected"][i] == d["topics"][n-1] for i, n in enumerate(d["selection_numbers"]))` |
| 사후 추가 시 REPLACE | `d["selected"] = [d["topics"][-1]]` (append 금지) |

## 검증 명령

```python
import json
path = "/Users/hjshin/.hermes/memory/notebooklm_selection.json"
with open(path) as f:
    d = json.load(f)
nums = d["selection_numbers"]
sel = d["selected"]
print(f"selection_numbers: {nums}")
print(f"selected 길이: {len(sel)}")
print(f"selected 내용 매핑: {[d['topics'][n-1]['name'][:30] for n in nums]}")
assert len(sel) == len(nums), "❌ selected와 selection_numbers 길이 불일치"
print("✅ 정상")
```
