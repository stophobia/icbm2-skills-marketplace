# YouTube OAuth 재인증 절차

> 작성: 2026-06-04 (NotebookLM 업로드 토큰 만료 + 스코프 부족 이슈)

## 발생 시나리오

| 증상 | 원인 | 해결 |
|------|------|------|
| `invalid_grant: Token has been expired or revoked.` | access_token 만료 + refresh_token도 revoke | 풀 OAuth 재발급 |
| `Request had insufficient authentication scopes.` | `youtube.upload` 스코프만 있는 토큰으로 delete/search 시도 | 더 넓은 스코프로 재발급 |
| 토큰이 invalid_grant인데 refresh_token 있다고 나옴 | refresh_token도 만료/revoke된 상태 | 풀 OAuth 재발급 |

## 자동 갱신 시도 (refresh_token 사용)

```python
from google.auth.transport.requests import Request
import pickle

TOKEN_PATH = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")

with open(TOKEN_PATH, "rb") as f:
    creds = pickle.load(f)

if creds.refresh_token and not creds.valid:
    try:
        creds.refresh(Request())
        with open(TOKEN_PATH, "wb") as f:
            pickle.dump(creds, f)
    except Exception as e:
        # refresh_token 자체가 revoke된 경우 → 풀 OAuth 필요
        ...
```

**⚠️ 흔한 함정:** `creds.refresh_token`이 있다고 출력되어도 실제로 호출하면 `invalid_grant`로 실패할 수 있다. refresh_token은 사용 후 revoke되는 정책이라, 1회 갱신 후 다시 만료되면 무조건 풀 OAuth 필요.

## 풀 OAuth 재발급

`scripts/youtube_reauth.py` 사용 (스킬에 동봉):

```bash
# 업로드만 필요한 경우
SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]

# 삭제/search/video 관리도 필요한 경우
SCOPES = ["https://www.googleapis.com/auth/youtube"]
```

스크립트 실행 → 브라우저에서 Google 로그인 → 자동으로 토큰 저장.

## 스코프 선택 가이드

| 시나리오 | 권장 스코프 |
|---------|-----------|
| YouTube 업로드만 (평소) | `youtube.upload` |
| 영상 삭제 필요 | `youtube` (전체) |
| 채널 검색/통계 필요 | `youtube` (전체) |
| 비디오 자막/캡션 수정 | `youtube.force-ssl` |

**권장:** 향후 delete가 필요할 가능성을 고려해 처음부터 `youtube` 전체 스코프 사용. 토큰 발급 시점의 추가 동의 한 번이면 끝남.

## ⚠️ f-string 마스킹 함정 (Bearer 토큰 외)

`youtube_reauth.py` 첫 작성 시 발생한 SyntaxError:

```python
# ❌ SyntaxError (*** 마스킹이 f-string을 깨뜨림)
# 인증 마스킹으로 secret 문자열이 깨진 상태로 f-string이 들어감
```

**해결:** `os.path.expanduser` + 문자열 연결로 토큰/secret 경로 처리:

```python
# ✅ 정상 동작
CLIENT_SECRET = find_client_secret()  # 내부에서 expanduser 처리
print("Using: " + CLIENT_SECRET)
```

`write_file`에도 같은 마스킹 규칙이 적용되므로, 토큰이 들어가는 스크립트는 반드시 `write_file`로 외부 파일 작성 후 실행.

## 백업 정책

`youtube_reauth.py`는 기존 토큰을 `.bak`으로 자동 백업:

- `youtube_token.pickle.bak` (최근 1회, 자동)
- 직접 관리: `youtube_token.pickle.expired.bak`, `.upload-only.bak` 등

만료된 토큰도 복구 가능하므로 백업 보존 권장 (디스크 1.4KB).

## 검증 절차

재발급 후:

```bash
source ~/.hermes/venv-notebooklm/bin/activate
python3 - << 'EOF'
import os, pickle
from googleapiclient.discovery import build
TOKEN_PATH = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")
with open(TOKEN_PATH, "rb") as f:
    creds = pickle.load(f)
youtube = build("youtube", "v3", credentials=creds)
res = youtube.channels().list(part="snippet", mine=True).execute()
print("OK:", res["items"][0]["snippet"]["title"])
EOF
```
