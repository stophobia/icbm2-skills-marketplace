#!/usr/bin/env python3
"""Summarize cron job success/failure for an ISO week from the cron output dirs.

Counts output files per job and inspects each for error markers. Prints
a per-job breakdown + overall success rate. Designed to run from a cron
context (no execute_code, no pipe-to-interpreter, no interactive prompts).

Usage:
    python3 scripts/cron_weekly_summary.py <year> <iso_week>
    # e.g. python3 scripts/cron_weekly_summary.py 2026 23
"""
import os
import re
import sys
from collections import defaultdict
from datetime import date, timedelta

CRON_OUT = os.path.expanduser("~/.hermes/cron/output")
ERROR_MARKERS = ["RuntimeError", "Traceback", "APIError", "HTTPError", "Failed"]


def iso_week_range(year, week):
    start = date.fromisocalendar(year, week, 1)
    end = date.fromisocalendar(year, week, 7)
    return start, end


def daterange(start, end):
    d = start
    while d <= end:
        yield d
        d += timedelta(days=1)


def summarize_job(job_dir, start, end):
    if not os.path.isdir(job_dir):
        return None
    runs = 0
    errors = []
    for d in daterange(start, end):
        pattern = f"{d.isoformat()}_"
        for fname in os.listdir(job_dir):
            if fname.startswith(pattern) and fname.endswith(".md"):
                runs += 1
                path = os.path.join(job_dir, fname)
                try:
                    with open(path, encoding="utf-8") as f:
                        text = f.read(2000)
                except Exception:
                    continue
                for marker in ERROR_MARKERS:
                    if marker in text:
                        errors.append((d.isoformat(), marker))
                        break
    return {"runs": runs, "errors": errors}


def main():
    if len(sys.argv) != 3:
        print("usage: cron_weekly_summary.py <year> <iso_week>")
        sys.exit(1)
    year, week = int(sys.argv[1]), int(sys.argv[2])
    start, end = iso_week_range(year, week)

    print(f"Cron summary for ISO {year}-W{week:02d} ({start} .. {end})")
    print("---")

    if not os.path.isdir(CRON_OUT):
        print(f"cron output dir not found: {CRON_OUT}")
        sys.exit(1)

    total_runs = 0
    total_errors = 0
    for job_id in sorted(os.listdir(CRON_OUT)):
        job_dir = os.path.join(CRON_OUT, job_id)
        result = summarize_job(job_dir, start, end)
        if not result or result["runs"] == 0:
            continue
        total_runs += result["runs"]
        total_errors += len(result["errors"])
        rate = (result["runs"] - len(result["errors"])) / result["runs"] * 100
        status = "OK" if not result["errors"] else f"ERR x{len(result['errors'])}"
        print(f"{job_id[:12]}  runs={result['runs']:3d}  success={rate:5.1f}%  [{status}]")
        for err_date, marker in result["errors"][:3]:
            print(f"   - {err_date}: {marker}")

    print("---")
    if total_runs:
        rate = (total_runs - total_errors) / total_runs * 100
        print(f"OVERALL: {total_runs} runs, {total_errors} errors, {rate:.1f}% success")


if __name__ == "__main__":
    main()
