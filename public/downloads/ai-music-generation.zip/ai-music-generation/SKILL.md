---
name: ai-music-generation
description: AI 음악 생성 풀 워크플로우 — 원곡 분석, 한국어 가사 작성, mmx CLI로 mp3 생성, 외부 전달까지. 사용자가 "AI로 노래 만들어줘", "원곡 느낌으로 창작곡", "Suno/mmx로 발라드" 등 요청 시 발동.
version: 1.0.0
metadata:
  hermes:
    tags: [music, audio, generation, ai, mmx, lyrics, korean, ballad, k-pop]
    related_skills: [heartmula, kaggle-music-voice-gen, remote-file-delivery]
---

# AI Music Generation Workflow

## Overview

사용자가 "원곡 X 느낌의 AI 창작곡"을 요청할 때의 엔드투엔드 파이프라인.

**핵심 도구: mmx CLI** (MiniMax 공식 CLI — `mmx music generate`)
- 텍스트 프롬프트 + 가사 + 메타태그 → mp3 직접 생성
- 한국어 보컬, IU/원하는 아티스트 톤 지정 가능
- 3500자 이내 가사, 구조 태그 [Intro][Verse][Chorus][Bridge][Outro] 지원
- AIGC 워터마크 옵션 (--aigc-watermark)

**사전 확인 필수:**
- `mmx --version` (최신이면 OK, 아니면 `npm update -g mmx-cli`)
- `mmx auth status` (API key 등록 여부)
- 가사 길이: 3500자 이하 (한국어 약 1000~1200자 = 2~3분 곡 안전)

## Workflow (5단계)

### 1단계: 원곡 심층 분석 (사용자가 원곡을 지목한 경우)

**절대 건너뛰지 말 것.** 이 단계 빠뜨리면 "원곡과 동떨어진 느낌"이라는 피드백 받음 (실제 발생).

분석해야 할 항목:
- **장르/분위기**: "발라드" / "팝" / "댄스" / "중국식 팝" / "인디" — 제목만으로 추측하지 말 것
- **BPM**: Spotify stats, music wiki, YouTube description에서 확인. Spotify stats 같은 게 제일 정확 (예: "117 BPM, 85% danceability")
- **Key**: Chordify, Ultimate Guitar에서 코드 추출 → Key 확인
- **에너지/댄스어빌리티**: 50% 이하면 잔잔, 70% 이상이면 중독성 있는 팝
- **가사 톤**: 위트? 진지? 자위? 풍자? — 가사 전문 직접 읽어보기
- **편곡**: 어떤 악기가 중심? (피아노/우쿨렐레/일렉기타/스트링)

**체크리스트:**
```
[ ] Spotify/music wiki로 BPM, danceability, energy 확인
[ ] Chordify/UG로 코드 진행 + Key 확인
[ ] 나무위키/가사 사이트에서 가사 전문 + 의미 확인
[ ] Bilibili/YouTube에서 가사 해석/해설 영상 1개 이상 시청
[ ] 위의 정보를 종합해서 "이 곡의 정체" 1~2문장으로 정리
```

### 2단계: 가사 작성 (한국어 창작)

원곡의 **메시지/톤/이미지**는 유지하되, 한국어 가사는 새로 창작.

**구조 템플릿:**
```
[Intro]

[Verse 1]
4~8줄. 도입. 원곡의 핵심 이미지를 한국적 정서로.

[Pre-Chorus]  (선택)
2~4줄. 감정 빌드업.

[Chorus]
4~6줄. 가장 중독성 있어야 함. 반복 가능한 후렴.

[Verse 2]
4~8줄. 전개.

[Pre-Chorus] (반복 or 변형)

[Chorus] (반복)

[Bridge]  (선택)
3~5줄. 감정 전환. 원곡에 bridge 있으면 반드시 살릴 것.

[Chorus] (마지막, 약간 변형)

[Outro]
1~2줄. 여운.
```

**가사 작성 원칙:**
- 한국어 음절이 멜로디에 잘 얹히도록 짧은 어절 위주
- 후렴은 4~6마디로 반복 (원곡이 반복 후렴이면 반드시)
- Bridge는 원곡에 있을 때만 (없으면 skip)
- 한자/한문 최소화 (사용자 선호)
- "잘했어" "괜찮아" 같은 한국적 위로 표현 자연스럽게

### 3단계: 제목 결정

원곡 제목과 **명확히 구분**되어야 함 (사용자가 직접 요구).

**제목 후보 생성 팁:**
- 후렴의 핵심 문장을 제목으로
- 가사의 핵심 감정을 한 단어로
- 원곡의 키워드("평범", "곁")를 가져가도 되지만 다른 결로

### 4단계: mmx music generate 실행

```bash
mmx music generate \
  --prompt "<장르/분위기/악기 종합 설명>" \
  --vocals "<보컬 톤 상세>" \
  --genre "<장르>" \
  --mood "<분위기>" \
  --instruments "<악기 리스트>" \
  --tempo "<slow/medium/fast>" \
  --bpm <숫자> \
  --key "<Key>" \
  --references "<레퍼런스 아티스트/곡>" \
  --lyrics-file <lyrics.txt 경로> \
  --out <output.mp3 경로> \
  --aigc-watermark
```

**프롬프트 작성 팁:**
- `--prompt`: 한 문장으로 장르+분위기+악기+에너지
- `--vocals`: "warm female soprano, soft and breathy, IU inspired, Korean vocal style"
- `--references`: "IU Love poem, IU Through the Night" 같은 식으로
- 원곡의 BPM/Key를 정확히 모방하면 후렴/멜로디 결이 가까워짐

### 5단계: 결과 전달

**생성된 파일을 사용자가 어떻게 듣게 할 것인가:**

| 상황 | 방법 |
|------|------|
| PC 앞, Telegram 사용 | `MEDIA:<경로>` 태그 |
| 모바일, Telegram 사용 | ngrok 터널 + 공개 URL (→ `remote-file-delivery` 스킬) |
| PC 없음, 어디서든 | ngrok 터널 + 공개 URL |

**미리듣기 만들기 (30초 클립, Telegram 음성 메시지 호환):**
```bash
ffmpeg -y -i original.mp3 -ss 0 -t 30 -c:a libmp3lame -b:a 96k -ac 1 -ar 22050 preview.mp3
```

**한글 파일명 URL 인코딩 우회:**
ASCII 심볼릭 링크로 별칭 만들기:
```bash
ln -sf "한글파일명.mp3" "ascii_alias.mp3"
```
이유: HTTP 서버가 한글 URL을 404로 응답하는 경우 많음. ASCII 별칭으로 우회.

## Pitfalls (실제 발생했던 것들)

1. **원곡 분석을 대충 하고 창작 → "동떨어진 느낌" 피드백 받음**
   - "평범하게 네 곁에"라는 제목만 보고 "잔잔한 발라드"로 가정
   - 실제는 117 BPM 중독성 있는 중국식 팝이었음 (Spotify 85% danceability)
   - **교훈**: 제목/분위기 키워드는 거짓말을 함. 반드시 BPM/energy/danceability를 숫자로 확인.

2. **mmx CLI 버전 outdated**
   - `mmx update`만 치면 npm 명령어 가이드만 나옴
   - 실제 업데이트: `npm update -g mmx-cli` 직접 실행
   - 업데이트 전/후로 `mmx --version` 재확인

3. **libopus / libvorbis 인코더 부재**
   - macOS 기본 ffmpeg에 `libopus`/`libvorbis` 없을 수 있음
   - 대안: 그냥 `opus` / `vorbis` 이름으로 시도, 그것도 안 되면 mp3로 (Telegram 음성 메시지는 OGG Opus 권장이지만 mp3 첨부파일도 동작)

4. **가사 안에 [태그]에 설명 쓰면 안 됨**
   - `[Verse 1 - 잔잔하게 시작]` ❌ — 설명이 보컬로 불림
   - `[Verse 1]` ✅ — 태그는 깨끗하게

5. **MEDIA: 태그가 텍스트로만 출력되는 경우**
   - 플랫폼에 따라 media 자동 인식 안 될 수 있음
   - 그럴 땐 ngrok URL로 우회

6. **3500자 가사 제한**
   - 한글 1자 = 약 3바이트 (UTF-8)
   - 안전 범위: 한글 약 1000자 이내 (분명하게 안전)
   - 그 이상은 mmx에서 거부당할 수 있음

7. **첫 결과가 마음에 안 들 수 있음 (정상)**
   - v1이 별로면 v2로 재생성. mmx는 30~60초면 생성됨
   - 원곡 분석을 다시 해서 빠진 요소를 보강하고 재생성

## Verification

생성 후 확인:
```bash
ffprobe -v error -show_format <output.mp3> 2>&1 | grep -E "duration|bit_rate"
ls -la <output.mp3>  # 파일 크기 1MB 이상 정상
```

- 정상 mp3: duration=120~180초 (2~3분), bit_rate=256000
- 비정상: duration=0, 파일 크기 < 100KB, 재생 안 됨

## Related Skills

- `remote-file-delivery` — ngrok으로 외부에서 mp3 들을 수 있게 URL 만들기
- `heartmula` — 로컬 GPU 있으면 대안 (Linux/CUDA only, macOS 불가)
- `kaggle-music-voice-gen` — 인스트루멘탈만 필요한 경우 (보컬 합성 불가)
