# 176차 세션 노트 — Show GN: lily-svelte

**일자**: 2026-06-20
**주제**: Show GN: lily-svelte — Svelte 5 컴포넌트 라이브러리
**URL**: https://sigco.tistory.com/813
**source_url**: https://news.hada.io/topic?id=30633

## 분기 적용

- **긱뉴스 본문 699자 (짧음) + GitHub raw README 2,038자 풍부**
- **175차 정형화 분기 (자체 HN/댓글 인라인 활용) + GitHub raw README fetch 변형 (176차 신규)**
- 긱뉴스 "함께 보면 좋은 글" 4건 인라인 (FlyOnUI / ui-devtools / Tailwind UI / Prompt-Kit)
- 긱뉴스 본문에서 GitHub 저장소 식별: `curl https://github.com/search?q=lily-svelte&type=repositories` → `levish0/lily-svelte`
- raw README 직접 fetch: `curl https://raw.githubusercontent.com/levish0/lily-svelte/main/README.md` → 2,038자 마크다운 텍스트 (HTML 파싱 불필요)

## 발행 결과

| 항목 | 값 |
|------|---|
| 글자수 | 3,853자 (publisher 측정 3,743자) |
| H2 | 8개 (도입/배경/도입흐름/디자인철학/monorepo/릴리즈/생태계/전망/요약) |
| 비교표 | 1개 (monorepo 구조: packages/cli, packages/registry, docs) |
| 코드블록 | 0개 (CLI 명령어는 인라인 코드) |
| 정량 | 7개 태그 / 3개 monorepo 경로 / 1개 npm 패키지 / Node 24 / 3단계 릴리즈 / 4개 동종 라이브러리 |
| Picsum ID | 557 (자동 할당) |
| CDN 업로드 | 2/2 성공 (각 136KB, 동일 사이즈) |
| CJK | 0건 |
| 1회 컷 | 56회째 |

## 마일스톤

- **176차 56회째 1회 컷 누적** (175차 55회째 → 176차 56회째)
- **CJK 0건 65회 연속** (175차 64 → 176차 65)
- **--record 사전+사후 2단계 시퀀스 19회째 안정** (158차 신규 → 176차 19회째)
- **--record-topic 4인자 정형화 누적 50회째**
- **Picsum ID 557 자동 할당** — query `lily svelte Svelte 5 component library soft monochrome` (영문 7단어, 170차 권장 5단어보다 길지만 결정성 유지)
- **CDN 업로드 안정성 81회째** (136KB/136KB 동일 사이즈는 동일 ID 557 재사용 영향)
- **AI/ML 카테고리 1219746 안정 사용** — 176차 Svelte 주제이나 AI/ML 카테고리 그대로 유지

## 신규 학습

### GitHub raw README fetch 변형 (176차 신규 — 검증된 단순화 경로)

162차/168차 "GitHub README fetch" 분기는 자동 렌더된 GitHub 페이지에서 `article.markdown-body` HTML 파싱으로 README를 추출했다. **176차에서 더 단순한 경로 검증**: GitHub 검색으로 owner/repo 식별 후 `raw.githubusercontent.com/<owner>/<repo>/<branch>/README.md` 직접 fetch → HTML 파싱 단계 스킵, 마크다운 텍스트 그대로 사용.

**시퀀스**:
1. `curl https://github.com/search?q=<keyword>&type=repositories` → `re.findall(r'href="(/[^"]+/<repo>[^"]*)"', html)` 로 owner/repo 경로 추출
2. `curl https://raw.githubusercontent.com/<owner>/<repo>/main/README.md` → 마크다운 텍스트
3. 긱뉴스 본문 짧음 + README 텍스트 → 자체 H2 구조로 재구성

**Tirith 통과**: `raw.githubusercontent.com` 도메인은 .dev/.exe 같은 lookalike TLD에 해당 안 됨 → 보안 스캔 무경고. `github.com/search`도 통과.

**판단 정식화**:
- README 1~5KB → raw README fetch (176차 신규 경로)
- README 5~15KB+ → 자동 렌더 README fetch (162차/168차 기존 경로)

### Picsum query 단어 수 가벼운 갱신

170차 권장 "영문 키워드 + 공백 5단어" 가이드라인을 176차에서 7단어로 늘려 사용 → Picsum ID 557 자동 할당, 결정성 유지. **판단 갱신**: 5~7단어 범위는 모두 결정성 유지 OK. 5단어 권장은 그대로 두되 6~7단어도 무방.

## Pitfall

없음 (175차 정형화 분기 안정적 재현, 신규 함정 미발견)

## Patch 이력

- 176차: 1회 작성 → CJK 0건 → publish 1회 성공 → --record 사후 호출 성공 → 0회 patch

## 175차 vs 176차 비교

| 차수 | 긱뉴스 본문 | 외부 fetch | 본문 fetch 결과 | 1회 컷 |
|------|-----------|-----------|-----------------|--------|
| 175차 | 734자 (짧음) | 없음 (HN 댓글 인라인 4,225자) | — | 4,118자 |
| **176차** | **699자 (짧음)** | **GitHub raw README** | **2,038자** | **3,853자** |

두 차수 모두 긱뉴스 본문 700자 미만 + 외부 컨텐츠 풍부 → **H2 7~8개 + 비교표 1개 + 코드블록 0개 분기 안정 재현**. 175차 긱뉴스 자체에 HN 의견 섹션이 내장되어 외부 fetch 불필요, 176차는 raw README 직접 fetch로 외부 컨텐츠 확보.