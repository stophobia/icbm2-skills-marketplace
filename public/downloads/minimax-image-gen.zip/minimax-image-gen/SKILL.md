---
name: minimax-image-gen
description: MiniMax image-01 텍스트→이미지 생성. 프롬프트만 주면 기본 16:9 비율로 생성. 가로세로 비율/개수 지정 가능.
triggers:
  - "이미지 생성해줘"
  - "이미지 만들어줘"
  - "image generation"
  - "그림 그려줘"
default_options:
  aspect_ratio: "16:9"
  n: 1
  response_format: "url"
---

# MiniMax Image Generation (image-01)

## ⚠️ 밝은 이미지 생성 규칙 (유머/위트 테마 필수)

**주인님 선호:** 포토리얼리즘이면서 **밝고 활기찬** 이미지. 어두운 이미지를 절대 원하지 않음.

**✅ 항상 포함:** `bright daylight, vivid colors, high-key lighting, cheerful atmosphere`
**❌ 절대 사용 금지:** `cinematic photography, natural lighting, low-key lighting, moody atmosphere, dark, night scene` — 어두운 이미지 유발

**유머/위트 테마 추가 키워드:** `comedic contrast, playful light, saturated tones, warm golden hour`

**예시 (옳음):**
```
Photorealistic, bright daylight, sunny street market, colorful awnings, saturated tones, high-key lighting, comedic contrast, cheerful atmosphere
```

**예시 (❌):**
```
Photorealistic, cinematic photography, moody atmosphere, natural lighting, dark tones
```

MiniMax `image-01` 모델로 텍스트 프롬프트에서 이미지를 생성합니다.

## 사용량 잔여 (2026-05-19 기준)

| 구분 | 잔여 | 상태 |
|------|------|------|
| Interval | 50/50 | ✅ 100% |
| Weekly | 350/350 | ✅ 100% |

## API 정보

- **Endpoint:** `POST https://api.minimax.io/v1/image_generation`
- **모델:** `image-01`
- **URL 만료:** 24시간

## 파라미터

| 파라미터 | 기본값 | 설명 |
|----------|--------|------|
| `prompt` | (필수) | 이미지 설명 (최대 1500자) |
| `aspect_ratio` | `16:9` | 비율: 1:1, 16:9, 4:3, 3:2, 2:3, 3:4, 9:16, 21:9 |
| `n` | `1` | 생성 개수 (1~9) |
| `response_format` | `url` | `url` 또는 `base64` |
| `prompt_optimizer` | `false` | 프롬프트 자동 최적화 |

## 사용 예시

### simplest call (디폴트 16:9)
```
흰 배경을 앞에 두고 귀여운 robot이 달리는 샛빛 레트로 스타일
```

### 9:16 세로형 (Shorts용)
```
aspect_ratio=9:16
비오는 도시 야경, 네온 불빛이 물에 반사, cinematic mood
```

### 1:1 정사각형
```
aspect_ratio=1:1
minimalist workspace, macbook, coffee, plants, soft lighting
```

## curl 명령어

```bash
curl -s -X POST "https://api.minimax.io/v1/image_generation" \
  -H "Authorization: Bearer $MINIMAX_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "image-01",
    "prompt": "yscene description",
    "aspect_ratio": "16:9",
    "response_format": "url",
    "n": 1
  }'
```

## 에러 처리

- **401:** API 키无效
- **10001:** 파라미터 에러 (prompt 너무 길면)
- **1033:** 일시적 서버 에러 → 3회 재시도

## 저장소

- 스크립트: `scripts/generate.py`
- 시크릿: `~/.hermes/secrets/minimax.env` (MINIMAX_API_KEY)