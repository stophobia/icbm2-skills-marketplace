# 서비스 장애 워치독 패턴 (cron no_agent)

> 외부 서비스 장애를 감지해서 복구 시점에 1회 알림. 2026-06-23 Notion 장애 감시 세션에서 확립.

## 적용 시점

- 사용자가 "X 서비스 안 되는데 장애인지 알려줘" / "X 복구되면 알려줘"
- cron + LLM 호출은 비용이므로 장애 감시는 **no_agent=True** 스크립트로 처리
- 토큰 0원 + 자동 종료 + silent 정상 동작

## 핵심 설계 원칙

1. **silent 우선** — 정상 복구 후에는 알리지 않음. 한 번 알리면 끝
2. **인증키 / 외부 의존성 없으면 silent** — 우리 환경 문제 vs 서비스 장애 구분 어려우므로 일단 silent
3. **HTTP / 네트워크 오류는 silent** — 다음 cron tick에서 재시도
4. **출력은 stdout, 비어 있으면 silent** — cron `no_agent=True`는 빈 stdout이면 메시지 발송 안 함

## 패턴 (4요소)

### 1. cronjob 등록

```python
cronjob(
    action="create",
    name="notion-outage-watch-3h",
    schedule="30m",
    repeat=6,  # 30분 × 6회 = 3시간
    script="notion_outage_watch.py",  # 파일명만! 절대경로 거부됨
    no_agent=True,
    deliver="origin",  # 텔레그램으로 자동 발송
)
```

**절대경로 함정**: `script='/Users/.../foo.py'` 또는 `script='~/.hermes/scripts/foo.py'` 모두 거부됨. **반드시 파일명만**.

### 2. 워치독 스크립트 구조

```python
import os, sys, json
from urllib import request as urlrequest
from urllib.error import URLError, HTTPError
from datetime import datetime, timezone, timedelta

KST = timezone(timedelta(hours=9))

def kst_now():
    return datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST")

def check_service():
    api_key = os.environ.get("SERVICE_API_KEY", "").strip()
    if not api_key:
        return (False, "API 키 미설정")  # silent
    req = urlrequest.Request("https://api.service.com/v1/health",
                              headers={"Authorization": f"Bearer {api_key}"})
    try:
        with urlrequest.urlopen(req, timeout=10) as resp:
            if resp.status == 200:
                return (True, f"정상 응답")
            return (False, f"HTTP {resp.status}")
    except (HTTPError, URLError, TimeoutError, OSError) as e:
        return (False, f"오류: {type(e).__name__}")

def main():
    is_healthy, detail = check_service()
    if is_healthy:
        print(f"✅ 서비스 복구 감지 — {kst_now()}")
        print(f"   상세: {detail}")
    return 0  # 장애 중 silent
```

전체 재사용 템플릿은 `templates/notion-outage-watch.py` 참조.

### 3. silent 검증

```bash
source ~/.hermes/.env && python3 ~/.hermes/scripts/notion_outage_watch.py
echo "stdout_bytes: $(source ~/.hermes/.env && python3 ~/.hermes/scripts/notion_outage_watch.py | wc -c)"
```

`stdout_bytes: 0` 이면 정상 silent.

### 4. 자동 종료 + 재개 명령어

```bash
hermes cron run {job_id}        # 즉시 1회 실행
hermes cron pause {job_id}      # 일시 중지
hermes cron resume {job_id}     # 재개
hermes cron update {job_id} --repeat 24   # 반복 횟수 늘리기
hermes cron remove {job_id}     # 완전 삭제
```

## repeat / schedule 조합

| 의도 | schedule | repeat | 자동 종료 |
|---|---|---|---|
| 1회성 | `30m` | 1 | ✅ 1번 후 |
| 반나절 | `30m` | 24 | ✅ 12h 후 |
| 1일 | `30m` | 48 | ✅ 24h 후 |
| 1주일 | `1h` | 168 | ✅ 7d 후 |
| 무한 | `30m` | 생략 | ❌ 수동 remove |

## 흔한 함정

- **`script` 절대경로** — `script='/Users/hjshin/.hermes/scripts/foo.py'`는 거부됨. 파일명만 사용.
- **`tuple[bool, str]` 타입힌트 (Python 3.8)** — 시스템 base conda 3.8에서 `TypeError: 'type' object is not subscriptable`. `from typing import Tuple` 또는 `Optional`로 대체.
- **인증키 없이 빈 stdout이 안 나오는 경우** — `if not api_key: return False` 분기를 명시 안 하면 `urllib.error` 단계에서 traceback 출력될 수 있음. 첫 줄에 silent 분기.
- **cron 환경 PATH 차이** — `~/.hermes/.env`에 있는 키는 `source ~/.hermes/.env` 후 실행해야 로드. cron 자체는 .env를 자동 로드 안 함.
- **복구 후 또 알림** — cron이 6회 반복이면 1회 알림 후 5회는 silent. `last_alerted.json` 같은 상태 파일 만들면 "이미 알림 보냄" 추적 가능 (대부분 불필요).
- **no_agent=False로 설정** — LLM 호출 들어가서 토큰 비용 발생. 장애 감시는 무조건 `no_agent=True`.

## 적용 사례

### Notion 장애 감시 (2026-06-23)

- **API**: `https://api.notion.com/v1/users/me` (인증 필요)
- **인증**: `NOTION_API_KEY` (이미 `.env`에 있음)
- **반복**: 30분 × 6회 = 3시간, 자동 종료
- **결과**: 09:08 첫 실행 시 Notion 응답 없음 → silent. 10:08 복구 감지 → "Notion 복구됨" 메시지 텔레그램 발송

## 다른 서비스로 확장

| 서비스 | 헬스체크 엔드포인트 | 환경변수 |
|---|---|---|
| Notion | `GET /v1/users/me` | `NOTION_API_KEY` |
| GitHub | `GET /octocat` (인증 불필요) | (없음) |
| Slack | `GET /api/auth.test` | `SLACK_BOT_TOKEN` |
| OpenAI | `GET /v1/models` | `OPENAI_API_KEY` |
| Vercel | `GET /v1/integrations/deploy-hooks` | `VERCEL_TOKEN` |

각 서비스의 가장 가벼운 인증 엔드포인트를 찾아서 `check_service()` 함수 본문만 교체하면 됨.