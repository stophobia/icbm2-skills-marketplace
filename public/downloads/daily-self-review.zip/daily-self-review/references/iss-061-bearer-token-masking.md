# ISS-061 — `write_file`의 Bearer 토큰 마스킹 함정

**발견일**: 2026-06-04 08:32 KST  
**발견 위치**: ios-trend-digest 크론 잡 (075bec58df7b) — `iOS/Swift 트렌드 수집` 1단계 실행 시  
**Severity**: 🟡 경고 (cron 잡 전체 fail은 아니나, 모든 Notion/HTTP API 호출 코드에 영향)  
**상태**: 진행중 (해결 패턴은 patch 완료, 100% spread는 미완)

---

## 증상

`write_file` 또는 `terminal` heredoc에 `Bearer <token>` 같은 평문 토큰이 포함되면, **토큰이 마스킹되면서 인접 문자열이 깨져 SyntaxError**가 발생한다.

```python
# ❌ 동작 안 함 (마스킹됨, SyntaxError)
prefix = "Authorization: Bearer <actual_token>"
# → write_file: prefix = "Authorization: Bearer ***"
# → SyntaxError: EOL while scanning string literal (인접 문자열 깨짐)
```

```bash
# ❌ 동작 안 함 (마스킹됨)
curl -H "Authorization: Bearer <actual_token>" ...
# → terminal: -H "Authorization: Bearer *** ..."
```

**핵심**: 단순히 토큰만 마스킹되는 게 아니라, **인접한 문자열 구조가 깨지면서 SyntaxError로 fail**. 즉, 디버깅이 어려움.

---

## 해결 패턴 (Runtime Composition)

```python
# ✅ 동작함 — 런타임에 토큰 조합
import os
NOTION_TOKEN = os.environ.get("NOTION_TOKEN") or open("~/.hermes/secrets/notion_token.txt").read().strip()
BEARER = "Bearer " + ""  # 마스킹 회피용: "Bearer" + 토큰
headers = {"Authorization": f"{BEARER}{NOTION_TOKEN}", "Notion-Version": "2022-06-28"}
```

```bash
# ✅ 동작함 — env var + 빈 문자열 조합
BEARER="Bearer "
TOKEN=$(cat ~/.hermes/secrets/notion_token.txt)
curl -H "Authorization: ${BEARER}${TOKEN}" ...
```

**원리**: 마스킹 로직이 완성된 토큰 문자열을 한 단위로 감지하므로, `"Bearer "` + 토큰을 **런타임에 합치면** 마스킹을 우회하면서 SyntaxError도 피할 수 있다.

---

## 영향 범위 (Class-Level)

이 함정은 **모든 Notion/HTTP API를 호출하는 cron 스킬**에 적용된다:

- ios-trend-digest ✅ patch 완료 (2026-06-04 08:33)
- ai-model-tracker ✅ patch 완료 (2026-06-04 08:33)
- tistory-publisher — 점검 필요
- knowledge-graph — 점검 필요
- stock-market-tracker — 점검 필요
- blog-pipeline (tistory 발행) — 점검 필요
- music-video-generator — 점검 필요
- 그 외 Notion/GitHub API 호출 cron

**self-review 작업 시 확인 절차**:
1. `grep -rn "Bearer " ~/.hermes/skills/ --include="*.md"` → 평문 토큰 사용한 스킬 식별
2. 해당 스킬의 SKILL.md에 Bearer 런타임 조합 패턴이 명시되어 있는지 확인
3. 없으면 해당 스킬 SKILL.md에 `references/cron-execution-pattern.md`로 cross-link 추가

---

## 참고 자료

- **상세 가이드**: `~/.hermes/skills/ai-model-tracker/references/cron-execution-pattern.md` (ios-trend-digest와 공유)
- **MEMORY.md**: "Bearer 토큰 마스킹 함정" 섹션
- **issues.md**: ISS-061
- **해결 커밋 (2026-06-04 08:33)**: ios-trend-digest SKILL.md, ai-model-tracker SKILL.md patch

---

## 일일 self-review에서 활용법

1. **다른 cron 스킬 patch 시**: SKILL.md를 수정하기 전에 해당 스킬이 `Bearer <token>` 평문을 사용하는지 확인
2. **memory에 등록 확인**: 새 patch 후 `MEMORY.md`와 `issues.md`에 동시 등록
3. **재발 방지**: 새 cron 스킬 작성 시 SKILL.md 템플릿에 Bearer 패턴 단락 포함

---

*최초 작성: 2026-06-04 22:01 KST*  
*최종 업데이트: 2026-06-04 22:01 KST*
