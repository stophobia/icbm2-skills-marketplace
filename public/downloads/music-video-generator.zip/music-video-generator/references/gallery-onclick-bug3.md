# Gallery — Inline JS onclick Bug 3 (2026-05-23)

## Problem
Even after fixing JS syntax errors (empty string `''` in onclick + regex newline), clicking gallery images produced zero reaction (no lightbox, no new window).

## Root Cause — Attribute Value Truncation

The inline onclick builds a long attribute value:
```javascript
imgTags += '<img ... onclick="openLightbox(\'' + entry.images[k] + '\', ' + 
    JSON.stringify(entry.images || []) + ', ' + k + ')">';
```

`JSON.stringify(entry.images)` produces:
```json
["https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img1.png",
 "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img2.png",
 "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img3.png"]
```
~200 chars of URL arrays inside an onclick attribute. **Browser DOM silently truncates inline onclick at ~512 chars**, breaking the handler silently.

## Playwright Diagnosis
```python
# Confirmed via Playwright:
full_onclick = await page.evaluate("img.getAttribute('onclick')")
# Returns: "openLightbox('https://...img1.png', ["  (truncated at 96 chars!)
```

## Solution — Data Attributes + Delegated Event Listener

```javascript
// HTML generation — no onclick, use data attributes
imgTags += '<img class="card-img" src="' + entry.images[k] + '" ' +
    'style="height:120px;..." ' +
    'data-images="' + encodeURIComponent(JSON.stringify(entry.images || [])) + '" ' +
    'data-index="' + k + '">';

// Delegated event listener (document-level, works even on dynamically inserted elements)
document.addEventListener('click', function(e) {
    var img = e.target.closest('.card-img');
    if (img) {
        var images = JSON.parse(decodeURIComponent(img.getAttribute('data-images') || '[]'));
        var index = parseInt(img.getAttribute('data-index') || '0', 10);
        openLightbox(img.src, images, index);
    }
});
```

## Verification (Playwright)
```python
# data-images attr confirmed set (~200 chars URI-encoded)
has_attr = await page.evaluate("img.getAttribute('data-images')")
# → "%5B%22https%3A%2F%2Fraw.githubusercontent.com..."

# Clicking activates lightbox:
await img.click()
is_active = await page.evaluate("document.getElementById('lightbox').classList.contains('active')")
# → True ✅
```

## Rule
**NEVER put `JSON.stringify()` inside an inline onclick attribute.** Use `data-*` attributes + delegated event listeners instead. This applies to any scenario where the attribute value could exceed ~500 chars.