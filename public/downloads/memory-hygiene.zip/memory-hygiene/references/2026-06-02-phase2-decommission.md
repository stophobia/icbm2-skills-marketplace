# 2026-06-02 2차 정리 — 컴포넌트 폐기 통합 실행

## 배경

이전 1차 정리(MUSIC VIDEO RULES / Notion 음악 주제 DB)는 잘못된 파일에 적용됨. 복구 후 진짜 소스(`~/.hermes/MEMORY.md`)에 재적용.

## 2차 정리 — 사용자 결정 ("뮤직비디오/공개데이터포탈 안 할 거임")

### 1단계: 영향 범위 조사 (1분)
```bash
# 스크립트/시크릿/출력 폴더/크론 잡 식별
ls /Users/hjshin/.hermes/scripts/music_video*  # 2개
ls /Users/hjshin/.hermes/scripts/apikey_holiday*  # 1개
ls /Users/hjshin/.hermes/secrets/datagokr*  # 2개
ls /Users/hjshin/.hermes/music_videos/  # 909KB, 112파일
grep -rln "music_video\|apikey_holiday\|datagokr" /Users/hjshin/.hermes/cron/  # 2개 잡 ID 식별
```

### 2단계: MEMORY.md 정리 (3분)
- `## 뮤직비디오 자동화 (2026-05-25 수정)` 섹션 전체 제거
- `## 공개데이터포탈` 섹션 전체 제거
- `## 주인님 프로필` 안의 "뮤직비디오 음악 스타일" 1줄 제거
- `## 자동화 성과` 안의 "🟡 🎬 뮤직비디오 제작 cron TimeoutError" 이슈 1줄 제거 (잔여 흔적)

### 3단계: 자산 폐기 (2분)
- 스크립트 3개 `rm -f` (영구 삭제)
- 시크릿 2개 `trash` (보안상 복구 가능성 유지)
- `music_videos/` 폴더 `rm -rf` (112파일, 909KB)
- 크론 잡 `8b859449c91d` `cronjob action=remove`

### 4단계: 검증 (1분)
```bash
# 3곳 grep — 모두 0 hits 확인
grep -c "뮤직비디오\|공개데이터포탈\|music_video\|apikey_holiday\|datagokr" /Users/hjshin/.hermes/MEMORY.md
# 결과: 0
```

## 결과

- **MEMORY.md: 8,964B → 4,259B** (−52%)
- **스크립트 3개 영구 삭제**
- **시크릿 2개 trash** (Finder에서 복구 가능)
- **출력 폴더 1개 영구 삭제 (112파일)**
- **크론 잡 1개 remove**

## 학습 — 이번 세션의 핵심

### A. 사용자 결정적 응답 처리
"1번" / "A, B, C, E, F" 식의 응답은 **재확인 없이 곧장 진행**:
- todo 분할 후 즉시 실행
- 각 단계마다 짧은 보고 (사용자가 인터럽트 가능)

### B. 시크릿(trash) vs 코드(rm) 분리
- 사용자 선택지에 시크릿 항목이 없어도 trash가 안전한 기본값
- 시크릿은 다른 시스템에 재사용 중일 수 있으므로 복구 가능성 유지
- macOS `trash` 명령 사용 — `rm`보다 안전

### C. 3단계 잔여 흔적 확인 (memory-hygiene 4단계에 임베드됨)
- 본문 정리 + 알려진 이슈 섹션 + 보조 파일 — 3곳 모두 grep
- 본문만 정리하고 끝내면 dead reference가 남음

### D. 부분 패치의 인접 줄 매칭 위험 (재발)
- `patch` 도구의 fuzzy matching이 의도한 줄 너머까지 일치시키면 인접 줄이 같이 사라짐
- E 패치에서 "스크립트:" 줄까지 같이 지웠다가 복구
- **패치 후 grep + read_file로 인접 5줄 재확인 필수** (memory-hygiene 3단계 Pitfall에 이미 기록, 이번에 재확인)

## 안전 장치 체크리스트

- [x] 영향 범위 사전 조사 (스크립트/시크릿/폴더/크론)
- [x] 사용자 결정적 응답은 재확인 없이 진행
- [x] 시크릿은 trash (보안상 안전)
- [x] 부분 패치 후 인접 5줄 grep 검증
- [x] 3곳 잔여 흔적 grep (본문/이슈/보조파일)
- [x] 최종 MEMORY.md 크기 확인 (목표: 7,000B 이하)
