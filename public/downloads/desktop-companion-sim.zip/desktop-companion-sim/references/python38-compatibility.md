# Python 3.8 Compatibility — Type Hint Cheatsheet

Hermes PC runs **Python 3.8.8** (still, as of 2026-06). Newer syntax that requires 3.10+ **will** throw `TypeError` at import time. This cheatsheet covers the common offenders in companion-sim code.

## Type hints

### ❌ Don't (3.10+ only)

```python
def f(x: int | None) -> dict | None:    # SyntaxError in 3.8
    def g() -> list[str]: ...           # SyntaxError in 3.8
    return [int(x)]                     # ✓ this is fine, runtime check
```

### ✅ Use

```python
from typing import Optional, List, Dict, Union, Tuple, Callable

def f(x: Optional[int]) -> Optional[Dict]:    # OK in 3.8
    def g() -> List[str]: ...                  # OK in 3.8
    mapping: Dict[str, List[int]] = {}         # OK in 3.8
    pair: Union[int, str, None] = None         # OK in 3.8
```

## Other common offenders

### `match` statement (3.10+)

```python
# ❌ Don't
match cmd:
    case "quit": quit()

# ✅ Use
if cmd == "quit":
    quit()
elif cmd == "help":
    ...
```

### Parenthesized context managers (3.10+)

```python
# ❌ Don't
with (
    open("a") as a,
    open("b") as b,
):
    ...

# ✅ Use
with open("a") as a, open("b") as b:
    ...
```

### `ParamSpec` and `Concatenate` (3.10+)

If you reach for these, fall back to `typing.Any` placeholders.

## Detection at runtime

If you suspect a 3.10+ feature snuck in, run the file directly:

```bash
python3 -c "import your_module"
```

A syntax error fires immediately at parse time, not at the line that uses the feature. The error message is usually clear: "Type hints in stubs require 'annotations' feature" or "Expected ':' instead of '|'".

## Strategy: target 3.8+ for max compatibility

Unless you have a specific reason to need 3.10+ features, write code that works on 3.8. This is the lowest common denominator across:
- Hermes host machines (3.8.8 currently)
- macOS system Python (still 3.8 on some users' machines)
- Older Linux distros' default Python

If you do need 3.10+ features, document the minimum version in the file header:

```python
"""Kiwi face renderer. Requires Python 3.10+ for X | None type hints."""
```

## Upgrading Python on macOS

Not recommended for Hermes environment. Stick with the system Python and use `python3 -m pip install --user` for user-site packages. If you absolutely need 3.10+:

```bash
brew install python@3.10
# Don't override system python3 — let it stay
# Use python3.10 explicitly
```

This breaks fewer things than fighting macOS's `python3` symlink.
