# 알려진 Tistory 카테고리 ID (158-160차 검증)

Tistory `category.json` API는 블로그마다 고유 ID를 반환한다. `sigco.tistory.com` 블로그에서 자주 쓰이는 카테고리 ID:

| 카테고리 | ID | 검증 차수 | 용도 |
|---------|-----|----------|------|
| AI/ML | **1219746** | 158, 159, 160차 | AI 관련 주제 |
| (기타) | 미검증 | — | `python3 ~/.hermes/scripts/tistory_publisher.py --categories` 로 확인 가능 |

## 발행 시 카테고리 결정 절차

1. `blog_pipeline.py` JSON 출력의 `tistory_category_id` 필드 사용 (자동으로 카테고리 매핑됨)
2. 기본값 0이면 `--categories` 인자로 목록 조회 후 적절한 ID 선택
3. ID 0은 거부되므로 (`--category는 필수입니다` 에러) 반드시 유효 ID 입력

## Pitfalls

- `tistory_publisher.py`는 `--category`가 0이면 거절함. blog_pipeline의 `tistory_category_id`가 0이 아닌지 확인
- 카테고리 ID는 블로그마다 다름 (sigco.tistory.com 전용 ID). 다른 블로그 발행 시에는 그 블로그의 `category.json`에서 새로 조회
- 카테고리 ID가 변경되었을 수 있으므로 (Tistory 내부 정책), 가끔 1회 검증 필요. `blog_pipeline.py`의 `tistory_category_id`가 신뢰 가능한 최신 값
