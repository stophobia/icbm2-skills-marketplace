---
name: canvas-static-site-pipeline
description: 플랫폼 SDK 제약 하의 미니앱/마이크로 프로젝트 End-to-End 파이프라인 — 컨셉 → GitHub 저장소 생성 → 구현 → 배포. 토스 앱인토스·스팀 워크샵·iOS/Android 등 외부 플랫폼 SDK 의존 미니앱 + 단일 페이지 정적 웹 프로젝트(Canvas API, D3.js, Three.js, p5.js 시각화) 모두 포함. **brainstorming 전 플랫폼 SDK 가능 범위 검증 + 서버 0/API 키 0 원칙**이 강하게 작용하는 클래스.
category: devops
tags:
  - static-site
  - canvas
  - vercel
  - github
  - simulation
  - visualization
  - educational
  - platform-sdk
  - mini-app
  - toss-apps-in-toss
  - serverless
when to use: >
  사용자가 새로운 웹 앱/시뮬레이터/시각화 프로젝트 요청 시.
  "저장소 생성하고 Vercel로 배포해줘" 계열의 요청.
  Canvas API, 순수 JavaScript 기반 인터랙티브 앱 제작.
  **외부 플랫폼 SDK (앱인토스 Granite, 스팀 워크샵, iOS App Clip, Android Instant App 등) 기반 미니앱/챌린지 출품작**.
  단, **백엔드/DB/API 키 발급이 강하게 회피되는 상황**에서 아이디어 → 검증 → 구현으로 이어질 때.
---

# canvas-static-site-pipeline (확장: 플랫폼 SDK 미니앱 + 정적 웹)

> 본 스킬은 처음에 "단일 페이지 정적 웹 프로젝트"용으로 시작했지만, 2026-06-18 토스 앱인토스 바이브코딩 챌린지 세션에서 **외부 플랫폼 SDK 제약 하의 미니앱** 클래스도 다룬다. 챌린지 마감 + 서버 0 + API 키 0 + 다른 PC 핸드오프 같은 패턴이 동일하게 적용됨.

## steps

### 0. 컨셉/스코프 정리 (구현 전 필수)

**반드시 구현 전에 한다.** 사용자가 처음에 LLM/agent/AI benchmark를 언급해도 실제 deliverable이 **(a) 정적 시각화, (b) LLM 평가/벤치마크, (c) 외부 플랫폼 SDK 미니앱, (d) 그 외** 중 어디에 속하는지 먼저 분류한다 — 다른 워크플로로 빠지는 함정. (2026-06-11 세션: "Artemis Mission Control Challenge"가 LLM 에이전트 평가로 보였지만 실제 목표는 GPT-5.5 키노트 스타일 정적 궤적 시각화였음.)

**0.1 플랫폼 가능 범위 사전 검증 (조건부 필수)**

대상 플랫폼(앱인토스, 스팀, iOS 등)이 정해져 있고 그 플랫폼의 SDK/API가 필요한 아이디어면 **brainstorming 전에** "이 플랫폼 SDK가 실제로 그 데이터를 노출하는가"를 검증한다. 아이디어가 참신해도 SDK가 닫혀있으면 구현 불가.

검증 절차 (2026-06-18 앱인토스 챌린지 세션에서 확립):
1. **공식 SDK 패키지 확인** — NPM/Pub.dev/CocoaPods 등에서 플랫폼 SDK 검색 (예: `registry.npmjs.org/-/v1/search?text=@apps-in-toss`)
2. **패키지 tarball 직접 추출** — `curl -sL registry.npmjs.org/{pkg}/-/{pkg}-{ver}.tgz | tar -xz` → `src/` 트리에서 함수명/타입 추출
3. **각 함수의 시그니처 + 반환 타입 확인** — 특히 `Promise<X>`의 X가 string 한 개인지 객체/배열인지가 핵심
4. **공식 예제 repo** (예: `toss/apps-in-toss-examples`)에서 examples 디렉토리 목록 추출 — 어떤 use case가 공식 지원되는지 100% 판단 가능
5. **부재한 기능 보고** — 아이디어가 그 기능에 의존하면 **솔직하게 "기술적으로 불가능" 보고**. "노력하면 됩니다" 거짓말 금지.

참고: 앱인토스 Granite SDK 2.9.1 (2026-06 기준) 가능 범위는 `references/platform-sdk-capability-check.md` 참조. 핵심 요약:
- ✅ `getConsentedUserData` → 이름/성별/생년/전화/주소/이메일/USER_CONSUMPTION_HISTORY(string 1개)
- ✅ `storage` (단순 KV), `appLogin`, `fetchContacts`, `getCurrentLocation`, `getClipboardText`, `share` 등 디바이스 권한 SDK
- ❌ 결제/카드/송금/자산/친구 목록 내역 조회 API **전혀 없음**

확정 후 **brainstorming-first** 패턴으로 3~4개 결정 포인트를 A/B/C 옵션으로 제시하고 **추천 1개를 굵게** 표시한다.

**흔한 앱 함정 회피** (2026-06-18 학습): brainstorming의 1차 아이디어가 "정산/N빵", "날씨 코디", "약 알림", "계산기" 같은 일반적 카테고리면 **사용자가 "전부 있는 앱인데..." 거절할 가능성 ↑**. brainstorming 직전에 항상 다음 체크:
- 마켓플레이스/스토어에 이미 비슷한 앱 다수? → 컨셉 자체를 뒤집어야
- 누구나 생각할 수 있는 자명한 카테고리? → 사용자 차별화 어필 불가
- 차별화 포인트를 1차 옵션이 아니라 2~3개 합쳐서 만들어야

**0.2 데이터 소스 — 무키(API Key 불필요) 우선 검토 (2026-06-18 학습)**

챌린지/사이드 프로젝트에서 사용자가 "유지비 0"을 명시하면 **외부 공개 API도 키 발급 없이 쓸 수 있는 것만 골라야** 한다. 키 발급 + 만료 관리가 필요한 API는 6개월 후 앱이 망가질 수 있음.

검증 절차: `references/keyless-public-apis.md` 참조. 검증된 무키 API 예시:
- Open-Meteo (날씨/미세먼지/지오코딩) — CORS OK, 영구 무료
- 서울 열린데이터 sample 키 (따릉이) — quota 작지만 작동
- Nager Date (공휴일) — 100+ 국가, 무제한
- Nominatim Reverse (좌표→주소) — 1 req/sec rate limit
- Wikipedia REST API
- → 풀 카탈로그: <https://github.com/public-apis/public-apis> (Auth=No 인 것 우선)

**판단 기준**: 챌린지/사이드 프로젝트는 "발표일 작동 + 마감 후 6개월 안 깨짐"만 충족하면 OK. 키 만료 관리는 사용자가 원하지 않는 부채.

**0.3 결정 포인트 5가지** (상황에 따라 4개로 축약)

- **데이터 소스** (live API vs precomputed JSON vs runtime fetch — 아래 섹션). **무키 가능 여부**가 우선 필터.
- **렌더링 라이브러리** (Three.js vs regl vs r3f vs raw WebGL — 아래 섹션). **플랫폼 SDK 미니앱**이면 Granite(React Native) + TDS 디자인 시스템 강제.
- **비주얼 컨셉 범위** (2D / 3D / 토글 / 텔레메트리 오버레이)
- **작업 흐름 분할** (이 PC에서 끝 / 다른 PC 위주 / 협업) — 챌린지 마감 압박 시 "다른 PC로 핸드오프" 빈번
- **유지비 구조** (정적 호스팅 vs 서버 필요 vs 무료 티어 활용) — 챌린지/사이드 프로젝트에서 사용자가 명시적으로 거론할 때만. **무료 티어 + 무키 API = 서버 0으로 가능**

---

### 1. 저장소 생성
```bash
gh repo create {project-name} --public --clone
mkdir -p ~/Desktop/project/work/ai/{project-name}
```

**플랫폼 SDK 미니앱 변형 (2026-06-18 dongne-today)**: 챌린지 마감 압박 + 사용자가 다른 PC에서 작업 예정이라고 하면, **로컬 디렉토리만 생성 + 첫 commit만** 하고 사용자에게 GitHub push는 위임. README + AGENTS.md + docs/ 만 채운 상태로 핸드오프.

```bash
mkdir -p ~/workspace/{project-name}/docs
cd ~/workspace/{project-name}
git init -b main
# README/AGENTS.md/docs/LICENSE/.gitignore/package.json/granite.config.ts 작성
git add . && git commit -m "docs: initial docs-only scaffold for {project-name}"
# 사용자에게 push 위임: gh repo create sigco3111/{project-name} --public --source=. --push
```

상세 핸드오프 패턴은 step 7 참조.

### 2. 프로젝트 구현

**정적 웹 변형**:
```
/index.html    - 메인 HTML
/styles.css    - 스타일시트
/app.js        - Canvas/애니메이션 로직
/vercel.json   - Vercel 설정 (정적 사이트)
/README.md     - 한국어 프로젝트 설명
```

**플랫폼 SDK 미니앱 변형 (토스 앱인토스 등)**:
```
/README.md                  # 한/영 병기 다층 옵션
/AGENTS.md                  # 다른 PC 에이전트용 가이드 (필독)
/package.json               # 의존성 + scripts
/tsconfig.json              # TypeScript 설정
/granite.config.ts          # (앱인토스) 권한 + services 등록
/app.json                   # 앱 메타 + 챌린지 정보
/LICENSE                    # MIT + 3rd-party API attribution
/.gitignore                 # Granite + Node + Yarn
/docs/
  ├── ARCHITECTURE.md       # 앱 구조 + 데이터 흐름 + 컴포넌트 트리
  ├── DATA_SOURCES.md       # 6종 API 검증 결과 (응답 예시 포함)
  ├── DESIGN_SYSTEM.md      # 캐릭터 + 디자인 토큰
  ├── SETUP.md              # 플랫폼 SDK 환경 세팅 가이드
  ├── CHECKLIST.md          # 마감 일정표 + 위험 요소
  └── AI_VIBE_CODING.md     # AI 도구 (AX MCP 등) 워크플로
/src/                       # 구현 시작 시 채움 (assets/, components/, screens/, services/, utils/)
```

`vercel.json` 템플릿 (정적 웹):
```json
{
  "buildCommand": null,
  "outputDirectory": ".",
  "installCommand": null,
  "framework": null,
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
}
```

### 3. GitHub 푸시
```bash
cd ~/Desktop/project/work/ai/{project-name}
git init
git remote add origin https://github.com/sigco3111/{project-name}.git
git add -A
git commit -m "{이모지} {프로젝트명} - {한 줄 설명}"
git branch -M main
git push -u origin main
```

### 4. Vercel 배포 (정적 웹만)
```bash
vercel --yes --prod --token $(cat ~/.hermes/secrets/vercel_token.txt)
```

**플랫폼 SDK 미니앱**: 토스 앱인토스 콘솔(`apps-in-toss.toss.im`)에서 ZIP 업로드. Vercel 미사용.

### 5. 결과 보고
- GitHub 저장소 URL
- 라이브 Vercel URL (또는 플랫폼 마켓플레이스 URL)
- 구현된 기능 목록

### 5.5 Self-check (보고 전, "실망" 방지)

**사용자 보고 전 한 번 더 점검.** 결과물이 "발표 데모"급이려면:

- [ ] **브라우저에서 직접 확인** — Vercel URL 열어서 (a) 첫 프레임에 모든 body 보임, (b) trail이 끊김 없이 부드럽게 그려짐, (c) timeline/play 정상 작동, (d) 콘솔 에러 없음. curl HEAD 200 + grep 데이터 본문만으로는 부족.
- [ ] **시각적 임팩트** — 단순 Three.js sphere + line은 "키노트 데모"가 아님. 발광(emissive), halo, particle star field, 단일 액센트 색, 텔레메트리 HUD 같은 요소가 최소 1~2개.
- [ ] **인터랙션** — 자동 orbit만으로는 부족. OrbitControls 또는 hover/click 인터랙션 1개 이상.
- [ ] **README의 "구현된 기능"** — phase table / screenshot 등이 **실제 결과물과 일치**. 부풀려 쓰지 않기. 사용자가 phase table 보고 Vercel 열면 "이게 그거?" 안 되게.

자체 평가 통과 못 하면 **추가 polish 1라운드** 후 보고. (2026-06-11: phase table의 "GPT-5.5 데모 스타일" 카피와 실제 Three.js 결과물 사이 간극이 사용자 실망 신호. "있어 보이게 쓰지 말 것" lesson.)

### 6. 철거 / Cleanup (사용자가 요청 시)

Vercel + GitHub repo 한 번에 정리. **로컬 디렉토리, /tmp 산출물, ~/.hermes/skills/ 심볼릭 링크**는 별도 — 사용자에게 확인 후 `trash`로.

```bash
# 1) GitHub repo 삭제
gh repo delete sigco3111/{project-name} --yes

# 2) Vercel 프로젝트 + 모든 배포 + alias 제거
# ⚠️ `vercel project rm --yes` 옵션 없음. `yes y | ...` 무한 stdin은 hang.
# → `printf "y\n"` + `--non-interactive` 조합이 정답.
printf "y\n" | vercel project rm {project-name} --non-interactive --token $(cat ~/.hermes/secrets/vercel_token.txt)

# 3) 남은 alias 개별 제거 (production + preview URL들)
for alias in $(vercel alias ls --token $(cat ~/.hermes/secrets/vercel_token.txt) 2>&1 | grep -i {project-name} | awk '{print $1}'); do
  vercel alias rm "$alias" --yes --token $(cat ~/.hermes/secrets/vercel_token.txt)
done

# 4) 검증 — project/alias 모두 0건
vercel project ls --token $(cat ~/.hermes/secrets/vercel_token.txt) 2>&1 | grep -i {project-name}
vercel alias ls --token $(cat ~/.hermes/secrets/vercel_token.txt) 2>&1 | grep -i {project-name}

# 5) 로컬 디렉토리 + /tmp 산출물
trash ~/Desktop/project/work/ai/{project-name}
trash /tmp/{h_*,*.json}  # 데이터 수집 단계 임시 파일
```

**정리 대상 체크리스트**:
- [ ] GitHub repo (소유자 확인: `gh repo view sigco3111/{name}` → 404)
- [ ] Vercel project + 모든 deployment
- [ ] Vercel alias (production + preview URL 모두)
- [ ] 로컬 디렉토리 (사용자 확인 후 `trash`, 절대 `rm -rf` 금지)
- [ ] /tmp 임시 파일 (ephemeris raw, JSON 변환본 등)
- [ ] `~/.hermes/skills/` 심볼릭 링크 (다른 프로젝트에서 쓰는 스킬이면 보존)

### 7. 다른 PC 핸드오프 (자주 발생)

사용자가 "다른 PC에서 작업 예정"을 시사하면 step 5 직후 **자동으로 다음을 작성**:

1. **상세 docs/ 폴더** — `docs/ARCHITECTURE.md`, `docs/DATA_SOURCES.md`, `docs/SETUP.md`, `docs/CHECKLIST.md` 등 챌린지/플랫폼별 가이드
2. **`AGENTS.md`** — 다른 PC에서 작업할 AI 에이전트(Claude Code, Cursor, Codex 등)가 이 저장소를 열었을 때 즉시 컨텍스트 복원 가능하도록

**AGENTS.md 필수 포함 내용** (2026-06-18 dongne-today 패턴):
- 프로젝트 한 줄 요약
- 디렉토리 구조 (현재 상태 + 구현 시 추가될 구조)
- **절대 어기지 말 것 (Red Lines)** — 서버 만들지 마, API 키 발급 받지 마, 결제 SDK 사용 금지 등
- 핵심 기술 결정 (플랫폼 SDK 가능 범위, 무키 API 목록, 디자인 시스템)
- AI 비브코딩 워크플로 (AX MCP 등 공식 도구)
- 작업 시작 체크리스트
- 막혔을 때 도움 요청 채널

다른 PC에서:
```bash
git clone https://github.com/sigco3111/{project-name}.git
cd {project-name}
# AGENTS.md → docs/ 순서로 읽기
# yarn install (npmAuthToken 필요)
# yarn dev → 샌드박스 앱 QR 스캔 → 테스트
```

**정적 웹 변형 HANDOFF.md 예시**:
```markdown
# Handoff — 다른 PC에서 이어서 작업하기

## 🌐 라이브 URL
- Vercel: https://{project-name}.vercel.app
- GitHub: https://github.com/sigco3111/{project-name}

## 📦 클론 & 실행
git clone https://github.com/sigco3111/{project-name}.git
cd {project-name}
npm install
npm run dev   # http://localhost:5173

## 🧱 핵심 파일
- app.js — Three.js main scene (line XX~YY = scene setup)
- trajectory.json — JPL Horizons data
- index.html — HUD layout

## 🎯 다음 단계 후보
1. OrbitControls (마우스 인터랙션)
2. Phase labels (TLI / MCC / flyby / re-entry)
3. Mobile touch

## 🔑 토큰 (다른 PC)
- Vercel: `vercel login` 필요
- GitHub: gh auth login
```

핸드오프는 GitHub repo에 같이 커밋 (`HANDOFF.md` 또는 `AGENTS.md`) — `git clone` 한 번이면 다 따라옴.

## implementation notes

**GitHub Pages 배포 후 검증:**
- 롤백 감지: `curl -sI "https://{user}.github.io/{repo}/" | grep last-modified` — 날짜가 예상과 다르면 롤백 의심
- 컨텐츠 검증: `curl -s "URL" | grep -c "unique-string"` — 핵심 문자열 존재 확인
- 실패 시: `git log --oneline -5` → 최종 커밋 확인 → 강제 푸시로 복구

**OpenCode 위임 시:**
- `delegate_task` 사용 시 `toolsets: ["terminal", "file"]` 필수
- OpenCode 404/연결 오류 시 직접 구현으로 폴백
- ⚠️ **2026-06-18 검증**: `delegate_task`로 보낸 서브에이전트는 **환경 점검만 하고 종료되는 패턴**이 자주 발생 (web fetch + browser 자동화 미작동, 환경에서 즉시 실패). 직접 `terminal` + `web` toolsets로 직접 작업이 더 빠를 때 많음. **웹 조사/스크래핑 위임은 실패 가능성 높음** — 직접 fetch 권장.

**Canvas 구현 (정적 웹):**
- DPI 대응: `canvas.width = rect.width * 2; ctx.scale(2, 2)`
- 애니메이션: `requestAnimationFrame` + deltaTime
- 반응형: `window.addEventListener('resize', resizeCanvas)`

**플랫폼 SDK 미니앱 구현 (앱인토스 Granite 등):**
- Granite = React Native 기반 (`@granite-js/react-native`)
- 디자인 시스템 = 토스 TDS (Toss Design System) **검수 필수**
- 빌드: `yarn granite build` → `dist/` 폴더에 번들
- 배포: `apps-in-toss.toss.im` 콘솔에서 ZIP 업로드
- AI 도구: `ax mcp start` (AppsInToss eXperience MCP) — Cursor/Claude에서 토스 공식 문서/예제 실시간 조회
  - `search_docs`, `get_doc`, `search_tds_rn_docs`, `get_tds_rn_doc`, `list_examples`, `get_example` 6종 도구
  - 설치: `brew tap toss/tap && brew install ax` 또는 `npm i -g @apps-in-toss/ax`

**데이터 소스 결정 (정적 시각화 / 미니앱 공통):**
실세계 데이터 시각화 프로젝트(궤적, 날씨, 주가, 지진 등)는 거의 항상 이 결정이 먼저다. 세 가지 패턴:

| 패턴 | 장점 | 단점 | 적합 시점 |
|---|---|---|---|
| **A. 빌드 시 precompute** — Python/Node로 API 호출 → JSON 커밋 | 정적 호스팅 OK, 클라이언트 부담 0, 결정적 | 데이터 갱신 시 재빌드 필요 | 임의 시점 스냅샷 (NASA JPL Horizons, 과거 주가) |
| **B. 런타임 fetch** — 클라이언트가 공개 API 직접 호출 | 항상 최신, 빌드 단순 | CORS·API 키·rate limit 이슈 | 날씨, 라이브 주가 (API 키 클라이언트 노출 시 B는 부적합) |
| **C. 사전 임베드 + 시뮬레이션** — 임의 시점 데이터 + 클라이언트 보간 | 1개 데이터셋으로 임의 시점 표시 | 계산량·정확도 트레이드오프 | "Artemis II 발사 10일 trajectory" 같이 고정 임무 표시 |

2026-06-11 Artemis 시각화 세션에서는 **A 패턴 채택** — Horizons API에서 발사±10일 ephemeris를 시간 스텝으로 sampling해 `data/trajectory.json` 커밋, Vite 정적 호스팅. 가장 안전·가볍고 결정적.

2026-06-18 앱인토스 챌린지 dongne-today는 **B 패턴 + 무키 API 6종 채택** — Open-Meteo/따릉이/Nager Date를 클라이언트에서 직접 fetch. 챌린지 마감이므로 빌드 시간 줄이는 게 우선.

**WebGL 라이브러리 선택 (정적 웹):**
사용자가 "WebGL + Vite"를 지정하면 후보:
- **Three.js** — 가장 보편적. 광원·카메라 컨트롤·로드러 즉시 사용. AI 키노트 데모 느낌에 가장 가까움. (추천 기본값)
- **regl** — functional WebGL, 더 가벼움, 코드 명시적. 단순 도형·궤적선에 적합.
- **react-three-fiber + drei** — React 선호 시. 컴포넌트 구조.
- **raw WebGL2** — 가장 가볍지만 작업량 多. 특수한 셰이더 효과 필요 시.

Vite + Three.js 보일러플레이트는 `templates/threejs-vite-data-viz.md` 참조 (전체 프로젝트 구조 + 코드 스니펫 + 배포 워크플로 + JSON inline 검증법).

NASA JPL Horizons(실측 천체역학) API로 우주선/행성 ephemeris를 가져오는 절차는 `references/jpl-horizons-api-guide.md` 참조 — `curl -k` SSL 우회, spacecraft ID 검색, 발사/임무 cutoff 시간 처리, km→scene unit 스케일링.

**AI 키노트 데모 미학 (GPT-5.5/Gemini/Claude 발표 페이지 스타일):**
- **배경**: 완전 검정 `#000` 또는 매우 어두운 그라데이션 (`#0a0a14` → `#000`). 별 입자(particle field) 추가하면 "우주적" 인상 ↑.
- **색상 팔레트**: 단일 액센트 (시안 `#00d4ff` 또는 오렌지 `#ff6b35`) + 흰색 텍스트. 무지개 그라데이션 금지.
- **타이포그래피**: 모노스페이스 또는 Inter/Geist Sans. 텍스트는 화면 모서리에 floating, 중앙은 시각화 전용.
- **텔레메트리 오버레이**: 좌상단 = 미션명·시작 시각, 우상단 = 현재 속도/거리/단계. 폰트 작게(12~14px), 반투명.
- **카메라**: 자동 회전 (0.1 rad/s) + 마우스 드래그로 manual override. 너무 빠르지 않게.
- **궤적선**: TubeGeometry 또는 Line2 (fat line), 발광(`emissive` + `emissiveIntensity`)로 빛나는 느낌.
- **포인트 라이트**: 궤적 따라가는 광원 1~2개, 거리 따라 intensity 변동.
상세 노트는 `references/ai-keynote-demo-aesthetics.md`.

**Pitfalls:**
- **정적 시각화 vs LLM 평가 혼동**: "Artemis Challenge", "GPT-X benchmark" 같은 키워드가 나와도 deliverable이 agent 평가 환경이 아닐 수 있음. `clarify`로 1차 분류 후 진행.
- **아이디어 1차 카테고리 함정** (2026-06-18 학습): N빵/정산, 날씨 코디, 약 알림, 계산기 같은 자명한 카테고리는 brainstorming 직후 사용자가 "전부 있는 앱인데..." 거절함. 마켓플레이스/스토어에 이미 포화된 카테고리는 컨셉 자체를 뒤집어야. **SDK 검증 + 흔한 앱 회피**를 step 0의 brainstorming 직전에 항상 거치기.
- **SDK 가능 범위 미검증 아이디어 함정** (2026-06-18 학습): "내 토스 사용 패턴 리포트" 같은 아이디어는 1차적으로 그럴듯해 보이지만 SDK가 결제/송금/자산 내역을 노출하지 않으면 구현 불가. **brainstorming 전에 항상 `0.1 플랫폼 가능 범위 사전 검증` 절차 거치기**. 솔직하게 "기술적으로 불가능" 보고가 거짓 "노력하면 됩니다"보다 낫다.
- **서버 유지비 사용자 거절** (2026-06-18 학습): 사용자가 챌린지/사이드 프로젝트 아이디어에서 서버 의존성을 거절하는 패턴 확인. brainstorming 결정 포인트에 "유지비 구조" 추가하고 **정적 호스팅/클라이언트 처리/무료 티어** 우선 검토.
- **API 키 발급 사용자 거절** (2026-06-18 학습): "서버 0" 다음 단계로 "API 키 0"도 강하게 작용. 사용자가 "키 발급이 필요한 경우 키만료일에 따른 유지보수가 걱정됨"이라고 명시적으로 거절. **무키 공개 API만 사용**하는 게 챌린지/사이드 프로젝트 기본. 검증 절차는 `0.2 데이터 소스 — 무키 우선 검토` + `references/keyless-public-apis.md`.
- **Vercel 스킬 이름 충돌**: `skill_view(name='vercel')`은 **ambiguous 에러**를 던진다 (devops 본 스킬 + archive 템플릿이 충돌). `skill_view(name='devops/vercel')` 처럼 카테고리 경로 명시. 이 skill 본문에서 `vercel`을 related-skill로 언급할 때도 `'devops/vercel'`로 표기.
- **빌드 명령 누락**: Vite 프로젝트는 `vercel.json`에 `buildCommand: "npm run build"`, `outputDirectory: "dist"` 필수. `canvas-static-site-pipeline` 기본 템플릿(plain HTML)은 빌드 명령 없음 — Vite로 가면 템플릿을 덮어쓴다.
- **CORS 우회 안 됨**: 런타임 fetch 패턴(B)에서 API가 CORS 막으면 백엔드 프록시 필요 → 정적 호스팅 불가. 가능하면 A 패턴 권장.
- **Vite prod JSON import는 minify된 채 inline됨** (2026-06-11 학습): `grep "mission" dist/assets/*.js` 같은 키 검색은 0. 대신 **데이터 패턴**(날짜, 숫자)으로 검증: `grep -c "2026-04-" dist/*.js` → inline 됐다면 644+ 같은 큰 숫자. 0이면 JSON이 external URL fetch로 빠진 것 → 코드에서 `fetch()`로 변경 필요.
- **Vercel 토큰 export 형태** (2026-06-11 학습): `vercel --token $(cat ~/.hermes/secrets/vercel_token.txt)` 한 줄이 가장 짧지만 subshell 안에선 변수 export가 필요. `export VERCEL_TOKEN=...; vercel --token $VERCEL_TOKEN` 패턴. 첫 배포 시 `vercel link --yes`로 프로젝트 연결 후 `vercel deploy --prod`가 안전.
- **`vercel project rm` 옵션 함정** (2026-06-11 학습): `--yes`, `--force`, `-f` 전부 **unknown option** 에러. 정답: `--non-interactive` + `printf "y\n" |` (single stdin). `yes y |`는 무한 stdin으로 60초+ hang. 옵션 확인은 `vercel project rm --help`로 (Global Options: `--non-interactive` 명시). cleanup script는 항상 timeout 또는 single-y stdin으로.
- **Vercel cleanup 후 alias 잔존**: project 삭제해도 alias (production 도메인)는 **자동 삭제되지 않음**. `vercel alias ls`로 잔존 확인 후 `vercel alias rm` 개별 처리. preview alias (UUID 포함된 `xxx-username.vercel.app`)는 보통 deploy와 함께 사라지지만 production alias는 명시적 제거 필요.
- **shell 명령에 `$()` + secret 환경변수 섞으면 break** (2026-06-11 학습): `export VERCEL_TOKEN=$(cat ~/.hermes/secrets/vercel_token.txt)` 같은 한 줄을 `terminal`/`patch`로 직접 실행하면 `(...)` 부분이 tool output 마스킹 단계에서 깨져서 `syntax error near unexpected token ')'` 에러. 해결: `write_file`로 `.sh` 스크립트 본문 전체를 먼저 쓰고 `chmod +x` → 실행. heredoc 안에서도 동일 문제 발생 — `.sh` 파일이 정답. `HOM...` 같은 환경변수는 write_file 결과도 마스킹되니 주의.
- **delegate_task 서브에이전트 환경 점검 실패 패턴** (2026-06-18 학습): web fetch / browser 자동화 미작동으로 서브에이전트가 환경 점검만 하고 즉시 종료하는 패턴 자주 발생. **웹 조사/스크래핑/리서치는 delegate_task 대신 직접 `terminal` + `web` toolsets로 작업**이 더 빠르고 안정적.
- **패키지 러너는 `npx -y`로 통일 — cron/shell script에서 `bunx` 함정** (2026-06-18 학습): npm CLI 도구를 다른 PC로 핸드오프하는 패키지(`tokscale-setup/scripts/install.sh`, `daily-submit.sh` 등)에 처음에는 `bunx {pkg}@latest ...`로 작성했지만, 사용자가 "크론잡에서 bunx가 동작 안할 수 있다. bunx가 npx 호환이라 npx로 작성해줘. `bunx → npx -y`로 일괄 교체" 라고 명시적으로 거절. Bun 미설치 환경에서는 `bunx` 자체가 PATH에 없어서 `command -v bunx`가 실패하고, Bun이 있어도 cron 환경(매우 제한된 PATH)에서는 `bunx`가 PATH에 잡히지 않을 수 있음. **결론**: 셸 alias/cron script/다른 PC 핸드오프 패키지에서는 **`npx -y`로 통일**이 정답. Bun 설치는 사용자가 명시적으로 선택한 환경일 때만 `bunx` 우선. install 스크립트는 두 runner를 모두 감지해서 fallback 구현: `command -v bunx &> /dev/null && RUNNER=bunx || RUNNER="npx -y"`. 적용 대상: 다른 PC로 전달할 셸 스크립트, `~/.zshrc` alias, crontab 등록 스크립트, AGENTS.md/HANDOFF.md의 모든 예제 명령어.

**갤러리 카드 구현 패턴 (정적 HTML):**
- 이미지 3개 고정 너비: `width: 33.33%` flex 레이아웃, 카드마다 이미지 수 동적 대응 필요 시 class based (`one/two/three`)
- **모달 이미지 뷰어**: 클릭 → `openModal(img)` → 카드 내 `.card-img-wrap`에서 전체 이미지 배열 추출 → 좌우 화살표(`navModal`), ESC 키 지원. `data-search` 속성에 검색 키워드 저장
- **접기/펼침 기능**: preview 텍스트만 HTML에 있으면 의미 없음 → 전체 텍스트를 `data-fulllyrics` 속성에 분리 저장 → 클릭 시 모달(`showLyrics`)로 표시. `data-fulllyrics` 없는 카드(가사 없음)는 토글 의미 없음

## related skills
- `devops/vercel` — Vercel 특화 작업 (환경변수, 로그, 프로젝트 관리). **반드시 카테고리 경로 명시** — bare name `'vercel'`은 ambiguous 에러 발생.
- `github/github-cli` — GitHub 저장소 관리
- `autonomous-ai-agents/opencode` — 코딩 에이전트 위임 (실패 시 이 파이프라인으로 폴백)
- `automation/python-oss-bootstrap` — Python OSS 부트스트랩 패턴 (Phase 0 "다른 PC 변형"은 범용, 그 외는 Python 전용이지만 디렉토리 구조/문서 패턴 차용 가능)