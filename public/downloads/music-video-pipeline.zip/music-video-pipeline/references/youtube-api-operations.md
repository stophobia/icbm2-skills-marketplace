# YouTube API 운영 참고 (2026-05-23)

## Quota 관리 — YouTube Data API (2026-05-23)

**API quota (기본):** ~6 Video INSERTs/day per project  
**그러나:** 사용자 경험상 15개+ 업로드 가능 — 기본 quota보다 높은 프로젝트로 추정.
**주의:** 429 발생 시 다음 날 아침 자동 복구. 당일 중복 시도 의미 없음.

**429 발생 시 대응:**
1. 영상 제작 완료 후 업로드 대기 상태로 두기
2. 다음 날 아침 quota 리셋 후 연속 업로드
3. 토큰은 2시간마다 만료되므로 업로드 직전 refresh 필요

## 토큰 추출 워크어라운드

`google-api-python-client` 모듈 import 실패 시 (의존성 충돌):
```python
import os

TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")
CLIENT_FILE = os.path.expanduser("~/.hermes/secrets/client_secret_1088895812408-fa0fjavjisgfdaubidspvegqk0harjqg.apps.googleusercontent.com.json")

with open(TOKEN_FILE, 'rb') as f:
    data = f.read()

# Access token 추출
token_start = data.find(b'ya29.')
token_end = data.find(b'\x94', token_start + 30)
access_token = data[token_start:token_end].decode('utf-8', errors='replace')

# Refresh token 추출
refresh_start = data.find(b'1//')
refresh_end = data.find(b'\x94', refresh_start + 20)
refresh_token = data[refresh_start:refresh_end].decode('utf-8', errors='replace')

# 토큰 리프레시
import requests, json
with open(CLIENT_FILE) as f:
    client = json.load(f)

resp = requests.post("https://oauth2.googleapis.com/token", data={
    "client_id": client['installed']['client_id'],
    "client_secret": client['installed']['client_secret'],
    "refresh_token": refresh_token,
    "grant_type": "refresh_token"
})
new_token = resp.json()['access_token']
```

## 9:16 Shorts 제작 — 이미지 기반 Approach

FFmpeg로 16:9 → 9:16 변환 시反复 "moov atom not found" 오류 발생.
**안정적인 방법:** 원본 이미지에서 9:16 영상을 직접 생성.

```bash
# 3개 이미지 × 20초 = 60초 Shorts
ffmpeg -y \
  -loop 1 -t 20 -i image1.png \
  -loop 1 -t 20 -i image2.png \
  -loop 1 -t 20 -i image3.png \
  -f lavfi -t 60 -i anullsrc=r=44100:cl=stereo \
  -filter_complex "[0:v]scale=1920:1080,crop=1920:1080,fps=1[v0];
                     [1:v]scale=1920:1080,crop=1920:1080,fps=1[v1];
                     [2:v]scale=1920:1080,crop=1920:1080,fps=1[v2];
                     [v0][v1][v2]concat=n=3:v=1:a=0[vt];
                     [vt][3:a]concat=n=1:v=1:a=1[out]" \
  -map "[out]" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  short_video.mp4

# 세로형 (9:16) 변환
ffmpeg -y -i short_video.mp4 \
  -vf "scale=-2:1920" \
  -c:v libx264 -preset fast -crf 23 \
  -c:a copy \
  short_vertical.mp4
```

## FFmpeg concat + audio 트랩

**문제:** `concat=n=3:v=1:a=1` 사용 시 모든 입력에 audio stream 필요.
**해결:** audio 없는 입력 → `anullsrc` 더미 오디오注入.

```bash
# audio 없는 이미지 → audio 포함 세그먼트로 변환
ffmpeg -y -loop 1 -i image.png -f lavfi -i anullsrc=r=44100:cl=stereo \
  -t 20 -vf "scale=1280:720" -c:v libx264 -preset ultrafast -crf 28 \
  -c:a aac -b:a 128k seg1.mp4
```

## Gallery 페이지 로딩 안 되는 问题

**원인:** `gallery_data.json`에 로그 메시지 텍스트가 youtube_url 필드에 그대로 저장됨.
**예시:**
```json
// ❌ 잘못된 형태
"youtube_url": "Uploading:...\nSUCCESS: https://youtube.com/watch?v=xxx"

// ✅ 올바른 형태
"youtube_url": "https://youtube.com/watch?v=xxx"
```

**디버깅:** 페이지가 "Loading..."에서 멈추면 → DevTools Console에서 JSON parse error 확인 → gallery_data.json 첫 번째 entry 검사.