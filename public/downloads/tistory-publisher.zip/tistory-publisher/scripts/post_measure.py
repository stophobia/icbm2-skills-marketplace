#!/usr/bin/env python3
"""
Tistory 발행용 본문 측정 헬퍼 (108차 신규)

사용법:
  python3 post_measure.py /tmp/blog_post.md
  python3 post_measure.py /tmp/blog_tistory.html --html

출력:
  - 본문 글자수 (공백 제외)
  - H2 개수
  - 총 문장 수
  - 단문 15~40자 개수 + 비중
  - 단문 20~30자 개수 + 비중
  - 평균 문장 길이
  - 가설 4중 충족 진단
  - h1_idx 위치 (cover figure 삽입용)

108차 교훈:
  - re.sub(r'\s+', '', text) 후 split하면 delimiter 없어 1문장 처리됨
  - 올바른 패턴: <[^>]+> 제거 → &xxx; 제거 → [ \t]+ 만 제거 (줄바꿈 유지) → split
  - 본문 6회 재조정의 고통을 함수화
"""
import re
import sys
import argparse


def measure_markdown(md_path: str) -> dict:
    """Markdown 파일 측정"""
    with open(md_path, 'r', encoding='utf-8') as f:
        md = f.read()

    # 헤더 라인 제외
    body = re.sub(r'^#.*$', '', md, flags=re.MULTILINE)
    # 코드블록 제외
    body = re.sub(r'```.*?```', '', body, flags=re.DOTALL)
    # 글머리 마커 제거
    body = re.sub(r'^[\s]*[-*•]\s*', '', body, flags=re.MULTILINE)
    # 연속 공백 정리 (줄바꿈은 유지!)
    body = re.sub(r'[ \t]+', ' ', body)

    # 본문 글자수 (공백 제외)
    text_chars = re.sub(r'\s', '', body)
    chars = len(text_chars)

    # H2 개수
    h2_count = len(re.findall(r'^##\s+', md, re.MULTILINE))

    # 한국어 문장 분리
    sentences = re.split(r'(?<=[.!?])\s+', body)
    sentences = [s.strip() for s in sentences if len(s.strip()) >= 5]
    sent_count = len(sentences)

    # 단문 카운트 (108차 가설: 15~40자 1차 지표, 20~30자 보조)
    short_15_40 = [s for s in sentences if 15 <= len(re.sub(r'\s', '', s)) <= 40]
    short_20_30 = [s for s in sentences if 20 <= len(re.sub(r'\s', '', s)) <= 30]

    short_15_40_pct = 100 * len(short_15_40) / max(sent_count, 1)
    short_20_30_pct = 100 * len(short_20_30) / max(sent_count, 1)

    # 평균 문장 길이
    avg_len = sum(len(re.sub(r'\s', '', s)) for s in sentences) / max(sent_count, 1)

    return {
        'chars': chars,
        'h2_count': h2_count,
        'sentences': sent_count,
        'short_15_40': len(short_15_40),
        'short_15_40_pct': short_15_40_pct,
        'short_20_30': len(short_20_30),
        'short_20_30_pct': short_20_30_pct,
        'avg_sentence_len': avg_len,
    }


def measure_html(html_path: str) -> dict:
    """HTML 파일 측정 (markdown_to_tistory_html.py 출력)"""
    with open(html_path, 'r', encoding='utf-8') as f:
        html = f.read()

    # body 추출
    body_match = re.search(r'<body[^>]*>(.*?)</body>', html, re.DOTALL)
    body = body_match.group(1) if body_match else html

    # HTML 태그 제거 (공백 1칸으로)
    text_only = re.sub(r'<[^>]+>', ' ', body)
    # HTML 엔티티 제거
    text_only = re.sub(r'&[a-z]+;', ' ', text_only)
    # 연속 공백 정리 (줄바꿈은 유지)
    text_only = re.sub(r'[ \t]+', ' ', text_only)

    # 본문 글자수
    text_chars = re.sub(r'\s', '', text_only)
    chars = len(text_chars)

    # H2 개수
    h2_count = body.count('<h2 ')

    # 한국어 문장 분리
    sentences = re.split(r'(?<=[.!?])\s+', text_only)
    sentences = [s.strip() for s in sentences if len(s.strip()) >= 5]
    sent_count = len(sentences)

    # 단문 카운트
    short_15_40 = [s for s in sentences if 15 <= len(re.sub(r'\s', '', s)) <= 40]
    short_20_30 = [s for s in sentences if 20 <= len(re.sub(r'\s', '', s)) <= 30]

    short_15_40_pct = 100 * len(short_15_40) / max(sent_count, 1)
    short_20_30_pct = 100 * len(short_20_30) / max(sent_count, 1)

    # 평균 문장 길이
    avg_len = sum(len(re.sub(r'\s', '', s)) for s in sentences) / max(sent_count, 1)

    # h1 위치 (cover figure 삽입용)
    h1_idx = html.find('<h1 ')

    return {
        'chars': chars,
        'h2_count': h2_count,
        'sentences': sent_count,
        'short_15_40': len(short_15_40),
        'short_15_40_pct': short_15_40_pct,
        'short_20_30': len(short_20_30),
        'short_20_30_pct': short_20_30_pct,
        'avg_sentence_len': avg_len,
        'h1_idx': h1_idx,
    }


def diagnose_hypothesis(m: dict) -> list:
    """가설 4중 조합 진단 (96차~108차 누적)"""
    issues = []
    score = 0

    # H2 4~6개
    if 4 <= m['h2_count'] <= 6:
        score += 1
    else:
        issues.append(f"❌ H2 {m['h2_count']}개 — 가설 4~6개 위반")

    # 본문 2,300~3,000자 (108차: 1자 단위 민감)
    if 2300 <= m['chars'] <= 3000:
        score += 1
    elif m['chars'] < 2300:
        margin = 2300 - m['chars']
        issues.append(f"❌ 본문 {m['chars']}자 — 하한선 -{margin}자 미달 (108차: 1자 단위 경계)")
    else:
        issues.append(f"⚠️ 본문 {m['chars']}자 — 가설 상한 3000자 +{(m['chars']-3000)}자 초과")

    # 단문 7~22개 (절대량)
    if 7 <= m['short_15_40'] <= 22:
        score += 1
    else:
        issues.append(f"❌ 단문(15~40자) {m['short_15_40']}개 — 가설 7~22개 위반")

    # 단문 25~35% (비중)
    if 25 <= m['short_15_40_pct'] <= 35:
        score += 1
    else:
        issues.append(f"❌ 단문 비중 {m['short_15_40_pct']:.1f}% — 가설 25~35% 위반 (108차: 39%는 A 70점)")

    return issues, score


def main():
    parser = argparse.ArgumentParser(description='Tistory 발행용 본문 측정')
    parser.add_argument('path', help='측정할 파일 경로 (.md 또는 .html)')
    parser.add_argument('--html', action='store_true', help='HTML 파일로 처리')
    args = parser.parse_args()

    if args.html or args.path.endswith('.html'):
        m = measure_html(args.path)
        print(f"=== HTML 측정: {args.path} ===")
    else:
        m = measure_markdown(args.path)
        print(f"=== Markdown 측정: {args.path} ===")

    print(f"본문 글자수 (공백 제외): {m['chars']}자")
    print(f"H2 개수: {m['h2_count']}개")
    print(f"총 문장 수: {m['sentences']}개")
    print(f"단문 15~40자: {m['short_15_40']}개 ({m['short_15_40_pct']:.1f}%) [1차 지표]")
    print(f"단문 20~30자: {m['short_20_30']}개 ({m['short_20_30_pct']:.1f}%) [보조 지표]")
    print(f"평균 문장 길이: {m['avg_sentence_len']:.1f}자")

    if 'h1_idx' in m:
        print(f"h1_idx 위치: {m['h1_idx']} (cover figure 삽입 시 {'>= 0 패턴 사용' if m['h1_idx'] >= 0 else 'h1 없음'})")

    print()
    print("=== 가설 4중 조합 진단 (96차~108차 누적) ===")
    issues, score = diagnose_hypothesis(m)
    if not issues:
        print(f"✅ 가설 4중 모두 충족 ({score}/4) — readability 14/20 + A 80점대 예상")
    else:
        for issue in issues:
            print(issue)
        print(f"충족: {score}/4 — readability 11~13/20 + A 70~78점 예상")


if __name__ == '__main__':
    main()
