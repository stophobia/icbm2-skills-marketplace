# ngrok 검수 재시도 — 부처님오신날 세션 (2026-05-25)

## 문제 발생
家主님이 기존 두 영상(직장인 점심시간, 사진 찍기 어색한 친구들)을 탈락시키시고, 부처님오신날 새 뮤직비디오 제작 요청.

## 해결한 문제들

### 1. mmx music 생성 — 명령 인자 형식
**잘못된 형식:**
```bash
mmx music "Upbeat K-pop..." ...  # positional arguments 안 됨
```

**올바른 형식:**
```bash
mmx music generate \
  --prompt "Upbeat K-pop, 130 BPM, Hook First..." \
  --lyrics "[Verse 1]..." \
  --vocals "bright female soprano, cheerful, energetic" \
  --genre pop \
  --mood uplifting \
  --bpm 130 \
  --out music_buddha_20260525.mp3
```

### 2. PIL ImportError — python3 경로 문제
**문제:** `python3` → hermes-agent venv Python 3.11 (PIL 없음)
**해결:** `which python3` 확인 후 경로 선택. PIL은 system Python 3.9에 설치.

### 3. Ken Burns 슬라이드쇼 — FFmpeg zoompan timeout
**문제:** FFmpeg zoompan으로 Ken Burns 효과 생성 시 120초 이상 → `execute_code` timeout (120초)
**해결:** `terminal(background=True)` 사용

### 4. ngrok 재시도 — 포트/프로세스 충돌
**문제:** 기존 ngrok/http.server 프로세스 잔여로 `ERR_NGROK_334`
**순서:** pkill ngrok → pkill http.server → kill -9 residual → 새 실행

### 5.家主님 선호도 (확인됨 2026-05-25)
- 음악: **2~3분 분량** (家主님 "2~3분 분량으로 해줘" 직접 요청)
- 후렴선행형 + 밝고 신나는 Upbeat
- mmx music generate의 `--lyrics`에서 구조 태그 ([Verse], [Hook], [Bridge] 등)

## 생성된 파일
```
images_20260525_083730/image_0.jpg  (613KB)
images_20260525_083730/image_1.jpg  (407KB)
images_20260525_083730/image_2.jpg  (328KB)
music_buddha_20260525_083730.mp3    (120초/3.8MB)
equalizer.gif                      (30초 loop, PIL generated)
slide_raw_20260525_083730.mp4      (25MB, 98초)
video_buddha_20260525_083730.mp4   (32.8MB, 2분)
short_buddha_20260525_083730.mp4   (18.5MB, 60초)
```